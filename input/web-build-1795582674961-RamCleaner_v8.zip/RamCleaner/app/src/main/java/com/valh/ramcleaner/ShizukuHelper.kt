package com.valh.ramcleaner

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

object Storage {
    fun freeBytes(): Long = StatFs(Environment.getDataDirectory().path).availableBytes
    fun totalBytes(): Long = StatFs(Environment.getDataDirectory().path).totalBytes
}

object ShizukuHelper {
    const val SHIZUKU_PKG = "moe.shizuku.privileged.api"
    const val START_CMD = "adb shell sh /storage/emulated/0/Android/data/moe.shizuku.privileged.api/start.sh"

    fun isRunning(): Boolean = try { Shizuku.pingBinder() } catch (_: Throwable) { false }

    fun hasPermission(): Boolean = try {
        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (_: Throwable) { false }

    /** true nếu người dùng đã từ chối và chọn không hỏi lại. */
    fun deniedForever(): Boolean = try {
        Shizuku.shouldShowRequestPermissionRationale()
    } catch (_: Throwable) { false }

    fun requestPermission() {
        try { Shizuku.requestPermission(1001) } catch (_: Throwable) { }
    }

    fun isInstalled(ctx: Context): Boolean = try {
        ctx.packageManager.getPackageInfo(SHIZUKU_PKG, 0); true
    } catch (_: Throwable) { false }

    fun openShizuku(ctx: Context): Boolean {
        val i = ctx.packageManager.getLaunchIntentForPackage(SHIZUKU_PKG) ?: return false
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try { ctx.startActivity(i); true } catch (_: Throwable) { false }
    }

    fun openInstallPage(ctx: Context) {
        try {
            ctx.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/RikkaApps/Shizuku/releases"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (_: Throwable) { }
    }

    fun openDevSettings(ctx: Context) {
        try {
            ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Throwable) {
            try { ctx.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Throwable) { }
        }
    }

    fun usbDebugOn(ctx: Context): Boolean = try {
        Settings.Global.getInt(ctx.contentResolver, Settings.Global.ADB_ENABLED, 0) == 1
    } catch (_: Throwable) { false }

    fun wifiDebugOn(ctx: Context): Boolean = try {
        Settings.Global.getInt(ctx.contentResolver, "adb_wifi_enabled", 0) == 1
    } catch (_: Throwable) { false }

    /** Chạy lệnh shell với quyền shell (UID 2000) thông qua Shizuku. Trả về (mã thoát, đầu ra). */
    suspend fun exec(cmd: String): Pair<Int, String> = withContext(Dispatchers.IO) {
        try {
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java, Array<String>::class.java, String::class.java
            )
            m.isAccessible = true
            val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
            val out = p.inputStream.bufferedReader().readText()
            val err = p.errorStream.bufferedReader().readText()
            p.waitFor() to (out + err).trim()
        } catch (e: Throwable) {
            -1 to (e.cause?.message ?: e.message ?: "Không chạy được lệnh")
        }
    }
}
