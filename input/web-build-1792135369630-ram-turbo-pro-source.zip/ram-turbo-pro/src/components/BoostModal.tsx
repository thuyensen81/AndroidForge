import { useEffect, useState } from 'react';
import { BoostResult } from '../types';
import { CheckCircle2, Zap, Cpu, Sparkles, Layers, ShieldCheck, X, Terminal, Copy, Check } from 'lucide-react';
import { soundFX } from '../utils/audio';

interface BoostModalProps {
  isOpen: boolean;
  onClose: () => void;
  result: BoostResult | null;
  language: 'vi' | 'en';
}

export function BoostModal({ isOpen, onClose, result, language }: BoostModalProps) {
  const [step, setStep] = useState<number>(0);
  const [progress, setProgress] = useState<number>(0);
  const [isFinished, setIsFinished] = useState<boolean>(false);

  const stepsVi = [
    { title: 'Quét bảng trang nhớ và giải phóng heap bộ nhớ DVM/ART...', cmd: 'cmd activity trim-memory all RUNNING_CRITICAL', icon: Layers },
    { title: 'Vô hiệu hóa tiến trình ma và các nhánh phụ ngầm (Phantom Killer)...', cmd: 'device_config put activity_manager max_phantom_processes 2147483647', icon: ShieldCheck },
    { title: 'Thu gọn và nén bộ nhớ đệm zRAM swap...', cmd: 'echo 1 > /sys/block/zram0/compact && sysctl -w vm.swappiness=60', icon: Zap },
    { title: 'Xả sạch page cache và dồn các khối nhớ phân mảnh...', cmd: 'echo 3 > /proc/sys/vm/drop_caches && echo 1 > /proc/sys/vm/compact_memory', icon: Sparkles },
  ];

  const stepsEn = [
    { title: 'Trimming runtime heap allocations and background cache...', cmd: 'cmd activity trim-memory all RUNNING_CRITICAL', icon: Layers },
    { title: 'Disabling rogue child forks via Phantom Process Killer...', cmd: 'device_config put activity_manager max_phantom_processes 2147483647', icon: ShieldCheck },
    { title: 'Compacting & compressing zRAM swap buffer blocks...', cmd: 'echo 1 > /sys/block/zram0/compact && sysctl -w vm.swappiness=60', icon: Zap },
    { title: 'Flushing page caches & compacting contiguous memory frames...', cmd: 'echo 3 > /proc/sys/vm/drop_caches && echo 1 > /proc/sys/vm/compact_memory', icon: Sparkles },
  ];

  const steps = language === 'vi' ? stepsVi : stepsEn;

  useEffect(() => {
    if (!isOpen) {
      setStep(0);
      setProgress(0);
      setIsFinished(false);
      return;
    }

    // Play whoosh
    soundFX.playWhoosh();

    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsFinished(true);
          soundFX.playBoostComplete();
          return 100;
        }
        const next = prev + 5;
        if (next >= 75) setStep(3);
        else if (next >= 50) setStep(2);
        else if (next >= 25) setStep(1);
        else setStep(0);
        return next;
      });
    }, 45);

    return () => clearInterval(interval);
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="w-full max-w-md bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950 border border-emerald-500/30 rounded-3xl p-6 shadow-2xl relative overflow-hidden">
        {/* Decorative corner glows */}
        <div className="absolute top-0 right-0 w-40 h-40 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-40 h-40 bg-cyan-500/10 rounded-full blur-2xl pointer-events-none" />

        {!isFinished ? (
          // In-Progress Animation
          <div className="flex flex-col items-center text-center py-6">
            <div className="relative w-24 h-24 mb-5 flex items-center justify-center">
              <div className="absolute inset-0 rounded-full border-4 border-slate-800" />
              <div
                className="absolute inset-0 rounded-full border-4 border-t-emerald-400 border-r-cyan-400 border-b-transparent border-l-transparent animate-spin"
                style={{ animationDuration: '0.8s' }}
              />
              <div className="w-16 h-16 rounded-full bg-emerald-500/20 flex items-center justify-center text-emerald-400">
                <Zap size={30} className="animate-pulse" />
              </div>
            </div>

            <h3 className="text-xl font-bold text-white mb-1">
              {language === 'vi' ? 'Đang Tăng Tốc RAM Chuyên Sâu...' : 'Boosting System Memory...'}
            </h3>
            <p className="text-xs text-slate-400 mb-6 font-mono">
              {language === 'vi' ? 'Tiến độ: ' : 'Progress: '}
              <span className="text-cyan-400 font-bold">{progress}%</span>
            </p>

            {/* Stepper Display */}
            <div className="w-full space-y-2.5 text-left mb-4">
              {steps.map((st, idx) => {
                const Icon = st.icon;
                const isActive = step === idx;
                const isPassed = step > idx;
                return (
                  <div
                    key={idx}
                    className={`flex items-center gap-3 p-2.5 rounded-xl border text-xs transition-all ${
                      isActive
                        ? 'bg-emerald-500/10 border-emerald-500/40 text-emerald-300'
                        : isPassed
                        ? 'bg-slate-800/40 border-slate-800 text-slate-400'
                        : 'bg-transparent border-transparent text-slate-600'
                    }`}
                  >
                    <div
                      className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold shrink-0 ${
                        isPassed
                          ? 'bg-emerald-500 text-black'
                          : isActive
                          ? 'bg-cyan-500 text-black animate-pulse'
                          : 'bg-slate-800 text-slate-500'
                      }`}
                    >
                      {isPassed ? <CheckCircle2 size={13} /> : idx + 1}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1.5">
                        <Icon size={13} className={isActive ? 'text-emerald-400' : 'text-slate-500'} />
                        <span className="truncate font-semibold text-white">{st.title}</span>
                      </div>
                      <div className="text-[10px] font-mono text-cyan-400/90 truncate mt-0.5">
                        <span className="text-slate-600 mr-1">$</span>
                        {st.cmd}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Progress bar */}
            <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
              <div
                className="bg-gradient-to-r from-emerald-400 to-cyan-400 h-full rounded-full transition-all duration-150"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
        ) : (
          // Completion View
          <div className="flex flex-col items-center text-center py-4">
            <button
              onClick={() => {
                soundFX.playTap();
                onClose();
              }}
              className="absolute top-4 right-4 p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition"
            >
              <X size={18} />
            </button>

            <div className="w-16 h-16 rounded-full bg-emerald-500/20 border-2 border-emerald-400 flex items-center justify-center text-emerald-400 mb-4 animate-bounce">
              <CheckCircle2 size={36} />
            </div>

            <h3 className="text-2xl font-black text-white tracking-tight mb-1">
              {language === 'vi' ? 'TĂNG TỐC HOÀN TẤT!' : 'BOOST COMPLETED!'}
            </h3>
            <p className="text-xs text-slate-400 mb-6">
              {language === 'vi'
                ? 'Hệ thống bộ nhớ đã được dọn sạch và tối ưu hóa tối đa.'
                : 'Memory subsystem has been fully streamlined and compacted.'}
            </p>

            {/* Result Stats Cards */}
            <div className="grid grid-cols-2 gap-3 w-full mb-6">
              <div className="p-3 rounded-2xl bg-slate-800/60 border border-slate-700/60 text-left">
                <div className="text-[11px] text-slate-400 mb-1">
                  {language === 'vi' ? 'RAM Giải Phóng' : 'RAM Freed'}
                </div>
                <div className="text-xl font-bold font-mono text-emerald-400">
                  +{result?.freedMb || 2450} <span className="text-xs">MB</span>
                </div>
                <div className="text-[10px] text-slate-500 mt-0.5">
                  ~{(((result?.freedMb || 2450) / 1024)).toFixed(2)} GB bộ nhớ
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-slate-800/60 border border-slate-700/60 text-left">
                <div className="text-[11px] text-slate-400 mb-1">
                  {language === 'vi' ? 'Tác vụ đã dừng' : 'Apps Closed'}
                </div>
                <div className="text-xl font-bold font-mono text-cyan-400">
                  {result?.appsClosed || 6} <span className="text-xs">tiến trình</span>
                </div>
                <div className="text-[10px] text-slate-500 mt-0.5">
                  {language === 'vi' ? 'Bảo lưu ứng dụng chat' : 'Chat apps preserved'}
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-slate-800/60 border border-slate-700/60 text-left">
                <div className="text-[11px] text-slate-400 mb-1">
                  {language === 'vi' ? 'Thu gọn zRAM' : 'zRAM Compacted'}
                </div>
                <div className="text-xl font-bold font-mono text-violet-400">
                  {result?.zramCompactedMb || 1120} <span className="text-xs">MB</span>
                </div>
                <div className="text-[10px] text-slate-500 mt-0.5">
                  {language === 'vi' ? 'Tỉ lệ nén ZSTD 3:1' : 'ZSTD 3:1 ratio'}
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-slate-800/60 border border-slate-700/60 text-left">
                <div className="text-[11px] text-slate-400 mb-1">
                  {language === 'vi' ? 'Độ trễ phản hồi' : 'App Launch Delay'}
                </div>
                <div className="text-xl font-bold font-mono text-amber-400">
                  -34% <span className="text-xs">ms</span>
                </div>
                <div className="text-[10px] text-slate-500 mt-0.5">
                  {language === 'vi' ? 'Mở app mượt hơn' : 'Instant responsiveness'}
                </div>
              </div>
            </div>

            {/* Executed Shell Command Preview */}
            <div className="w-full p-3 rounded-2xl bg-black border border-slate-800 text-left mb-5">
              <div className="flex items-center justify-between mb-1.5">
                <div className="flex items-center gap-1.5 text-[11px] font-mono text-slate-300">
                  <Terminal size={13} className="text-emerald-400" />
                  <span>{language === 'vi' ? 'Lệnh hạt nhân đã thực thi:' : 'Executed Kernel Command:'}</span>
                </div>
                <button
                  onClick={() => {
                    soundFX.playTap();
                    navigator.clipboard.writeText('echo 3 > /proc/sys/vm/drop_caches && echo 1 > /proc/sys/vm/compact_memory && echo 1 > /sys/block/zram0/compact');
                  }}
                  title="Sao chép lệnh"
                  className="text-[10px] text-cyan-400 hover:text-white flex items-center gap-1 px-1.5 py-0.5 rounded bg-slate-900 border border-slate-700 transition"
                >
                  <Copy size={11} />
                  <span>Copy</span>
                </button>
              </div>
              <div className="text-[10px] font-mono text-cyan-300 bg-slate-950 p-2 rounded-xl border border-slate-900 overflow-x-auto select-all">
                # echo 3 &gt; /proc/sys/vm/drop_caches &amp;&amp; echo 1 &gt; /proc/sys/vm/compact_memory &amp;&amp; echo 1 &gt; /sys/block/zram0/compact
              </div>
            </div>

            {/* Done button */}
            <button
              onClick={() => {
                soundFX.playTap();
                onClose();
              }}
              className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-bold text-sm tracking-wide shadow-lg shadow-emerald-500/20 transition-all transform active:scale-95"
            >
              {language === 'vi' ? 'HOÀN TẤT & ĐÓNG' : 'DONE & RETURN'}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
