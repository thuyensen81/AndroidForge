import { useState } from 'react';
import { LmkMode, TurboGamePackage, AppProcess } from '../../types';
import {
  Flame,
  ShieldAlert,
  Zap,
  Trophy,
  Check,
  Plus,
  Edit2,
  Trash2,
  X,
  Package,
  RotateCcw,
  Sparkles,
  Layers,
  ArrowRight,
  Terminal,
  Copy
} from 'lucide-react';
import { soundFX } from '../../utils/audio';

interface GameTurboTabProps {
  gameTurboActive: boolean;
  onToggleGameTurbo: () => void;
  selectedGameId: string | null;
  onSelectGame: (id: string) => void;
  gamesList: TurboGamePackage[];
  onAddCustomGame: (game: TurboGamePackage) => void;
  onUpdateGame: (game: TurboGamePackage) => void;
  onDeleteGame: (id: string) => void;
  onRestoreDefaultGames: () => void;
  installedProcesses: AppProcess[];
  lmkMode: LmkMode;
  onSetLmkMode: (mode: LmkMode) => void;
  language: 'vi' | 'en';
}

const EMOJI_OPTIONS = ['🎮', '⚔️', '🔥', '🎯', '✨', '🏆', '🏎️', '⚡', '🚀', '👾', '👑', '🛡️'];

export function GameTurboTab({
  gameTurboActive,
  onToggleGameTurbo,
  selectedGameId,
  onSelectGame,
  gamesList,
  onAddCustomGame,
  onUpdateGame,
  onDeleteGame,
  onRestoreDefaultGames,
  installedProcesses,
  lmkMode,
  onSetLmkMode,
  language,
}: GameTurboTabProps) {
  // Modal State for Adding / Editing Package
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingGameId, setEditingGameId] = useState<string | null>(null);

  // Form State
  const [formPackageName, setFormPackageName] = useState('');
  const [formName, setFormName] = useState('');
  const [formIcon, setFormIcon] = useState('🎮');
  const [formRamGb, setFormRamGb] = useState<number>(4);
  const [formFps, setFormFps] = useState<number>(120);
  const [formError, setFormError] = useState<string | null>(null);

  const currentGame =
    gamesList.find((g) => g.id === selectedGameId || g.packageName === selectedGameId) ||
    gamesList[0];

  // Open modal to add new package
  const handleOpenAddModal = () => {
    soundFX.playTap();
    setEditingGameId(null);
    setFormPackageName('');
    setFormName('');
    setFormIcon('🎮');
    setFormRamGb(4);
    setFormFps(120);
    setFormError(null);
    setIsModalOpen(true);
  };

  // Open modal to edit existing package
  const handleOpenEditModal = (game: TurboGamePackage, e: React.MouseEvent) => {
    e.stopPropagation();
    soundFX.playTap();
    setEditingGameId(game.id);
    setFormPackageName(game.packageName);
    setFormName(game.name);
    setFormIcon(game.icon || '🎮');
    setFormRamGb(game.dedicatedRamGb || 4);
    setFormFps(game.targetFps || 120);
    setFormError(null);
    setIsModalOpen(true);
  };

  // Quick select an installed process
  const handleQuickPickApp = (proc: AppProcess) => {
    soundFX.playTap();
    setFormPackageName(proc.packageName);
    setFormName(proc.name);
    setFormError(null);
  };

  // Submit modal form
  const handleSavePackage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formPackageName.trim()) {
      setFormError(language === 'vi' ? 'Vui lòng nhập Package ID (ví dụ: com.game.name)' : 'Please enter a Package ID');
      return;
    }
    if (!formName.trim()) {
      setFormError(language === 'vi' ? 'Vui lòng nhập tên hiển thị của trò chơi / ứng dụng' : 'Please enter a display name');
      return;
    }

    soundFX.playBoostComplete();

    if (editingGameId) {
      // Update
      onUpdateGame({
        id: editingGameId,
        packageName: formPackageName.trim(),
        name: formName.trim(),
        icon: formIcon,
        dedicatedRamGb: formRamGb,
        targetFps: formFps,
        isCustom: true,
      });
    } else {
      // Add new
      const newId = `custom-${Date.now()}`;
      onAddCustomGame({
        id: newId,
        packageName: formPackageName.trim(),
        name: formName.trim(),
        icon: formIcon,
        dedicatedRamGb: formRamGb,
        targetFps: formFps,
        isCustom: true,
      });
      onSelectGame(newId);
    }

    setIsModalOpen(false);
  };

  return (
    <div className="space-y-5 pb-6">
      {/* Master Game Turbo Banner */}
      <div
        className={`relative overflow-hidden rounded-3xl p-6 border transition-all duration-500 shadow-2xl ${
          gameTurboActive
            ? 'bg-gradient-to-br from-rose-950/80 via-slate-900 to-amber-950/80 border-rose-500/50 shadow-rose-500/20'
            : 'bg-slate-900/60 border-slate-800'
        }`}
      >
        {/* Glow ambient */}
        {gameTurboActive && (
          <div className="absolute -top-10 -right-10 w-48 h-48 bg-rose-500/20 rounded-full blur-3xl pointer-events-none animate-pulse" />
        )}

        <div className="relative z-10">
          <div className="flex items-center justify-between gap-3 mb-4">
            <div className="flex items-center gap-2.5">
              <div
                className={`w-12 h-12 rounded-2xl flex items-center justify-center font-bold text-2xl transition ${
                  gameTurboActive
                    ? 'bg-gradient-to-tr from-rose-500 to-amber-500 text-slate-950 shadow-lg shadow-rose-500/30'
                    : 'bg-slate-800 text-slate-400'
                }`}
              >
                {gameTurboActive ? currentGame?.icon || '🔥' : <Flame size={24} />}
              </div>
              <div>
                <h3 className="text-base font-black text-white tracking-wide uppercase">
                  {language === 'vi' ? 'Game Turbo Pro' : 'RAM Turbo Game Mode'}
                </h3>
                <div className="flex items-center gap-1.5 text-xs">
                  <span
                    className={`font-semibold ${
                      gameTurboActive ? 'text-rose-400 font-mono' : 'text-slate-500'
                    }`}
                  >
                    {gameTurboActive
                      ? language === 'vi'
                        ? `● ĐANG ƯU TIÊN: ${currentGame?.name}`
                        : `● TURBO ACTIVE: ${currentGame?.name}`
                      : language === 'vi'
                      ? 'Chưa kích hoạt'
                      : 'Disabled'}
                  </span>
                </div>
              </div>
            </div>

            {/* Target FPS indicator */}
            <div className="px-3 py-1.5 rounded-xl bg-slate-950/80 border border-slate-800 text-center">
              <div className="text-[9px] text-slate-400 font-mono">TARGET</div>
              <div className="text-sm font-black font-mono text-amber-400">
                {currentGame?.targetFps || 120} FPS
              </div>
            </div>
          </div>

          {/* Active Package Info Card */}
          <div className="p-3.5 rounded-2xl bg-slate-950/70 border border-slate-800 mb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <div className="text-[10px] text-slate-400 font-mono uppercase">
                {language === 'vi' ? 'Package được cấp phát độc quyền:' : 'Dedicated Target Package:'}
              </div>
              <div className="text-xs font-mono font-bold text-cyan-300 truncate max-w-xs mt-0.5">
                {currentGame?.packageName}
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-[11px] font-mono font-bold">
                +{currentGame?.dedicatedRamGb || 4} GB RAM
              </span>
              <span className="px-2 py-0.5 rounded-lg bg-amber-500/10 text-amber-400 border border-amber-500/30 text-[11px] font-mono font-bold">
                {currentGame?.targetFps || 120} FPS
              </span>
            </div>
          </div>

          {/* Dedicated Shell / ADB command preview */}
          <div className="mb-4 p-2.5 rounded-xl bg-slate-950/80 border border-slate-800 flex items-center justify-between gap-2">
            <div className="min-w-0 flex items-center gap-2">
              <Terminal size={12} className="text-rose-400 shrink-0" />
              <div className="text-[10px] font-mono text-slate-300 truncate">
                cmd game set --mode performance {currentGame?.packageName} &amp;&amp; echo -1000 &gt; /proc/$(pidof {currentGame?.packageName})/oom_score_adj
              </div>
            </div>
            <button
              onClick={() => {
                soundFX.playTap();
                navigator.clipboard.writeText(`cmd game set --mode performance ${currentGame?.packageName} && echo -1000 > /proc/$(pidof ${currentGame?.packageName})/oom_score_adj`);
              }}
              title="Sao chép lệnh Game Turbo"
              className="p-1 px-2 rounded-lg bg-slate-900 hover:bg-slate-800 text-[10px] text-cyan-300 border border-slate-700 font-mono transition shrink-0"
            >
              Copy
            </button>
          </div>

          {/* Master Toggle Button */}
          <button
            onClick={() => {
              if (!gameTurboActive) {
                soundFX.playTurbo();
              } else {
                soundFX.playTap();
              }
              onToggleGameTurbo();
            }}
            className={`w-full py-4 rounded-2xl font-black text-xs sm:text-sm tracking-widest uppercase transition-all duration-300 flex items-center justify-center gap-3 shadow-xl cursor-pointer ${
              gameTurboActive
                ? 'bg-slate-800 hover:bg-slate-700 text-rose-400 border border-rose-500/30'
                : 'bg-gradient-to-r from-rose-500 via-red-500 to-amber-500 hover:from-rose-400 hover:to-amber-400 text-slate-950 shadow-rose-500/25 active:scale-98'
            }`}
          >
            <Zap size={18} />
            <span>
              {gameTurboActive
                ? language === 'vi'
                  ? 'TẮT CHẾ ĐỘ GAME TURBO'
                  : 'DISENGAGE GAME TURBO'
                : language === 'vi'
                ? `KÍCH HOẠT GAME TURBO (DÀNH ${currentGame?.dedicatedRamGb || 4}GB RAM)`
                : `ENGAGE GAME TURBO (${currentGame?.dedicatedRamGb || 4}GB RAM)`}
            </span>
          </button>
        </div>
      </div>

      {/* Package Manager Section Header */}
      <div className="bg-slate-900/60 backdrop-blur-md border border-slate-800 rounded-3xl p-5 shadow-lg">
        <div className="flex items-center justify-between gap-3 mb-2">
          <div className="flex items-center gap-2">
            <Trophy size={16} className="text-amber-400" />
            <h4 className="text-sm font-bold text-white uppercase tracking-wider">
              {language === 'vi' ? 'Quản Lý Package Game Tùy Chỉnh' : 'Custom Game & Package Manager'}
            </h4>
          </div>

          <div className="flex items-center gap-2">
            {/* Restore defaults */}
            <button
              onClick={() => {
                soundFX.playTap();
                onRestoreDefaultGames();
              }}
              title={language === 'vi' ? 'Khôi phục danh sách mặc định' : 'Restore default packages'}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition"
            >
              <RotateCcw size={14} />
            </button>

            {/* Add Custom Game Button */}
            <button
              onClick={handleOpenAddModal}
              className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 text-xs font-bold flex items-center gap-1.5 shadow-md shadow-emerald-500/20 active:scale-95 transition"
            >
              <Plus size={15} />
              <span>{language === 'vi' ? 'Thêm Package Mới' : 'Add Custom Package'}</span>
            </button>
          </div>
        </div>

        <p className="text-[11px] text-slate-400 mb-4">
          {language === 'vi'
            ? 'Bạn có thể chỉnh sửa tên package, gán mức RAM riêng (2GB - 8GB), mục tiêu FPS và chọn từ các app đang chạy trên máy.'
            : 'Customize Android package IDs, allocate dedicated RAM buffer (2GB - 8GB), set target FPS, or pick from running apps.'}
        </p>

        {/* List of Game Packages */}
        <div className="space-y-2.5">
          {gamesList.map((game) => {
            const isSelected =
              selectedGameId === game.id ||
              selectedGameId === game.packageName ||
              (!selectedGameId && game.id === gamesList[0].id);

            return (
              <div
                key={game.id}
                onClick={() => {
                  soundFX.playTap();
                  onSelectGame(game.id);
                }}
                className={`p-3.5 rounded-2xl border cursor-pointer transition-all flex items-center justify-between gap-3 ${
                  isSelected
                    ? 'bg-rose-500/10 border-rose-500/50 shadow-md shadow-rose-500/10'
                    : 'bg-slate-950/60 border-slate-800/90 text-slate-400 hover:border-slate-700 hover:bg-slate-900/60'
                }`}
              >
                {/* Left: Icon & Info */}
                <div className="flex items-center gap-3 min-w-0">
                  <div
                    className={`w-11 h-11 rounded-2xl flex items-center justify-center text-2xl shrink-0 border ${
                      isSelected
                        ? 'bg-rose-500/20 border-rose-500/40 text-white'
                        : 'bg-slate-900 border-slate-800'
                    }`}
                  >
                    {game.icon || '🎮'}
                  </div>

                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <h5 className="text-xs font-bold text-white truncate">{game.name}</h5>
                      {game.isCustom && (
                        <span className="text-[9px] px-1.5 py-0.2 rounded bg-cyan-500/15 text-cyan-400 font-mono border border-cyan-500/30">
                          Custom
                        </span>
                      )}
                    </div>

                    <div className="text-[10px] text-slate-400 font-mono truncate mt-0.5 flex items-center gap-2">
                      <span className="text-cyan-400/90 truncate">{game.packageName}</span>
                    </div>

                    <div className="flex items-center gap-2 text-[10px] mt-1 font-mono">
                      <span className="text-emerald-400 font-bold">
                        +{game.dedicatedRamGb || 4}GB RAM
                      </span>
                      <span className="text-slate-600">•</span>
                      <span className="text-amber-400 font-bold">
                        {game.targetFps || 120} FPS
                      </span>
                    </div>
                  </div>
                </div>

                {/* Right: Actions */}
                <div className="flex items-center gap-2 shrink-0">
                  {/* Edit button */}
                  <button
                    onClick={(e) => handleOpenEditModal(game, e)}
                    title={language === 'vi' ? 'Chỉnh sửa package này' : 'Edit package settings'}
                    className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-cyan-300 transition"
                  >
                    <Edit2 size={13} />
                  </button>

                  {/* Delete button (if more than 1 item) */}
                  {gamesList.length > 1 && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        soundFX.playTap();
                        onDeleteGame(game.id);
                      }}
                      title={language === 'vi' ? 'Xoá package này' : 'Delete package'}
                      className="p-2 rounded-xl bg-slate-800/80 hover:bg-rose-500/20 text-slate-400 hover:text-rose-400 transition"
                    >
                      <Trash2 size={13} />
                    </button>
                  )}

                  {/* Selection radio check */}
                  <div
                    className={`w-6 h-6 rounded-full flex items-center justify-center border transition-all ${
                      isSelected
                        ? 'bg-rose-500 border-rose-400 text-slate-950 font-bold shadow-md shadow-rose-500/30'
                        : 'border-slate-700 bg-slate-900/80'
                    }`}
                  >
                    {isSelected && <Check size={13} strokeWidth={3} />}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* LMKd (Low Memory Killer Daemon) Tuning */}
      <div className="bg-slate-900/60 backdrop-blur-md border border-slate-800 rounded-3xl p-5 shadow-lg">
        <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-2 flex items-center gap-2">
          <ShieldAlert size={14} className="text-cyan-400" />
          <span>{language === 'vi' ? 'Cấu Hình LMKd Cho Package Game' : 'LMKd Daemon Profile'}</span>
        </h4>
        <p className="text-[11px] text-slate-400 mb-4">
          {language === 'vi'
            ? 'Thiết lập mức độ ưu tiên tiến trình hạt nhân hệ thống khi chơi game.'
            : 'Controls kernel oom_score_adj thresholds during active gaming sessions.'}
        </p>

        <div className="space-y-2.5">
          {/* Gaming Extreme */}
          <div
            onClick={() => {
              soundFX.playTap();
              onSetLmkMode('extreme_gaming');
            }}
            className={`p-3.5 rounded-2xl border cursor-pointer transition ${
              lmkMode === 'extreme_gaming'
                ? 'bg-rose-500/10 border-rose-500/50 text-rose-300'
                : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700'
            }`}
          >
            <div className="flex items-center justify-between mb-1">
              <span className="font-bold text-xs text-white">
                {language === 'vi' ? 'Gaming Tối Thượng (Extreme Gaming)' : 'Extreme Gaming Profile'}
              </span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-rose-500/20 text-rose-400 font-bold">
                oom_adj: -1000
              </span>
            </div>
            <p className="text-[11px] text-slate-400">
              {language === 'vi'
                ? 'Dành toàn bộ RAM cho package game đã chọn, đóng băng tuyệt đối mọi ứng dụng nền.'
                : 'Allocates maximal physical RAM for the active game, locking out all background tasks.'}
            </p>
          </div>

          {/* Balanced */}
          <div
            onClick={() => {
              soundFX.playTap();
              onSetLmkMode('balanced');
            }}
            className={`p-3.5 rounded-2xl border cursor-pointer transition ${
              lmkMode === 'balanced'
                ? 'bg-emerald-500/10 border-emerald-500/50 text-emerald-300'
                : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700'
            }`}
          >
            <div className="flex items-center justify-between mb-1">
              <span className="font-bold text-xs text-white">
                {language === 'vi' ? 'Cân Bằng Tiêu Chuẩn (Balanced)' : 'Standard Balanced'}
              </span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-bold">
                Default
              </span>
            </div>
            <p className="text-[11px] text-slate-400">
              {language === 'vi'
                ? 'Cân bằng giữa hiệu năng chơi game và thông báo cuộc gọi, tin nhắn.'
                : 'Standard heuristic balancing active app priority with chat notifications.'}
            </p>
          </div>
        </div>
      </div>

      {/* MODAL: Add / Edit Game Package */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
          <div className="w-full max-w-lg bg-slate-900 border border-slate-700 rounded-3xl p-6 shadow-2xl relative max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => {
                soundFX.playTap();
                setIsModalOpen(false);
              }}
              className="absolute top-4 right-4 p-2 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition"
            >
              <X size={18} />
            </button>

            <div className="flex items-center gap-2.5 mb-1">
              <div className="p-2 rounded-xl bg-rose-500/20 text-rose-400">
                <Package size={20} />
              </div>
              <h3 className="text-base font-bold text-white">
                {editingGameId
                  ? language === 'vi'
                    ? 'Chỉnh Sửa Package Game'
                    : 'Edit Game Package'
                  : language === 'vi'
                  ? 'Thêm Package Tùy Chỉnh'
                  : 'Add Custom Game Package'}
              </h3>
            </div>
            <p className="text-xs text-slate-400 mb-5">
              {language === 'vi'
                ? 'Nhập tên gói ứng dụng (package name) để cấp phát bộ nhớ RAM độc quyền khi chơi game.'
                : 'Enter package name to allocate dedicated RAM buffer during gameplay.'}
            </p>

            {/* Quick Pick from Installed Apps */}
            <div className="mb-5 p-3 rounded-2xl bg-slate-950/80 border border-slate-800">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-300 mb-2">
                <Layers size={13} className="text-cyan-400" />
                <span>
                  {language === 'vi'
                    ? 'Chọn nhanh từ ứng dụng đang chạy:'
                    : 'Quick pick from running apps:'}
                </span>
              </div>
              <div className="flex flex-wrap gap-1.5 max-h-28 overflow-y-auto pr-1">
                {installedProcesses.map((p) => (
                  <button
                    type="button"
                    key={p.id}
                    onClick={() => handleQuickPickApp(p)}
                    className="text-[11px] px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700/80 flex items-center gap-1.5 transition truncate max-w-full"
                  >
                    <span className="truncate">{p.name}</span>
                    <span className="text-[9px] text-cyan-400 font-mono">({p.packageName})</span>
                  </button>
                ))}
              </div>
            </div>

            <form onSubmit={handleSavePackage} className="space-y-4">
              {/* Package ID input */}
              <div>
                <label className="block text-xs font-bold text-slate-200 mb-1.5">
                  Package Name / ID <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  value={formPackageName}
                  onChange={(e) => {
                    setFormPackageName(e.target.value);
                    setFormError(null);
                  }}
                  placeholder="e.g. com.activision.callofduty.shooter"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-white font-mono placeholder-slate-600 focus:outline-none focus:border-rose-500 transition"
                />
                <span className="text-[10px] text-slate-500 mt-1 block">
                  {language === 'vi'
                    ? 'Ví dụ: com.garena.game.kgvn, com.miHoYo.GenshinImpact, com.roblox.client'
                    : 'Android unique package identifier'}
                </span>
              </div>

              {/* Game display name */}
              <div>
                <label className="block text-xs font-bold text-slate-200 mb-1.5">
                  {language === 'vi' ? 'Tên Hiển Thị Trò Chơi' : 'Game Display Name'}{' '}
                  <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  value={formName}
                  onChange={(e) => {
                    setFormName(e.target.value);
                    setFormError(null);
                  }}
                  placeholder={language === 'vi' ? 'Ví dụ: Call of Duty Mobile' : 'e.g. Call of Duty Mobile'}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-rose-500 transition"
                />
              </div>

              {/* Emoji / Icon Selector */}
              <div>
                <label className="block text-xs font-bold text-slate-200 mb-1.5">
                  {language === 'vi' ? 'Biểu Tượng (Icon)' : 'Select Icon'}
                </label>
                <div className="flex flex-wrap gap-2">
                  {EMOJI_OPTIONS.map((emoji) => (
                    <button
                      type="button"
                      key={emoji}
                      onClick={() => setFormIcon(emoji)}
                      className={`w-9 h-9 rounded-xl text-lg flex items-center justify-center transition ${
                        formIcon === emoji
                          ? 'bg-rose-500/20 border-2 border-rose-500 scale-110'
                          : 'bg-slate-950 border border-slate-800 hover:border-slate-700'
                      }`}
                    >
                      {emoji}
                    </button>
                  ))}
                </div>
              </div>

              {/* Dedicated RAM Allocation */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-bold text-slate-200">
                    {language === 'vi' ? 'Bộ Nhớ RAM Dành Riêng Cho Game' : 'Dedicated RAM Buffer'}
                  </label>
                  <span className="text-xs font-mono font-bold text-emerald-400">
                    +{formRamGb} GB RAM
                  </span>
                </div>
                <div className="grid grid-cols-4 gap-2">
                  {[2, 4, 6, 8].map((ram) => (
                    <button
                      type="button"
                      key={ram}
                      onClick={() => setFormRamGb(ram)}
                      className={`py-2 rounded-xl text-xs font-bold font-mono transition border ${
                        formRamGb === ram
                          ? 'bg-emerald-500 text-slate-950 border-emerald-400'
                          : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
                      }`}
                    >
                      +{ram} GB
                    </button>
                  ))}
                </div>
              </div>

              {/* Target FPS */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-bold text-slate-200">
                    {language === 'vi' ? 'Mục Tiêu Khung Hình (Target FPS)' : 'Target Framerate'}
                  </label>
                  <span className="text-xs font-mono font-bold text-amber-400">
                    {formFps} FPS
                  </span>
                </div>
                <div className="grid grid-cols-4 gap-2">
                  {[60, 90, 120, 144].map((fps) => (
                    <button
                      type="button"
                      key={fps}
                      onClick={() => setFormFps(fps)}
                      className={`py-2 rounded-xl text-xs font-bold font-mono transition border ${
                        formFps === fps
                          ? 'bg-amber-500 text-slate-950 border-amber-400'
                          : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
                      }`}
                    >
                      {fps} FPS
                    </button>
                  ))}
                </div>
              </div>

              {/* Error message */}
              {formError && (
                <div className="p-2.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs">
                  {formError}
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex items-center gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="flex-1 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition"
                >
                  {language === 'vi' ? 'HỦY' : 'CANCEL'}
                </button>
                <button
                  type="submit"
                  className="flex-1 py-3 rounded-xl bg-gradient-to-r from-rose-500 to-amber-500 hover:from-rose-400 hover:to-amber-400 text-slate-950 font-bold text-xs tracking-wider uppercase transition shadow-lg shadow-rose-500/20 active:scale-95"
                >
                  {editingGameId
                    ? language === 'vi'
                      ? 'LƯU THAY ĐỔI'
                      : 'SAVE CHANGES'
                    : language === 'vi'
                    ? 'THÊM PACKAGE'
                    : 'ADD PACKAGE'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
