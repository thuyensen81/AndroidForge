import { useMemo } from 'react';
import { RAMStats } from '../types';
import { Sparkles, Layers, ShieldCheck, AlertTriangle } from 'lucide-react';

interface RamGaugeProps {
  stats: RAMStats;
  language: 'vi' | 'en';
}

export function RamGauge({ stats, language }: RamGaugeProps) {
  const percentage = useMemo(() => {
    return Math.min(100, Math.max(0, Math.round((stats.usedMb / stats.totalMb) * 100)));
  }, [stats.usedMb, stats.totalMb]);

  const usedGb = (stats.usedMb / 1024).toFixed(1);
  const totalGb = (stats.totalMb / 1024).toFixed(0);
  const freeGb = (stats.freeMb / 1024).toFixed(1);

  // Determine status color scheme
  const statusConfig = useMemo(() => {
    if (percentage < 65) {
      return {
        color: 'from-emerald-400 via-teal-400 to-cyan-500',
        stroke: '#10b981',
        glow: 'rgba(16, 185, 129, 0.35)',
        text: language === 'vi' ? 'Hiệu Suất Tối Ưu' : 'Optimal Performance',
        icon: ShieldCheck,
        badgeClass: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
      };
    } else if (percentage < 85) {
      return {
        color: 'from-amber-400 via-yellow-400 to-orange-500',
        stroke: '#f59e0b',
        glow: 'rgba(245, 158, 11, 0.35)',
        text: language === 'vi' ? 'Bộ Nhớ Trung Bình' : 'Moderate Usage',
        icon: Layers,
        badgeClass: 'bg-amber-500/10 text-amber-400 border-amber-500/30',
      };
    } else {
      return {
        color: 'from-rose-500 via-red-500 to-orange-600',
        stroke: '#f43f5e',
        glow: 'rgba(244, 63, 94, 0.45)',
        text: language === 'vi' ? 'Quá Tải - Cần Tăng Tốc' : 'High Load - Boost Recommended',
        icon: AlertTriangle,
        badgeClass: 'bg-rose-500/10 text-rose-400 border-rose-500/30 animate-pulse',
      };
    }
  }, [percentage, language]);

  // SVG Circular math
  const size = 260;
  const strokeWidth = 16;
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  // Let's create an arc (260 degrees arc for a speed meter feel)
  const arcLength = circumference * 0.75;
  const strokeDashoffset = arcLength - (arcLength * percentage) / 100;

  const StatusIcon = statusConfig.icon;

  return (
    <div className="relative flex flex-col items-center justify-center p-4">
      {/* Glow effect behind gauge */}
      <div
        className="absolute w-56 h-56 rounded-full blur-3xl transition-all duration-700 pointer-events-none opacity-40"
        style={{ backgroundColor: statusConfig.stroke }}
      />

      {/* SVG Radial Meter */}
      <div className="relative w-[240px] h-[240px] flex items-center justify-center">
        <svg
          className="w-full h-full transform -rotate-[135deg]"
          viewBox={`0 0 ${size} ${size}`}
        >
          {/* Defs for gradients */}
          <defs>
            <linearGradient id="gaugeGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#10b981" />
              <stop offset="50%" stopColor="#06b6d4" />
              <stop offset="100%" stopColor="#8b5cf6" />
            </linearGradient>
            <filter id="glowFilter" x="-20%" y="-20%" width="140%" height="140%">
              <feDropShadow dx="0" dy="0" stdDeviation="4" floodColor={statusConfig.stroke} floodOpacity="0.6" />
            </filter>
          </defs>

          {/* Background Track Arc */}
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="none"
            stroke="#1e293b"
            strokeWidth={strokeWidth}
            strokeDasharray={`${arcLength} ${circumference}`}
            strokeLinecap="round"
          />

          {/* Value Progress Arc */}
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="none"
            stroke="url(#gaugeGradient)"
            strokeWidth={strokeWidth}
            strokeDasharray={`${arcLength} ${circumference}`}
            strokeDashoffset={strokeDashoffset}
            strokeLinecap="round"
            filter="url(#glowFilter)"
            className="transition-all duration-700 ease-out"
          />
        </svg>

        {/* Center Content */}
        <div className="absolute inset-0 flex flex-col items-center justify-center text-center select-none pt-4">
          <div className="flex items-baseline justify-center">
            <span className="text-5xl font-black font-mono tracking-tight text-white drop-shadow-md">
              {percentage}
            </span>
            <span className="text-xl font-bold text-emerald-400 font-mono ml-0.5">%</span>
          </div>

          <div className="text-xs text-slate-300 font-medium mt-1 flex items-center gap-1.5">
            <span className="text-cyan-400 font-mono font-semibold">{usedGb} GB</span>
            <span className="text-slate-500">/</span>
            <span className="text-slate-400 font-mono">{totalGb} GB</span>
          </div>

          <div className="mt-2 text-[11px] text-slate-400">
            {language === 'vi' ? 'Trống: ' : 'Free: '}
            <span className="text-emerald-400 font-bold font-mono">{freeGb} GB</span>
          </div>
        </div>
      </div>

      {/* Status Pill Badge */}
      <div className="flex flex-col items-center gap-2 mt-1 z-10">
        <div className={`flex items-center gap-1.5 px-3 py-1 rounded-full border text-xs font-semibold backdrop-blur-md ${statusConfig.badgeClass}`}>
          <StatusIcon size={14} />
          <span>{statusConfig.text}</span>
        </div>

        {/* 16KB Page Mode Micro-Pill */}
        <div className="flex items-center gap-2 text-[11px] text-slate-400">
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-slate-800/80 border border-slate-700/60 text-cyan-300 font-mono">
            <Sparkles size={11} className="text-cyan-400" />
            <span>16KB Page Engine</span>
          </span>
          <span className="text-slate-500">•</span>
          <span className="text-slate-400 font-mono">
            {language === 'vi' ? 'Phân mảnh: ' : 'Frag: '}
            <span className={stats.fragmentationPercent > 20 ? 'text-amber-400' : 'text-emerald-400 font-semibold'}>
              {stats.fragmentationPercent}%
            </span>
          </span>
        </div>
      </div>
    </div>
  );
}
