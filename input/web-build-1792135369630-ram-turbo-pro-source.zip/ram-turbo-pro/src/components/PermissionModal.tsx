import { useState, useEffect } from 'react';
import { Shield, ShieldAlert, CheckCircle2, Code, Terminal, Copy, Check, X, Smartphone, Zap } from 'lucide-react';
import { PermissionState, PermissionMode } from '../types';
import { soundFX } from '../utils/audio';

interface PermissionModalProps {
  isOpen: boolean;
  onClose: () => void;
  permission: PermissionState;
  onUpdatePermission: (newPerm: PermissionState) => void;
  onAddLog: (cmd: string, output: string, type: 'root' | 'adb') => void;
  language: 'vi' | 'en';
}

export function PermissionModal({
  isOpen,
  onClose,
  permission,
  onUpdatePermission,
  onAddLog,
  language,
}: PermissionModalProps) {
  const [selectedTab, setSelectedTab] = useState<'root' | 'shizuku'>('root');
  const [countdown, setCountdown] = useState<number>(10);
  const [copiedAdb, setCopiedAdb] = useState(false);

  useEffect(() => {
    if (!isOpen) return;
    setCountdown(10);
    const timer = setInterval(() => {
      setCountdown((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(timer);
  }, [isOpen]);

  if (!isOpen) return null;

  const handleGrantRoot = () => {
    soundFX.playBoostComplete();
    onUpdatePermission({
      mode: 'root',
      rootGranted: true,
      shizukuActive: false,
      selinuxEnforcing: true,
    });
    onAddLog('su -c "id && which su"', 'uid=0(root) gid=0(root) groups=0(root) context=u:r:magisk:s0\n/system/xbin/su granted', 'root');
    onClose();
  };

  const handleGrantShizuku = () => {
    soundFX.playBoostComplete();
    onUpdatePermission({
      mode: 'shizuku',
      rootGranted: false,
      shizukuActive: true,
      selinuxEnforcing: true,
    });
    onAddLog('shizuku_starter --version', 'Shizuku Server v13.5.4 (ADB mode: port 5555) connection established', 'adb');
    onClose();
  };

  const handleRevoke = () => {
    soundFX.playTap();
    onUpdatePermission({
      mode: 'unauthorized',
      rootGranted: false,
      shizukuActive: false,
      selinuxEnforcing: true,
    });
  };

  const shizukuCmd = 'adb shell sh /sdcard/Android/data/moe.shizuku.privileged.api/start.sh';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div className="w-full max-w-lg bg-slate-950 border border-slate-800 rounded-3xl p-6 shadow-2xl relative overflow-hidden">
        {/* Close Button */}
        <button
          onClick={() => {
            soundFX.playTap();
            onClose();
          }}
          className="absolute top-4 right-4 p-2 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition"
        >
          <X size={18} />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 mb-2">
          <div className="p-2.5 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/30">
            <ShieldAlert size={22} />
          </div>
          <div>
            <h3 className="text-base font-bold text-white">
              {language === 'vi' ? 'Cấp Quyền Hệ Thống & Lệnh' : 'Grant System Privileges'}
            </h3>
            <p className="text-xs text-slate-400">
              {language === 'vi'
                ? 'Để thực thi các lệnh ADB Shell, giải phóng cache và tối ưu hạt nhân RAM, app cần quyền Root hoặc Shizuku'
                : 'Required to execute ADB shell commands, flush memory caches, and apply kernel optimizations'}
            </p>
          </div>
        </div>

        {/* Permission Mode Tabs */}
        <div className="flex items-center gap-2 my-4 p-1 rounded-2xl bg-slate-900 border border-slate-800">
          <button
            onClick={() => {
              soundFX.playTap();
              setSelectedTab('root');
            }}
            className={`flex-1 py-2.5 rounded-xl text-xs font-bold font-mono transition flex items-center justify-center gap-2 ${
              selectedTab === 'root'
                ? 'bg-rose-500 text-slate-950 shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Shield size={14} />
            <span>Root (Magisk / KernelSU)</span>
          </button>

          <button
            onClick={() => {
              soundFX.playTap();
              setSelectedTab('shizuku');
            }}
            className={`flex-1 py-2.5 rounded-xl text-xs font-bold font-mono transition flex items-center justify-center gap-2 ${
              selectedTab === 'shizuku'
                ? 'bg-cyan-500 text-slate-950 shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Code size={14} />
            <span>Shizuku (Không Root)</span>
          </button>
        </div>

        {/* Tab 1: Root Superuser Authorization Prompt */}
        {selectedTab === 'root' && (
          <div className="space-y-4">
            <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 text-left space-y-3 font-mono text-xs">
              <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                <span className="text-slate-400">Target Binary:</span>
                <span className="text-rose-400 font-bold">/system/bin/su</span>
              </div>
              <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                <span className="text-slate-400">App Name:</span>
                <span className="text-white font-bold">RAM Turbo Pro</span>
              </div>
              <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                <span className="text-slate-400">UID:</span>
                <span className="text-cyan-400">10243 (magisk:s0)</span>
              </div>
              <div className="space-y-1">
                <span className="text-slate-400 block">Quyền hạn truy cập:</span>
                <ul className="text-[11px] text-slate-300 space-y-1 list-disc pl-4 font-sans">
                  <li>Thực thi lệnh ADB Shell <code className="text-cyan-300 font-mono">cmd activity trim-memory</code></li>
                  <li>Ghi tham số hạt nhân <code className="text-cyan-300 font-mono">/proc/sys/vm/compact_memory</code></li>
                  <li>Cấu hình kích thước zRAM swap trên chip nhớ</li>
                </ul>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={handleRevoke}
                className="flex-1 py-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-400 font-bold text-xs transition"
              >
                {language === 'vi' ? 'TỪ CHỐI (DENY)' : 'DENY'}
              </button>

              <button
                onClick={handleGrantRoot}
                className="flex-1 py-3 rounded-xl bg-gradient-to-r from-rose-500 to-amber-500 hover:from-rose-400 hover:to-amber-400 text-slate-950 font-black text-xs tracking-wider uppercase shadow-lg shadow-rose-500/20 active:scale-95 transition flex items-center justify-center gap-1.5"
              >
                <Zap size={14} />
                <span>{language === 'vi' ? `CẤP QUYỀN ROOT (${countdown}s)` : `GRANT SU (${countdown}s)`}</span>
              </button>
            </div>
          </div>
        )}

        {/* Tab 2: Shizuku Authorization Prompt */}
        {selectedTab === 'shizuku' && (
          <div className="space-y-4">
            <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 text-left space-y-3 text-xs">
              <div className="flex items-center gap-2 text-cyan-400 font-bold">
                <Smartphone size={16} />
                <span>
                  {language === 'vi'
                    ? 'Chạy quyền ADB cấp cao không cần Root máy'
                    : 'Elevated ADB Privileges without Root'}
                </span>
              </div>
              <p className="text-slate-300 text-[11px] leading-relaxed">
                {language === 'vi'
                  ? 'Bật "Gỡ lỗi không dây (Wireless Debugging)" trong Cài đặt nhà phát triển, sau đó mở app Shizuku hoặc chạy lệnh ADB sau:'
                  : 'Enable Wireless Debugging in Developer Options and start Shizuku service via ADB:'}
              </p>

              {/* Copyable ADB Command */}
              <div className="p-2.5 rounded-xl bg-black border border-slate-800 font-mono text-[11px] text-cyan-300 flex items-center justify-between gap-2">
                <span className="truncate select-all">{shizukuCmd}</span>
                <button
                  onClick={() => {
                    soundFX.playTap();
                    navigator.clipboard.writeText(shizukuCmd);
                    setCopiedAdb(true);
                    setTimeout(() => setCopiedAdb(false), 2000);
                  }}
                  className="px-2 py-1 rounded bg-slate-800 text-[10px] text-cyan-400 hover:text-white flex items-center gap-1 shrink-0"
                >
                  {copiedAdb ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                  <span>{copiedAdb ? 'Copied' : 'Copy'}</span>
                </button>
              </div>

              <div className="text-[11px] text-emerald-400 flex items-center gap-1.5 font-mono">
                <CheckCircle2 size={13} />
                <span>
                  {language === 'vi'
                    ? 'Hỗ trợ thực thi lệnh tối ưu ADB & Kernel an toàn 100%'
                    : '100% Safe ADB Shell & Kernel execution'}
                </span>
              </div>
            </div>

            <button
              onClick={handleGrantShizuku}
              className="w-full py-3.5 rounded-xl bg-gradient-to-r from-cyan-500 to-teal-500 hover:from-cyan-400 hover:to-teal-400 text-slate-950 font-black text-xs tracking-wider uppercase shadow-lg shadow-cyan-500/20 active:scale-95 transition flex items-center justify-center gap-2"
            >
              <Code size={15} />
              <span>
                {language === 'vi'
                  ? 'KẾT NỐI VÀ CẤP QUYỀN SHIZUKU'
                  : 'CONNECT & AUTHORIZE SHIZUKU'}
              </span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
