# RAM Turbo Pro - Tăng Tốc & Tối Ưu RAM Chuyên Sâu (Android)

Ứng dụng web mô phỏng và công cụ điều khiển tối ưu bộ nhớ RAM chuyên sâu cho các thiết bị Android, hỗ trợ các vi xử lý flagship hiện đại (Snapdragon 8 Elite, Tensor, Exynos...) và các lệnh ADB Shell & Kernel thực tế thông qua Root (Magisk/KernelSU) hoặc Shizuku.

## 🚀 Tính Năng Chính

- **Kiến Trúc Trang Nhớ 16KB**: Tối ưu hoá bộ nhớ thế hệ mới với kích thước trang 16KB (16,384 bytes), giảm 42% TLB miss và tăng thông lượng LPDDR5X.
- **Hồ Sơ Thiết Bị Flagship**: Bổ sung sẵn các dòng máy Snapdragon 8 Elite RAM khủng (16GB - 24GB): OnePlus 13, iQOO 13, Vivo X200 Ultra, Honor Magic 7 RSR, Xiaomi 15 Ultra, ROG Phone 9 Pro... cùng hiển thị động theo phiên bản Android (Android 13 API 33, Android 14 API 34, Android 15 API 35, Android 16 DP API 36).
- **Bộ Quản Lý Tiến Trình (Process Manager)**: Theo dõi bộ nhớ Dalvik/ART của các app (Genshin Impact, TikTok, Facebook...), hỗ trợ đóng băng (freeze), whitelist và dọn dẹp bộ nhớ đệm.
- **RAM Ảo & zRAM Compaction**: Tùy chỉnh kích thước hoán đổi swap (4GB - 16GB), thuật toán nén siêu mật độ LZ4 / ZSTD / LZO-RLE và tỉ lệ `vm.swappiness`.
- **Game Turbo Extreme**: Dành riêng bộ nhớ liên tục không phân mảnh cho game, tối ưu tần số quét màn hình 120Hz và ghim độ ưu tiên `oom_score_adj=-1000`.
- **Bảng Lệnh ADB Shell & Terminal Console**: Tạo kịch bản master shell script (`.sh`), chạy và sao chép các lệnh `cmd activity trim-memory`, `echo 3 > /proc/sys/vm/drop_caches`, `compact_memory`, `device_config put activity_manager max_phantom_processes`.
- **Cấp Quyền Hệ Thống**: Hộp thoại hướng dẫn và cấp quyền Root & Shizuku chuyên nghiệp.
- **Âm Thanh & Xúc Giác**: Web Audio SFX sống động khi tương tác và tăng tốc.

## 🛠️ Hướng Dẫn Cài Đặt & Chạy

Yêu cầu: [Node.js](https://nodejs.org/) v18+ trở lên.

1. Giải nén file ZIP:
```bash
unzip ram-turbo-pro-source.zip
cd ram-turbo-pro
```

2. Cài đặt các gói phụ thuộc (Dependencies):
```bash
npm install
```

3. Khởi chạy máy chủ phát triển (Development Server):
```bash
npm run dev
```
Mở trình duyệt tại địa chỉ `http://localhost:3000` (hoặc cổng hiển thị trong terminal).

4. Đóng gói cho môi trường Production:
```bash
npm run build
```
Thư mục `dist/` sẽ chứa toàn bộ mã nguồn đã được build tối ưu.

## 📁 Cấu Trúc Thư Mục

```text
├── src/
│   ├── components/         # Các thành phần giao diện (Tabs, Gauge, Status Bar, Modals)
│   │   ├── Tabs/           # QuickBoost, ProcessManager, VirtualRam, GameTurbo, Benchmark, Settings
│   │   ├── AndroidStatusBar.tsx
│   │   ├── BoostModal.tsx
│   │   ├── CommandConsoleModal.tsx
│   │   ├── PermissionModal.tsx
│   │   ├── RamGauge.tsx
│   │   └── Navigation.tsx
│   ├── types/              # Định nghĩa kiểu dữ liệu TypeScript
│   ├── utils/              # Mock data, Audio engine, Tính toán RAM, Đa ngôn ngữ (VI/EN)
│   ├── App.tsx             # Giao diện chính và luồng xử lý ứng dụng
│   ├── main.tsx            # Điểm khởi chạy React
│   └── index.css           # Cấu hình Tailwind CSS và font chữ
├── index.html              # HTML entry point
├── package.json
├── tsconfig.json
├── vite.config.ts
└── README.md
```

## 📜 Giấy Phép
Dự án được phân phối dưới giấy phép MIT.
