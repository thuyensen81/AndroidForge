exec 2>/dev/null
setv() {
  k=$1; f=$2; v=$3
  [ -w "$f" ] || return
  eval "$k=1"
  s=/data/local/tmp/mp_$(echo "$f" | tr / _)
  [ -f "$s" ] || cat "$f" > "$s"
  if [ "$v" = default ]; then cat "$s" > "$f"; else echo "$v" > "$f"; fi
}
cpu=0; gpu=0
for f in /sys/devices/system/cpu/cpufreq/policy*/scaling_governor; do
  setv cpu "$f" @GOV@
done
for d in /sys/devices/system/cpu/cpufreq/policy*; do
  if [ "@MAXMIN@" = 1 ]; then setv cpu "$d/scaling_min_freq" "$(cat $d/cpuinfo_max_freq)"
  else setv cpu "$d/scaling_min_freq" default; fi
done
for f in /sys/class/kgsl/kgsl-3d0/devfreq/governor /sys/class/devfreq/*mali*/governor /sys/class/devfreq/*gpu*/governor; do
  setv gpu "$f" @GOV@
done
settings put global low_power @SAVER@
cmd power set-fixed-performance-mode-enabled @PERF@
[ "@KILL@" = 1 ] && am kill-all
for p in $(pm list packages -3 | cut -d: -f2); do cmd game mode @GAME@ "$p"; done >/dev/null
echo "cpu=$cpu gpu=$gpu"
