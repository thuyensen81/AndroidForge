package com.monsterplus

import android.app.ActivityManager
import android.content.*
import android.os.BatteryManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import rikka.shizuku.Shizuku
import kotlinx.coroutines.delay

// ---------- Chế độ hiệu suất ----------
enum class Mode(
    val title: String, val sub: String, val level: Float,
    val c1: Color, val c2: Color, val governor: String
) {
    ECO("Eco", "Tiết kiệm pin tối đa", .15f, Color(0xFF34D399), Color(0xFF10B981), "powersave"),
    BALANCED("Cân bằng", "Mượt mà và bền pin mỗi ngày", .38f, Color(0xFF60A5FA), Color(0xFF3B82F6), "default"),
    MONSTER("Monster", "Hiệu năng cao cho game và đa nhiệm", .62f, Color(0xFFFBBF24), Color(0xFFF97316), "default"),
    PLUS("Monster+", "Ép xung nhẹ, ưu tiên khung hình", .82f, Color(0xFFF472B6), Color(0xFFD946EF), "performance"),
    EXTREME("Monster Extreme", "Toàn bộ sức mạnh, máy sẽ nóng", 1f, Color(0xFFFB7185), Color(0xFF7C3AED), "performance")
}

// ---------- Engine áp dụng chế độ (qua Shizuku) ----------
object PerformanceEngine {
    /** 0 = Shizuku chưa chạy, 1 = chưa cấp quyền, 2 = sẵn sàng */
    fun state(): Int = runCatching {
        if (!Shizuku.pingBinder()) 0
        else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) 2 else 1
    }.getOrDefault(0)

    fun requestPermission() { runCatching { Shizuku.requestPermission(1) } }

    private fun sh(script: String): String = runCatching {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        )
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", script), null, null) as Process
        val out = p.inputStream.bufferedReader().readText()
        p.waitFor(); out
    }.getOrDefault("")

    /** Chạy tune.sh, trả về chuỗi mô tả CPU/GPU có đổi được hay không. */
    fun apply(ctx: Context, m: Mode, onResult: (String) -> Unit) {
        val gov = when (m) { Mode.ECO -> "powersave"; Mode.PLUS, Mode.EXTREME -> "performance"; else -> "default" }
        val game = when (m) { Mode.ECO -> "battery"; Mode.BALANCED -> "standard"; else -> "performance" }
        val script = ctx.resources.openRawResource(R.raw.tune).bufferedReader().readText()
            .replace("@GOV@", gov).replace("@GAME@", game)
            .replace("@MAXMIN@", if (m == Mode.EXTREME) "1" else "0")
            .replace("@SAVER@", if (m == Mode.ECO) "1" else "0")
            .replace("@KILL@", if (m == Mode.ECO) "1" else "0")
            .replace("@PERF@", (m == Mode.PLUS || m == Mode.EXTREME).toString())
        Thread {
            val out = sh(script)
            fun ok(k: String) = if (out.contains("$k=1")) "đã áp dụng" else "máy chặn"
            onResult(if (out.isBlank()) "Không chạy được lệnh" else "CPU: ${ok("cpu")} · GPU: ${ok("gpu")}")
        }.start()
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { MonsterApp(this) }
    }
}

// ---------- Giao diện ----------
@Composable
fun MonsterApp(act: ComponentActivity) {
    var dark by remember { mutableStateOf(true) }
    var mode by remember { mutableStateOf(Mode.BALANCED) }
    var shown by remember { mutableStateOf(false) }
    val haptic = LocalHapticFeedback.current
    val ctx = LocalContext.current

    val bg by animateColorAsState(if (dark) Color(0xFF0A0C12) else Color(0xFFF1F4FA), tween(500), label = "bg")
    val card = if (dark) Color(0xFF161922) else Color.White
    val ink = if (dark) Color(0xFFF3F5FA) else Color(0xFF12151C)
    val soft = if (dark) Color(0xFF9AA1B2) else Color(0xFF6B7280)

    LaunchedEffect(Unit) { shown = true }
    var sz by remember { mutableStateOf(0) }
    var tune by remember { mutableStateOf("") }
    LaunchedEffect(mode, sz) { if (sz == 2) PerformanceEngine.apply(ctx, mode) { tune = it } }

    // Số liệu pin / RAM cập nhật mỗi 2 giây
    var battery by remember { mutableStateOf(0) }
    var temp by remember { mutableStateOf(0f) }
    var ram by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) {
            val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            battery = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
            temp = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
            sz = PerformanceEngine.state()
            val mi = ActivityManager.MemoryInfo()
            (ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
            ram = (100 * (mi.totalMem - mi.availMem) / mi.totalMem).toInt()
            kotlinx.coroutines.delay(2000)
        }
    }

    Box(Modifier.fillMaxSize().background(bg)) {
        // Nền hào quang đổi màu theo chế độ
        val glow by animateColorAsState(mode.c1.copy(alpha = if (dark) .22f else .28f), tween(700), label = "glow")
        Box(Modifier.fillMaxWidth().height(420.dp).background(Brush.verticalGradient(listOf(glow, Color.Transparent))))

        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                .statusBarsPadding().navigationBarsPadding().padding(horizontal = 20.dp)
        ) {
            Row(Modifier.fillMaxWidth().padding(top = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Monster+", color = ink, fontSize = 34.sp, fontWeight = FontWeight.Black)
                    Text("Trung tâm hiệu suất", color = soft, fontSize = 14.sp)
                }
                ThemeToggle(dark, card, ink) { dark = !dark; haptic.performHapticFeedback(HapticFeedbackType.LongPress) }
            }

            ShizukuChip(sz, card, ink) { PerformanceEngine.requestPermission() }
            if (tune.isNotEmpty() && sz == 2) Text(tune, color = soft, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp, start = 6.dp))
            Spacer(Modifier.height(4.dp))
            Orb(mode, ink, soft)
            Spacer(Modifier.height(8.dp))

            // Thẻ thông số
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Stat("Pin", "$battery%", card, ink, soft, Modifier.weight(1f))
                Stat("Nhiệt độ", "%.1f°".format(temp), card, ink, soft, Modifier.weight(1f))
                Stat("RAM", "$ram%", card, ink, soft, Modifier.weight(1f))
            }
            Spacer(Modifier.height(20.dp))
            Text("Chế độ", color = ink, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))

            Mode.values().forEachIndexed { i, m ->
                AnimatedVisibility(
                    visible = shown,
                    enter = fadeIn(tween(450, 120 + i * 80)) +
                        slideInVertically(spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessLow)) { it / 2 }
                ) {
                    ModeCard(m, m == mode, card, ink, soft) {
                        mode = m; haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    }
                }
                Spacer(Modifier.height(12.dp))
            }
            Text(
                "Cần bật Shizuku. CPU/GPU chỉ đổi được nếu máy cho phép ghi vào hệ thống.",
                color = soft, fontSize = 12.sp, textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp)
            )
        }
    }
}

@Composable
fun Orb(mode: Mode, ink: Color, soft: Color) {
    val c1 by animateColorAsState(mode.c1, tween(700), label = "c1")
    val c2 by animateColorAsState(mode.c2, tween(700), label = "c2")
    val level by animateFloatAsState(mode.level, spring(Spring.DampingRatioLowBouncy, Spring.StiffnessVeryLow), label = "lv")
    val inf = rememberInfiniteTransition(label = "orb")
    val spin by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(6000, easing = LinearEasing)), label = "spin")
    val pulse by inf.animateFloat(.94f, 1.06f, infiniteRepeatable(tween(1600, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse")

    Box(Modifier.fillMaxWidth().height(290.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(260.dp)) {
            val r = size.minDimension / 2
            drawCircle(Brush.radialGradient(listOf(c1.copy(.45f), Color.Transparent), radius = r * 1.25f * pulse))
            drawCircle(c1.copy(.12f), radius = r * .78f, style = Stroke(26f))
            rotate(spin) {
                drawArc(
                    Brush.sweepGradient(listOf(c1, c2, c1)), -90f, 360f * level, false,
                    topLeft = Offset(r * .22f, r * .22f), size = Size(r * 1.56f, r * 1.56f),
                    style = Stroke(26f, cap = StrokeCap.Round)
                )
            }
            drawCircle(Brush.linearGradient(listOf(c1, c2)), radius = r * .52f * pulse)
        }
        AnimatedContent(
            targetState = mode,
            transitionSpec = { (fadeIn(tween(350)) + scaleIn(initialScale = .8f)) togetherWith fadeOut(tween(200)) },
            label = "title"
        ) { m ->
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("${(m.level * 100).toInt()}", color = Color.White, fontSize = 44.sp, fontWeight = FontWeight.Black)
                Text(m.title, color = Color.White.copy(.9f), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
fun ModeCard(m: Mode, selected: Boolean, card: Color, ink: Color, soft: Color, onClick: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) .96f else 1f, spring(Spring.DampingRatioMediumBouncy), label = "s")
    val shape = RoundedCornerShape(28.dp)
    val bg = if (selected) Modifier.background(Brush.linearGradient(listOf(m.c1, m.c2)), shape) else Modifier.background(card, shape)
    val fg = if (selected) Color.White else ink

    Row(
        Modifier.fillMaxWidth().scale(scale).clip(shape).then(bg)
            .clickable(src, null, onClick = onClick).padding(18.dp).animateContentSize(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(46.dp).background(if (selected) Color.White.copy(.25f) else m.c1.copy(.18f), CircleShape), Alignment.Center) {
            Box(Modifier.size(16.dp).background(if (selected) Color.White else m.c1, CircleShape))
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(m.title, color = fg, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            Text(m.sub, color = if (selected) Color.White.copy(.85f) else soft, fontSize = 13.sp)
        }
        AnimatedVisibility(selected, enter = scaleIn(spring(Spring.DampingRatioMediumBouncy)), exit = scaleOut()) {
            Text("✓", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
fun Stat(label: String, value: String, card: Color, ink: Color, soft: Color, mod: Modifier) {
    Column(mod.background(card, RoundedCornerShape(22.dp)).padding(vertical = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        AnimatedContent(value, transitionSpec = { slideInVertically { it } + fadeIn() togetherWith slideOutVertically { -it } + fadeOut() }, label = "v") {
            Text(it, color = ink, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        Text(label, color = soft, fontSize = 12.sp)
    }
}

@Composable
fun ThemeToggle(dark: Boolean, card: Color, ink: Color, onClick: () -> Unit) {
    val x by animateDpAsState(if (dark) 30.dp else 0.dp, spring(Spring.DampingRatioMediumBouncy), label = "x")
    Box(Modifier.width(66.dp).height(36.dp).clip(CircleShape).background(card).clickable(onClick = onClick).padding(3.dp)) {
        Box(Modifier.offset(x).size(30.dp).background(ink, CircleShape), Alignment.Center) {
            Text(if (dark) "☾" else "☀", color = card, fontSize = 15.sp)
        }
    }
}


@Composable
fun ShizukuChip(sz: Int, card: Color, ink: Color, onClick: () -> Unit) {
    val dot by animateColorAsState(
        when (sz) { 2 -> Color(0xFF34D399); 1 -> Color(0xFFFBBF24); else -> Color(0xFFFB7185) }, tween(400), label = "d"
    )
    val text = when (sz) { 2 -> "Shizuku đã kết nối"; 1 -> "Chạm để cấp quyền Shizuku"; else -> "Shizuku chưa chạy, hãy mở Shizuku" }
    Row(
        Modifier.padding(top = 12.dp).clip(CircleShape).background(card)
            .clickable(enabled = sz == 1, onClick = onClick).padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(8.dp).background(dot, CircleShape))
        Spacer(Modifier.width(8.dp))
        Text(text, color = ink, fontSize = 13.sp)
    }
}
