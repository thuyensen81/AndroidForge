import { AppSettings, DeviceProfile } from '../../types';
import { DEVICE_PROFILES } from '../../utils/mockData';
import { Settings, Sliders, Smartphone, Volume2, ShieldCheck, Cpu, Info, Check, Terminal, Copy, Code, Shield, Sparkles } from 'lucide-react';
import { soundFX } from '../../utils/audio';

interface SettingsTabProps {
  settings: AppSettings;
  onUpdateSettings: (patch: Partial<AppSettings>) => void;
  currentDevice: DeviceProfile;
  onSelectDevice: (deviceId: string) => void;
  onOpenTerminal?: () => void;
  language: 'vi' | 'en';
}

export function SettingsTab({
  settings,
  onUpdateSettings,
  currentDevice,
  onSelectDevice,
  onOpenTerminal,
  language,
}: SettingsTabProps) {
  return (
    <div className="space-y-5 pb-6">
      {/* Automation Rules */}
      <div className="bg-slate-900/60 backdrop-blur-md border border-slate-800 rounded-3xl p-5 shadow-lg">
        <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-4 flex items-center gap-2">
          <Sliders size={14} className="text-emerald-400" />
          <span>{language === 'vi' ? 'Quy Tắc Tự Động Hóa' : 'Automated RAM Optimization'}</span>
        </h4>

        <div className="space-y-4">
          {/* Threshold auto boost */}
          <div className="flex items-center justify-between gap-3">
            <div>
              <div className="text-xs font-bold text-white">
                {language === 'vi'
                  ? 'Tự động dọn RAM khi vượt ngưỡng'
                  : 'Auto-boost when RAM exceeds threshold'}
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5">
                {language === 'vi'
                  ? `Kích hoạt dọn dẹp nhẹ khi bộ nhớ đầy trên ${settings.autoBoostThresholdPercent}%`
                  : `Silently trims memory when usage hits ${settings.autoBoostThresholdPercent}%`}
              </div>
            </div>
            <button
              onClick={() => {
                soundFX.playSwitch(!settings.autoBoostEnabled);
                onUpdateSettings({ autoBoostEnabled: !settings.autoBoostEnabled });
              }}
              className={`w-12 h-6 rounded-full transition-colors p-0.5 shrink-0 ${
                settings.autoBoostEnabled ? 'bg-emerald-500' : 'bg-slate-800'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  settings.autoBoostEnabled ? 'translate-x-6' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Clean on screen lock */}
          <div className="flex items-center justify-between gap-3 pt-3 border-t border-slate-800/60">
            <div>
              <div className="text-xs font-bold text-white">
                {language === 'vi'
                  ? 'Tự động tăng tốc khi khoá màn hình'
                  : 'Auto-clean upon screen lock'}
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5">
                {language === 'vi'
                  ? 'Giải phóng bộ nhớ đệm ngay khi tắt màn hình để tiết kiệm pin tối đa'
                  : 'Compacts background allocations whenever the screen turns off'}
              </div>
            </div>
            <button
              onClick={() => {
                soundFX.playSwitch(!settings.boostOnScreenLock);
                onUpdateSettings({ boostOnScreenLock: !settings.boostOnScreenLock });
              }}
              className={`w-12 h-6 rounded-full transition-colors p-0.5 shrink-0 ${
                settings.boostOnScreenLock ? 'bg-emerald-500' : 'bg-slate-800'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  settings.boostOnScreenLock ? 'translate-x-6' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Sound & Haptics */}
          <div className="flex items-center justify-between gap-3 pt-3 border-t border-slate-800/60">
            <div>
              <div className="text-xs font-bold text-white">
                {language === 'vi'
                  ? 'Âm thanh phản hồi xúc giác'
                  : 'Sound Effects & Haptic Audio'}
              </div>
              <div className="text-[11px] text-slate-400 mt-0.5">
                {language === 'vi'
                  ? 'Phát âm thanh mô phỏng tiến trình bộ nhớ và tăng tốc'
                  : 'Synthesized cyber audio feedback on UI actions'}
              </div>
            </div>
            <button
              onClick={() => {
                soundFX.playSwitch(!settings.soundEnabled);
                onUpdateSettings({ soundEnabled: !settings.soundEnabled });
              }}
              className={`w-12 h-6 rounded-full transition-colors p-0.5 shrink-0 ${
                settings.soundEnabled ? 'bg-emerald-500' : 'bg-slate-800'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white transition-transform ${
                  settings.soundEnabled ? 'translate-x-6' : 'translate-x-0'
                }`}
              />
            </button>
          </div>
        </div>
      </div>

      {/* Device Profile Switcher */}
      <div className="bg-slate-900/60 backdrop-blur-md border border-slate-800 rounded-3xl p-5 shadow-lg">
        <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-2 flex items-center gap-2">
          <Smartphone size={14} className="text-cyan-400" />
          <span>{language === 'vi' ? 'Hồ Sơ Thiết Bị Mô Phỏng' : 'Simulated Device Profile'}</span>
        </h4>
        <p className="text-[11px] text-slate-400 mb-4">
          {language === 'vi'
            ? 'Thay đổi thiết bị để trải nghiệm khả năng quản lý RAM ở các mức dung lượng khác nhau (8GB - 24GB).'
            : 'Select device to experience RAM optimization across different hardware tiers.'}
        </p>

        <div className="space-y-2.5">
          {DEVICE_PROFILES.map((profile) => {
            const isSelected = profile.id === currentDevice.id;
            return (
              <div
                key={profile.id}
                onClick={() => {
                  soundFX.playTap();
                  onSelectDevice(profile.id);
                }}
                className={`p-3.5 rounded-2xl border cursor-pointer transition flex items-center justify-between ${
                  isSelected
                    ? 'bg-cyan-500/10 border-cyan-500/50 text-white'
                    : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700'
                }`}
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-white">{profile.name}</span>
                    <span className="text-[10px] px-1.5 py-0.2 rounded bg-cyan-500/20 text-cyan-400 font-mono font-bold">
                      {profile.totalRamGb} GB RAM
                    </span>
                  </div>
                  <div className="text-[10px] text-slate-500 font-mono mt-0.5">
                    {profile.chipset}
                  </div>
                </div>

                <div
                  className={`w-5 h-5 rounded-full flex items-center justify-center border ${
                    isSelected ? 'bg-cyan-500 border-cyan-400 text-slate-950' : 'border-slate-700'
                  }`}
                >
                  {isSelected && <Check size={12} strokeWidth={3} />}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Kernel & Technical Specifications */}
      <div className="bg-slate-900/60 backdrop-blur-md border border-slate-800 rounded-3xl p-5 shadow-lg">
        <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-3 flex items-center gap-2">
          <Cpu size={14} className="text-purple-400" />
          <span>{language === 'vi' ? 'Thông Tin Kỹ Thuật Nhân Hệ Thống' : 'System & Kernel Specs'}</span>
        </h4>

        <div className="space-y-2 text-xs font-mono">
          <div className="flex justify-between py-1.5 border-b border-slate-800">
            <span className="text-slate-400">Android System</span>
            <span className="text-white font-bold">{currentDevice.androidVersion}</span>
          </div>
          <div className="flex justify-between py-1.5 border-b border-slate-800">
            <span className="text-slate-400">API Level</span>
            <span className="text-emerald-400 font-bold">{currentDevice.apiLevel}</span>
          </div>
          <div className="flex justify-between py-1.5 border-b border-slate-800">
            <span className="text-slate-400">Kernel Version</span>
            <span className="text-slate-300 truncate max-w-[220px]">{currentDevice.kernelVersion}</span>
          </div>
          <div className="flex justify-between py-1.5 border-b border-slate-800">
            <span className="text-slate-400">Memory Page Size</span>
            <span className="text-cyan-400 font-bold">{currentDevice.supports16kbPage ? '16KB (16384 bytes)' : '4KB (4096 bytes)'}</span>
          </div>
          <div className="flex justify-between py-1.5 border-b border-slate-800">
            <span className="text-slate-400">CONFIG_ARM64_16K_PAGES</span>
            <span className={`font-bold ${currentDevice.supports16kbPage ? 'text-emerald-400' : 'text-slate-500'}`}>
              {currentDevice.supports16kbPage ? 'Enabled' : 'Disabled (4KB Standard)'}
            </span>
          </div>
          <div className="flex justify-between py-1.5">
            <span className="text-slate-400">ART Optimizer Compiler</span>
            <span className="text-violet-400 font-bold">dex2oat (API {currentDevice.apiLevel})</span>
          </div>
        </div>
      </div>

      {/* ADB Shell & Kernel Commands Center Card */}
      <div className="bg-gradient-to-r from-cyan-950/40 via-slate-900 to-emerald-950/40 border border-cyan-500/30 rounded-3xl p-5 shadow-lg">
        <div className="flex items-start justify-between gap-4 mb-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-cyan-500/20 text-cyan-400 flex items-center justify-center shrink-0">
              <Terminal size={20} />
            </div>
            <div>
              <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                {language === 'vi' ? 'Bảng Lệnh ADB Shell & Tối Ưu Hạt Nhân' : 'ADB Shell & Kernel Commands'}
              </h4>
              <p className="text-[11px] text-slate-400 mt-0.5">
                {language === 'vi'
                  ? 'Tổng hợp các lệnh hệ thống thực thi qua Shizuku và Termux'
                  : 'Real system commands executed via Shizuku and Termux'}
              </p>
            </div>
          </div>
          <span className="text-[10px] px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-400 font-mono font-bold">
            SHIZUKU ADB
          </span>
        </div>

        {/* Quick Command List with Copy */}
        <div className="space-y-2 mb-4 font-mono text-[11px]">
          <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-2">
            <div className="truncate text-slate-300">
              <span className="text-emerald-400 mr-1.5">$</span>
              pm trim-caches 1024G
            </div>
            <button
              onClick={() => {
                soundFX.playTap();
                navigator.clipboard.writeText('pm trim-caches 1024G');
              }}
              className="text-[10px] text-cyan-400 hover:text-white px-2 py-0.5 rounded bg-slate-900 border border-slate-700 shrink-0"
            >
              Copy
            </button>
          </div>

          <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-2">
            <div className="truncate text-slate-300">
              <span className="text-cyan-400 mr-1.5">$</span>
              cmd activity trim-memory all RUNNING_CRITICAL
            </div>
            <button
              onClick={() => {
                soundFX.playTap();
                navigator.clipboard.writeText('cmd activity trim-memory all RUNNING_CRITICAL');
              }}
              className="text-[10px] text-cyan-400 hover:text-white px-2 py-0.5 rounded bg-slate-900 border border-slate-700 shrink-0"
            >
              Copy
            </button>
          </div>

          <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-2">
            <div className="truncate text-slate-300">
              <span className="text-cyan-400 mr-1.5">$</span>
              device_config put activity_manager max_phantom_processes 2147483647
            </div>
            <button
              onClick={() => {
                soundFX.playTap();
                navigator.clipboard.writeText('device_config put activity_manager max_phantom_processes 2147483647');
              }}
              className="text-[10px] text-cyan-400 hover:text-white px-2 py-0.5 rounded bg-slate-900 border border-slate-700 shrink-0"
            >
              Copy
            </button>
          </div>

          <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-2">
            <div className="truncate text-slate-300">
              <span className="text-emerald-400 mr-1.5">#</span>
              echo 3 &gt; /proc/sys/vm/drop_caches &amp;&amp; echo 1 &gt; /proc/sys/vm/compact_memory
            </div>
            <button
              onClick={() => {
                soundFX.playTap();
                navigator.clipboard.writeText('echo 3 > /proc/sys/vm/drop_caches && echo 1 > /proc/sys/vm/compact_memory');
              }}
              className="text-[10px] text-cyan-400 hover:text-white px-2 py-0.5 rounded bg-slate-900 border border-slate-700 shrink-0"
            >
              Copy
            </button>
          </div>

          <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between gap-2">
            <div className="truncate text-slate-300">
              <span className="text-violet-400 mr-1.5">#</span>
              echo 1 &gt; /sys/block/zram0/compact &amp;&amp; sysctl -w vm.swappiness=60
            </div>
            <button
              onClick={() => {
                soundFX.playTap();
                navigator.clipboard.writeText('echo 1 > /sys/block/zram0/compact && sysctl -w vm.swappiness=60');
              }}
              className="text-[10px] text-cyan-400 hover:text-white px-2 py-0.5 rounded bg-slate-900 border border-slate-700 shrink-0"
            >
              Copy
            </button>
          </div>
        </div>

        {onOpenTerminal && (
          <button
            onClick={() => {
              soundFX.playTap();
              onOpenTerminal();
            }}
            className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-cyan-500 via-teal-500 to-emerald-500 hover:from-cyan-400 hover:to-emerald-400 text-slate-950 font-black text-xs tracking-wider uppercase flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/20 active:scale-98 transition"
          >
            <Terminal size={16} />
            <span>{language === 'vi' ? 'MỞ BẢNG ĐIỀU KHIỂN TERMINAL SHELL' : 'OPEN TERMINAL COMMAND CENTER'}</span>
          </button>
        )}
      </div>
    </div>
  );
}
