import { useState, useMemo, useEffect } from 'react';
import {
  AppProcess,
  DeviceProfile,
  AppSettings,
  BoostResult,
  BenchmarkMetrics,
  CompressionAlgorithm,
  LmkMode,
  TurboGamePackage,
  PermissionState,
} from './types';
import {
  DEVICE_PROFILES,
  INITIAL_PROCESSES,
  INITIAL_BENCHMARK,
  DEFAULT_GAMES_LIST,
  computeRAMStats,
} from './utils/mockData';
import { soundFX } from './utils/audio';
import { Shield, Code, ShieldAlert } from 'lucide-react';
import { AndroidStatusBar } from './components/AndroidStatusBar';
import { Navigation, TabType } from './components/Navigation';
import { BoostModal } from './components/BoostModal';
import { PermissionModal } from './components/PermissionModal';
import { QuickBoostTab } from './components/Tabs/QuickBoostTab';
import { ProcessManagerTab } from './components/Tabs/ProcessManagerTab';
import { VirtualRamTab } from './components/Tabs/VirtualRamTab';
import { GameTurboTab } from './components/Tabs/GameTurboTab';
import { BenchmarkTab } from './components/Tabs/BenchmarkTab';
import { SettingsTab } from './components/Tabs/SettingsTab';
import { CommandConsoleModal, CommandLog } from './components/CommandConsoleModal';

export default function App() {
  // Device & Settings State (Default to OnePlus 13 Snapdragon 8 Elite 24GB RAM)
  const [selectedDeviceId, setSelectedDeviceId] = useState<string>('oneplus-13');
  const [activeTab, setActiveTab] = useState<TabType>('overview');
  const [language, setLanguage] = useState<'vi' | 'en'>('vi');
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [viewMode, setViewMode] = useState<'responsive' | 'phone_mockup'>('responsive');

  // Virtual RAM and Kernel state
  const [virtualRamSizeGb, setVirtualRamSizeGb] = useState<number>(16);
  const [zramAlgorithm, setZramAlgorithm] = useState<CompressionAlgorithm>('ZSTD');
  const [swappiness, setSwappiness] = useState<number>(60);
  const [lmkMode, setLmkMode] = useState<LmkMode>('balanced');

  // Shizuku Elevated Permission State
  const [permission, setPermission] = useState<PermissionState>({
    mode: 'shizuku',
    shizukuActive: true,
    wirelessDebuggingEnabled: true,
    selinuxEnforcing: true,
  });
  const [isPermissionModalOpen, setIsPermissionModalOpen] = useState<boolean>(false);

  // Game Turbo state
  const [gameTurboActive, setGameTurboActive] = useState<boolean>(false);
  const [gamesList, setGamesList] = useState<TurboGamePackage[]>(() => {
    try {
      const saved = localStorage.getItem('ram_turbo_games');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // Ignore
    }
    return DEFAULT_GAMES_LIST;
  });
  const [selectedGame, setSelectedGame] = useState<string | null>(DEFAULT_GAMES_LIST[0].id);

  // Sync games list to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('ram_turbo_games', JSON.stringify(gamesList));
    } catch {
      // Ignore
    }
  }, [gamesList]);

  // Automation settings
  const [autoBoostEnabled, setAutoBoostEnabled] = useState<boolean>(true);
  const [autoBoostThresholdPercent, setAutoBoostThresholdPercent] = useState<number>(80);
  const [boostOnScreenLock, setBoostOnScreenLock] = useState<boolean>(false);

  // Processes state
  const [processes, setProcesses] = useState<AppProcess[]>(INITIAL_PROCESSES);

  // Boost modal and status
  const [isBoosting, setIsBoosting] = useState<boolean>(false);
  const [isBoostModalOpen, setIsBoostModalOpen] = useState<boolean>(false);
  const [lastBoostResult, setLastBoostResult] = useState<BoostResult | null>(null);

  // Benchmark stats
  const [benchmark, setBenchmark] = useState<BenchmarkMetrics>(INITIAL_BENCHMARK);

  // Current Device
  const currentDevice = useMemo(() => {
    return DEVICE_PROFILES.find((d) => d.id === selectedDeviceId) || DEVICE_PROFILES[0];
  }, [selectedDeviceId]);

  // Compute live RAM statistics
  const stats = useMemo(() => {
    return computeRAMStats(currentDevice, processes, virtualRamSizeGb, swappiness, zramAlgorithm);
  }, [currentDevice, processes, virtualRamSizeGb, swappiness, zramAlgorithm]);

  // Terminal & Command Console State
  const [isTerminalOpen, setIsTerminalOpen] = useState<boolean>(false);
  const [terminalLogs, setTerminalLogs] = useState<CommandLog[]>([
    {
      id: 'init-1',
      command: 'cat /proc/sys/vm/page_size_kb && getprop ro.product.cpu.abi',
      output: '16 KB (16384 bytes) architecture verified\narm64-v9a (Snapdragon 8 Elite / Oryon CPU)',
      type: 'adb',
      timestamp: '09:41:00',
      status: 'success',
    },
    {
      id: 'init-2',
      command: 'shizuku_starter --status && cat /proc/meminfo | grep MemTotal',
      output: 'Shizuku Privileged Service v13.5.4 Active (Port 5555)\nMemTotal: 24715840 kB (24 GB LPDDR5X Ultra)',
      type: 'adb',
      timestamp: '09:41:01',
      status: 'success',
    },
  ]);

  const addCommandLog = (command: string, output: string, type: 'root' | 'adb' = 'adb') => {
    const newLog: CommandLog = {
      id: `log-${Date.now()}-${Math.random()}`,
      command,
      output,
      type,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      status: 'success',
    };
    setTerminalLogs((prev) => [newLog, ...prev.slice(0, 49)]);
  };

  const handleExecuteConsoleCommand = (cmd: string, type: 'root' | 'adb') => {
    soundFX.playBoostComplete();
    let simOutput = 'Execution finished with exit code 0 (success)';
    if (cmd.includes('pm trim-caches')) {
      simOutput = 'Package manager trimmed caches (target 1024GB).\nPurged all third-party and system app cache directories.\nFreed internal cache storage and reclaimed Dalvik/ART page buffers.';
    } else if (cmd.includes('drop_caches')) {
      simOutput = 'Memory cache dropped. Page tables compacted into 16KB blocks.\nAllocated physical contiguous memory pages.';
    } else if (cmd.includes('max_phantom_processes')) {
      simOutput = 'DeviceConfig updated: max_phantom_processes=2147483647.\nPhantom process monitor disabled.';
    } else if (cmd.includes('compact')) {
      simOutput = 'zRAM swap device /dev/block/zram0 compacted.\nCompression algorithm: LZ4/ZSTD.\nSwappiness ratio set to 60.';
    } else if (cmd.includes('oom_score_adj') || cmd.includes('set-inactive')) {
      simOutput = 'Package priority pinned to oom_score_adj=-1000 (OOM protected).\nStandby inactivity disabled via Shizuku.';
    }
    addCommandLog(cmd, simOutput, type);
  };

  // Sync sound setting with Web Audio engine
  useEffect(() => {
    soundFX.setEnabled(soundEnabled);
  }, [soundEnabled]);

  // Trigger Master Boost
  const handleTriggerBoost = () => {
    setIsBoosting(true);
    soundFX.playWhoosh();

    const previousUsed = stats.usedMb;

    // Simulate killing all unwhitelisted cached & phantom processes
    setTimeout(() => {
      let freed = 0;
      let closedCount = 0;

      setProcesses((prev) =>
        prev.map((p) => {
          if (!p.isProtected && p.canKill && (p.priority === 'cached' || p.priority === 'phantom')) {
            freed += p.ramUsageMb;
            closedCount += 1;
            return { ...p, isKilled: true, isFrozen: false };
          }
          return p;
        })
      );

      const compactedZram = Math.round(stats.zramUsedMb * 0.45);
      const totalFreed = freed + compactedZram;

      const result: BoostResult = {
        freedMb: totalFreed > 0 ? totalFreed : 1850,
        appsClosed: closedCount > 0 ? closedCount : 5,
        zramCompactedMb: compactedZram > 0 ? compactedZram : 940,
        previousUsedMb: previousUsed,
        newUsedMb: Math.max(1024, previousUsed - totalFreed),
        durationMs: 1400,
        timestamp: new Date(),
      };

      addCommandLog(
        'echo 3 > /proc/sys/vm/drop_caches && echo 1 > /proc/sys/vm/compact_memory',
        `Reclaimed ${result.freedMb}MB RAM. Closed ${result.appsClosed} cached processes. Compacted ${result.zramCompactedMb}MB zRAM.`
      );

      setLastBoostResult(result);
      setIsBoosting(false);
      setIsBoostModalOpen(true);
    }, 900);
  };

  // Quick action handling from tiles
  const handleQuickAction = (actionType: 'cache' | 'phantom' | '16kb' | 'zram') => {
    if (actionType === 'cache') {
      let freed = 0;
      setProcesses((prev) =>
        prev.map((p) => {
          if (p.priority === 'cached' && !p.isProtected && p.canKill) {
            freed += p.ramUsageMb;
            return { ...p, isKilled: true };
          }
          return p;
        })
      );
      addCommandLog('pm trim-caches 1024G', 'Package manager trimmed caches (target 1024G). Purged all app caches across Android system.', 'adb');
      soundFX.playBoostComplete();
    } else if (actionType === 'phantom') {
      setProcesses((prev) =>
        prev.map((p) => {
          if (p.priority === 'phantom' && p.canKill) {
            return { ...p, isKilled: true };
          }
          return p;
        })
      );
      addCommandLog('device_config put activity_manager max_phantom_processes 2147483647', 'PhantomProcessKiller monitor disabled. Orphan forks terminated.', 'adb');
      soundFX.playBoostComplete();
    } else if (actionType === '16kb') {
      // Defragment 16KB pages
      setProcesses((prev) =>
        prev.map((p) => ({ ...p, page16kbAligned: true }))
      );
      addCommandLog('echo 1 > /proc/sys/vm/compact_memory && sysctl -w vm.compact_memory=1', 'Defragmented 16KB memory page frames. TLB alignment: 100%.');
      soundFX.playBoostComplete();
    } else if (actionType === 'zram') {
      addCommandLog('echo 1 > /sys/block/zram0/compact && sysctl -w vm.swappiness=60', `zRAM swap compaction triggered with algorithm: ${zramAlgorithm}.`);
      soundFX.playBoostComplete();
    }
  };

  // Process item actions
  const handleToggleProtect = (id: string) => {
    setProcesses((prev) =>
      prev.map((p) => (p.id === id ? { ...p, isProtected: !p.isProtected } : p))
    );
  };

  const handleToggleFreeze = (id: string) => {
    const target = processes.find((p) => p.id === id);
    if (target) {
      if (!target.isFrozen) {
        addCommandLog(`cmd appops set ${target.packageName} RUN_IN_BACKGROUND ignore`, `Revoked background execution for ${target.packageName}.`, 'adb');
      } else {
        addCommandLog(`cmd appops set ${target.packageName} RUN_IN_BACKGROUND allow`, `Restored background execution for ${target.packageName}.`, 'adb');
      }
    }
    setProcesses((prev) =>
      prev.map((p) => (p.id === id ? { ...p, isFrozen: !p.isFrozen } : p))
    );
  };

  const handleKillProcess = (id: string) => {
    const target = processes.find((p) => p.id === id);
    if (target) {
      addCommandLog(`am force-stop ${target.packageName}`, `Process ${target.packageName} terminated with SIGKILL.`, 'adb');
    }
    setProcesses((prev) =>
      prev.map((p) => (p.id === id ? { ...p, isKilled: true, isFrozen: false } : p))
    );
  };

  const handleKillAllCached = () => {
    addCommandLog('am kill-all && echo 3 > /proc/sys/vm/drop_caches', 'All cached tasks terminated via ActivityManager and drop_caches.');
    setProcesses((prev) =>
      prev.map((p) => {
        if (!p.isProtected && p.canKill && (p.priority === 'cached' || p.priority === 'phantom')) {
          return { ...p, isKilled: true, isFrozen: false };
        }
        return p;
      })
    );
    soundFX.playBoostComplete();
  };

  const handleResetProcesses = () => {
    setProcesses(INITIAL_PROCESSES);
    soundFX.playTap();
  };

  const handleToggleGameTurbo = () => {
    setGameTurboActive((prev) => {
      const next = !prev;
      const curGame = gamesList.find((g) => g.id === selectedGame) || gamesList[0];
      if (next) {
        addCommandLog(
          `echo -1000 > /proc/$(pidof ${curGame.packageName})/oom_score_adj && am set-inactive ${curGame.packageName} false`,
          `Game Turbo engaged for ${curGame.name}. Allocated +${curGame.dedicatedRamGb}GB dedicated RAM buffer and pinned top priority via Shizuku.`,
          'adb'
        );
        setLmkMode('extreme_gaming');
      } else {
        addCommandLog(
          `am set-inactive ${curGame.packageName} false`,
          `Game Turbo disengaged for ${curGame.name}. Restored standard balanced profile.`,
          'adb'
        );
        setLmkMode('balanced');
      }
      return next;
    });
  };

  // Custom Game Package Handlers
  const handleAddCustomGame = (newGame: TurboGamePackage) => {
    setGamesList((prev) => [newGame, ...prev]);
    setSelectedGame(newGame.id);
  };

  const handleUpdateGame = (updatedGame: TurboGamePackage) => {
    setGamesList((prev) =>
      prev.map((g) => (g.id === updatedGame.id ? updatedGame : g))
    );
  };

  const handleDeleteGame = (id: string) => {
    setGamesList((prev) => {
      const filtered = prev.filter((g) => g.id !== id);
      if (selectedGame === id && filtered.length > 0) {
        setSelectedGame(filtered[0].id);
      }
      return filtered;
    });
  };

  const handleRestoreDefaultGames = () => {
    setGamesList(DEFAULT_GAMES_LIST);
    setSelectedGame(DEFAULT_GAMES_LIST[0].id);
    soundFX.playBoostComplete();
  };

  // Device selection
  const handleSelectDevice = (deviceId: string) => {
    setSelectedDeviceId(deviceId);
    const newDev = DEVICE_PROFILES.find((d) => d.id === deviceId);
    if (newDev) {
      setVirtualRamSizeGb(newDev.defaultSwapGb);
    }
    soundFX.playTap();
  };

  const appSettings: AppSettings = {
    language,
    soundEnabled,
    autoBoostEnabled,
    autoBoostThresholdPercent,
    boostOnScreenLock,
    viewMode,
    selectedDeviceId,
    lmkMode,
    page16kbCompaction: true,
    virtualRamSizeGb,
    zramAlgorithm,
    swappiness,
    gameTurboActive,
    selectedGameForTurbo: selectedGame,
  };

  const handleUpdateSettings = (patch: Partial<AppSettings>) => {
    if (patch.autoBoostEnabled !== undefined) setAutoBoostEnabled(patch.autoBoostEnabled);
    if (patch.autoBoostThresholdPercent !== undefined)
      setAutoBoostThresholdPercent(patch.autoBoostThresholdPercent);
    if (patch.boostOnScreenLock !== undefined) setBoostOnScreenLock(patch.boostOnScreenLock);
    if (patch.soundEnabled !== undefined) setSoundEnabled(patch.soundEnabled);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center justify-start antialiased selection:bg-emerald-500 selection:text-black">
      {/* Phone Mockup Wrapper or Fullscreen Responsive */}
      <div
        className={`w-full transition-all duration-300 ${
          viewMode === 'phone_mockup'
            ? 'max-w-[430px] my-6 rounded-[48px] border-8 border-slate-800 shadow-[0_0_60px_rgba(0,0,0,0.8)] overflow-hidden bg-slate-950 ring-1 ring-slate-700/50'
            : 'max-w-2xl min-h-screen border-x border-slate-900 bg-slate-950'
        }`}
      >
        {/* System Status Bar */}
        <AndroidStatusBar
          device={currentDevice}
          soundEnabled={soundEnabled}
          onToggleSound={() => setSoundEnabled((prev) => !prev)}
          language={language}
          onToggleLanguage={() => setLanguage((prev) => (prev === 'vi' ? 'en' : 'vi'))}
          viewMode={viewMode}
          onToggleViewMode={() =>
            setViewMode((prev) => (prev === 'phone_mockup' ? 'responsive' : 'phone_mockup'))
          }
          onToggleTerminal={() => setIsTerminalOpen((prev) => !prev)}
          isTerminalOpen={isTerminalOpen}
        />

        {/* Dynamic Header */}
        <header className="px-5 pt-4 pb-2">
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg font-black text-white tracking-tight">
                  {language === 'vi' ? 'TĂNG TỐC RAM PRO' : 'RAM TURBO PRO'}
                </h1>
                <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-gradient-to-r from-emerald-500/20 to-cyan-500/20 text-emerald-300 border border-emerald-500/30">
                  {currentDevice.androidVersion} • API {currentDevice.apiLevel}
                </span>
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">
                {currentDevice.name}
              </p>
            </div>

            {/* Quick Game Turbo indicator if active */}
            {gameTurboActive && (
              <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-rose-500/20 border border-rose-500/40 text-rose-300 text-xs font-bold animate-pulse truncate max-w-[170px]">
                <span>🔥 TURBO +{gamesList.find((g) => g.id === selectedGame)?.dedicatedRamGb || 4}GB</span>
              </div>
            )}
          </div>
        </header>

        {/* Prominent Shizuku Permission Grant & Status Notification Banner */}
        <div className="px-4 py-1.5">
          <div
            onClick={() => {
              soundFX.playTap();
              setIsPermissionModalOpen(true);
            }}
            className={`p-3 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-3 shadow-md ${
              permission.shizukuActive
                ? 'bg-cyan-950/30 border-cyan-500/40 hover:bg-cyan-950/40 text-cyan-300'
                : 'bg-amber-950/40 border-amber-500/50 hover:bg-amber-950/50 text-amber-300 animate-pulse'
            }`}
          >
            <div className="flex items-center gap-2.5 min-w-0">
              <div
                className={`p-2 rounded-xl shrink-0 ${
                  permission.shizukuActive
                    ? 'bg-cyan-500/20 text-cyan-400'
                    : 'bg-amber-500/20 text-amber-400'
                }`}
              >
                {permission.shizukuActive ? (
                  <Code size={16} />
                ) : (
                  <ShieldAlert size={16} />
                )}
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-white tracking-wide truncate">
                    {permission.shizukuActive
                      ? language === 'vi'
                        ? 'Dịch Vụ Shizuku v13.5 (Hoạt Động)'
                        : 'Shizuku API Service Active'
                      : language === 'vi'
                      ? 'Yêu Cầu Cấp Quyền Shizuku'
                      : 'Grant Shizuku Permission'}
                  </span>
                  <span
                    className={`text-[9px] font-mono font-bold px-1.5 py-0.2 rounded border shrink-0 ${
                      !permission.shizukuActive
                        ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 animate-bounce'
                        : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                    }`}
                  >
                    {!permission.shizukuActive ? 'CẦN CẤP QUYỀN' : 'SẴN SÀNG'}
                  </span>
                </div>
                <p className="text-[10px] text-slate-300 truncate mt-0.5">
                  {permission.shizukuActive
                    ? language === 'vi'
                      ? 'Đặc quyền ADB Shell UID=2000 sẵn sàng tối ưu RAM và nén zRAM'
                      : 'Privileged ADB Shell UID=2000 active for RAM optimization'
                    : language === 'vi'
                    ? 'Bật Gỡ lỗi không dây & cấp quyền Shizuku để tối ưu RAM không cần Root'
                    : 'Enable Wireless Debugging & authorize Shizuku for rootless optimization'}
                </p>
              </div>
            </div>

            <button
              onClick={(e) => {
                e.stopPropagation();
                soundFX.playTap();
                setIsPermissionModalOpen(true);
              }}
              className={`px-2.5 py-1.5 rounded-xl text-[10px] font-bold font-mono tracking-wider shrink-0 transition active:scale-95 shadow ${
                permission.shizukuActive
                  ? 'bg-cyan-500 text-slate-950 hover:bg-cyan-400'
                  : 'bg-amber-500 text-slate-950 hover:bg-amber-400 font-black'
              }`}
            >
              {!permission.shizukuActive
                ? language === 'vi'
                  ? 'CẤP QUYỀN'
                  : 'GRANT'
                : language === 'vi'
                ? 'CẤU HÌNH'
                : 'CONFIG'}
            </button>
          </div>
        </div>

        {/* Main Content View with Active Tab */}
        <main className="px-4 py-3 pb-24">
          {activeTab === 'overview' && (
            <QuickBoostTab
              stats={stats}
              processes={processes}
              onTriggerBoost={handleTriggerBoost}
              onQuickAction={handleQuickAction}
              onOpenTerminal={() => setIsTerminalOpen(true)}
              language={language}
              isBoosting={isBoosting}
              lastBoostResult={lastBoostResult}
            />
          )}

          {activeTab === 'processes' && (
            <ProcessManagerTab
              processes={processes}
              onToggleProtect={handleToggleProtect}
              onToggleFreeze={handleToggleFreeze}
              onKillProcess={handleKillProcess}
              onKillAllCached={handleKillAllCached}
              onResetProcesses={handleResetProcesses}
              language={language}
            />
          )}

          {activeTab === 'virtual_ram' && (
            <VirtualRamTab
              stats={stats}
              virtualRamSizeGb={virtualRamSizeGb}
              onSetVirtualRamSize={setVirtualRamSizeGb}
              zramAlgorithm={zramAlgorithm}
              onSetAlgorithm={setZramAlgorithm}
              swappiness={swappiness}
              onSetSwappiness={setSwappiness}
              onCompactZram={() => handleQuickAction('zram')}
              language={language}
            />
          )}

          {activeTab === 'game_turbo' && (
            <GameTurboTab
              gameTurboActive={gameTurboActive}
              onToggleGameTurbo={handleToggleGameTurbo}
              selectedGameId={selectedGame}
              onSelectGame={setSelectedGame}
              gamesList={gamesList}
              onAddCustomGame={handleAddCustomGame}
              onUpdateGame={handleUpdateGame}
              onDeleteGame={handleDeleteGame}
              onRestoreDefaultGames={handleRestoreDefaultGames}
              installedProcesses={processes}
              lmkMode={lmkMode}
              onSetLmkMode={setLmkMode}
              language={language}
            />
          )}

          {activeTab === 'benchmark' && (
            <BenchmarkTab
              stats={stats}
              benchmark={benchmark}
              onUpdateBenchmark={setBenchmark}
              language={language}
            />
          )}

          {activeTab === 'settings' && (
            <SettingsTab
              settings={appSettings}
              onUpdateSettings={handleUpdateSettings}
              currentDevice={currentDevice}
              onSelectDevice={handleSelectDevice}
              onOpenTerminal={() => setIsTerminalOpen(true)}
              language={language}
            />
          )}
        </main>

        {/* Bottom Navigation */}
        <Navigation
          activeTab={activeTab}
          onSelectTab={setActiveTab}
          language={language}
        />

        {/* Interactive Boost Animation & Summary Modal */}
        <BoostModal
          isOpen={isBoostModalOpen}
          onClose={() => setIsBoostModalOpen(false)}
          result={lastBoostResult}
          language={language}
        />

        {/* Live ADB & Kernel Shell Command Console Modal */}
        <CommandConsoleModal
          isOpen={isTerminalOpen}
          onClose={() => setIsTerminalOpen(false)}
          logs={terminalLogs}
          onClearLogs={() => setTerminalLogs([])}
          onExecuteCommand={handleExecuteConsoleCommand}
          language={language}
          device={currentDevice}
        />

        {/* Root & Shizuku System Permission Grant Modal */}
        <PermissionModal
          isOpen={isPermissionModalOpen}
          onClose={() => setIsPermissionModalOpen(false)}
          permission={permission}
          onUpdatePermission={setPermission}
          onAddLog={addCommandLog}
          language={language}
        />
      </div>
    </div>
  );
}
