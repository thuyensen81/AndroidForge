package com.valh.ramcleaner

import android.content.Context
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.roundToLong

// ───────────── Bảng màu Cyberpunk (tối / sáng) ─────────────

data class Pal(
    val dark: Boolean,
    val bg: Color, val panel: Color, val panel2: Color, val line: Color,
    val text: Color, val muted: Color, val hi: Color,
    val accent: Color, val onAccent: Color,
    val c1: Color, val c2: Color, val c3: Color, val c4: Color, val c5: Color
)

// Tối: nền đen, vàng chói + cyan + đỏ neon
private val DarkPal = Pal(
    dark = true,
    bg = Color(0xFF07070C), panel = Color(0xFF111118), panel2 = Color(0xFF0A0A10), line = Color(0xFF5C5708),
    text = Color(0xFFEDEDED), muted = Color(0xFF8E8E9C), hi = Color(0xFFFCEE0A),
    accent = Color(0xFFFCEE0A), onAccent = Color(0xFF0A0A0A),
    c1 = Color(0xFF00F0FF), c2 = Color(0xFFFF003C), c3 = Color(0xFFB026FF), c4 = Color(0xFFFF8A00), c5 = Color(0xFF00FF9C)
)

// Sáng: nền vàng Cyberpunk, viền và chữ đen
private val LightPal = Pal(
    dark = false,
    bg = Color(0xFFFCEE0A), panel = Color(0xFFFFF566), panel2 = Color(0xFFF1DF00), line = Color(0xFF0A0A0A),
    text = Color(0xFF0A0A0A), muted = Color(0xFF4D4800), hi = Color(0xFF0A0A0A),
    accent = Color(0xFF0A0A0A), onAccent = Color(0xFFFCEE0A),
    c1 = Color(0xFF006C78), c2 = Color(0xFFC8002E), c3 = Color(0xFF5B0AA5), c4 = Color(0xFF9A4A00), c5 = Color(0xFF0A6B3A)
)

private val LocalPal = staticCompositionLocalOf { DarkPal }

/** Hình chữ nhật vát góc (trên-phải và dưới-trái) đặc trưng của HUD Cyberpunk. */
private class CutShape(private val cutDp: Float) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val c = cutDp * density.density
        val path = Path().apply {
            moveTo(0f, 0f)
            lineTo(size.width - c, 0f)
            lineTo(size.width, c)
            lineTo(size.width, size.height)
            lineTo(c, size.height)
            lineTo(0f, size.height - c)
            close()
        }
        return Outline.Generic(path)
    }
}

private fun Modifier.scanlines(on: Boolean): Modifier = if (!on) this else drawBehind {
    val step = 6.dp.toPx()
    var y = 0f
    while (y < size.height) {
        drawLine(Color(0x0DFFFFFF), Offset(0f, y), Offset(size.width, y), 1f)
        y += step
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { App() } }
    }
}

// ───────────── Thành phần dùng chung ─────────────

@Composable
private fun T(
    text: String, color: Color = LocalPal.current.text, size: Int = 14,
    weight: FontWeight = FontWeight.Normal, modifier: Modifier = Modifier,
    align: TextAlign? = null, spacing: Int = 0
) = Text(
    text, color = color, fontSize = size.sp, fontWeight = weight, modifier = modifier,
    fontFamily = FontFamily.Monospace, textAlign = align, letterSpacing = spacing.sp
)

@Composable
private fun Panel(title: String? = null, content: @Composable ColumnScope.() -> Unit) {
    val p = LocalPal.current
    val shape = CutShape(16f)
    Column(
        Modifier.fillMaxWidth().clip(shape).background(p.panel).border(2.dp, p.line, shape).padding(18.dp)
    ) {
        if (title != null) {
            T("// $title", p.hi, 12, FontWeight.Bold, spacing = 2)
            Spacer(Modifier.height(12.dp))
        }
        content()
    }
}

@Composable
private fun Chip(text: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val p = LocalPal.current
    val shape = CutShape(8f)
    Box(
        modifier.clip(shape)
            .background(if (selected) p.accent else Color.Transparent)
            .border(1.5.dp, if (selected) p.accent else p.line, shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 10.dp)
    ) { T(text, if (selected) p.onAccent else p.muted, 13, FontWeight.Bold, spacing = 1) }
}

@Composable
private fun Tag(text: String, color: Color) {
    val shape = CutShape(6f)
    Box(
        Modifier.clip(shape).border(1.dp, color, shape).padding(horizontal = 8.dp, vertical = 4.dp)
    ) { T(text, color, 11, FontWeight.Bold, spacing = 1) }
}

@Composable
private fun NeonButton(text: String, busy: Boolean, onClick: () -> Unit) {
    val p = LocalPal.current
    val shape = CutShape(18f)
    Box(
        Modifier.fillMaxWidth().height(58.dp).clip(shape)
            .background(if (busy) p.muted else p.accent)
            .clickable(enabled = !busy, onClick = onClick),
        contentAlignment = Alignment.Center
    ) { T(text, p.onAccent, 16, FontWeight.Bold, spacing = 2) }
}

// ───────────── Khung ứng dụng ─────────────

@Composable
private fun App() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("ramc", Context.MODE_PRIVATE) }
    var dark by remember { mutableStateOf(prefs.getBoolean("dark", true)) }
    val pal = if (dark) DarkPal else LightPal
    val cleaner = remember { RamCleaner(context) }
    var tab by remember { mutableIntStateOf(0) }

    LaunchedEffect(dark) {
        val act = context as? ComponentActivity ?: return@LaunchedEffect
        val t = android.graphics.Color.TRANSPARENT
        val style = if (dark) SystemBarStyle.dark(t) else SystemBarStyle.light(t, t)
        act.enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
    }

    CompositionLocalProvider(LocalPal provides pal) {
        Column(Modifier.fillMaxSize().background(pal.bg).scanlines(dark).systemBarsPadding()) {
            Header(dark) {
                dark = !dark
                prefs.edit().putBoolean("dark", dark).apply()
            }
            Box(Modifier.weight(1f)) {
                if (tab == 0) OverviewScreen(cleaner) else ProcessScreen()
            }
            BottomBar(tab) { tab = it }
        }
    }
}

@Composable
private fun Header(dark: Boolean, onToggle: () -> Unit) {
    val p = LocalPal.current
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.weight(1f)) {
                if (dark) {
                    T("RAMC", p.c2, 36, FontWeight.Bold, Modifier.offset(x = (-2).dp), spacing = 3)
                    T("RAMC", p.c1, 36, FontWeight.Bold, Modifier.offset(x = 2.dp), spacing = 3)
                } else {
                    T("RAMC", p.c2, 36, FontWeight.Bold, Modifier.offset(x = 2.dp, y = 2.dp), spacing = 3)
                }
                T("RAMC", p.hi, 36, FontWeight.Bold, spacing = 3)
            }
            Chip(if (dark) "☀ SÁNG" else "☾ TỐI", selected = false, onClick = onToggle)
        }
        Spacer(Modifier.height(4.dp))
        T("// RAM CLEANER · ${Build.MODEL.uppercase()}", p.muted, 11, spacing = 1)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Tag("ANDROID ${Build.VERSION.RELEASE} · API ${Build.VERSION.SDK_INT}", p.c1)
            Tag("V6", p.c2)
        }
    }
}

@Composable
private fun BottomBar(selected: Int, onSelect: (Int) -> Unit) {
    val p = LocalPal.current
    val items = listOf("ϟ" to "TỔNG QUAN", "≣" to "TIẾN TRÌNH")
    Column(Modifier.fillMaxWidth().background(p.panel)) {
        Box(Modifier.fillMaxWidth().height(2.dp).background(p.line))
        Row(Modifier.fillMaxWidth()) {
            items.forEachIndexed { i, (icon, label) ->
                val on = i == selected
                Column(
                    Modifier.weight(1f).clickable { onSelect(i) },
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(Modifier.fillMaxWidth().height(3.dp).background(if (on) p.accent else Color.Transparent))
                    Spacer(Modifier.height(8.dp))
                    T(icon, if (on) p.hi else p.muted, 22)
                    T(label, if (on) p.hi else p.muted, 11, if (on) FontWeight.Bold else FontWeight.Normal, spacing = 1)
                    Spacer(Modifier.height(10.dp))
                }
            }
        }
    }
}

// ───────────── Tab Tổng quan ─────────────

@Composable
private fun OverviewScreen(cleaner: RamCleaner) {
    val p = LocalPal.current
    val scope = rememberCoroutineScope()
    var ram by remember { mutableStateOf(cleaner.readRam()) }
    var bd by remember { mutableStateOf(cleaner.readBreakdown()) }
    var cleaning by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<CleanResult?>(null) }
    val pageSize = remember { cleaner.pageSizeBytes() }

    LaunchedEffect(Unit) {
        while (true) {
            ram = cleaner.readRam(); bd = cleaner.readBreakdown(); delay(2000)
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Panel("TRẠNG THÁI RAM") {
            Gauge(ram)
            Spacer(Modifier.height(12.dp))
            T("PAGE SIZE: $pageSize BYTES", p.muted, 11, modifier = Modifier.fillMaxWidth(),
                align = TextAlign.Center, spacing = 1)
            Spacer(Modifier.height(16.dp))
            NeonButton(if (cleaning) "ĐANG DỌN..." else "ϟ  TĂNG TỐC RAM NGAY", cleaning) {
                scope.launch {
                    cleaning = true
                    result = cleaner.clean()
                    ram = cleaner.readRam()
                    cleaning = false
                }
            }
            result?.let {
                Spacer(Modifier.height(14.dp))
                T("ĐÃ DỪNG ${it.appsTargeted} ỨNG DỤNG NỀN\nGIẢI PHÓNG ${it.freedBytes.toMb()} MB",
                    p.c5, 13, FontWeight.Bold, Modifier.fillMaxWidth(), TextAlign.Center)
            }
        }

        Panel("PHÂN BỔ BỘ NHỚ") {
            Row {
                T("${ram.usedBytes.toMb()} / ${ram.totalBytes.toMb()} MB", p.muted, 12)
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth().height(14.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                Seg(bd.appsMb, p.c1); Seg(bd.cachedMb, p.c4); Seg(bd.kernelMb, p.c3); Seg(bd.freeMb, p.c5)
            }
            Spacer(Modifier.height(16.dp))
            Row {
                Legend("ỨNG DỤNG", bd.appsMb, p.c1, Modifier.weight(1f))
                Legend("ĐỆM", bd.cachedMb, p.c4, Modifier.weight(1f))
            }
            Spacer(Modifier.height(10.dp))
            Row {
                Legend("KERNEL", bd.kernelMb, p.c3, Modifier.weight(1f))
                Legend("TRỐNG", bd.freeMb, p.c5, Modifier.weight(1f))
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun RowScope.Seg(value: Long, color: Color) {
    Box(Modifier.weight(maxOf(value, 1L).toFloat()).fillMaxHeight().background(color))
}

@Composable
private fun Legend(name: String, mb: Long, color: Color, modifier: Modifier) {
    val p = LocalPal.current
    Column(modifier) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(10.dp).background(color))
            Spacer(Modifier.width(8.dp))
            T(name, p.muted, 11, spacing = 1)
        }
        T("${mb} MB", color, 15, FontWeight.Bold, Modifier.padding(start = 18.dp))
    }
}

@Composable
private fun Gauge(ram: RamInfo) {
    val p = LocalPal.current
    val prog by animateFloatAsState(ram.usedPercent, tween(800), label = "gauge")
    val ring = when {
        prog < 0.6f -> p.c1
        prog < 0.8f -> p.hi
        else -> p.c2
    }
    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Box(Modifier.size(250.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize().padding(16.dp)) {
                val w = 24f
                drawArc(p.line.copy(alpha = 0.35f), 135f, 270f, false, style = Stroke(w))
                drawArc(ring.copy(alpha = 0.22f), 135f, 270f * prog, false, style = Stroke(w + 14f))
                drawArc(ring, 135f, 270f * prog, false, style = Stroke(w))
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Row(verticalAlignment = Alignment.Bottom) {
                    T("${(prog * 100).toInt()}", p.text, 56, FontWeight.Bold)
                    T("%", p.c2, 22, FontWeight.Bold, Modifier.padding(bottom = 10.dp))
                }
                val gb = 1024.0 * 1024 * 1024
                T("%.1f / %.1f GB".format(ram.usedBytes / gb, ram.totalBytes / gb), p.c1, 14, FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                T("TRỐNG %.1f GB".format(ram.availBytes / gb), p.hi, 13)
            }
        }
    }
}

// ───────────── Tab Tiến trình (pm trim-caches) ─────────────

private fun gbText(bytes: Long) = "%.1f GB".format(bytes / 1024.0 / 1024 / 1024)

private fun unitBytes(unit: String): Double = if (unit == "GB") 1024.0 * 1024 * 1024 else 1024.0 * 1024

private fun fmtAmount(v: Double, unit: String): String = when {
    unit == "MB" -> v.roundToLong().toString()
    v % 1.0 == 0.0 -> v.toLong().toString()
    else -> "%.1f".format(Locale.US, v)
}

@Composable
private fun ProcessScreen() {
    val p = LocalPal.current
    val scope = rememberCoroutineScope()
    var unit by remember { mutableStateOf("GB") }
    var text by remember { mutableStateOf("5") }
    var all by remember { mutableStateOf(false) }
    var running by remember { mutableStateOf(false) }
    var granted by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var free by remember { mutableLongStateOf(Storage.freeBytes()) }
    var report by remember { mutableStateOf<String?>(null) }
    var reportOk by remember { mutableStateOf(true) }
    val total = remember { Storage.totalBytes() }

    LaunchedEffect(Unit) {
        while (true) {
            running = ShizukuHelper.isRunning()
            granted = running && ShizukuHelper.hasPermission()
            if (!busy) free = Storage.freeBytes()
            delay(1000)
        }
    }

    val ub = unitBytes(unit)
    val maxUnits = total / ub
    val amount = (text.replace(',', '.').toDoubleOrNull() ?: 0.0).coerceIn(0.0, maxUnits)
    val amountBytes = (amount * ub).toLong()
    val mb = 1024L * 1024
    val desiredFreeMb = if (all) total / mb else (free + amountBytes) / mb
    val command = "pm trim-caches ${desiredFreeMb}M"

    fun switchUnit(new: String) {
        if (new == unit) return
        val bytes = amount * ub
        unit = new
        text = fmtAmount(bytes / unitBytes(new), new)
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Panel("DỌN BỘ NHỚ ĐỆM") {
            Row(verticalAlignment = Alignment.Top) {
                val iconShape = CutShape(8f)
                Box(
                    Modifier.size(52.dp).clip(iconShape).background(p.panel2).border(1.5.dp, p.c4, iconShape),
                    contentAlignment = Alignment.Center
                ) { T("▤", p.c4, 26) }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    T("DỌN CACHE ỨNG DỤNG", p.text, 15, FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                    T("Xóa cache của app hệ thống và bên thứ ba để lấy lại dung lượng lưu trữ.", p.muted, 12)
                }
            }
            Spacer(Modifier.height(14.dp))
            val (label, color) = when {
                !running -> "SHIZUKU CHƯA CHẠY" to p.c2
                !granted -> "CHƯA CẤP QUYỀN SHIZUKU" to p.c4
                else -> "SHIZUKU SẴN SÀNG" to p.c5
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(10.dp).background(color))
                Spacer(Modifier.width(8.dp))
                T(label, color, 12, FontWeight.Bold, spacing = 1)
            }
        }

        Panel("SỐ LƯỢNG CẦN DỌN") {
            Row {
                T("BỘ NHỚ TRỐNG", p.muted, 12, modifier = Modifier.weight(1f))
                T("${gbText(free)} / ${gbText(total)}", p.c1, 12, FontWeight.Bold)
            }
            Spacer(Modifier.height(16.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                val boxShape = CutShape(10f)
                Box(
                    Modifier.weight(1f).clip(boxShape).background(p.panel2)
                        .border(1.5.dp, if (all) p.line else p.hi, boxShape)
                        .padding(horizontal = 14.dp, vertical = 12.dp)
                ) {
                    BasicTextField(
                        value = if (all) "TẤT CẢ" else text,
                        onValueChange = { v ->
                            if (v.length <= 9 && v.all { it.isDigit() || it == '.' || it == ',' }) {
                                val n = v.replace(',', '.').toDoubleOrNull()
                                text = if (n != null && n > maxUnits) fmtAmount(maxUnits, unit) else v
                            }
                        },
                        enabled = !all,
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        textStyle = TextStyle(
                            color = if (all) p.muted else p.hi, fontSize = 22.sp,
                            fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace
                        ),
                        cursorBrush = SolidColor(p.hi),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                Spacer(Modifier.width(10.dp))
                Chip("GB", unit == "GB", { switchUnit("GB") })
                Spacer(Modifier.width(6.dp))
                Chip("MB", unit == "MB", { switchUnit("MB") })
            }

            Spacer(Modifier.height(8.dp))
            Slider(
                value = amount.toFloat().coerceIn(0f, maxUnits.toFloat()),
                onValueChange = { text = fmtAmount(it.toDouble(), unit) },
                valueRange = 0f..maxUnits.toFloat(),
                enabled = !all,
                colors = SliderDefaults.colors(
                    thumbColor = p.accent, activeTrackColor = p.accent,
                    inactiveTrackColor = p.line.copy(alpha = 0.35f),
                    disabledThumbColor = p.muted, disabledActiveTrackColor = p.muted.copy(alpha = 0.5f),
                    disabledInactiveTrackColor = p.line.copy(alpha = 0.25f)
                )
            )
            Row {
                T("0", p.muted, 11, modifier = Modifier.weight(1f))
                T("${fmtAmount(maxUnits, unit)} $unit", p.muted, 11)
            }

            Spacer(Modifier.height(12.dp))
            Chip("DỌN TẤT CẢ CACHE", all, { all = !all })

            Spacer(Modifier.height(16.dp))
            val cmdShape = CutShape(8f)
            Box(
                Modifier.fillMaxWidth().clip(cmdShape).background(p.panel2)
                    .border(1.dp, p.line, cmdShape).padding(12.dp)
            ) { T("$ $command", p.c1, 13, FontWeight.Bold) }

            Spacer(Modifier.height(16.dp))
            NeonButton(
                when {
                    busy -> "ĐANG DỌN..."
                    running && !granted -> "CẤP QUYỀN SHIZUKU"
                    else -> "DỌN BỘ NHỚ ĐỆM"
                },
                busy
            ) {
                when {
                    !all && amountBytes <= 0L -> {
                        reportOk = false
                        report = "Nhập số lượng lớn hơn 0 hoặc bật Dọn tất cả cache."
                    }
                    !running -> {
                        reportOk = false
                        report = "Shizuku chưa chạy. Mở ứng dụng Shizuku và khởi động dịch vụ (gỡ lỗi không dây hoặc root), rồi quay lại đây."
                    }
                    !granted -> ShizukuHelper.requestPermission()
                    else -> scope.launch {
                        busy = true
                        val before = Storage.freeBytes()
                        val (code, out) = ShizukuHelper.exec(command)
                        delay(500)
                        val after = Storage.freeBytes()
                        free = after
                        reportOk = code == 0
                        report = if (code == 0)
                            "GIẢI PHÓNG ${gbText((after - before).coerceAtLeast(0))}\nTRỐNG: ${gbText(before)} → ${gbText(after)}"
                        else "LỖI ($code): $out"
                        busy = false
                    }
                }
            }
            report?.let {
                Spacer(Modifier.height(14.dp))
                T(it, if (reportOk) p.c5 else p.c2, 13, FontWeight.Bold, Modifier.fillMaxWidth(), TextAlign.Center)
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}
