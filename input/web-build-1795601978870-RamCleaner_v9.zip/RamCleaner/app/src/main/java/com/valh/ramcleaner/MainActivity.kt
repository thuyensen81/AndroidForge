package com.valh.ramcleaner

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.roundToInt
import kotlin.math.roundToLong

// ═════════════ Bảng màu: kính lỏng (liquid glass) sáng / tối ═════════════

data class Pal(
    val dark: Boolean,
    val base: Color, val b1: Color, val b2: Color, val b3: Color,
    val glass: Color, val sheen: Color, val edgeTop: Color, val edgeBottom: Color,
    val text: Color, val sub: Color,
    val accent: Color, val accent2: Color,
    val ok: Color, val warn: Color, val bad: Color,
    val track: Color, val tile: Color
)

private val LightPal = Pal(
    dark = false,
    base = Color(0xFFEAF0FA), b1 = Color(0xFF8FB4FF), b2 = Color(0xFFC7A8FF), b3 = Color(0xFF8FE6D6),
    glass = Color(0xA6FFFFFF), sheen = Color(0xD9FFFFFF), edgeTop = Color(0xF2FFFFFF), edgeBottom = Color(0x66FFFFFF),
    text = Color(0xFF0F1724), sub = Color(0xFF5B6678),
    accent = Color(0xFF2F6BFF), accent2 = Color(0xFF8B5CF6),
    ok = Color(0xFF12B76A), warn = Color(0xFFF79009), bad = Color(0xFFF04438),
    track = Color(0x1A0F1724), tile = Color(0x80FFFFFF)
)

private val DarkPal = Pal(
    dark = true,
    base = Color(0xFF080B14), b1 = Color(0xFF2F4FD0), b2 = Color(0xFF6B3FD4), b3 = Color(0xFF0C8F85),
    glass = Color(0x1FFFFFFF), sheen = Color(0x2EFFFFFF), edgeTop = Color(0x55FFFFFF), edgeBottom = Color(0x14FFFFFF),
    text = Color(0xFFF4F6FB), sub = Color(0xFF9AA6BC),
    accent = Color(0xFF5B8CFF), accent2 = Color(0xFFA78BFA),
    ok = Color(0xFF32D583), warn = Color(0xFFFDB022), bad = Color(0xFFF97066),
    track = Color(0x26FFFFFF), tile = Color(0x14FFFFFF)
)

private val LocalPal = compositionLocalOf { DarkPal }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { App() } }
    }
}

// ═════════════ Chuyển động: một hồ sơ lò xo thống nhất (Origin Animation) ═════════════

private fun <T> originSpring() = spring<T>(dampingRatio = 0.82f, stiffness = 380f)
private fun <T> softSpring() = spring<T>(dampingRatio = 1f, stiffness = 140f)

@Composable
private fun anim(c: Color): Color = animateColorAsState(c, tween(500), label = "pal").value

@Composable
private fun animatedPal(t: Pal): Pal = Pal(
    t.dark, anim(t.base), anim(t.b1), anim(t.b2), anim(t.b3),
    anim(t.glass), anim(t.sheen), anim(t.edgeTop), anim(t.edgeBottom),
    anim(t.text), anim(t.sub), anim(t.accent), anim(t.accent2),
    anim(t.ok), anim(t.warn), anim(t.bad), anim(t.track), anim(t.tile)
)

/** Nhấn xuống: co lại bằng lò xo, gợn sóng lan từ điểm chạm, thả ra thì nảy như thạch. */
@Composable
private fun Modifier.glassClick(
    shape: Shape, enabled: Boolean = true, rippleColor: Color? = null, onClick: () -> Unit
): Modifier {
    val p = LocalPal.current
    val rc = rippleColor ?: if (p.dark) Color.White else p.accent
    val scale = remember { Animatable(1f) }
    val ripple = remember { Animatable(0f) }
    val rippleAlpha = remember { Animatable(0f) }
    var origin by remember { mutableStateOf(Offset.Zero) }
    val scope = rememberCoroutineScope()
    val onClickState by rememberUpdatedState(onClick)
    return this
        .graphicsLayer { scaleX = scale.value; scaleY = scale.value }
        .clip(shape)
        .drawWithContent {
            drawContent()
            val a = rippleAlpha.value
            if (a > 0.01f) {
                val r = (ripple.value * size.maxDimension * 1.3f).coerceAtLeast(1f)
                drawCircle(
                    Brush.radialGradient(
                        listOf(rc.copy(alpha = 0.34f * a), Color.Transparent), center = origin, radius = r
                    ),
                    radius = r, center = origin
                )
            }
        }
        .pointerInput(enabled) {
            if (enabled) {
                detectTapGestures(
                    onPress = { off ->
                        origin = off
                        scope.launch { scale.animateTo(0.94f, spring(dampingRatio = 0.6f, stiffness = 600f)) }
                        scope.launch {
                            ripple.snapTo(0f)
                            rippleAlpha.snapTo(1f)
                            ripple.animateTo(1f, tween(550, easing = FastOutSlowInEasing))
                        }
                        tryAwaitRelease()
                        scope.launch { scale.animateTo(1f, spring(dampingRatio = 0.42f, stiffness = 380f)) }
                        scope.launch { rippleAlpha.animateTo(0f, tween(380)) }
                    },
                    onTap = { onClickState() }
                )
            }
        }
}

/** Hiện dần, trượt lên và phóng nhẹ, mỗi phần tử trễ hơn một nhịp. */
@Composable
private fun Modifier.enter(index: Int): Modifier {
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay(index * 70L)
        a.animateTo(1f, spring(dampingRatio = 0.8f, stiffness = 200f))
    }
    return this.graphicsLayer {
        alpha = a.value.coerceIn(0f, 1f)
        translationY = (1f - a.value) * 80f
        val s = 0.94f + 0.06f * a.value
        scaleX = s
        scaleY = s
    }
}

// ═════════════ Nền ánh sáng trôi chậm ═════════════

@Composable
private fun LiquidBackground(p: Pal) {
    val inf = rememberInfiniteTransition(label = "bg")
    val t1 by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(18000, easing = LinearEasing), RepeatMode.Reverse), label = "t1")
    val t2 by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(23000, easing = LinearEasing), RepeatMode.Reverse), label = "t2")
    val t3 by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(29000, easing = LinearEasing), RepeatMode.Reverse), label = "t3")
    Canvas(Modifier.fillMaxSize()) {
        drawRect(p.base)
        val w = size.width
        val h = size.height
        val a = if (p.dark) 0.55f else 0.75f
        fun blob(c: Color, cx: Float, cy: Float, r: Float) {
            drawCircle(
                Brush.radialGradient(listOf(c.copy(alpha = a), Color.Transparent), center = Offset(cx, cy), radius = r),
                radius = r, center = Offset(cx, cy)
            )
        }
        blob(p.b1, w * (0.15f + 0.5f * t1), h * (0.12f + 0.15f * t2), w * 0.75f)
        blob(p.b2, w * (0.95f - 0.5f * t2), h * (0.45f + 0.2f * t3), w * 0.8f)
        blob(p.b3, w * (0.2f + 0.4f * t3), h * (0.95f - 0.2f * t1), w * 0.8f)
    }
}

// ═════════════ Thành phần giao diện ═════════════

@Composable
private fun T(
    text: String, size: Int = 14, weight: FontWeight = FontWeight.Normal,
    color: Color = LocalPal.current.text, modifier: Modifier = Modifier, align: TextAlign? = null
) = Text(
    text, color = color, fontSize = size.sp, fontWeight = weight, modifier = modifier,
    textAlign = align, lineHeight = (size * 1.35f).sp
)

@Composable
private fun Glass(
    modifier: Modifier = Modifier, radius: Int = 28, pad: Int = 18, index: Int = -1,
    content: @Composable ColumnScope.() -> Unit
) {
    val p = LocalPal.current
    val shape = RoundedCornerShape(radius.dp)
    var m = modifier
    if (index >= 0) m = m.enter(index)
    Column(
        m.fillMaxWidth()
            .then(
                if (!p.dark) Modifier.shadow(
                    14.dp, shape, clip = false,
                    ambientColor = Color(0x1A2A4BA0), spotColor = Color(0x262A4BA0)
                ) else Modifier
            )
            .clip(shape)
            .background(Brush.verticalGradient(listOf(p.sheen, p.glass)))
            .border(1.dp, Brush.verticalGradient(listOf(p.edgeTop, p.edgeBottom)), shape)
            .padding(pad.dp),
        content = content
    )
}

@Composable
private fun Pill(text: String, color: Color) {
    Box(
        Modifier.clip(RoundedCornerShape(50)).background(color.copy(alpha = 0.16f))
            .padding(horizontal = 12.dp, vertical = 5.dp)
    ) { T(text, 12, FontWeight.SemiBold, color) }
}

@Composable
private fun PrimaryButton(text: String, busy: Boolean = false, onClick: () -> Unit) {
    val p = LocalPal.current
    val shape = RoundedCornerShape(50)
    val inf = rememberInfiniteTransition(label = "pb")
    val flow by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(2600, easing = LinearEasing)), label = "flow")
    val dots by inf.animateFloat(0f, 3.99f, infiniteRepeatable(tween(1200, easing = LinearEasing)), label = "dots")
    val fade by animateFloatAsState(if (busy) 0.78f else 1f, softSpring(), label = "pbFade")
    val n = dots.toInt()
    Box(
        Modifier.fillMaxWidth().height(58.dp)
            .graphicsLayer { alpha = fade }
            .shadow(
                16.dp, shape, clip = false,
                ambientColor = p.accent.copy(alpha = 0.3f), spotColor = p.accent.copy(alpha = 0.55f)
            )
            .glassClick(shape, enabled = !busy, rippleColor = Color.White, onClick = onClick)
            .background(Brush.horizontalGradient(listOf(p.accent, p.accent2)))
            .drawBehind {
                val x = flow * (size.width + 300f) - 150f
                drawRect(
                    Brush.horizontalGradient(
                        listOf(Color.Transparent, Color.White.copy(alpha = 0.28f), Color.Transparent),
                        startX = x - 100f, endX = x + 100f
                    )
                )
            },
        contentAlignment = Alignment.Center
    ) {
        T(
            if (busy) text + ".".repeat(n) + " ".repeat(3 - n) else text,
            17, FontWeight.SemiBold, Color.White
        )
    }
}

@Composable
private fun SecondaryButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val p = LocalPal.current
    val shape = RoundedCornerShape(50)
    Box(
        modifier.glassClick(shape, onClick = onClick)
            .background(p.tile)
            .border(1.dp, Brush.verticalGradient(listOf(p.edgeTop, p.edgeBottom)), shape)
            .padding(horizontal = 14.dp, vertical = 14.dp),
        contentAlignment = Alignment.Center
    ) { T(text, 13, FontWeight.SemiBold, p.accent, align = TextAlign.Center) }
}

@Composable
private fun Segmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    val p = LocalPal.current
    val shape = RoundedCornerShape(50)
    val frac by animateFloatAsState(selected.toFloat(), originSpring(), label = "seg")
    Box(modifier.height(42.dp).clip(shape).background(p.track)) {
        BoxWithConstraints(Modifier.fillMaxSize().padding(3.dp)) {
            val w = maxWidth / options.size
            Box(
                Modifier.offset(x = w * frac).width(w).fillMaxHeight().clip(shape)
                    .background(if (p.dark) Color(0x33FFFFFF) else Color.White)
            )
            Row(Modifier.fillMaxSize()) {
                options.forEachIndexed { i, label ->
                    val c by animateColorAsState(if (i == selected) p.text else p.sub, tween(250), label = "segC")
                    Box(
                        Modifier.weight(1f).fillMaxHeight().clickable(
                            interactionSource = remember { MutableInteractionSource() }, indication = null
                        ) { onSelect(i) },
                        contentAlignment = Alignment.Center
                    ) { T(label, 14, FontWeight.Medium, c) }
                }
            }
        }
    }
}

@Composable
private fun GlassSwitch(checked: Boolean, onChange: (Boolean) -> Unit) {
    val p = LocalPal.current
    val pos by animateFloatAsState(
        if (checked) 1f else 0f, spring(dampingRatio = 0.6f, stiffness = 500f), label = "sw"
    )
    val track by animateColorAsState(if (checked) p.ok else p.track, tween(250), label = "swT")
    Box(
        Modifier.width(54.dp).height(32.dp).clip(RoundedCornerShape(50)).background(track)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
                onChange(!checked)
            }
    ) {
        Box(Modifier.offset(x = 3.dp + 22.dp * pos, y = 3.dp).size(26.dp).background(Color.White, CircleShape))
    }
}

@Composable
private fun StatusRow(label: String, ok: Boolean, onText: String, offText: String) {
    val p = LocalPal.current
    val c by animateColorAsState(if (ok) p.ok else p.bad, tween(300), label = "st")
    Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
        T(label, 14, FontWeight.Normal, p.text, Modifier.weight(1f))
        Pill(if (ok) onText else offText, c)
    }
}

@Composable
private fun Step(n: Int, text: String) {
    val p = LocalPal.current
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.Top) {
        Box(
            Modifier.size(24.dp).clip(CircleShape).background(p.accent.copy(alpha = 0.16f)),
            contentAlignment = Alignment.Center
        ) { T("$n", 12, FontWeight.Bold, p.accent) }
        Spacer(Modifier.width(12.dp))
        T(text, 13, FontWeight.Normal, p.text, Modifier.weight(1f).padding(top = 2.dp))
    }
}

// ═════════════ Biểu tượng vẽ tay ═════════════

@Composable
private fun RingIcon(color: Color) {
    Canvas(Modifier.size(26.dp)) {
        val sw = 2.6.dp.toPx()
        drawArc(
            color, 135f, 270f, false, Offset(sw, sw), Size(size.width - 2 * sw, size.height - 2 * sw),
            style = Stroke(sw, cap = StrokeCap.Round)
        )
        drawCircle(color, radius = 2.2.dp.toPx())
    }
}

@Composable
private fun PillIcon(color: Color, modifier: Modifier = Modifier.size(26.dp)) {
    Canvas(modifier) {
        val w = size.width
        val ch = w * 0.46f
        val top = (w - ch) / 2f
        val r = CornerRadius(ch / 2f, ch / 2f)
        rotate(-45f) {
            val left = Path().apply {
                addRoundRect(RoundRect(0f, top, w / 2f, top + ch, r, CornerRadius.Zero, CornerRadius.Zero, r))
            }
            drawPath(left, color)
            drawRoundRect(color, topLeft = Offset(0f, top), size = Size(w, ch), cornerRadius = r, style = Stroke(3f))
            drawLine(color, Offset(w / 2f, top), Offset(w / 2f, top + ch), 3f)
        }
    }
}

@Composable
private fun TermIcon(color: Color) {
    Canvas(Modifier.size(26.dp)) {
        val sw = 2.6.dp.toPx()
        val w = size.width
        val h = size.height
        drawLine(color, Offset(w * 0.18f, h * 0.28f), Offset(w * 0.42f, h * 0.5f), sw, StrokeCap.Round)
        drawLine(color, Offset(w * 0.42f, h * 0.5f), Offset(w * 0.18f, h * 0.72f), sw, StrokeCap.Round)
        drawLine(color, Offset(w * 0.52f, h * 0.74f), Offset(w * 0.84f, h * 0.74f), sw, StrokeCap.Round)
    }
}

// ═════════════ Khung ứng dụng ═════════════

@Composable
private fun App() {
    val context = LocalContext.current
    val systemDark = isSystemInDarkTheme()
    val prefs = remember { context.getSharedPreferences("ramc", Context.MODE_PRIVATE) }
    var dark by remember {
        mutableStateOf(if (prefs.contains("dark2")) prefs.getBoolean("dark2", false) else systemDark)
    }
    val pal = animatedPal(if (dark) DarkPal else LightPal)
    val cleaner = remember { RamCleaner(context) }
    var tab by remember { mutableIntStateOf(0) }

    LaunchedEffect(dark) {
        val act = context as? ComponentActivity ?: return@LaunchedEffect
        val t = android.graphics.Color.TRANSPARENT
        val style = if (dark) SystemBarStyle.dark(t) else SystemBarStyle.light(t, t)
        act.enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
    }

    CompositionLocalProvider(LocalPal provides pal) {
        Box(Modifier.fillMaxSize()) {
            LiquidBackground(pal)
            Column(Modifier.fillMaxSize().statusBarsPadding()) {
                TopBar(tab, dark) {
                    dark = !dark
                    prefs.edit().putBoolean("dark2", dark).apply()
                }
                AnimatedContent(
                    targetState = tab,
                    modifier = Modifier.weight(1f),
                    transitionSpec = {
                        val dir = if (targetState > initialState) 1 else -1
                        (slideInHorizontally(originSpring()) { w -> w * dir / 5 } +
                            fadeIn(softSpring()) +
                            scaleIn(originSpring(), initialScale = 0.94f)) togetherWith
                            (slideOutHorizontally(tween(260, easing = FastOutSlowInEasing)) { w -> -w * dir / 6 } +
                                fadeOut(tween(180)) +
                                scaleOut(tween(260), targetScale = 0.96f))
                    },
                    label = "tabs"
                ) { t ->
                    when (t) {
                        0 -> OverviewScreen(cleaner)
                        1 -> ProcessScreen()
                        else -> ShizukuScreen()
                    }
                }
            }
            Box(Modifier.align(Alignment.BottomCenter).navigationBarsPadding()) {
                NavBar(tab) { tab = it }
            }
        }
    }
}

@Composable
private fun TopBar(tab: Int, dark: Boolean, onToggle: () -> Unit) {
    val p = LocalPal.current
    val titles = listOf("Tổng quan", "Tiến trình", "Shizuku / ADB")
    val subs = listOf("Tình trạng RAM theo thời gian thực", "Dọn bộ nhớ đệm ứng dụng", "Kết nối và cấp quyền")
    Row(
        Modifier.fillMaxWidth().padding(start = 24.dp, end = 20.dp, top = 12.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.weight(1f)) {
            AnimatedContent(
                targetState = tab,
                transitionSpec = {
                    (fadeIn(softSpring()) + slideInVertically(originSpring()) { h -> h / 3 }) togetherWith
                        (fadeOut(tween(150)) + slideOutVertically(tween(200)) { h -> -h / 3 })
                },
                label = "title"
            ) { t ->
                Column {
                    T(titles[t], 32, FontWeight.Bold)
                    T(subs[t], 13, FontWeight.Normal, p.sub)
                }
            }
        }
        ThemeButton(dark, onToggle)
    }
}

@Composable
private fun ThemeButton(dark: Boolean, onToggle: () -> Unit) {
    val p = LocalPal.current
    val rot by animateFloatAsState(
        if (dark) 0f else 180f, spring(dampingRatio = 0.6f, stiffness = 200f), label = "rot"
    )
    Box(
        Modifier.size(46.dp)
            .glassClick(CircleShape, onClick = onToggle)
            .background(Brush.verticalGradient(listOf(p.sheen, p.glass)))
            .border(1.dp, Brush.verticalGradient(listOf(p.edgeTop, p.edgeBottom)), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        T("◐", 22, FontWeight.Normal, p.text, Modifier.graphicsLayer { rotationZ = rot })
    }
}

// ═════════════ Thanh điều hướng kính với "thấu kính lỏng" trượt ═════════════

@Composable
private fun NavItem(
    label: String, on: Boolean, modifier: Modifier, icon: @Composable (Color) -> Unit, onClick: () -> Unit
) {
    val p = LocalPal.current
    val c by animateColorAsState(if (on) p.accent else p.sub, tween(300), label = "navC")
    val scale by animateFloatAsState(
        if (on) 1.12f else 1f, spring(dampingRatio = 0.5f, stiffness = 400f), label = "navS"
    )
    Column(
        modifier.fillMaxHeight().clickable(
            interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick
        ),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(Modifier.graphicsLayer { scaleX = scale; scaleY = scale }) { icon(c) }
        Spacer(Modifier.height(2.dp))
        T(label, 11, FontWeight.Medium, c)
    }
}

@Composable
private fun NavBar(selected: Int, onSelect: (Int) -> Unit) {
    val p = LocalPal.current
    val density = LocalDensity.current
    val shape = RoundedCornerShape(50)
    val left = remember { Animatable(0f) }
    val right = remember { Animatable(0f) }
    var barW by remember { mutableFloatStateOf(0f) }
    val itemW = barW / 3f

    // Cạnh dẫn đầu chạy nhanh, cạnh theo sau chạy chậm: thấu kính giãn ra rồi co lại như chất lỏng.
    LaunchedEffect(selected, barW) {
        if (barW > 0f) {
            val tl = selected * itemW
            val tr = tl + itemW
            if (right.value == 0f) {
                left.snapTo(tl)
                right.snapTo(tr)
            } else {
                val goingRight = tl > left.value
                launch { left.animateTo(tl, spring(dampingRatio = 0.72f, stiffness = if (goingRight) 160f else 520f)) }
                launch { right.animateTo(tr, spring(dampingRatio = 0.72f, stiffness = if (goingRight) 520f else 160f)) }
            }
        }
    }

    Box(Modifier.enter(3).fillMaxWidth().padding(horizontal = 22.dp, vertical = 12.dp)) {
        Box(
            Modifier.fillMaxWidth().height(68.dp)
                .then(
                    if (!p.dark) Modifier.shadow(
                        18.dp, shape, clip = false,
                        ambientColor = Color(0x1A2A4BA0), spotColor = Color(0x332A4BA0)
                    ) else Modifier
                )
                .clip(shape)
                .background(Brush.verticalGradient(listOf(p.base.copy(alpha = 0.80f), p.base.copy(alpha = 0.92f))))
                .border(1.dp, Brush.verticalGradient(listOf(p.edgeTop, p.edgeBottom)), shape)
        ) {
            Box(Modifier.fillMaxSize().padding(5.dp).onSizeChanged { barW = it.width.toFloat() }) {
                val lensW = with(density) { (right.value - left.value).coerceAtLeast(0f).toDp() }
                Box(
                    Modifier.offset { IntOffset(left.value.roundToInt(), 0) }
                        .width(lensW).fillMaxHeight().clip(shape)
                        .background(p.accent.copy(alpha = if (p.dark) 0.28f else 0.16f))
                        .border(1.dp, p.accent.copy(alpha = 0.35f), shape)
                )
                Row(Modifier.fillMaxSize()) {
                    NavItem("Tổng quan", selected == 0, Modifier.weight(1f), { c -> RingIcon(c) }) { onSelect(0) }
                    NavItem("Tiến trình", selected == 1, Modifier.weight(1f), { c -> PillIcon(c) }) { onSelect(1) }
                    NavItem("Shizuku/ADB", selected == 2, Modifier.weight(1f), { c -> TermIcon(c) }) { onSelect(2) }
                }
            }
        }
    }
}

// ═════════════ Tab Tổng quan ═════════════

@Composable
private fun OverviewScreen(cleaner: RamCleaner) {
    val p = LocalPal.current
    val scope = rememberCoroutineScope()
    var ram by remember { mutableStateOf(cleaner.readRam()) }
    var bd by remember { mutableStateOf(cleaner.readBreakdown()) }
    var cleaning by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<CleanResult?>(null) }
    val pageSize = remember { cleaner.pageSizeBytes() }

    LaunchedEffect(Unit) {
        while (true) {
            ram = cleaner.readRam()
            bd = cleaner.readBreakdown()
            delay(2000)
        }
    }

    val gb = 1024f * 1024f * 1024f
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Glass(index = 0, radius = 36, pad = 20) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                T("Bộ nhớ RAM", 17, FontWeight.SemiBold, modifier = Modifier.weight(1f))
                val level = when {
                    ram.usedPercent < 0.6f -> "Thoải mái" to p.ok
                    ram.usedPercent < 0.8f -> "Vừa phải" to p.warn
                    else -> "Cao" to p.bad
                }
                Pill(level.first, level.second)
            }
            Gauge(ram)
            Spacer(Modifier.height(16.dp))
            PrimaryButton(if (cleaning) "Đang dọn" else "Tăng tốc RAM", cleaning) {
                scope.launch {
                    cleaning = true
                    result = cleaner.clean()
                    ram = cleaner.readRam()
                    cleaning = false
                }
            }
            AnimatedVisibility(
                visible = result != null,
                enter = fadeIn(softSpring()) + expandVertically(originSpring())
            ) {
                val r = result
                if (r != null) {
                    var tgt by remember { mutableIntStateOf(0) }
                    LaunchedEffect(r) { tgt = r.freedBytes.toMb().toInt() }
                    val shown by animateIntAsState(tgt, softSpring(), label = "freed")
                    Column {
                        Spacer(Modifier.height(14.dp))
                        T(
                            "Đã dừng ${r.appsTargeted} ứng dụng nền, giải phóng $shown MB",
                            13, FontWeight.Medium, p.ok, Modifier.fillMaxWidth(), TextAlign.Center
                        )
                    }
                }
            }
        }

        Row(Modifier.fillMaxWidth().enter(1), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            StatTile("Đã dùng", ram.usedBytes / gb, p.accent, ram.usedPercent, Modifier.weight(1f))
            StatTile("Còn trống", ram.availBytes / gb, p.ok, 1f - ram.usedPercent, Modifier.weight(1f))
        }

        Glass(index = 2, radius = 32) {
            T("Phân bổ bộ nhớ", 16, FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            T("${ram.usedBytes.toMb()} / ${ram.totalBytes.toMb()} MB", 12, FontWeight.Normal, p.sub)
            Spacer(Modifier.height(14.dp))
            Row(
                Modifier.fillMaxWidth().height(12.dp).clip(CircleShape),
                horizontalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Seg(bd.appsMb, p.accent)
                Seg(bd.cachedMb, p.warn)
                Seg(bd.kernelMb, p.accent2)
                Seg(bd.freeMb, p.ok)
            }
            Spacer(Modifier.height(16.dp))
            Row {
                Legend("Ứng dụng", bd.appsMb, p.accent, Modifier.weight(1f))
                Legend("Bộ nhớ đệm", bd.cachedMb, p.warn, Modifier.weight(1f))
            }
            Spacer(Modifier.height(12.dp))
            Row {
                Legend("Kernel", bd.kernelMb, p.accent2, Modifier.weight(1f))
                Legend("Trống", bd.freeMb, p.ok, Modifier.weight(1f))
            }
        }

        Row(Modifier.fillMaxWidth().enter(3), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            InfoTile("Kích thước trang", "$pageSize B", Modifier.weight(1f))
            InfoTile("Android", "${Build.VERSION.RELEASE} · API ${Build.VERSION.SDK_INT}", Modifier.weight(1f))
        }
        Spacer(Modifier.height(130.dp))
    }
}

@Composable
private fun StatTile(title: String, gbValue: Float, color: Color, frac: Float, modifier: Modifier) {
    val p = LocalPal.current
    val shown by animateFloatAsState(gbValue, softSpring(), label = "tileV")
    val f by animateFloatAsState(frac.coerceIn(0f, 1f), softSpring(), label = "tileF")
    Glass(modifier, radius = 28, pad = 16) {
        T(title, 13, FontWeight.Medium, p.sub)
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.Bottom) {
            T("%.1f".format(shown), 30, FontWeight.SemiBold)
            Spacer(Modifier.width(4.dp))
            T("GB", 14, FontWeight.Medium, p.sub, Modifier.padding(bottom = 5.dp))
        }
        Spacer(Modifier.height(10.dp))
        Box(Modifier.fillMaxWidth().height(6.dp).clip(CircleShape).background(p.track)) {
            Box(Modifier.fillMaxWidth(f).fillMaxHeight().clip(CircleShape).background(color))
        }
    }
}

@Composable
private fun InfoTile(title: String, value: String, modifier: Modifier) {
    val p = LocalPal.current
    Glass(modifier, radius = 26, pad = 16) {
        T(title, 12, FontWeight.Medium, p.sub)
        Spacer(Modifier.height(4.dp))
        T(value, 15, FontWeight.SemiBold)
    }
}

@Composable
private fun RowScope.Seg(value: Long, color: Color) {
    val w by animateFloatAsState(maxOf(value, 1L).toFloat(), softSpring(), label = "seg")
    Box(Modifier.weight(w).fillMaxHeight().background(color))
}

@Composable
private fun Legend(name: String, mb: Long, color: Color, modifier: Modifier) {
    val p = LocalPal.current
    val shown by animateIntAsState(mb.toInt(), softSpring(), label = "legend")
    Column(modifier) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(10.dp).background(color, CircleShape))
            Spacer(Modifier.width(8.dp))
            T(name, 12, FontWeight.Medium, p.sub)
        }
        T("$shown MB", 16, FontWeight.SemiBold, modifier = Modifier.padding(start = 18.dp))
    }
}

@Composable
private fun Gauge(ram: RamInfo) {
    val p = LocalPal.current
    var target by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(ram.usedPercent) { target = ram.usedPercent }
    val prog by animateFloatAsState(target, spring(dampingRatio = 0.75f, stiffness = 55f), label = "gauge")
    val pct by animateIntAsState((target * 100).toInt(), spring(dampingRatio = 1f, stiffness = 55f), label = "pct")
    val ring by animateColorAsState(
        when {
            target < 0.6f -> p.accent
            target < 0.8f -> p.warn
            else -> p.bad
        },
        tween(600), label = "ring"
    )
    val inf = rememberInfiniteTransition(label = "gauge-inf")
    val breathe by inf.animateFloat(
        0.9f, 1.05f, infiniteRepeatable(tween(2800, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "breathe"
    )

    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Box(Modifier.size(240.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize().padding(10.dp)) {
                val sw = 22.dp.toPx()
                val tl = Offset(sw / 2f, sw / 2f)
                val arcSize = Size(size.width - sw, size.height - sw)
                drawCircle(
                    Brush.radialGradient(
                        listOf(ring.copy(alpha = 0.20f), Color.Transparent),
                        center = center, radius = size.minDimension / 2f * 0.7f * breathe
                    ),
                    radius = size.minDimension / 2f * 0.7f * breathe, center = center
                )
                drawArc(
                    color = p.track, startAngle = 135f, sweepAngle = 270f, useCenter = false,
                    topLeft = tl, size = arcSize, style = Stroke(sw, cap = StrokeCap.Round)
                )
                rotate(135f) {
                    drawArc(
                        brush = Brush.sweepGradient(listOf(ring, p.accent2, ring), center = center),
                        startAngle = 0f, sweepAngle = 270f * prog, useCenter = false,
                        topLeft = tl, size = arcSize, style = Stroke(sw, cap = StrokeCap.Round)
                    )
                }
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Row(verticalAlignment = Alignment.Bottom) {
                    T("$pct", 64, FontWeight.Light)
                    T("%", 22, FontWeight.Medium, p.sub, Modifier.padding(bottom = 12.dp, start = 2.dp))
                }
                val g = 1024.0 * 1024 * 1024
                T("%.1f / %.1f GB".format(ram.usedBytes / g, ram.totalBytes / g), 14, FontWeight.Medium, p.sub)
            }
        }
    }
}

// ═════════════ Tab Tiến trình (pm trim-caches) ═════════════

private fun gbText(bytes: Long) = "%.1f GB".format(bytes / 1024.0 / 1024 / 1024)

private fun unitBytes(unit: String): Double = if (unit == "GB") 1024.0 * 1024 * 1024 else 1024.0 * 1024

private fun fmtAmount(v: Double, unit: String): String = when {
    unit == "MB" -> v.roundToLong().toString()
    v % 1.0 == 0.0 -> v.toLong().toString()
    else -> "%.1f".format(Locale.US, v)
}

@Composable
private fun ProcessScreen() {
    val p = LocalPal.current
    val scope = rememberCoroutineScope()
    var unit by remember { mutableStateOf("GB") }
    var text by remember { mutableStateOf("5") }
    var all by remember { mutableStateOf(false) }
    var running by remember { mutableStateOf(false) }
    var granted by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var free by remember { mutableLongStateOf(Storage.freeBytes()) }
    var report by remember { mutableStateOf<String?>(null) }
    var reportOk by remember { mutableStateOf(true) }
    val total = remember { Storage.totalBytes() }

    LaunchedEffect(Unit) {
        while (true) {
            running = ShizukuHelper.isRunning()
            granted = running && ShizukuHelper.hasPermission()
            if (!busy) free = Storage.freeBytes()
            delay(1000)
        }
    }

    val ub = unitBytes(unit)
    val maxUnits = total / ub
    val amount = (text.replace(',', '.').toDoubleOrNull() ?: 0.0).coerceIn(0.0, maxUnits)
    val amountBytes = (amount * ub).toLong()
    val mb = 1024L * 1024
    val desiredFreeMb = if (all) total / mb else (free + amountBytes) / mb
    val command = "pm trim-caches ${desiredFreeMb}M"

    fun switchUnit(new: String) {
        if (new != unit) {
            val bytes = amount * ub
            unit = new
            text = fmtAmount(bytes / unitBytes(new), new)
        }
    }

    val usedFrac = if (total > 0) (total - free).toFloat() / total else 0f
    val usedAnim by animateFloatAsState(usedFrac.coerceIn(0f, 1f), softSpring(), label = "used")

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Glass(index = 0, radius = 34, pad = 20) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(56.dp).clip(CircleShape)
                        .background(Brush.linearGradient(listOf(p.accent, p.accent2))),
                    contentAlignment = Alignment.Center
                ) { PillIcon(Color.White, Modifier.size(30.dp)) }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    T("Dọn bộ nhớ đệm", 19, FontWeight.Bold)
                    Spacer(Modifier.height(2.dp))
                    T("Xóa cache của ứng dụng để lấy lại dung lượng lưu trữ.", 12, FontWeight.Normal, p.sub)
                }
            }
            Spacer(Modifier.height(14.dp))
            val st = when {
                !running -> "Shizuku chưa chạy" to p.bad
                !granted -> "Chưa cấp quyền Shizuku" to p.warn
                else -> "Shizuku sẵn sàng" to p.ok
            }
            Pill(st.first, st.second)
        }

        Glass(index = 1, radius = 32) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                T("Dung lượng lưu trữ", 16, FontWeight.SemiBold, modifier = Modifier.weight(1f))
                T("${gbText(total - free)} / ${gbText(total)}", 12, FontWeight.Medium, p.sub)
            }
            Spacer(Modifier.height(12.dp))
            Box(Modifier.fillMaxWidth().height(10.dp).clip(CircleShape).background(p.track)) {
                Box(
                    Modifier.fillMaxWidth(usedAnim).fillMaxHeight().clip(CircleShape)
                        .background(Brush.horizontalGradient(listOf(p.accent, p.accent2)))
                )
            }
            Spacer(Modifier.height(8.dp))
            T("Còn trống ${gbText(free)}", 12, FontWeight.Normal, p.sub)
        }

        Glass(index = 2, radius = 34, pad = 20) {
            T("Số lượng cần dọn", 16, FontWeight.SemiBold)
            Spacer(Modifier.height(10.dp))
            BasicTextField(
                value = if (all) "Tất cả" else text,
                onValueChange = { v ->
                    if (v.length <= 9 && v.all { it.isDigit() || it == '.' || it == ',' }) {
                        val n = v.replace(',', '.').toDoubleOrNull()
                        text = if (n != null && n > maxUnits) fmtAmount(maxUnits, unit) else v
                    }
                },
                enabled = !all,
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                textStyle = TextStyle(
                    color = if (all) p.sub else p.accent, fontSize = 52.sp,
                    fontWeight = FontWeight.Light, textAlign = TextAlign.Center
                ),
                cursorBrush = SolidColor(p.accent),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            Segmented(listOf("GB", "MB"), if (unit == "GB") 0 else 1, { i -> switchUnit(if (i == 0) "GB" else "MB") }, Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            Slider(
                value = amount.toFloat().coerceIn(0f, maxUnits.toFloat()),
                onValueChange = { text = fmtAmount(it.toDouble(), unit) },
                valueRange = 0f..maxUnits.toFloat(),
                enabled = !all,
                colors = SliderDefaults.colors(
                    thumbColor = Color.White, activeTrackColor = p.accent, inactiveTrackColor = p.track,
                    disabledThumbColor = p.sub, disabledActiveTrackColor = p.track, disabledInactiveTrackColor = p.track
                )
            )
            Row {
                T("0", 11, FontWeight.Normal, p.sub, Modifier.weight(1f))
                T("${fmtAmount(maxUnits, unit)} $unit", 11, FontWeight.Normal, p.sub)
            }
            Spacer(Modifier.height(14.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    T("Dọn tất cả cache", 15, FontWeight.Medium)
                    T("Xóa mọi cache có thể xóa", 12, FontWeight.Normal, p.sub)
                }
                GlassSwitch(all) { all = it }
            }
            Spacer(Modifier.height(14.dp))
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(p.track).padding(14.dp)
            ) {
                AnimatedContent(
                    targetState = command,
                    transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(120)) },
                    label = "cmd"
                ) { c ->
                    Text("$ $c", color = p.accent, fontSize = 13.sp, fontWeight = FontWeight.Medium, fontFamily = FontFamily.Monospace)
                }
            }
            Spacer(Modifier.height(16.dp))
            PrimaryButton(
                when {
                    busy -> "Đang dọn"
                    running && !granted -> "Cấp quyền Shizuku"
                    else -> "Dọn bộ nhớ đệm"
                },
                busy
            ) {
                when {
                    !all && amountBytes <= 0L -> {
                        reportOk = false
                        report = "Nhập số lượng lớn hơn 0 hoặc bật Dọn tất cả cache."
                    }
                    !running -> {
                        reportOk = false
                        report = "Shizuku chưa chạy. Vào tab Shizuku/ADB để khởi động."
                    }
                    !granted -> ShizukuHelper.requestPermission()
                    else -> scope.launch {
                        busy = true
                        val before = Storage.freeBytes()
                        val (code, out) = ShizukuHelper.exec(command)
                        delay(500)
                        val after = Storage.freeBytes()
                        free = after
                        reportOk = code == 0
                        report = if (code == 0)
                            "Giải phóng ${gbText((after - before).coerceAtLeast(0))}. Trống: ${gbText(before)} → ${gbText(after)}"
                        else "Lỗi ($code): $out"
                        busy = false
                    }
                }
            }
            AnimatedVisibility(
                visible = report != null,
                enter = fadeIn(softSpring()) + expandVertically(originSpring())
            ) {
                Column {
                    Spacer(Modifier.height(14.dp))
                    T(
                        report ?: "", 13, FontWeight.Medium, if (reportOk) p.ok else p.bad,
                        Modifier.fillMaxWidth(), TextAlign.Center
                    )
                }
            }
        }
        Spacer(Modifier.height(130.dp))
    }
}

// ═════════════ Tab Shizuku / ADB ═════════════

@Composable
private fun ShizukuScreen() {
    val p = LocalPal.current
    val context = LocalContext.current
    var installed by remember { mutableStateOf(false) }
    var running by remember { mutableStateOf(false) }
    var granted by remember { mutableStateOf(false) }
    var denied by remember { mutableStateOf(false) }
    var usb by remember { mutableStateOf(false) }
    var wifi by remember { mutableStateOf(false) }
    var copied by remember { mutableStateOf(false) }
    var note by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        while (true) {
            installed = ShizukuHelper.isInstalled(context)
            running = ShizukuHelper.isRunning()
            granted = running && ShizukuHelper.hasPermission()
            denied = running && !granted && ShizukuHelper.deniedForever()
            usb = ShizukuHelper.usbDebugOn(context)
            wifi = ShizukuHelper.wifiDebugOn(context)
            delay(1000)
        }
    }
    LaunchedEffect(copied) {
        if (copied) {
            delay(1800)
            copied = false
        }
    }

    val stage = when {
        !installed -> 0
        !running -> 1
        !granted -> 2
        else -> 3
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Glass(index = 0, radius = 34, pad = 20) {
            AnimatedContent(
                targetState = running,
                transitionSpec = { fadeIn(softSpring()) togetherWith fadeOut(tween(150)) },
                label = "head"
            ) { r ->
                T(if (r) "Shizuku đang chạy" else "Shizuku chưa chạy", 22, FontWeight.Bold, if (r) p.ok else p.bad)
            }
            Spacer(Modifier.height(6.dp))
            StatusRow("Đã cài Shizuku", installed, "Có", "Chưa")
            StatusRow("Dịch vụ Shizuku", running, "Đang chạy", "Dừng")
            StatusRow("Quyền cho RAMC", granted, "Đã cấp", "Chưa cấp")
            StatusRow("Gỡ lỗi USB", usb, "Bật", "Tắt")
            StatusRow("Gỡ lỗi không dây", wifi, "Bật", "Tắt")
        }

        Glass(index = 1, radius = 32) {
            T("Cấp quyền Shizuku", 16, FontWeight.SemiBold)
            Spacer(Modifier.height(6.dp))
            T(
                when (stage) {
                    0 -> "Chưa tìm thấy Shizuku trên máy. Hãy cài Shizuku trước."
                    1 -> "Shizuku đã cài nhưng chưa chạy. Khởi động bằng một trong hai cách bên dưới."
                    2 -> "Shizuku đang chạy. Cấp quyền để RAMC chạy được lệnh pm trim-caches."
                    else -> "RAMC đã có quyền Shizuku, bạn dùng được tab Tiến trình."
                },
                13, FontWeight.Normal, p.sub
            )
            Spacer(Modifier.height(14.dp))
            AnimatedContent(
                targetState = stage,
                transitionSpec = { fadeIn(softSpring()) togetherWith fadeOut(tween(150)) },
                label = "perm"
            ) { st ->
                when (st) {
                    0 -> PrimaryButton("Cài Shizuku") { ShizukuHelper.openInstallPage(context) }
                    1 -> PrimaryButton("Mở Shizuku") {
                        if (!ShizukuHelper.openShizuku(context)) note = "Không mở được Shizuku."
                    }
                    2 -> if (denied) {
                        PrimaryButton("Mở Shizuku để bật quyền") { ShizukuHelper.openShizuku(context) }
                    } else {
                        PrimaryButton("Cấp quyền Shizuku") { ShizukuHelper.requestPermission() }
                    }
                    else -> Box(
                        Modifier.fillMaxWidth().height(58.dp).clip(RoundedCornerShape(50))
                            .background(p.ok.copy(alpha = 0.16f)),
                        contentAlignment = Alignment.Center
                    ) { T("Đã cấp quyền · Sẵn sàng", 16, FontWeight.SemiBold, p.ok) }
                }
            }
            AnimatedVisibility(
                visible = denied,
                enter = fadeIn(softSpring()) + expandVertically(originSpring())
            ) {
                Column {
                    Spacer(Modifier.height(12.dp))
                    T(
                        "Bạn đã từ chối quyền. Vào Shizuku, mục ứng dụng được ủy quyền, rồi bật cho RAMC.",
                        12, FontWeight.Medium, p.warn
                    )
                }
            }
            AnimatedVisibility(
                visible = note != null,
                enter = fadeIn(softSpring()) + expandVertically(originSpring())
            ) {
                Column {
                    Spacer(Modifier.height(12.dp))
                    T(note ?: "", 12, FontWeight.Medium, p.bad)
                }
            }
        }

        Glass(index = 2, radius = 32) {
            T("Chạy qua gỡ lỗi không dây", 16, FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            T("Android 11 trở lên, không cần máy tính. Máy phải kết nối Wi-Fi.", 12, FontWeight.Normal, p.sub)
            Spacer(Modifier.height(10.dp))
            Step(1, "Bật Gỡ lỗi không dây trong Tùy chọn nhà phát triển.")
            Step(2, "Mở Shizuku, chọn Khởi động qua gỡ lỗi không dây.")
            Step(3, "Chọn Ghép nối bằng mã và nhập mã 6 số máy hiển thị.")
            Step(4, "Quay lại đây, khi Dịch vụ Shizuku báo Đang chạy là xong.")
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SecondaryButton("Tùy chọn nhà phát triển", Modifier.weight(1f)) { ShizukuHelper.openDevSettings(context) }
                SecondaryButton("Mở Shizuku", Modifier.weight(1f)) {
                    if (!ShizukuHelper.openShizuku(context)) note = "Chưa cài Shizuku nên không mở được."
                }
            }
        }

        Glass(index = 3, radius = 32) {
            T("Chạy qua gỡ lỗi USB", 16, FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            T("Cần máy tính có ADB. Dùng được trên mọi bản Android.", 12, FontWeight.Normal, p.sub)
            Spacer(Modifier.height(10.dp))
            Step(1, "Bật Gỡ lỗi USB trong Tùy chọn nhà phát triển.")
            Step(2, "Cắm cáp vào máy tính và bấm Cho phép trên điện thoại.")
            Step(3, "Chạy lệnh bên dưới trên máy tính.")
            Spacer(Modifier.height(10.dp))
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(p.track).padding(14.dp)
            ) {
                Text(
                    "$ ${ShizukuHelper.START_CMD}", color = p.accent, fontSize = 12.sp,
                    fontWeight = FontWeight.Medium, fontFamily = FontFamily.Monospace
                )
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SecondaryButton(if (copied) "Đã sao chép" else "Sao chép lệnh", Modifier.weight(1f)) {
                    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("shizuku", ShizukuHelper.START_CMD))
                    copied = true
                }
                SecondaryButton("Tùy chọn nhà phát triển", Modifier.weight(1f)) { ShizukuHelper.openDevSettings(context) }
            }
            Spacer(Modifier.height(12.dp))
            T(
                "Lưu ý: nếu không dùng root, Shizuku sẽ dừng khi khởi động lại máy và bạn cần chạy lại một trong hai cách.",
                12, FontWeight.Normal, p.sub
            )
        }
        Spacer(Modifier.height(130.dp))
    }
}
