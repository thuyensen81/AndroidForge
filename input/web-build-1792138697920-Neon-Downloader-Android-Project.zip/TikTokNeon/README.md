# Neon Downloader — Android Studio project

Dark Premium starter project for Android 8+ (target SDK 35). Package: `vn.neon.downloader`.

## Build APK
1. Open this folder in Android Studio (Hedgehog or newer).
2. Let Gradle sync; JDK 17+ and Android SDK 35 are required.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Debug APK is usually at `app/build/outputs/apk/debug/app-debug.apk`.

## Current implementation status
- Implemented: native Android launcher activity, embedded dark/neon UI, link input, clipboard paste bridge, TikTok URL validation, external browser handoff, back navigation.
- Not implemented/tested: automatic TikTok media extraction, in-app video/MP3 downloading, quality selection, download history, MP3 conversion, watermark removal. The current Continue action opens SnapTik in the browser; user must complete the steps on that service. Audio options depend on that service and rights/availability.
- No APK has been compiled in this environment because Android SDK / Gradle are not installed here. This is source code, not a ready-to-install APK.

Use only for media you own or have permission to download. This is an unofficial third-party tool and is not affiliated with TikTok.
