package vn.neon.downloader;

import android.app.Activity;
import android.os.Bundle;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView web;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        web.setBackgroundColor(0xFF070B14);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "Android");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }
    private class Bridge {
        @JavascriptInterface public void copy(String text) {
            ClipboardManager cb=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
            cb.setPrimaryClip(ClipData.newPlainText("TikTok URL", text));
            runOnUiThread(() -> Toast.makeText(MainActivity.this,"Đã sao chép liên kết",Toast.LENGTH_SHORT).show());
        }
        @JavascriptInterface public void open(String url) {
            if (!(url.startsWith("https://") && (url.contains("snaptik") || url.contains("cobalt") || url.contains("tiktok.com")))) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this,"Liên kết không được phép mở",Toast.LENGTH_SHORT).show()); return;
            }
            runOnUiThread(() -> startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))));
        }
        @JavascriptInterface public String clipboard() {
            ClipboardManager cb=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
            if(cb!=null && cb.hasPrimaryClip() && cb.getPrimaryClip().getItemCount()>0) {
                CharSequence s=cb.getPrimaryClip().getItemAt(0).coerceToText(MainActivity.this); return s==null?"":s.toString();
            }
            return "";
        }
    }
    @Override public void onBackPressed() {
        if(web!=null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
