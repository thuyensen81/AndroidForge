package com.ramturbopro.nativeapp

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

private val Bg = Color(0xFF090E18)
private val CardBg = Color(0xFF111B28)
private val Border = Color(0xFF263447)
private val Mint = Color(0xFF34D3A0)
private val Muted = Color(0xFF8C9AAF)
private val Cyan = Color(0xFF35C5DC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(9,14,24)
        window.navigationBarColor = android.graphics.Color.rgb(9,14,24)
        if (Build.VERSION.SDK_INT >= 29) window.isNavigationBarContrastEnforced = false
        setContent { NativeApp(this) }
    }
}

private data class Tab(val title: String, val icon: ImageVector)
private val tabs = listOf(
    Tab("Tổng Quan", Icons.Filled.Bolt), Tab("Tiến Trình", Icons.Filled.Layers),
    Tab("RAM Ảo", Icons.Filled.Memory), Tab("Game Turbo", Icons.Filled.LocalFireDepartment),
    Tab("Benchmark", Icons.Filled.Speed), Tab("Cài Đặt", Icons.Filled.Settings)
)

@Composable private fun NativeApp(context: Context) {
    var selected by remember { mutableIntStateOf(0) }
    var refresh by remember { mutableIntStateOf(0) }
    val memory = remember(refresh) { readMemory(context) }
    MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = CardBg, primary = Mint)) {
        Scaffold(containerColor = Bg, bottomBar = {
            NavigationBar(containerColor = Color(0xFF0B1320), contentColor = Muted, tonalElevation = 0.dp) {
                tabs.forEachIndexed { index, tab ->
                    NavigationBarItem(selected = selected == index, onClick = { selected = index },
                        icon = { Icon(tab.icon, contentDescription = tab.title) },
                        label = { Text(tab.title, fontSize = 10.sp, maxLines = 1) },
                        colors = NavigationBarItemDefaults.colors(selectedIconColor = Mint, selectedTextColor = Color.White,
                            indicatorColor = Color(0xFF12352F), unselectedIconColor = Muted, unselectedTextColor = Muted))
                }
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 18.dp)) {
                Header()
                Spacer(Modifier.height(24.dp))
                when (selected) {
                    0 -> Overview(context, memory, onRefresh = { refresh++ })
                    1 -> NativePlaceholder("Tiến Trình", "Android giới hạn khả năng xem và kết thúc tiến trình của ứng dụng khác. Chưa có thao tác dọn tiến trình được giả lập là thành công.", Icons.Filled.Layers)
                    2 -> NativePlaceholder("RAM Ảo", "Thông tin zRAM được hiển thị riêng khi có thể đọc từ hệ thống. Ứng dụng thường không thể tự ý thay đổi cấu hình kernel.", Icons.Filled.Memory)
                    3 -> NativePlaceholder("Game Turbo", "Bản native này chưa chuyển logic Game Turbo gốc sang Kotlin. Source GameTurboTab.tsx gốc được giữ nguyên trong reference-source; không tự ý thay đổi nội dung.", Icons.Filled.LocalFireDepartment)
                    4 -> NativePlaceholder("Benchmark", "Chưa chạy benchmark phần cứng thật. Các chỉ số giả lập không được hiển thị như kết quả đo thật.", Icons.Filled.Speed)
                    else -> NativePlaceholder("Cài Đặt", "RAM Turbo Pro Native · Android ${Build.VERSION.RELEASE} · ${Build.MANUFACTURER}", Icons.Filled.Settings)
                }
            }
        }
    }
}

@Composable private fun Header() {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Box(Modifier.size(58.dp).background(Color(0xFF10332F), RoundedCornerShape(18.dp)), contentAlignment = Alignment.Center) {
            Icon(Icons.Filled.Memory, null, tint = Mint, modifier = Modifier.size(31.dp))
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text("RAM TURBO PRO", color = Color(0xFFF4F7FC), fontSize = 21.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 0.6.sp)
            Text("NATIVE ANDROID", color = Mint, fontSize = 11.sp, letterSpacing = 2.5.sp)
        }
        Icon(Icons.Filled.Settings, null, tint = Muted, modifier = Modifier.size(28.dp))
    }
}

private data class MemoryInfo(val totalMb: Long, val availableMb: Long) {
    val usedMb get() = (totalMb - availableMb).coerceAtLeast(0)
    val percent get() = if (totalMb > 0) (usedMb * 100 / totalMb).toInt() else 0
}
private fun readMemory(context: Context): MemoryInfo {
    val manager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val info = ActivityManager.MemoryInfo(); manager.getMemoryInfo(info)
    return MemoryInfo(info.totalMem / (1024 * 1024), info.availMem / (1024 * 1024))
}
private fun gb(mb: Long) = String.format(Locale.getDefault(), "%.1f", mb / 1024.0)

@Composable private fun Overview(context: Context, memory: MemoryInfo, onRefresh: () -> Unit) {
    val deviceName = "${Build.MANUFACTURER.replaceFirstChar { it.uppercase() }} ${Build.MODEL}"
    Card(colors = CardDefaults.cardColors(containerColor = CardBg), shape = RoundedCornerShape(28.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Border), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(22.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("BỘ NHỚ THIẾT BỊ", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(7.dp)); Text("RAM đang sử dụng", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                }
                Icon(Icons.Filled.Memory, null, tint = Mint, modifier = Modifier.size(34.dp))
            }
            Spacer(Modifier.height(22.dp))
            Row(verticalAlignment = Alignment.Bottom) {
                Text(gb(memory.usedMb), color = Mint, fontSize = 48.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 52.sp)
                Spacer(Modifier.width(10.dp)); Text("/ ${gb(memory.totalMb)} GB", color = Muted, fontSize = 18.sp, modifier = Modifier.padding(bottom = 7.dp))
            }
            LinearProgressIndicator(progress = { (memory.percent / 100f).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().height(9.dp), color = Mint, trackColor = Color(0xFF1B283A))
            Spacer(Modifier.height(13.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Đã dùng ${memory.percent}%", color = Muted, fontSize = 13.sp)
                Text("Còn ${gb(memory.availableMb)} GB", color = Cyan, fontSize = 13.sp)
            }
        }
    }
    Spacer(Modifier.height(22.dp))
    Card(colors = CardDefaults.cardColors(containerColor = CardBg), shape = RoundedCornerShape(28.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Border), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(22.dp)) {
            Text("Tăng tốc nhanh", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            Text("RAM Turbo Pro không tự ý đóng ứng dụng hay sửa thông số kernel.", color = Muted, fontSize = 14.sp, lineHeight = 23.sp)
            Spacer(Modifier.height(20.dp))
            Button(onClick = onRefresh, modifier = Modifier.fillMaxWidth().height(54.dp), shape = CircleShape, colors = ButtonDefaults.buttonColors(containerColor = Mint, contentColor = Color(0xFF04130F))) {
                Icon(Icons.Filled.Bolt, null); Spacer(Modifier.width(8.dp)); Text("LÀM MỚI THÔNG TIN RAM", fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(14.dp)); Text("Sẵn sàng", color = Muted, fontSize = 13.sp)
        }
    }
    Spacer(Modifier.height(22.dp))
    Card(colors = CardDefaults.cardColors(containerColor = CardBg), shape = RoundedCornerShape(24.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Border), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp)) {
            Text("Thiết bị", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(14.dp)); Text("Tự nhận diện thiết bị", color = Cyan, fontSize = 18.sp)
            Spacer(Modifier.height(6.dp)); Text("Nhận diện thực tế: $deviceName", color = Muted, fontSize = 14.sp)
            Spacer(Modifier.height(12.dp)); Text("Model: ${Build.MODEL} · Android ${Build.VERSION.RELEASE}", color = Muted, fontSize = 13.sp)
        }
    }
}

@Composable private fun NativePlaceholder(title: String, message: String, icon: ImageVector) {
    Card(colors = CardDefaults.cardColors(containerColor = CardBg), shape = RoundedCornerShape(26.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Border), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(22.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = Mint, modifier = Modifier.size(28.dp)); Spacer(Modifier.width(12.dp)); Text(title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold) }
            Spacer(Modifier.height(16.dp)); Text(message, color = Muted, fontSize = 15.sp, lineHeight = 24.sp)
        }
    }
}
