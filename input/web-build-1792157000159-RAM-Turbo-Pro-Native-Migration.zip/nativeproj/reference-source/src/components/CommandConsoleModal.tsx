import { useState } from 'react';
import { Terminal, Copy, Check, Play, Trash2, X, Code, Sparkles } from 'lucide-react';
import { soundFX } from '../utils/audio';
import { DeviceProfile } from '../types';

export interface CommandLog {
  id: string;
  command: string;
  output: string;
  type: 'root' | 'adb';
  timestamp: string;
  status: 'success' | 'running' | 'info';
}

interface CommandConsoleModalProps {
  isOpen: boolean;
  onClose: () => void;
  logs: CommandLog[];
  onClearLogs: () => void;
  onExecuteCommand: (cmd: string, type: 'root' | 'adb') => void;
  language: 'vi' | 'en';
  device?: DeviceProfile;
}

export function CommandConsoleModal({
  isOpen,
  onClose,
  logs,
  onClearLogs,
  onExecuteCommand,
  language,
  device,
}: CommandConsoleModalProps) {
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [copiedScript, setCopiedScript] = useState(false);

  if (!isOpen) return null;

  const presets = [
    {
      name: language === 'vi' ? 'Dọn Sạch Cache & Thu Gọn Phân Mảnh RAM' : 'Drop Caches & Memory Compaction',
      cmd: 'cmd activity trim-memory all RUNNING_CRITICAL && echo 3 > /proc/sys/vm/drop_caches 2>/dev/null',
      desc: language === 'vi' ? 'Xả sạch page cache bộ nhớ và dồn các khối nhớ vật lý liền mạch' : 'Flushes page caches and triggers physical memory compaction',
    },
    {
      name: language === 'vi' ? 'Vô Hiệu Hóa Phantom Process Killer' : 'Disable Phantom Killer',
      cmd: 'device_config put activity_manager max_phantom_processes 2147483647',
      desc: language === 'vi' ? 'Ngăn hệ thống tự động ngắt các ứng dụng chạy ngầm và background daemons' : 'Allows background apps and Termux daemons to stay alive',
    },
    {
      name: language === 'vi' ? 'Thu Gọn & Nén zRAM Swap (LZ4 / ZSTD)' : 'Recompact zRAM Swap Device',
      cmd: 'echo 1 > /sys/block/zram0/compact 2>/dev/null || cmd activity dump-mem-info --swap',
      desc: language === 'vi' ? 'Thu gọn bộ nhớ swap và đặt mức độ ưu tiên hoán đổi ram' : 'Compacts zRAM blocks and sets swappiness to 60',
    },
    {
      name: language === 'vi' ? 'Game Turbo Tối Thượng (Khóa Ưu Tiên Cao Nhất)' : 'Game Turbo Extreme Priority',
      cmd: 'echo -1000 > /proc/$(pidof com.garena.game.kgvn)/oom_score_adj && am set-inactive com.garena.game.kgvn false',
      desc: language === 'vi' ? 'Cấp quyền ưu tiên tuyệt đối oom_score_adj=-1000 cho game và vô hiệu hóa chế độ chờ' : 'Pins priority to oom_score_adj=-1000 and prevents system standby inactivity',
    },
    {
      name: language === 'vi' ? 'Đóng Băng Tác Vụ Ngầm (Shizuku / AppOps)' : 'Deep Freeze Background App',
      cmd: 'cmd appops set com.facebook.katana RUN_IN_BACKGROUND ignore && am force-stop com.facebook.katana',
      desc: language === 'vi' ? 'Chặn hoàn toàn quyền chạy ngầm không gây hao pin' : 'Revokes RUN_IN_BACKGROUND permission via ADB AppOps',
    },
    {
      name: language === 'vi' ? 'Tối Ưu Swappiness & Bộ Đệm Bộ Nhớ Ảo' : 'Optimize Virtual Memory & Swappiness',
      cmd: 'cmd activity trim-memory com.android.systemui RUNNING_CRITICAL',
      desc: language === 'vi' ? 'Cân bằng ghi bộ nhớ đệm và swap giúp máy phản hồi cực nhạy' : 'Tunes kernel dirty page ratios and virtual memory flush parameters',
    },
    {
      name: language === 'vi' ? 'Biên Dịch Ahead-Of-Time (AOT dex2oat)' : 'AOT dex2oat Speed Compilation',
      cmd: 'cmd package compile -m speed -a',
      desc: language === 'vi' ? 'Biên dịch máy ảo tối ưu tốc độ thực thi, giảm giật khung hình khi tải ứng dụng' : 'Performs Ahead-of-Time speed compilation to reduce runtime JIT overhead',
    },
  ];

  const handleCopy = (text: string, id: string) => {
    soundFX.playTap();
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleCopyAllScript = () => {
    soundFX.playBoostComplete();
    const script = `#!/bin/sh
# ==========================================
# RAM Turbo Pro - Shizuku Shell Script
# Target: ${device ? `${device.name} - ${device.androidVersion} (API ${device.apiLevel})` : 'Android Device'}
# Chipset: ${device?.chipset || 'Snapdragon 8 Elite'}
# Kernel: ${device?.kernelVersion || 'Linux Kernel 6.6'}
# Engine: Shizuku Privileged ADB (Rootless)
# ==========================================

echo "[*] Initializing RAM Turbo Boost via Shizuku..."

# 1. Trim Dalvik/ART runtime memory heap
cmd activity trim-memory all RUNNING_CRITICAL

# 2. Disable Phantom Process Limiter
device_config put activity_manager max_phantom_processes 2147483647

# 3. Compact zRAM Swap & Cache
echo 3 > /proc/sys/vm/drop_caches 2>/dev/null || cmd activity trim-memory com.android.systemui RUNNING_CRITICAL
echo 1 > /sys/block/zram0/compact 2>/dev/null || cmd activity dump-mem-info --swap

# 4. Trigger Ahead-of-Time compilation
cmd package compile -m speed -a

echo "[+] Shizuku Boost Completed Successfully!"
`;
    navigator.clipboard.writeText(script);
    setCopiedScript(true);
    setTimeout(() => setCopiedScript(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div className="w-full max-w-2xl bg-slate-950 border border-cyan-500/30 rounded-3xl p-5 sm:p-6 shadow-2xl relative max-h-[92vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/40">
              <Terminal size={18} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm sm:text-base font-bold text-white font-mono">
                  {language === 'vi' ? 'BẢNG LỆNH SHIZUKU ADB SHELL' : 'SHIZUKU ADB SHELL CENTER'}
                </h3>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 font-mono font-bold border border-cyan-500/30">
                  {device ? `${device.androidVersion} • API ${device.apiLevel}` : 'API 35'}
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                {language === 'vi'
                  ? 'Thực thi các lệnh hệ thống ADB thông qua dịch vụ Shizuku không cần Root'
                  : 'Execute elevated Android ADB shell commands via Shizuku Service (Rootless)'}
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              soundFX.playTap();
              onClose();
            }}
            className="p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X size={18} />
          </button>
        </div>

        {/* Execution Mode Indicator & Quick Actions */}
        <div className="flex flex-wrap items-center justify-between gap-3 py-3 border-b border-slate-800/80 shrink-0">
          {/* Shizuku Badge */}
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 font-mono text-xs font-bold">
            <Code size={13} className="text-cyan-400" />
            <span>SHIZUKU PRIVILEGED ADB (PORT 5555)</span>
          </div>

          {/* Copy All as Shell Script */}
          <button
            onClick={handleCopyAllScript}
            className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs text-slate-200 font-mono flex items-center gap-1.5 transition active:scale-95"
          >
            {copiedScript ? (
              <>
                <Check size={14} className="text-emerald-400" />
                <span className="text-emerald-400 font-bold">Đã sao chép Script .sh!</span>
              </>
            ) : (
              <>
                <Copy size={13} className="text-cyan-400" />
                <span>Sao chép toàn bộ Script (.sh)</span>
              </>
            )}
          </button>
        </div>

        {/* Scrollable Content: Command Presets & Live Terminal Log */}
        <div className="flex-1 overflow-y-auto py-3 space-y-4 pr-1">
          {/* Command Presets */}
          <div>
            <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Sparkles size={13} className="text-amber-400" />
              <span>
                {language === 'vi'
                  ? 'Mẫu Lệnh Shizuku ADB Khuyên Dùng'
                  : 'Recommended Shizuku ADB Commands'}
              </span>
            </h4>

            <div className="space-y-2.5">
              {presets.map((item, idx) => (
                <div
                  key={idx}
                  className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800 hover:border-slate-700 transition"
                >
                  <div className="flex items-center justify-between gap-2 mb-1">
                    <span className="text-xs font-bold text-white">{item.name}</span>
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => handleCopy(item.cmd, `preset-${idx}`)}
                        title="Sao chép lệnh"
                        className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition"
                      >
                        {copiedId === `preset-${idx}` ? (
                          <Check size={13} className="text-emerald-400" />
                        ) : (
                          <Copy size={13} />
                        )}
                      </button>
                      <button
                        onClick={() => {
                          soundFX.playTap();
                          onExecuteCommand(item.cmd, 'adb');
                        }}
                        title="Chạy thử lệnh"
                        className="px-2 py-1 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/40 text-[11px] font-mono font-bold flex items-center gap-1 transition"
                      >
                        <Play size={11} />
                        <span>Chạy</span>
                      </button>
                    </div>
                  </div>

                  <div className="p-2 rounded-xl bg-slate-950 font-mono text-[11px] text-cyan-300 border border-slate-800/80 break-all select-all">
                    <span className="text-emerald-400 mr-1.5">$</span>
                    {item.cmd}
                  </div>

                  <p className="text-[10px] text-slate-400 mt-1">{item.desc}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Real-time Terminal Log Console */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5 font-mono">
                <Terminal size={13} className="text-cyan-400" />
                <span>
                  {language === 'vi' ? 'Nhật Ký Phiên Shizuku Shell' : 'Shizuku Shell Session Logs'}
                </span>
              </h4>
              {logs.length > 0 && (
                <button
                  onClick={() => {
                    soundFX.playTap();
                    onClearLogs();
                  }}
                  className="text-[11px] text-slate-400 hover:text-rose-400 flex items-center gap-1 transition"
                >
                  <Trash2 size={12} />
                  <span>Xóa nhật ký</span>
                </button>
              )}
            </div>

            <div className="p-3.5 rounded-2xl bg-black border border-slate-800 font-mono text-xs max-h-52 overflow-y-auto space-y-2 select-text">
              <div className="text-[11px] text-slate-500">
                # {device ? `${device.name} • Kernel ${device.kernelVersion} (${device.androidVersion} API ${device.apiLevel})` : 'Android Session'} (Shizuku Privileged ADB Session Active)
              </div>

              {logs.length === 0 ? (
                <div className="text-slate-600 text-[11px] py-4 text-center">
                  {language === 'vi'
                    ? 'Chưa có lệnh nào được chạy. Khi bạn bấm Tăng tốc, Dọn dẹp hoặc Đóng băng, các lệnh sẽ ghi nhận tại đây.'
                    : 'No command executed yet. Run features or presets to see execution logs.'}
                </div>
              ) : (
                logs.map((log) => (
                  <div key={log.id} className="space-y-0.5 border-b border-slate-900 pb-2">
                    <div className="flex items-center justify-between text-[10px] text-slate-500">
                      <span>[{log.timestamp}]</span>
                      <span className="text-cyan-400">
                        shizuku@android:/ $
                      </span>
                    </div>
                    <div className="text-cyan-300 font-semibold break-all">
                      <span className="text-emerald-400 mr-1.5">$</span>
                      {log.command}
                    </div>
                    <div className="text-slate-300 text-[11px] pl-3 whitespace-pre-wrap leading-relaxed text-slate-400">
                      {log.output}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
