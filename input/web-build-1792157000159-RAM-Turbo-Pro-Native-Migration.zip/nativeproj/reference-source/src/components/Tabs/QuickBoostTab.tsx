import { useEffect, useRef, useState } from 'react';
import { RAMStats, AppProcess, BoostResult } from '../../types';
import { RamGauge } from '../RamGauge';
import { Zap, Sparkles, Layers, ShieldCheck, Flame, ArrowUpRight, Cpu, Terminal, Copy, Check } from 'lucide-react';
import { soundFX } from '../../utils/audio';

interface QuickBoostTabProps {
  stats: RAMStats;
  processes: AppProcess[];
  onTriggerBoost: () => void;
  onQuickAction: (actionType: 'cache' | 'phantom' | '16kb' | 'zram') => void;
  onOpenTerminal?: () => void;
  language: 'vi' | 'en';
  isBoosting: boolean;
  lastBoostResult: BoostResult | null;
}

export function QuickBoostTab({
  stats,
  processes,
  onTriggerBoost,
  onQuickAction,
  onOpenTerminal,
  language,
  isBoosting,
  lastBoostResult,
}: QuickBoostTabProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Live streaming waveform graph for memory activity
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationId: number;
    const history: number[] = new Array(40).fill(50);

    const render = () => {
      // Simulate real-time memory bandwidth spikes
      const last = history[history.length - 1];
      const delta = (Math.random() - 0.48) * 8;
      const nextVal = Math.min(85, Math.max(15, last + delta));
      history.shift();
      history.push(nextVal);

      const width = canvas.width;
      const height = canvas.height;

      ctx.clearRect(0, 0, width, height);

      // Grid lines
      ctx.strokeStyle = 'rgba(30, 41, 59, 0.4)';
      ctx.lineWidth = 1;
      for (let y = 15; y < height; y += 15) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }

      // Draw gradient area under line
      const stepX = width / (history.length - 1);
      ctx.beginPath();
      ctx.moveTo(0, height);

      for (let i = 0; i < history.length; i++) {
        const x = i * stepX;
        const y = height - (history[i] / 100) * height;
        if (i === 0) ctx.lineTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.lineTo(width, height);
      ctx.closePath();

      const gradient = ctx.createLinearGradient(0, 0, 0, height);
      gradient.addColorStop(0, 'rgba(16, 185, 129, 0.25)');
      gradient.addColorStop(1, 'rgba(16, 185, 129, 0.0)');
      ctx.fillStyle = gradient;
      ctx.fill();

      // Draw line
      ctx.beginPath();
      for (let i = 0; i < history.length; i++) {
        const x = i * stepX;
        const y = height - (history[i] / 100) * height;
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.strokeStyle = '#10b981';
      ctx.lineWidth = 2;
      ctx.stroke();

      animationId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationId);
    };
  }, []);

  // Compute percentages for distribution bar
  const activePct = Math.round((stats.activeMb / stats.totalMb) * 100);
  const cachedPct = Math.round((stats.cachedMb / stats.totalMb) * 100);
  const kernelPct = Math.round((stats.kernelMb / stats.totalMb) * 100);
  const freePct = Math.max(0, 100 - activePct - cachedPct - kernelPct);

  return (
    <div className="space-y-6 pb-6">
      {/* Radial RAM Gauge Display */}
      <div className="bg-slate-900/60 backdrop-blur-md border border-slate-800 rounded-3xl p-4 shadow-xl">
        <RamGauge stats={stats} language={language} />

        {/* Big Tactile Boost Button */}
        <div className="mt-4 px-2">
          <button
            onClick={() => {
              soundFX.playTap();
              onTriggerBoost();
            }}
            disabled={isBoosting}
            className={`w-full py-4 px-6 rounded-2xl font-black text-sm tracking-widest uppercase transition-all duration-300 flex items-center justify-center gap-3 shadow-lg select-none ${
              isBoosting
                ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                : 'bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-slate-950 shadow-emerald-500/25 hover:shadow-emerald-500/40 transform hover:-translate-y-0.5 active:translate-y-0 active:scale-[0.99] cursor-pointer'
            }`}
          >
            <Zap className={`w-5 h-5 ${isBoosting ? 'animate-spin' : 'animate-bounce'}`} />
            <span>
              {isBoosting
                ? language === 'vi'
                  ? 'ĐANG TỐI ƯU HÓA...'
                  : 'OPTIMIZING MEMORY...'
                : language === 'vi'
                ? 'TĂNG TỐC RAM NGAY'
                : 'BOOST RAM NOW'}
            </span>
          </button>
        </div>

        {/* Command Box */}
        <div className="mt-3.5 mx-2 p-2.5 rounded-xl bg-slate-950/90 border border-slate-800 text-left flex items-center justify-between gap-2">
          <div className="min-w-0 flex items-center gap-2">
            <span className="p-1 rounded bg-cyan-500/10 text-cyan-400 font-mono text-[10px] shrink-0 font-bold">
              SHIZUKU ADB
            </span>
            <div className="text-[11px] font-mono text-cyan-300 truncate">
              echo 3 &gt; /proc/sys/vm/drop_caches &amp;&amp; echo 1 &gt; /proc/sys/vm/compact_memory
            </div>
          </div>
          <div className="flex items-center gap-1.5 shrink-0">
            <button
              onClick={() => {
                soundFX.playTap();
                navigator.clipboard.writeText('echo 3 > /proc/sys/vm/drop_caches && echo 1 > /proc/sys/vm/compact_memory');
              }}
              title="Sao chép lệnh"
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition"
            >
              <Copy size={12} />
            </button>
            {onOpenTerminal && (
              <button
                onClick={() => {
                  soundFX.playTap();
                  onOpenTerminal();
                }}
                className="px-2 py-1 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 font-mono text-[10px] font-bold border border-cyan-500/30 transition flex items-center gap-1"
              >
                <Terminal size={11} />
                <span>SHELL</span>
              </button>
            )}
          </div>
        </div>

        {lastBoostResult && (
          <div className="mt-3 text-center text-[11px] text-emerald-400 font-mono">
            ✨ {language === 'vi' ? 'Vừa giải phóng:' : 'Last boost freed:'}{' '}
            <span className="font-bold">+{lastBoostResult.freedMb} MB</span> |{' '}
            {language === 'vi' ? 'Dọn' : 'Cleaned'} {lastBoostResult.appsClosed} {language === 'vi' ? 'ứng dụng' : 'apps'}
          </div>
        )}
      </div>

      {/* Memory Distribution Bar */}
      <div className="bg-slate-900/60 backdrop-blur-md border border-slate-800 rounded-3xl p-5 shadow-lg">
        <div className="flex items-center justify-between mb-3 text-xs">
          <span className="font-semibold text-slate-200">
            {language === 'vi' ? 'Phân bổ Bộ nhớ RAM' : 'Memory Distribution'}
          </span>
          <span className="text-[11px] text-slate-400 font-mono">
            {stats.usedMb} MB / {stats.totalMb} MB
          </span>
        </div>

        {/* Multi-segmented Progress Bar */}
        <div className="h-4 w-full bg-slate-950 rounded-full overflow-hidden flex p-0.5 gap-0.5 border border-slate-800/80 mb-3">
          <div
            title={`Active: ${stats.activeMb} MB`}
            style={{ width: `${activePct}%` }}
            className="bg-cyan-500 h-full rounded-l-full transition-all duration-500"
          />
          <div
            title={`Cached: ${stats.cachedMb} MB`}
            style={{ width: `${cachedPct}%` }}
            className="bg-amber-500 h-full transition-all duration-500"
          />
          <div
            title={`Kernel: ${stats.kernelMb} MB`}
            style={{ width: `${kernelPct}%` }}
            className="bg-purple-500 h-full transition-all duration-500"
          />
          <div
            title={`Free: ${stats.freeMb} MB`}
            style={{ width: `${freePct}%` }}
            className="bg-emerald-500/30 h-full rounded-r-full transition-all duration-500"
          />
        </div>

        {/* Legend */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px]">
          <div className="flex items-center gap-1.5 text-slate-300">
            <span className="w-2.5 h-2.5 rounded-full bg-cyan-500 shrink-0" />
            <span className="truncate">Active: <span className="font-mono text-cyan-400 font-bold">{stats.activeMb}MB</span></span>
          </div>
          <div className="flex items-center gap-1.5 text-slate-300">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500 shrink-0" />
            <span className="truncate">Cached: <span className="font-mono text-amber-400 font-bold">{stats.cachedMb}MB</span></span>
          </div>
          <div className="flex items-center gap-1.5 text-slate-300">
            <span className="w-2.5 h-2.5 rounded-full bg-purple-500 shrink-0" />
            <span className="truncate">Kernel: <span className="font-mono text-purple-400 font-bold">{stats.kernelMb}MB</span></span>
          </div>
          <div className="flex items-center gap-1.5 text-slate-300">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 shrink-0" />
            <span className="truncate">Free: <span className="font-mono text-emerald-400 font-bold">{stats.freeMb}MB</span></span>
          </div>
        </div>
      </div>

      {/* 16KB Page Size & Kernel Architecture Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-emerald-950/60 via-slate-900 to-cyan-950/60 border border-emerald-500/30 p-5 shadow-lg">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 border border-emerald-400/30 flex items-center justify-center text-emerald-400 shrink-0">
            <Sparkles size={24} />
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1">
              <h4 className="text-sm font-bold text-white">
                {language === 'vi' ? 'Công Nghệ Trang Nhớ 16KB & Tối Ưu Hạt Nhân' : '16KB Page Engine & Kernel Architecture'}
              </h4>
              <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-bold border border-emerald-500/30">
                ACTIVE
              </span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed mb-3">
              {language === 'vi'
                ? 'Hệ thống mở rộng kích thước trang nhớ từ 4KB lên 16KB kết hợp cơ chế thu gọn phân mảnh hạt nhân, tối ưu thông lượng chip LPDDR5X, giảm độ trễ khởi động ứng dụng tới 12% và tiết kiệm năng lượng.'
                : 'System-level 16KB memory page size architecture combined with kernel page compaction, unlocking higher LPDDR5X throughput and cutting app launch latency by 12%.'}
            </p>
            <div className="flex flex-wrap items-center gap-4 text-xs font-mono text-slate-400">
              <span className="flex items-center gap-1">
                <span className="text-emerald-400 font-bold">16,384 bytes</span> / page
              </span>
              <span className="text-slate-600">•</span>
              <span className="flex items-center gap-1">
                TLB Misses: <span className="text-cyan-400 font-bold">-42%</span>
              </span>
              <span className="text-slate-600">•</span>
              <span className="flex items-center gap-1">
                Dex2oat: <span className="text-violet-400 font-bold">Optimized</span>
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Action Tiles */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {/* Action 1: Deep Cache Flush */}
        <button
          onClick={() => {
            soundFX.playTap();
            onQuickAction('cache');
          }}
          className="p-4 rounded-2xl bg-slate-900/60 hover:bg-slate-800/80 border border-slate-800 hover:border-emerald-500/40 text-left transition-all group flex items-start gap-3.5"
        >
          <div className="p-2.5 rounded-xl bg-amber-500/10 text-amber-400 group-hover:scale-110 transition-transform">
            <Layers size={20} />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white group-hover:text-emerald-300 transition-colors">
                {language === 'vi' ? 'Dọn Sâu Cache Ứng Dụng' : 'Deep Cache Flush'}
              </span>
              <ArrowUpRight size={14} className="text-slate-500 group-hover:text-emerald-400 transition" />
            </div>
            <p className="text-[11px] text-slate-400 mt-1">
              {language === 'vi'
                ? `Giải phóng ~${stats.cachedMb} MB bộ nhớ đệm ẩn không dùng`
                : `Reclaim ~${stats.cachedMb} MB inactive app standby cache`}
            </p>
            <div className="mt-2 text-[10px] font-mono text-amber-400/90 bg-slate-950/80 px-2 py-0.5 rounded-lg border border-slate-800/60 truncate">
              $ cmd activity trim-memory all RUNNING_CRITICAL
            </div>
          </div>
        </button>

        {/* Action 2: Phantom Task Killer */}
        <button
          onClick={() => {
            soundFX.playTap();
            onQuickAction('phantom');
          }}
          className="p-4 rounded-2xl bg-slate-900/60 hover:bg-slate-800/80 border border-slate-800 hover:border-cyan-500/40 text-left transition-all group flex items-start gap-3.5"
        >
          <div className="p-2.5 rounded-xl bg-cyan-500/10 text-cyan-400 group-hover:scale-110 transition-transform">
            <ShieldCheck size={20} />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white group-hover:text-cyan-300 transition-colors">
                {language === 'vi' ? 'Diệt Tiến Trình Ma (Phantom)' : 'Kill Phantom Processes'}
              </span>
              <ArrowUpRight size={14} className="text-slate-500 group-hover:text-cyan-400 transition" />
            </div>
            <p className="text-[11px] text-slate-400 mt-1">
              {language === 'vi'
                ? 'Dừng các tiến trình ngầm tự sinh bởi các app mạng xã hội'
                : 'Halt rogue background child forks draining battery and RAM'}
            </p>
            <div className="mt-2 text-[10px] font-mono text-cyan-400/90 bg-slate-950/80 px-2 py-0.5 rounded-lg border border-slate-800/60 truncate">
              $ device_config put activity_manager max_phantom_processes 2147483647
            </div>
          </div>
        </button>

        {/* Action 3: 16KB Page Compaction */}
        <button
          onClick={() => {
            soundFX.playTap();
            onQuickAction('16kb');
          }}
          className="p-4 rounded-2xl bg-slate-900/60 hover:bg-slate-800/80 border border-slate-800 hover:border-violet-500/40 text-left transition-all group flex items-start gap-3.5"
        >
          <div className="p-2.5 rounded-xl bg-violet-500/10 text-violet-400 group-hover:scale-110 transition-transform">
            <Sparkles size={20} />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white group-hover:text-violet-300 transition-colors">
                {language === 'vi' ? 'Thu Gọn Phân Mảnh (16KB)' : '16KB Memory Compaction'}
              </span>
              <ArrowUpRight size={14} className="text-slate-500 group-hover:text-violet-400 transition" />
            </div>
            <p className="text-[11px] text-slate-400 mt-1">
              {language === 'vi'
                ? `Giảm độ phân mảnh từ ${stats.fragmentationPercent}% về dưới 5%`
                : `Compact memory pages to minimize allocation overhead`}
            </p>
            <div className="mt-2 text-[10px] font-mono text-violet-400/90 bg-slate-950/80 px-2 py-0.5 rounded-lg border border-slate-800/60 truncate">
              # echo 1 &gt; /proc/sys/vm/compact_memory
            </div>
          </div>
        </button>

        {/* Action 4: zRAM Compression */}
        <button
          onClick={() => {
            soundFX.playTap();
            onQuickAction('zram');
          }}
          className="p-4 rounded-2xl bg-slate-900/60 hover:bg-slate-800/80 border border-slate-800 hover:border-rose-500/40 text-left transition-all group flex items-start gap-3.5"
        >
          <div className="p-2.5 rounded-xl bg-rose-500/10 text-rose-400 group-hover:scale-110 transition-transform">
            <Zap size={20} />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white group-hover:text-rose-300 transition-colors">
                {language === 'vi' ? 'Nén Bộ Nhớ Đệm zRAM' : 'Compress zRAM Swap'}
              </span>
              <ArrowUpRight size={14} className="text-slate-500 group-hover:text-rose-400 transition" />
            </div>
            <p className="text-[11px] text-slate-400 mt-1">
              {language === 'vi'
                ? `Kích hoạt thuật toán nén ${stats.zramAlgorithm} tiết kiệm RAM`
                : `Run high-density ${stats.zramAlgorithm} compression cycle`}
            </p>
            <div className="mt-2 text-[10px] font-mono text-rose-400/90 bg-slate-950/80 px-2 py-0.5 rounded-lg border border-slate-800/60 truncate">
              # echo 1 &gt; /sys/block/zram0/compact &amp;&amp; sysctl -w vm.swappiness=60
            </div>
          </div>
        </button>
      </div>

      {/* Real-time Memory Bandwidth Waveform Canvas */}
      <div className="bg-slate-900/60 backdrop-blur-md border border-slate-800 rounded-3xl p-5 shadow-lg">
        <div className="flex items-center justify-between mb-3 text-xs">
          <div className="flex items-center gap-2">
            <Cpu size={14} className="text-emerald-400" />
            <span className="font-semibold text-slate-200">
              {language === 'vi' ? 'Băng Thông RAM Theo Thời Gian Thực' : 'Live Memory Bandwidth Flow'}
            </span>
          </div>
          <span className="text-[11px] font-mono text-emerald-400 animate-pulse">
            ● LIVE STREAM
          </span>
        </div>

        <div className="w-full h-24 bg-slate-950 rounded-2xl overflow-hidden border border-slate-800/80 p-1">
          <canvas ref={canvasRef} width={600} height={90} className="w-full h-full block" />
        </div>

        <div className="flex justify-between items-center text-[10px] text-slate-500 mt-2 font-mono">
          <span>0.0 GB/s</span>
          <span>Băng thông trung bình: ~34.8 GB/s (LPDDR5X)</span>
          <span>64.0 GB/s</span>
        </div>
      </div>
    </div>
  );
}
