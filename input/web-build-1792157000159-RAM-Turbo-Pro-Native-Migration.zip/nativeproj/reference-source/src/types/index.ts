export type ProcessPriority = 'foreground' | 'service' | 'cached' | 'phantom';

export type AppCategory = 'social' | 'games' | 'media' | 'system' | 'tools' | 'shopping';

export interface AppProcess {
  id: string;
  name: string;
  packageName: string;
  category: AppCategory;
  ramUsageMb: number;
  initialRamMb: number;
  cpuPercent: number;
  priority: ProcessPriority;
  isProtected: boolean;
  isFrozen: boolean;
  isKilled: boolean;
  canKill: boolean;
  page16kbAligned: boolean;
}

export interface TurboGamePackage {
  id: string;
  packageName: string;
  name: string;
  icon: string;
  dedicatedRamGb: number;
  targetFps: number;
  isCustom?: boolean;
}

export interface DeviceProfile {
  id: string;
  name: string;
  model: string;
  chipset: string;
  totalRamGb: number;
  defaultSwapGb: number;
  kernelVersion: string;
  androidVersion: string;
  apiLevel: number;
  supports16kbPage: boolean;
}

export type CompressionAlgorithm = 'LZ4' | 'ZSTD' | 'LZO-RLE';

export interface RAMStats {
  totalMb: number;
  usedMb: number;
  freeMb: number;
  cachedMb: number;
  activeMb: number;
  kernelMb: number;
  zramTotalMb: number;
  zramUsedMb: number;
  zramAlgorithm: CompressionAlgorithm;
  swappiness: number;
  pageSizeKb: 16 | 4;
  fragmentationPercent: number;
}

export interface BoostResult {
  freedMb: number;
  appsClosed: number;
  zramCompactedMb: number;
  previousUsedMb: number;
  newUsedMb: number;
  durationMs: number;
  timestamp: Date;
}

export interface BenchmarkMetrics {
  readSpeedGbps: number;
  writeSpeedGbps: number;
  latencyNs: number;
  fragmentationPercent: number;
  page16kbScore: number;
  overallScore: number;
  testedAt: Date | null;
}

export type LmkMode = 'balanced' | 'aggressive' | 'extreme_gaming' | 'battery';

export type PermissionMode = 'shizuku' | 'unauthorized';

export interface PermissionState {
  mode: PermissionMode;
  shizukuActive: boolean;
  wirelessDebuggingEnabled: boolean;
  selinuxEnforcing: boolean;
}

export interface AppSettings {
  language: 'vi' | 'en';
  soundEnabled: boolean;
  autoBoostEnabled: boolean;
  autoBoostThresholdPercent: number;
  boostOnScreenLock: boolean;
  viewMode: 'responsive' | 'phone_mockup';
  selectedDeviceId: string;
  lmkMode: LmkMode;
  page16kbCompaction: boolean;
  virtualRamSizeGb: number;
  zramAlgorithm: CompressionAlgorithm;
  swappiness: number;
  gameTurboActive: boolean;
  selectedGameForTurbo: string | null;
}
