# RAM Turbo Pro — Native Android migration (work-in-progress)

This is a Kotlin + Jetpack Compose native Android project. The app UI is not a WebView and does not load HTML.

## Build
Open this folder in Android Studio, allow Gradle sync, then Build > Build APK(s). Requires JDK 17 and Android SDK 35.

## Important status
- Native overview screen reads real total/available memory via Android ActivityManager and reads actual device model/version from Build.
- Six bottom navigation tabs are present.
- Other tabs are honest placeholders; their original React implementations are retained in `reference-source/` for a screen-by-screen migration.
- `reference-source/src/components/Tabs/GameTurboTab.tsx` is copied unchanged from the uploaded original. The native Game Turbo implementation is not migrated yet, so it intentionally does not pretend to reproduce the original behavior.
- Shizuku Binder integration is not implemented in this initial native migration.
- No `settings put global` or `settings put system` commands are included in the native app source.
- This project has not been built/tested in an Android SDK environment in this session. Do not treat the ZIP as a verified APK.
