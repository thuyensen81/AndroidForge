package com.example.ramcleaner

import android.content.pm.PackageManager
import android.os.Environment
import android.os.StatFs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

object Storage {
    fun freeBytes(): Long = StatFs(Environment.getDataDirectory().path).availableBytes
    fun totalBytes(): Long = StatFs(Environment.getDataDirectory().path).totalBytes
}

object ShizukuHelper {
    fun isRunning(): Boolean = try { Shizuku.pingBinder() } catch (_: Throwable) { false }

    fun hasPermission(): Boolean = try {
        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (_: Throwable) { false }

    fun requestPermission() {
        try { Shizuku.requestPermission(1001) } catch (_: Throwable) { }
    }

    /** Chạy lệnh shell với quyền shell (UID 2000) thông qua Shizuku. Trả về (mã thoát, đầu ra). */
    suspend fun exec(cmd: String): Pair<Int, String> = withContext(Dispatchers.IO) {
        try {
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java, Array<String>::class.java, String::class.java
            )
            m.isAccessible = true
            val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
            val out = p.inputStream.bufferedReader().readText()
            val err = p.errorStream.bufferedReader().readText()
            p.waitFor() to (out + err).trim()
        } catch (e: Throwable) {
            -1 to (e.cause?.message ?: e.message ?: "Không chạy được lệnh")
        }
    }
}
