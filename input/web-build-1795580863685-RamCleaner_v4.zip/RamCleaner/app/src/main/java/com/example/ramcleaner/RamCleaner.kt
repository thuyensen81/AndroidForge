package com.example.ramcleaner

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.system.Os
import android.system.OsConstants
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

data class RamInfo(val totalBytes: Long, val availBytes: Long) {
    val usedBytes get() = totalBytes - availBytes
    val usedPercent get() = if (totalBytes == 0L) 0f else usedBytes.toFloat() / totalBytes
}

data class CleanResult(val appsTargeted: Int, val freedBytes: Long, val before: RamInfo, val after: RamInfo)

data class Breakdown(val appsMb: Long, val cachedMb: Long, val kernelMb: Long, val freeMb: Long)

class RamCleaner(private val context: Context) {

    fun pageSizeBytes(): Long = try { Os.sysconf(OsConstants._SC_PAGESIZE) } catch (_: Throwable) { 4096L }

    /** Đọc /proc/meminfo, chia thành 4 nhóm cộng lại đúng bằng tổng RAM. */
    fun readBreakdown(): Breakdown {
        val m = mutableMapOf<String, Long>()
        try {
            File("/proc/meminfo").forEachLine { line ->
                val p = line.split(":")
                if (p.size == 2) m[p[0].trim()] = p[1].replace("kB", "").trim().toLongOrNull() ?: 0L
            }
        } catch (_: Exception) { }
        val total = (m["MemTotal"] ?: 0L) / 1024
        val free = (m["MemFree"] ?: 0L) / 1024
        val cached = ((m["Cached"] ?: 0L) + (m["Buffers"] ?: 0L)) / 1024
        val kernel = ((m["Slab"] ?: 0L) + (m["KernelStack"] ?: 0L) + (m["PageTables"] ?: 0L)) / 1024
        val apps = (total - free - cached - kernel).coerceAtLeast(0)
        return Breakdown(apps, cached, kernel, free)
    }

    private val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager

    fun readRam(): RamInfo {
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        return RamInfo(mi.totalMem, mi.availMem)
    }

    /** Lấy các app người dùng (có launcher, không phải app hệ thống, không phải chính app này). */
    private fun targetPackages(): List<String> {
        val pm = context.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(launcher, 0)
            .map { it.activityInfo.applicationInfo }
            .filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 }
            .map { it.packageName }
            .filter { it != context.packageName }
            .distinct()
    }

    suspend fun clean(): CleanResult = withContext(Dispatchers.Default) {
        val before = readRam()
        val packages = targetPackages()
        packages.forEach { pkg ->
            try { am.killBackgroundProcesses(pkg) } catch (_: SecurityException) { }
        }
        delay(1200) // chờ hệ thống thu hồi bộ nhớ
        val after = readRam()
        CleanResult(
            appsTargeted = packages.size,
            freedBytes = (after.availBytes - before.availBytes).coerceAtLeast(0),
            before = before,
            after = after
        )
    }
}

fun Long.toMb(): Long = this / (1024 * 1024)
