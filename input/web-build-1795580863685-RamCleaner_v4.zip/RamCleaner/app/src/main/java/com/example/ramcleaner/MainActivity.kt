package com.example.ramcleaner

import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.roundToLong

private val Bg = Color(0xFF050B18)
private val CardBg = Color(0xFF0A1628)
private val Line = Color(0xFF14324A)
private val Cyan = Color(0xFF00BCD4)
private val Green = Color(0xFF10D98A)
private val Orange = Color(0xFFFF9800)
private val Purple = Color(0xFFA855F7)
private val Violet = Color(0xFF7C83FF)
private val Muted = Color(0xFF8A9BB0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { App() } }
    }
}

@Composable
private fun T(
    text: String, color: Color = Color.White, size: Int = 14,
    weight: FontWeight = FontWeight.Normal, mono: Boolean = false,
    modifier: Modifier = Modifier, align: TextAlign? = null
) = Text(
    text, color = color, fontSize = size.sp, fontWeight = weight, modifier = modifier,
    fontFamily = if (mono) FontFamily.Monospace else FontFamily.Default, textAlign = align
)

@Composable
private fun Panel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(24.dp)
    Column(
        modifier.fillMaxWidth().clip(shape).background(CardBg).border(1.dp, Line, shape).padding(20.dp),
        content = content
    )
}

@Composable
private fun App() {
    val context = LocalContext.current
    val cleaner = remember { RamCleaner(context) }
    var tab by remember { mutableIntStateOf(0) }

    Column(Modifier.fillMaxSize().background(Bg).systemBarsPadding()) {
        Header()
        Box(Modifier.weight(1f)) {
            if (tab == 0) OverviewScreen(cleaner) else ProcessScreen()
        }
        BottomBar(tab) { tab = it }
    }
}

@Composable
private fun Header() {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            T("TĂNG TỐC RAM", size = 24, weight = FontWeight.Bold)
            T(Build.MODEL, Muted, 13)
        }
        Box(
            Modifier.clip(RoundedCornerShape(20.dp)).background(Color(0xFF0B2A2E))
                .border(1.dp, Color(0xFF136B5A), RoundedCornerShape(20.dp)).padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            T("Android ${Build.VERSION.RELEASE}\nAPI ${Build.VERSION.SDK_INT}", Green, 12, mono = true)
        }
    }
}

@Composable
private fun OverviewScreen(cleaner: RamCleaner) {
    val scope = rememberCoroutineScope()
    var ram by remember { mutableStateOf(cleaner.readRam()) }
    var bd by remember { mutableStateOf(cleaner.readBreakdown()) }
    var cleaning by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<CleanResult?>(null) }
    val pageSize = remember { cleaner.pageSizeBytes() }

    LaunchedEffect(Unit) {
        while (true) {
            ram = cleaner.readRam(); bd = cleaner.readBreakdown(); delay(2000)
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Panel {
            Gauge(ram)
            Spacer(Modifier.height(16.dp))
            T("Kích thước trang nhớ: $pageSize bytes", Muted, 12, mono = true,
                modifier = Modifier.fillMaxWidth(), align = TextAlign.Center)
            Spacer(Modifier.height(16.dp))
            Box(
                Modifier.fillMaxWidth().height(60.dp).clip(RoundedCornerShape(20.dp))
                    .background(Brush.horizontalGradient(listOf(Green, Cyan)))
                    .clickable(enabled = !cleaning) {
                        scope.launch {
                            cleaning = true
                            result = cleaner.clean()
                            ram = cleaner.readRam()
                            cleaning = false
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                T(if (cleaning) "ĐANG DỌN..." else "⚡  TĂNG TỐC RAM NGAY", Color(0xFF04121C), 17, FontWeight.Bold)
            }
            result?.let {
                Spacer(Modifier.height(14.dp))
                T("Đã dừng ${it.appsTargeted} ứng dụng nền, giải phóng ${it.freedBytes.toMb()} MB",
                    Green, 13, mono = true, modifier = Modifier.fillMaxWidth(), align = TextAlign.Center)
            }
        }

        Panel {
            Row {
                T("Phân bổ bộ nhớ RAM", weight = FontWeight.Bold, size = 15, modifier = Modifier.weight(1f))
                T("${ram.usedBytes.toMb()} / ${ram.totalBytes.toMb()} MB", Muted, 12, mono = true)
            }
            Spacer(Modifier.height(14.dp))
            Row(
                Modifier.fillMaxWidth().height(16.dp).clip(CircleShape).background(Color(0xFF0B2A24))
            ) {
                Seg(bd.appsMb, Cyan); Seg(bd.cachedMb, Orange); Seg(bd.kernelMb, Purple); Seg(bd.freeMb, Color(0xFF0D4D3A))
            }
            Spacer(Modifier.height(16.dp))
            Row {
                Legend("Ứng dụng", bd.appsMb, Cyan, Modifier.weight(1f))
                Legend("Bộ nhớ đệm", bd.cachedMb, Orange, Modifier.weight(1f))
            }
            Spacer(Modifier.height(10.dp))
            Row {
                Legend("Kernel", bd.kernelMb, Purple, Modifier.weight(1f))
                Legend("Trống", bd.freeMb, Green, Modifier.weight(1f))
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun RowScope.Seg(value: Long, color: Color) {
    Box(Modifier.weight(maxOf(value, 1L).toFloat()).fillMaxHeight().background(color))
}

@Composable
private fun Legend(name: String, mb: Long, color: Color, modifier: Modifier) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(12.dp).clip(CircleShape).background(color))
        Spacer(Modifier.width(8.dp))
        T("$name: ", Muted, 13)
        T("${mb}MB", color, 13, FontWeight.Bold, mono = true)
    }
}

@Composable
private fun Gauge(ram: RamInfo) {
    val p by animateFloatAsState(ram.usedPercent, tween(800), label = "gauge")
    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Box(Modifier.size(250.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize().padding(16.dp)) {
                val s = Stroke(width = 32f, cap = StrokeCap.Round)
                drawArc(Color(0xFF16233A), 135f, 270f, false, style = s)
                drawArc(Brush.linearGradient(listOf(Violet, Cyan)), 135f, 270f * p, false, style = s)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Row(verticalAlignment = Alignment.Bottom) {
                    T("${(p * 100).toInt()}", size = 64, weight = FontWeight.Bold)
                    T("%", Green, 24, FontWeight.Bold, modifier = Modifier.padding(bottom = 10.dp))
                }
                val used = ram.usedBytes / 1024.0 / 1024 / 1024
                val total = ram.totalBytes / 1024.0 / 1024 / 1024
                T("%.1f GB / %.1f GB".format(used, total), Cyan, 15, mono = true)
                Spacer(Modifier.height(6.dp))
                T("Trống: %.1f GB".format(ram.availBytes / 1024.0 / 1024 / 1024), Green, 14, mono = true)
            }
        }
    }
}

private fun gbText(bytes: Long) = "%.1f GB".format(bytes / 1024.0 / 1024 / 1024)

private fun unitBytes(unit: String): Double = if (unit == "GB") 1024.0 * 1024 * 1024 else 1024.0 * 1024

private fun fmtAmount(v: Double, unit: String): String = when {
    unit == "MB" -> v.roundToLong().toString()
    v % 1.0 == 0.0 -> v.toLong().toString()
    else -> "%.1f".format(Locale.US, v)
}

@Composable
private fun ProcessScreen() {
    val scope = rememberCoroutineScope()
    var unit by remember { mutableStateOf("GB") }
    var text by remember { mutableStateOf("5") }
    var all by remember { mutableStateOf(false) }
    var running by remember { mutableStateOf(false) }
    var granted by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var free by remember { mutableLongStateOf(Storage.freeBytes()) }
    var report by remember { mutableStateOf<String?>(null) }
    var reportOk by remember { mutableStateOf(true) }
    val total = remember { Storage.totalBytes() }

    LaunchedEffect(Unit) {
        while (true) {
            running = ShizukuHelper.isRunning()
            granted = running && ShizukuHelper.hasPermission()
            if (!busy) free = Storage.freeBytes()
            delay(1000)
        }
    }

    val ub = unitBytes(unit)
    val maxUnits = total / ub
    val amount = (text.replace(',', '.').toDoubleOrNull() ?: 0.0).coerceIn(0.0, maxUnits)
    val amountBytes = (amount * ub).toLong()
    val mb = 1024L * 1024
    val desiredFreeMb = if (all) total / mb else (free + amountBytes) / mb
    val command = "pm trim-caches ${desiredFreeMb}M"

    fun switchUnit(new: String) {
        if (new == unit) return
        val bytes = amount * ub
        unit = new
        text = fmtAmount(bytes / unitBytes(new), new)
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Panel {
            Row(verticalAlignment = Alignment.Top) {
                Box(
                    Modifier.size(52.dp).clip(RoundedCornerShape(16.dp)).background(Color(0xFF2A1F10)),
                    contentAlignment = Alignment.Center
                ) { T("▤", Orange, 26) }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    T("Dọn dẹp bộ nhớ đệm ứng dụng", weight = FontWeight.Bold, size = 16)
                    Spacer(Modifier.height(4.dp))
                    T("Xóa cache của ứng dụng hệ thống và bên thứ ba để lấy lại dung lượng lưu trữ.", Muted, 13)
                }
            }
            Spacer(Modifier.height(14.dp))
            val (label, color) = when {
                !running -> "Shizuku chưa chạy" to Color(0xFFFF6B6B)
                !granted -> "Chưa cấp quyền Shizuku" to Orange
                else -> "Shizuku sẵn sàng" to Green
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(10.dp).clip(CircleShape).background(color))
                Spacer(Modifier.width(8.dp))
                T(label, color, 13, mono = true)
            }
        }

        Panel {
            Row {
                T("Bộ nhớ trống", Muted, 13, modifier = Modifier.weight(1f))
                T("${gbText(free)} / ${gbText(total)}", Cyan, 13, mono = true)
            }
            Spacer(Modifier.height(18.dp))
            T("Số lượng muốn dọn", weight = FontWeight.Bold, size = 15)
            Spacer(Modifier.height(10.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).background(Color(0xFF050B18))
                        .border(1.dp, if (all) Line else Orange, RoundedCornerShape(14.dp))
                        .padding(horizontal = 14.dp, vertical = 12.dp)
                ) {
                    BasicTextField(
                        value = if (all) "Tất cả" else text,
                        onValueChange = { v ->
                            if (v.length <= 9 && v.all { it.isDigit() || it == '.' || it == ',' }) {
                                val n = v.replace(',', '.').toDoubleOrNull()
                                text = if (n != null && n > maxUnits) fmtAmount(maxUnits, unit) else v
                            }
                        },
                        enabled = !all,
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        textStyle = TextStyle(
                            color = if (all) Muted else Orange, fontSize = 22.sp,
                            fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace
                        ),
                        cursorBrush = SolidColor(Orange),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                Spacer(Modifier.width(10.dp))
                listOf("GB", "MB").forEach { u ->
                    val on = u == unit
                    Box(
                        Modifier.padding(start = 6.dp).clip(RoundedCornerShape(14.dp))
                            .background(if (on) Color(0xFF2A1F10) else Color.Transparent)
                            .border(1.dp, if (on) Orange else Line, RoundedCornerShape(14.dp))
                            .clickable { switchUnit(u) }
                            .padding(horizontal = 14.dp, vertical = 14.dp)
                    ) { T(u, if (on) Orange else Muted, 14, FontWeight.Bold, mono = true) }
                }
            }

            Spacer(Modifier.height(8.dp))
            Slider(
                value = amount.toFloat().coerceIn(0f, maxUnits.toFloat()),
                onValueChange = { text = fmtAmount(it.toDouble(), unit) },
                valueRange = 0f..maxUnits.toFloat(),
                enabled = !all,
                colors = SliderDefaults.colors(
                    thumbColor = Orange, activeTrackColor = Orange,
                    inactiveTrackColor = Color(0xFF16233A), disabledThumbColor = Muted,
                    disabledActiveTrackColor = Color(0xFF2A3A52), disabledInactiveTrackColor = Color(0xFF16233A)
                )
            )
            Row {
                T("0", Muted, 11, mono = true, modifier = Modifier.weight(1f))
                T("${fmtAmount(maxUnits, unit)} $unit", Muted, 11, mono = true)
            }

            Spacer(Modifier.height(12.dp))
            Box(
                Modifier.clip(RoundedCornerShape(14.dp))
                    .background(if (all) Color(0xFF2A1F10) else Color.Transparent)
                    .border(1.dp, if (all) Orange else Line, RoundedCornerShape(14.dp))
                    .clickable { all = !all }
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            ) { T("Dọn tất cả cache", if (all) Orange else Muted, 13, FontWeight.Bold) }

            Spacer(Modifier.height(16.dp))
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color(0xFF050B18))
                    .border(1.dp, Line, RoundedCornerShape(14.dp)).padding(12.dp)
            ) { T("$ $command", Green, 13, mono = true) }

            Spacer(Modifier.height(16.dp))
            Box(
                Modifier.fillMaxWidth().height(60.dp).clip(RoundedCornerShape(20.dp))
                    .background(Brush.horizontalGradient(listOf(Orange, Color(0xFFFFC107))))
                    .clickable(enabled = !busy) {
                        when {
                            !all && amountBytes <= 0L -> {
                                reportOk = false
                                report = "Nhập số lượng lớn hơn 0 hoặc bật Dọn tất cả cache."
                            }
                            !running -> {
                                reportOk = false
                                report = "Shizuku chưa chạy. Mở ứng dụng Shizuku và khởi động dịch vụ (gỡ lỗi không dây hoặc root), rồi quay lại đây."
                            }
                            !granted -> ShizukuHelper.requestPermission()
                            else -> scope.launch {
                                busy = true
                                val before = Storage.freeBytes()
                                val (code, out) = ShizukuHelper.exec(command)
                                delay(500)
                                val after = Storage.freeBytes()
                                free = after
                                reportOk = code == 0
                                report = if (code == 0)
                                    "Giải phóng ${gbText((after - before).coerceAtLeast(0))}\nTrống: ${gbText(before)} → ${gbText(after)}"
                                else "Lỗi ($code): $out"
                                busy = false
                            }
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                T(
                    when {
                        busy -> "ĐANG DỌN..."
                        running && !granted -> "CẤP QUYỀN SHIZUKU"
                        else -> "DỌN BỘ NHỚ ĐỆM"
                    },
                    Color(0xFF1A1000), 17, FontWeight.Bold
                )
            }
            report?.let {
                Spacer(Modifier.height(14.dp))
                T(it, if (reportOk) Green else Color(0xFFFF6B6B), 13, mono = true,
                    modifier = Modifier.fillMaxWidth(), align = TextAlign.Center)
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun BottomBar(selected: Int, onSelect: (Int) -> Unit) {
    val items = listOf("⚡" to "Tổng quan", "☰" to "Tiến trình")
    Row(
        Modifier.fillMaxWidth().background(Color(0xFF070F1F)).padding(vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        items.forEachIndexed { i, (icon, label) ->
            val on = i == selected
            Column(
                Modifier.clip(RoundedCornerShape(16.dp)).clickable { onSelect(i) }
                    .background(if (on) Color(0xFF0B2A24) else Color.Transparent)
                    .padding(horizontal = 28.dp, vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                T(icon, if (on) Green else Muted, 22)
                T(label, if (on) Color.White else Muted, 12, if (on) FontWeight.Bold else FontWeight.Normal)
            }
        }
    }
}
