package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ExecutionMode
import com.example.service.PrivilegeManager
import com.example.ui.TurboBoostViewModel
import com.example.ui.components.TerminalOutputBox
import com.example.ui.theme.CardSurfaceDark
import com.example.ui.theme.CardSurfaceVariantDark
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.DangerCrimson
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark
import com.example.ui.theme.WarningAmber

@Composable
fun TrimCacheScreen(
    viewModel: TurboBoostViewModel,
    onNavigateToPrivileges: () -> Unit,
    modifier: Modifier = Modifier
) {
    val privilegeStatus by viewModel.privilegeStatus.collectAsState()
    val boostProgress by viewModel.boostProgress.collectAsState()
    val lastResult by viewModel.lastResult.collectAsState()
    val storageStats by viewModel.storageStats.collectAsState()

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        // Title
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Default.CleaningServices,
                contentDescription = null,
                tint = CyanPrimary,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "DỌN CACHE CHUYÊN SÂU",
                fontSize = 18.sp,
                fontWeight = FontWeight.Black,
                color = TextPrimaryDark,
                letterSpacing = 0.5.sp
            )
        }

        Text(
            text = "Lệnh: pm trim-caches 1024G qua Shizuku / Root",
            fontSize = 12.sp,
            color = TextSecondaryDark
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Explanation Card
        Card(
            colors = CardDefaults.cardColors(containerColor = CardSurfaceDark),
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(CyanPrimary.copy(alpha = 0.15f))
                    ) {
                        Icon(
                            imageVector = Icons.Default.Code,
                            contentDescription = null,
                            tint = CyanPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "pm trim-caches 1024G",
                        fontFamily = FontFamily.Monospace,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = CyanPrimary
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "Lệnh tiêu chuẩn của Android Package Manager để yêu cầu hệ thống thu hồi bộ nhớ cache của tất cả ứng dụng cài đặt trên máy. Lệnh này đòi hỏi quyền quản trị viên hệ thống (Shizuku API hoặc Root su) để thực thi an toàn và triệt để.",
                    fontSize = 12.sp,
                    color = TextSecondaryDark,
                    lineHeight = 18.sp
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Ước tính dọn dẹp: ~${storageStats.estimatedCacheMbFormatted}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = NeonEmerald
                    )

                    Surface(
                        color = if (privilegeStatus.hasPrivilege) NeonEmerald.copy(alpha = 0.15f) else WarningAmber.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.clickable { onNavigateToPrivileges() }
                    ) {
                        Text(
                            text = if (privilegeStatus.hasPrivilege) "Quyền: ${privilegeStatus.preferredPrivilegeName}" else "Chưa cấp quyền",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (privilegeStatus.hasPrivilege) NeonEmerald else WarningAmber,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Mode Selector
        Text(
            text = "CHẾ ĐỘ THỰC THI",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = TextSecondaryDark,
            letterSpacing = 1.sp
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = privilegeStatus.activeMode == ExecutionMode.AUTO,
                onClick = { viewModel.setExecutionMode(ExecutionMode.AUTO) },
                label = { Text("Tự động", fontSize = 12.sp) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = CyanPrimary.copy(alpha = 0.2f),
                    selectedLabelColor = CyanPrimary
                ),
                modifier = Modifier.testTag("mode_chip_auto")
            )

            FilterChip(
                selected = privilegeStatus.activeMode == ExecutionMode.SHIZUKU,
                onClick = { viewModel.setExecutionMode(ExecutionMode.SHIZUKU) },
                label = { Text("Shizuku", fontSize = 12.sp) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = CyanPrimary.copy(alpha = 0.2f),
                    selectedLabelColor = CyanPrimary
                ),
                modifier = Modifier.testTag("mode_chip_shizuku")
            )

            FilterChip(
                selected = privilegeStatus.activeMode == ExecutionMode.ROOT,
                onClick = { viewModel.setExecutionMode(ExecutionMode.ROOT) },
                label = { Text("Root (su)", fontSize = 12.sp) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = CyanPrimary.copy(alpha = 0.2f),
                    selectedLabelColor = CyanPrimary
                ),
                modifier = Modifier.testTag("mode_chip_root")
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Main Execution Button
        Button(
            onClick = { viewModel.runTrimCachesDirect() },
            enabled = !boostProgress.isRunning,
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary),
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .testTag("execute_trim_caches_button")
        ) {
            if (boostProgress.isRunning) {
                CircularProgressIndicator(
                    color = Color(0xFF0A0E17),
                    strokeWidth = 2.dp,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "Đang chạy pm trim-caches...",
                    color = Color(0xFF0A0E17),
                    fontWeight = FontWeight.Bold
                )
            } else {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = null,
                    tint = Color(0xFF0A0E17),
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Chạy 'pm trim-caches 1024G'",
                    color = Color(0xFF0A0E17),
                    fontWeight = FontWeight.Black,
                    fontSize = 14.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Output Display
        lastResult?.let { result ->
            Text(
                text = "KẾT QUẢ THỰC THI GẦN NHẤT",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = TextSecondaryDark,
                letterSpacing = 1.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            TerminalOutputBox(
                command = result.command,
                output = result.output,
                isSuccess = result.isSuccess
            )

            Spacer(modifier = Modifier.height(16.dp))
        }

        // Additional Advanced Cache Tools
        Text(
            text = "LỆNH DỌN DẸP BỔ SUNG",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = TextSecondaryDark,
            letterSpacing = 1.sp
        )

        Spacer(modifier = Modifier.height(8.dp))

        CommandQuickCard(
            title = "Dọn sạch Linux PageCache (Root)",
            command = "sync; echo 3 > /proc/sys/vm/drop_caches",
            description = "Xóa trang đệm RAM do nhân Linux giữ lại cho đĩa đọc/ghi.",
            enabled = !boostProgress.isRunning,
            onClick = {
                viewModel.executeTerminalCommand("sync; echo 3 > /proc/sys/vm/drop_caches")
            }
        )

        Spacer(modifier = Modifier.height(8.dp))

        CommandQuickCard(
            title = "Buộc giải phóng tiến trình treo (am kill-all)",
            command = "am kill-all",
            description = "Yêu cầu ActivityManager đóng các dịch vụ không cần thiết.",
            enabled = !boostProgress.isRunning,
            onClick = {
                viewModel.executeTerminalCommand("am kill-all")
            }
        )

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun CommandQuickCard(
    title: String,
    command: String,
    description: String,
    enabled: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = CardSurfaceDark,
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B)),
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimaryDark
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = command,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    color = CyanPrimary
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = description,
                    fontSize = 11.sp,
                    color = TextSecondaryDark
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            Button(
                onClick = onClick,
                enabled = enabled,
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = CardSurfaceVariantDark),
                modifier = Modifier.testTag("run_extra_command_button")
            ) {
                Text(
                    text = "Chạy",
                    color = CyanPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
