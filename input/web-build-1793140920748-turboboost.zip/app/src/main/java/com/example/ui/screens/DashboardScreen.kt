package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.DeviceThermostat
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CpuDeviceInfo
import com.example.model.MemoryStats
import com.example.model.OptimizationResult
import com.example.model.PrivilegeStatus
import com.example.model.StorageStats
import com.example.ui.BoostProgress
import com.example.ui.TurboBoostViewModel
import com.example.ui.components.CircularResourceGauge
import com.example.ui.components.MetricChip
import com.example.ui.components.StatusBadge
import com.example.ui.theme.CardSurfaceDark
import com.example.ui.theme.CardSurfaceVariantDark
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark
import com.example.ui.theme.WarningAmber

@Composable
fun DashboardScreen(
    viewModel: TurboBoostViewModel,
    onNavigateToTrim: () -> Unit,
    onNavigateToPrivileges: () -> Unit,
    modifier: Modifier = Modifier
) {
    val memStats by viewModel.memoryStats.collectAsState()
    val storageStats by viewModel.storageStats.collectAsState()
    val deviceInfo by viewModel.deviceInfo.collectAsState()
    val privilegeStatus by viewModel.privilegeStatus.collectAsState()
    val boostProgress by viewModel.boostProgress.collectAsState()
    val lastResult by viewModel.lastResult.collectAsState()

    val scrollState = rememberScrollState()

    Box(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Bolt,
                            contentDescription = null,
                            tint = CyanPrimary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "TURBO BOOST",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp,
                            color = TextPrimaryDark
                        )
                    }
                    Text(
                        text = "Tối ưu hóa RAM & Cache hệ thống",
                        fontSize = 12.sp,
                        color = TextSecondaryDark
                    )
                }

                IconButton(
                    onClick = { viewModel.refreshAll() },
                    modifier = Modifier
                        .size(40.dp)
                        .testTag("refresh_stats_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Làm mới dữ liệu",
                        tint = CyanPrimary
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Privilege Pill
            Surface(
                color = CardSurfaceVariantDark,
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF263554)),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onNavigateToPrivileges() }
                    .testTag("privilege_status_banner")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            tint = if (privilegeStatus.hasPrivilege) NeonEmerald else WarningAmber,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Quyền cấp cao:",
                                fontSize = 11.sp,
                                color = TextSecondaryDark
                            )
                            Text(
                                text = privilegeStatus.preferredPrivilegeName,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (privilegeStatus.hasPrivilege) NeonEmerald else WarningAmber
                            )
                        }
                    }

                    Text(
                        text = if (privilegeStatus.hasPrivilege) "Đã sẵn sàng ›" else "Thiết lập ngay ›",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = CyanPrimary
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Main RAM Hero Gauge Card
            Card(
                colors = CardDefaults.cardColors(containerColor = CardSurfaceDark),
                shape = RoundedCornerShape(20.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "BỘ NHỚ RAM KHẢ DỤNG",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        color = TextSecondaryDark
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    CircularResourceGauge(
                        percent = memStats.usedPercent,
                        label = "RAM đang dùng",
                        sublabel = "${memStats.usedMb} MB / ${memStats.totalMb} MB"
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // RAM details breakdown
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "Trống / Khả dụng",
                                fontSize = 11.sp,
                                color = TextSecondaryDark
                            )
                            Text(
                                text = "${memStats.availableMb} MB",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = NeonEmerald
                            )
                        }
                        Box(
                            modifier = Modifier
                                .width(1.dp)
                                .height(28.dp)
                                .background(Color(0xFF263554))
                        )
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "Bộ đệm / Cache",
                                fontSize = 11.sp,
                                color = TextSecondaryDark
                            )
                            Text(
                                text = "${memStats.cachedMb} MB",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = CyanPrimary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    // Boost Action Button
                    BoostActionButton(
                        isBoosting = boostProgress.isRunning,
                        currentStep = boostProgress.currentStep,
                        onClick = { viewModel.performQuickBoost() }
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Storage Status Card
            Card(
                colors = CardDefaults.cardColors(containerColor = CardSurfaceDark),
                shape = RoundedCornerShape(18.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Storage,
                                contentDescription = null,
                                tint = ElectricViolet,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Bộ nhớ trong",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimaryDark
                            )
                        }
                        Text(
                            text = "${storageStats.usedGbFormatted} / ${storageStats.totalGbFormatted}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextSecondaryDark
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    LinearProgressIndicator(
                        progress = { (storageStats.usedPercent / 100f).coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = if (storageStats.usedPercent > 88f) WarningAmber else ElectricViolet,
                        trackColor = Color(0xFF1E293B),
                        strokeCap = StrokeCap.Round
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Ước tính Cache hệ thống: ~${storageStats.estimatedCacheMbFormatted}",
                            fontSize = 12.sp,
                            color = CyanPrimary
                        )

                        Text(
                            text = "Dọn ngay ›",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = CyanPrimary,
                            modifier = Modifier.clickable { onNavigateToTrim() }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Device Telemetry Grid
            Text(
                text = "THÔNG TIN PHẦN CỨNG & THIẾT BỊ",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                color = TextSecondaryDark,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp, vertical = 4.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MetricChip(
                    icon = Icons.Default.Memory,
                    label = "CPU",
                    value = "${deviceInfo.cpuCores} nhân (${deviceInfo.cpuArch})",
                    tint = CyanPrimary,
                    modifier = Modifier.weight(1f)
                )
                MetricChip(
                    icon = Icons.Default.DeviceThermostat,
                    label = "Nhiệt độ Pin",
                    value = "${deviceInfo.batteryTempC}°C (${deviceInfo.batteryPercent}%)",
                    tint = if (deviceInfo.batteryTempC > 40f) WarningAmber else NeonEmerald,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MetricChip(
                    icon = Icons.Default.Timer,
                    label = "Thời gian bật máy",
                    value = deviceInfo.uptimeFormatted,
                    tint = ElectricViolet,
                    modifier = Modifier.weight(1f)
                )
                MetricChip(
                    icon = Icons.Default.CleaningServices,
                    label = "Lệnh dọn chính",
                    value = "pm trim-caches",
                    tint = CyanPrimary,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))
        }

        // Result Dialog
        lastResult?.let { result ->
            OptimizationResultDialog(
                result = result,
                onDismiss = { viewModel.dismissResult() }
            )
        }
    }
}

@Composable
fun BoostActionButton(
    isBoosting: Boolean,
    currentStep: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(
            animation = tween(800),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    Surface(
        onClick = onClick,
        enabled = !isBoosting,
        shape = RoundedCornerShape(16.dp),
        color = Color.Transparent,
        modifier = modifier
            .fillMaxWidth()
            .height(58.dp)
            .scale(if (!isBoosting) pulseScale else 1f)
            .testTag("quick_boost_action_button")
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.horizontalGradient(
                        colors = if (isBoosting) {
                            listOf(Color(0xFF334155), Color(0xFF1E293B))
                        } else {
                            listOf(CyanPrimary, ElectricViolet)
                        }
                    )
                )
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                if (isBoosting) {
                    CircularProgressIndicator(
                        color = Color.White,
                        modifier = Modifier.size(22.dp),
                        strokeWidth = 2.5.dp
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = currentStep.ifEmpty { "Đang tối ưu..." },
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.RocketLaunch,
                        contentDescription = null,
                        tint = Color(0xFF0A0E17),
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "TĂNG TỐC NGAY (BOOST)",
                        color = Color(0xFF0A0E17),
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                }
            }
        }
    }
}

@Composable
fun OptimizationResultDialog(
    result: OptimizationResult,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CardSurfaceDark,
        title = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .background(NeonEmerald.copy(alpha = 0.15f))
                        .border(2.dp, NeonEmerald, CircleShape)
                ) {
                    Icon(
                        imageVector = Icons.Default.RocketLaunch,
                        contentDescription = null,
                        tint = NeonEmerald,
                        modifier = Modifier.size(32.dp)
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "TỐI ƯU HÓA HOÀN TẤT!",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    color = TextPrimaryDark,
                    letterSpacing = 0.5.sp
                )
            }
        },
        text = {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "Hệ thống đã được dọn dẹp và thu hồi bộ nhớ thành công.",
                    fontSize = 13.sp,
                    color = TextSecondaryDark,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(16.dp))

                Surface(
                    color = CardSurfaceVariantDark,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "RAM giải phóng",
                                fontSize = 11.sp,
                                color = TextSecondaryDark
                            )
                            Text(
                                text = "+${result.freedRamMb} MB",
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold,
                                color = NeonEmerald
                            )
                        }

                        Box(
                            modifier = Modifier
                                .width(1.dp)
                                .height(32.dp)
                                .background(Color(0xFF263554))
                        )

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "Bộ nhớ dọn dẹp",
                                fontSize = 11.sp,
                                color = TextSecondaryDark
                            )
                            val storageMb = (result.freedStorageBytes / (1024.0 * 1024.0)).toInt()
                            Text(
                                text = "+$storageMb MB",
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold,
                                color = CyanPrimary
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "Quyền sử dụng: ${result.privilegeUsed}",
                    fontSize = 11.sp,
                    color = TextSecondaryDark
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = CyanPrimary),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("dialog_confirm_button")
            ) {
                Text(
                    text = "Tuyệt vời",
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0A0E17)
                )
            }
        }
    )
}
