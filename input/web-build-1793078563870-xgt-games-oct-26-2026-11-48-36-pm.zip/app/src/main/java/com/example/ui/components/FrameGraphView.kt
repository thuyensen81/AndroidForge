package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.XgtDarkSurface
import com.example.ui.theme.XgtMatrixGreen
import com.example.ui.theme.XgtNeonCyan
import com.example.ui.theme.XgtNeonMagenta
import com.example.ui.theme.XgtTextMuted
import com.example.ui.theme.XgtTextSecondary
import java.util.Locale

@Composable
fun FrameGraphView(
  frameTimesMs: List<Float>,
  targetRefreshRate: Int,
  modifier: Modifier = Modifier
) {
  val targetFrameTime = 1000f / targetRefreshRate
  val currentLatest = frameTimesMs.lastOrNull() ?: targetFrameTime

  Box(
    modifier = modifier
      .fillMaxWidth()
      .background(XgtDarkSurface, RoundedCornerShape(16.dp))
      .border(1.dp, Color(0xFF1E283D), RoundedCornerShape(16.dp))
      .padding(14.dp)
      .testTag("frame_graph_container")
  ) {
    Column {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "FRAME TIME PACING (MEMC SMOOTH)",
            color = XgtNeonCyan,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
          )
          Text(
            text = "Real-time hardware frame delta & jitter tracking",
            color = XgtTextMuted,
            fontSize = 10.sp
          )
        }

        Text(
          text = String.format(Locale.US, "%.1f ms", currentLatest),
          color = if (currentLatest <= targetFrameTime * 1.15f) XgtMatrixGreen else XgtNeonMagenta,
          fontSize = 14.sp,
          fontWeight = FontWeight.Black,
          fontFamily = FontFamily.Monospace
        )
      }

      Spacer(modifier = Modifier.height(10.dp))

      Canvas(
        modifier = Modifier
          .fillMaxWidth()
          .height(95.dp)
          .testTag("frame_graph_canvas")
      ) {
        val w = size.width
        val h = size.height

        // Graph scale: 0ms at bottom, 25ms at top
        val maxScaleMs = 25.0f

        // Draw horizontal guide lines: 16.6ms (60fps), 8.3ms (120fps)
        val y60 = h - (16.66f / maxScaleMs * h)
        val y120 = h - (8.33f / maxScaleMs * h)

        // 60fps line
        drawLine(
          color = Color(0x33FF9E00),
          start = Offset(0f, y60),
          end = Offset(w, y60),
          strokeWidth = 1.dp.toPx()
        )

        // 120fps target line
        drawLine(
          color = Color(0x5500FF9D),
          start = Offset(0f, y120),
          end = Offset(w, y120),
          strokeWidth = 1.dp.toPx()
        )

        if (frameTimesMs.size < 2) return@Canvas

        val stepX = w / (frameTimesMs.size - 1)
        val linePath = Path()
        val fillPath = Path()

        frameTimesMs.forEachIndexed { i, ms ->
          val clampedMs = ms.coerceIn(0f, maxScaleMs)
          val x = i * stepX
          val y = (h - (clampedMs / maxScaleMs * h)).coerceIn(0f, h)

          if (i == 0) {
            linePath.moveTo(x, y)
            fillPath.moveTo(x, h)
            fillPath.lineTo(x, y)
          } else {
            linePath.lineTo(x, y)
            fillPath.lineTo(x, y)
          }
        }

        fillPath.lineTo(w, h)
        fillPath.close()

        // Draw gradient area
        val areaGradient = Brush.verticalGradient(
          colors = listOf(
            XgtNeonCyan.copy(alpha = 0.35f),
            XgtNeonCyan.copy(alpha = 0.05f),
            Color.Transparent
          ),
          startY = 0f,
          endY = h
        )
        drawPath(fillPath, brush = areaGradient)

        // Draw curve stroke
        drawPath(
          linePath,
          color = XgtNeonCyan,
          style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round)
        )

        // Point at latest frame
        val lastX = w
        val lastY = (h - ((frameTimesMs.last().coerceIn(0f, maxScaleMs)) / maxScaleMs * h)).coerceIn(0f, h)
        drawCircle(
          color = XgtMatrixGreen,
          radius = 4.dp.toPx(),
          center = Offset(lastX, lastY)
        )
      }

      Spacer(modifier = Modifier.height(6.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Text(text = "← Past 50 Frames", color = XgtTextMuted, fontSize = 9.sp)
        Text(text = "Target Line: 8.3ms (120Hz)", color = XgtMatrixGreen, fontSize = 9.sp)
        Text(text = "Live Now →", color = XgtTextMuted, fontSize = 9.sp)
      }
    }
  }
}
