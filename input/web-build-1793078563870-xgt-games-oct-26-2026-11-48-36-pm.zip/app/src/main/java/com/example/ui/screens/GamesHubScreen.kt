package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.GameProfileEntity
import com.example.model.PerformanceMetrics
import com.example.ui.theme.XgtAmberBoost
import com.example.ui.theme.XgtDarkSurface
import com.example.ui.theme.XgtMatrixGreen
import com.example.ui.theme.XgtNeonCyan
import com.example.ui.theme.XgtNeonMagenta
import com.example.ui.theme.XgtSurfaceHighlight
import com.example.ui.theme.XgtSurfaceVariant
import com.example.ui.theme.XgtTextMuted
import com.example.ui.theme.XgtTextPrimary
import com.example.ui.theme.XgtTextSecondary
import java.util.Locale

@Composable
fun GamesHubScreen(
  profiles: List<GameProfileEntity>,
  metrics: PerformanceMetrics,
  onLaunchGame: (String) -> Unit,
  onApplyProfile: (GameProfileEntity) -> Unit,
  onSaveNewProfile: (String, String, String) -> Unit,
  onDeleteProfile: (String) -> Unit
) {
  var showAddDialog by remember { mutableStateOf(false) }
  var filterTab by remember { mutableIntStateOf(0) } // 0: All, 1: Installed Titles, 2: Built-in Games

  val filteredProfiles = when (filterTab) {
    1 -> profiles.filter { !it.isBuiltIn }
    2 -> profiles.filter { it.isBuiltIn }
    else -> profiles
  }

  Box(modifier = Modifier.fillMaxSize()) {
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp),
      contentPadding = PaddingValues(top = 16.dp, bottom = 96.dp)
    ) {
      // Header with Add Button
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text(
              text = "REUSABLE GAME PROFILES",
              color = XgtNeonCyan,
              fontSize = 18.sp,
              fontWeight = FontWeight.Black,
              letterSpacing = 1.sp
            )
            Text(
              text = "Room-persisted graphics & performance configurations",
              color = XgtTextSecondary,
              fontSize = 11.sp
            )
          }

          Button(
            onClick = { showAddDialog = true },
            colors = ButtonDefaults.buttonColors(containerColor = XgtNeonCyan),
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
            modifier = Modifier.testTag("save_current_profile_btn")
          ) {
            Icon(Icons.Default.Add, contentDescription = null, tint = Color(0xFF090D14), modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("SAVE CONFIG", color = Color(0xFF090D14), fontSize = 11.sp, fontWeight = FontWeight.Black)
          }
        }
      }

      // Filter Tabs (All, Installed Games, Built-in)
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          listOf("All (${profiles.size})", "Installed Games", "Built-in Games").forEachIndexed { index, label ->
            val isSelected = filterTab == index
            Box(
              modifier = Modifier
                .weight(1f)
                .background(
                  if (isSelected) XgtSurfaceHighlight else XgtDarkSurface,
                  RoundedCornerShape(10.dp)
                )
                .border(
                  width = 1.dp,
                  color = if (isSelected) XgtNeonCyan else Color(0xFF1E283D),
                  shape = RoundedCornerShape(10.dp)
                )
                .clickable { filterTab = index }
                .padding(vertical = 8.dp),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = label,
                color = if (isSelected) XgtNeonCyan else XgtTextSecondary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
              )
            }
          }
        }
      }

      // Profiles List
      items(filteredProfiles, key = { it.id }) { profile ->
        GameProfileCard(
          profile = profile,
          onLaunch = { onLaunchGame(profile.id) },
          onApply = { onApplyProfile(profile) },
          onDelete = { onDeleteProfile(profile.id) }
        )
      }

      // Room Schema Architecture Explanatory Card
      item {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .background(XgtDarkSurface, RoundedCornerShape(16.dp))
            .border(1.dp, Color(0xFF1E283D), RoundedCornerShape(16.dp))
            .padding(16.dp)
        ) {
          Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.Tune, contentDescription = null, tint = XgtMatrixGreen)
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "ROOM PERSISTENCE ARCHITECTURE",
                color = XgtTextPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
              )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
              text = "Stores per-game target refresh rates (60–144Hz), MEMC smoothing factors, touch polling (120–480Hz), deadzones, shader bloom, HDR, and resolution scale in a local SQLite Room schema. Tap 'APPLY CONFIG' to load any saved profile instantly.",
              color = XgtTextSecondary,
              fontSize = 11.sp,
              lineHeight = 16.sp
            )
          }
        }
      }
    }

    // Dialog for Saving Current Tuning as New Reusable Profile
    if (showAddDialog) {
      SaveProfileDialog(
        onDismiss = { showAddDialog = false },
        onConfirm = { name, pkg, genre ->
          onSaveNewProfile(name, pkg, genre)
          showAddDialog = false
        }
      )
    }
  }
}

@Composable
private fun GameProfileCard(
  profile: GameProfileEntity,
  onLaunch: () -> Unit,
  onApply: () -> Unit,
  onDelete: () -> Unit
) {
  Box(
    modifier = Modifier
      .fillMaxWidth()
      .background(XgtDarkSurface, RoundedCornerShape(18.dp))
      .border(1.dp, Color(0xFF1E283D), RoundedCornerShape(18.dp))
      .clip(RoundedCornerShape(18.dp))
      .testTag("game_profile_card_${profile.id}")
  ) {
    Column {
      // Banner or Cyber Gradient Header
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(if (profile.bannerResId != null) 130.dp else 75.dp)
          .background(XgtSurfaceVariant)
      ) {
        if (profile.bannerResId != null) {
          Image(
            painter = painterResource(id = profile.bannerResId),
            contentDescription = profile.gameTitle,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
          )
        } else {
          Box(
            modifier = Modifier
              .fillMaxSize()
              .background(
                Brush.linearGradient(
                  listOf(Color(0xFF0F172A), Color(0xFF1E1B4B), Color(0xFF042F2E))
                )
              )
          ) {
            Row(
              modifier = Modifier
                .padding(12.dp)
                .align(Alignment.CenterStart),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(
                imageVector = Icons.Default.Gamepad,
                contentDescription = null,
                tint = XgtNeonCyan,
                modifier = Modifier.size(32.dp)
              )
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text(
                  text = profile.gameTitle,
                  color = XgtTextPrimary,
                  fontSize = 16.sp,
                  fontWeight = FontWeight.Bold
                )
                Text(
                  text = profile.packageName,
                  color = XgtTextMuted,
                  fontSize = 10.sp,
                  fontFamily = FontFamily.Monospace
                )
              }
            }
          }
        }

        // Top Badges
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Box(
            modifier = Modifier
              .background(Color(0xD90A0E18), RoundedCornerShape(6.dp))
              .border(1.dp, XgtNeonCyan.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
              .padding(horizontal = 6.dp, vertical = 2.dp)
          ) {
            Text(
              text = "${profile.touchSamplingRateHz}Hz TOUCH",
              color = XgtNeonCyan,
              fontSize = 9.sp,
              fontWeight = FontWeight.Bold,
              fontFamily = FontFamily.Monospace
            )
          }

          Box(
            modifier = Modifier
              .background(Color(0xD90A0E18), RoundedCornerShape(6.dp))
              .border(1.dp, XgtMatrixGreen.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
              .padding(horizontal = 6.dp, vertical = 2.dp)
          ) {
            Text(
              text = "${profile.targetRefreshRate}Hz | MEMC",
              color = XgtMatrixGreen,
              fontSize = 9.sp,
              fontWeight = FontWeight.Bold,
              fontFamily = FontFamily.Monospace
            )
          }
        }
      }

      // Profile Content
      Column(modifier = Modifier.padding(14.dp)) {
        if (profile.bannerResId != null) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(
                text = profile.gameTitle,
                color = XgtTextPrimary,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
              )
              Text(
                text = profile.genre,
                color = XgtTextSecondary,
                fontSize = 11.sp
              )
            }
            Text(
              text = profile.packageName,
              color = XgtTextMuted,
              fontSize = 10.sp,
              fontFamily = FontFamily.Monospace
            )
          }
          Spacer(modifier = Modifier.height(10.dp))
        }

        // Detailed Settings Grid in Badge Chips
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          ConfigChip(
            label = "Scale",
            value = "${(profile.resolutionScale * 100).toInt()}%"
          )
          ConfigChip(
            label = "Sens",
            value = "${profile.touchSensitivity}x"
          )
          ConfigChip(
            label = "Deadzone",
            value = "${profile.deadzonePercent}%"
          )
          ConfigChip(
            label = "Haptics",
            value = profile.hapticFeedbackMode.take(6)
          )
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Action Buttons
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          // Apply Config Button (activates profile into governor)
          Button(
            onClick = onApply,
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E283D)),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
            modifier = Modifier.testTag("apply_profile_${profile.id}")
          ) {
            Icon(Icons.Default.Tune, contentDescription = null, tint = XgtNeonCyan, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("APPLY CONFIG", color = XgtNeonCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
          }

          Row(verticalAlignment = Alignment.CenterVertically) {
            if (profile.isBuiltIn) {
              Button(
                onClick = onLaunch,
                colors = ButtonDefaults.buttonColors(containerColor = XgtNeonCyan),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                modifier = Modifier.testTag("play_game_${profile.id}")
              ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color(0xFF090D14), modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("PLAY NOW", color = Color(0xFF090D14), fontSize = 11.sp, fontWeight = FontWeight.Black)
              }
            } else {
              IconButton(
                onClick = onDelete,
                modifier = Modifier.size(36.dp).testTag("delete_profile_${profile.id}")
              ) {
                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFF64748B), modifier = Modifier.size(18.dp))
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun ConfigChip(label: String, value: String) {
  Box(
    modifier = Modifier
      .background(Color(0xFF0A0E18), RoundedCornerShape(6.dp))
      .padding(horizontal = 6.dp, vertical = 3.dp)
  ) {
    Row {
      Text(text = "$label: ", color = XgtTextMuted, fontSize = 9.sp)
      Text(text = value, color = XgtTextPrimary, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    }
  }
}

@Composable
private fun SaveProfileDialog(
  onDismiss: () -> Unit,
  onConfirm: (name: String, pkg: String, genre: String) -> Unit
) {
  var gameName by remember { mutableStateOf("") }
  var packageName by remember { mutableStateOf("") }
  var genre by remember { mutableStateOf("Esports Action") }

  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = Color(0xFF0E1320),
    title = {
      Text(
        text = "SAVE GAME PROFILE",
        color = XgtNeonCyan,
        fontSize = 16.sp,
        fontWeight = FontWeight.Black,
        letterSpacing = 1.sp
      )
    },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
          text = "Save current graphics, 480Hz touch sensitivity, and MEMC frame pacing settings into Room database.",
          color = XgtTextSecondary,
          fontSize = 11.sp
        )

        OutlinedTextField(
          value = gameName,
          onValueChange = { gameName = it },
          label = { Text("Game Title (e.g. Apex Legends Mobile)") },
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = XgtNeonCyan,
            unfocusedBorderColor = Color(0xFF1E283D),
            focusedTextColor = XgtTextPrimary,
            unfocusedTextColor = XgtTextPrimary
          ),
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("input_game_title")
        )

        OutlinedTextField(
          value = packageName,
          onValueChange = { packageName = it },
          label = { Text("Package Name (e.g. com.ea.apex)") },
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = XgtNeonCyan,
            unfocusedBorderColor = Color(0xFF1E283D),
            focusedTextColor = XgtTextPrimary,
            unfocusedTextColor = XgtTextPrimary
          ),
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("input_package_name")
        )

        OutlinedTextField(
          value = genre,
          onValueChange = { genre = it },
          label = { Text("Genre (e.g. FPS / MOBA / Racing)") },
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = XgtNeonCyan,
            unfocusedBorderColor = Color(0xFF1E283D),
            focusedTextColor = XgtTextPrimary,
            unfocusedTextColor = XgtTextPrimary
          ),
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("input_game_genre")
        )
      }
    },
    confirmButton = {
      Button(
        onClick = { onConfirm(gameName, packageName, genre) },
        enabled = gameName.isNotBlank(),
        colors = ButtonDefaults.buttonColors(containerColor = XgtNeonCyan),
        modifier = Modifier.testTag("confirm_save_profile_btn")
      ) {
        Text("SAVE TO DATABASE", color = Color(0xFF090D14), fontWeight = FontWeight.Bold, fontSize = 12.sp)
      }
    },
    dismissButton = {
      Button(
        onClick = onDismiss,
        colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent)
      ) {
        Text("CANCEL", color = XgtTextSecondary)
      }
    }
  )
}
