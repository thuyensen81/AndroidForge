package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// XGT Esports Cyber Theme Palette
val XgtObsidian = Color(0xFF090C12)
val XgtDarkSurface = Color(0xFF101522)
val XgtSurfaceVariant = Color(0xFF182032)
val XgtSurfaceHighlight = Color(0xFF222C44)

// Accents & Neons
val XgtNeonCyan = Color(0xFF00E5FF)
val XgtNeonMagenta = Color(0xFFFF2A6D)
val XgtMatrixGreen = Color(0xFF00FF9D)
val XgtAmberBoost = Color(0xFFFF9E00)
val XgtElectricPurple = Color(0xFF9D4EDD)

// Text & Support
val XgtTextPrimary = Color(0xFFF1F5F9)
val XgtTextSecondary = Color(0xFF94A3B8)
val XgtTextMuted = Color(0xFF64748B)
val XgtBorder = Color(0xFF26334D)
val XgtError = Color(0xFFFF3366)

// Translucent Glows
val XgtCyanGlow = Color(0x3300E5FF)
val XgtMagentaGlow = Color(0x33FF2A6D)
val XgtGreenGlow = Color(0x3300FF9D)
