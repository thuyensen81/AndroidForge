package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BlurOn
import androidx.compose.material.icons.filled.BrightnessMedium
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.HighQuality
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ColorFilterMode
import com.example.model.GraphicSettings
import com.example.ui.components.CyberSlider
import com.example.ui.components.CyberSwitchCard
import com.example.ui.theme.XgtAmberBoost
import com.example.ui.theme.XgtDarkSurface
import com.example.ui.theme.XgtMatrixGreen
import com.example.ui.theme.XgtNeonCyan
import com.example.ui.theme.XgtNeonMagenta
import com.example.ui.theme.XgtSurfaceHighlight
import com.example.ui.theme.XgtTextMuted
import com.example.ui.theme.XgtTextPrimary
import com.example.ui.theme.XgtTextSecondary
import java.util.Locale
import kotlin.random.Random
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive

@Composable
fun GraphicsScreen(
  settings: GraphicSettings,
  onSettingsChanged: (GraphicSettings) -> Unit
) {
  var animPhase by remember { mutableFloatStateOf(0f) }

  LaunchedEffect(Unit) {
    while (isActive) {
      animPhase += 0.05f
      delay(16L)
    }
  }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp),
    contentPadding = PaddingValues(top = 16.dp, bottom = 96.dp)
  ) {
    item {
      Column {
        Text(
          text = "GRAPHICS & POST-PROCESSING",
          color = XgtNeonCyan,
          fontSize = 18.sp,
          fontWeight = FontWeight.Black,
          letterSpacing = 1.sp
        )
        Text(
          text = "Fine-tune rendering pipelines, shaders, particles, and clarity",
          color = XgtTextSecondary,
          fontSize = 11.sp
        )
      }
    }

    // Interactive Live Graphics Canvas Preview
    item {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(180.dp)
          .background(XgtDarkSurface, RoundedCornerShape(16.dp))
          .border(1.dp, XgtNeonCyan.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
          .clip(RoundedCornerShape(16.dp))
          .testTag("graphics_preview_canvas_box")
      ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
          drawLiveGraphicsPreview(settings, animPhase)
        }

        // Live stats badge on preview
        Box(
          modifier = Modifier
            .padding(10.dp)
            .background(Color(0xCC090D14), RoundedCornerShape(8.dp))
            .border(1.dp, XgtNeonCyan.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp)
            .align(Alignment.TopStart)
        ) {
          Text(
            text = "LIVE SHADER PREVIEW [${(settings.resolutionScale * 100).toInt()}%]",
            color = XgtNeonCyan,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
          )
        }
      }
    }

    // Resolution Scale Selection
    item {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .background(XgtDarkSurface, RoundedCornerShape(16.dp))
          .border(1.dp, Color(0xFF1E283D), RoundedCornerShape(16.dp))
          .padding(16.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text("RESOLUTION SCALE", color = XgtTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
          Text(
            text = when (settings.resolutionScale) {
              0.75f -> "720p Performance"
              1.0f -> "1080p FHD Native"
              1.25f -> "1440p 2K Ultra"
              else -> "4K Supersampling"
            },
            color = XgtNeonCyan,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
          )
        }
        Spacer(modifier = Modifier.height(12.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          listOf(0.75f to "720p", 1.0f to "1080p", 1.25f to "1440p", 1.5f to "2K+").forEach { (scale, label) ->
            val isSelected = settings.resolutionScale == scale
            Box(
              modifier = Modifier
                .weight(1f)
                .background(
                  if (isSelected) XgtSurfaceHighlight else Color(0xFF0F1522),
                  RoundedCornerShape(10.dp)
                )
                .border(
                  width = 1.dp,
                  color = if (isSelected) XgtNeonCyan else Color(0xFF1E283D),
                  shape = RoundedCornerShape(10.dp)
                )
                .clickable { onSettingsChanged(settings.copy(resolutionScale = scale)) }
                .padding(vertical = 10.dp),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = label,
                color = if (isSelected) XgtNeonCyan else XgtTextSecondary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
              )
            }
          }
        }
      }
    }

    // Color Grading Palettes
    item {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .background(XgtDarkSurface, RoundedCornerShape(16.dp))
          .border(1.dp, Color(0xFF1E283D), RoundedCornerShape(16.dp))
          .padding(16.dp)
      ) {
        Text("ESPORTS COLOR GRADING", color = XgtTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(10.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          ColorFilterMode.values().forEach { mode ->
            val isSelected = settings.colorFilter == mode
            Box(
              modifier = Modifier
                .weight(1f)
                .background(
                  if (isSelected) XgtSurfaceHighlight else Color(0xFF0F1522),
                  RoundedCornerShape(10.dp)
                )
                .border(
                  width = 1.dp,
                  color = if (isSelected) XgtNeonMagenta else Color(0xFF1E283D),
                  shape = RoundedCornerShape(10.dp)
                )
                .clickable { onSettingsChanged(settings.copy(colorFilter = mode)) }
                .padding(vertical = 8.dp),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = mode.label,
                color = if (isSelected) XgtNeonMagenta else XgtTextSecondary,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1
              )
            }
          }
        }
      }
    }

    // Detailed Shaders & Particle Sliders
    item {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .background(XgtDarkSurface, RoundedCornerShape(16.dp))
          .border(1.dp, Color(0xFF1E283D), RoundedCornerShape(16.dp))
          .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
      ) {
        Text("POST-PROCESSING & PARTICLE TUNING", color = XgtTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)

        CyberSlider(
          label = "Particle FX Density",
          valueText = "${(settings.particleDensity * 100).toInt()}%",
          value = settings.particleDensity,
          onValueChange = { onSettingsChanged(settings.copy(particleDensity = it)) },
          valueRange = 0.5f..2.0f,
          accentColor = XgtMatrixGreen
        )

        CyberSlider(
          label = "Neon Bloom Glow",
          valueText = "${(settings.bloomIntensity * 100).toInt()}%",
          value = settings.bloomIntensity,
          onValueChange = { onSettingsChanged(settings.copy(bloomIntensity = it)) },
          valueRange = 0.0f..1.0f,
          accentColor = XgtNeonCyan
        )

        CyberSlider(
          label = "Motion Blur Intensity",
          valueText = if (settings.motionBlur) "${(settings.motionBlurIntensity * 100).toInt()}%" else "Disabled",
          value = settings.motionBlurIntensity,
          onValueChange = { onSettingsChanged(settings.copy(motionBlurIntensity = it)) },
          valueRange = 0.0f..1.0f,
          accentColor = XgtNeonMagenta
        )
      }
    }

    // Toggles for HDR and Anti-Aliasing
    item {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        CyberSwitchCard(
          title = "HDR Dynamic Contrast",
          subtitle = "Expands shadow detail and highlights for esports visual clarity",
          checked = settings.hdrContrast,
          onCheckedChange = { onSettingsChanged(settings.copy(hdrContrast = it)) },
          icon = Icons.Default.BrightnessMedium,
          accentColor = XgtAmberBoost
        )

        CyberSwitchCard(
          title = "FXAA Anti-Aliasing Filter",
          subtitle = "Smooths jagged polygon edges with minimal GPU overhead",
          checked = settings.antiAliasing,
          onCheckedChange = { onSettingsChanged(settings.copy(antiAliasing = it)) },
          icon = Icons.Default.AutoAwesome,
          accentColor = XgtNeonCyan
        )

        CyberSwitchCard(
          title = "Dynamic Motion Blur",
          subtitle = "Simulates cinematic camera velocity during high-speed action",
          checked = settings.motionBlur,
          onCheckedChange = { onSettingsChanged(settings.copy(motionBlur = it)) },
          icon = Icons.Default.BlurOn,
          accentColor = XgtNeonMagenta
        )
      }
    }
  }
}

private fun DrawScope.drawLiveGraphicsPreview(settings: GraphicSettings, animPhase: Float) {
  val w = size.width
  val h = size.height

  val baseColor = when (settings.colorFilter) {
    ColorFilterMode.VIVID_NEON -> XgtNeonCyan
    ColorFilterMode.ESPORTS_CLARITY -> Color(0xFF00FFC2)
    ColorFilterMode.CINEMATIC_WARM -> Color(0xFFFF9E00)
    ColorFilterMode.NIGHT_VISION -> Color(0xFF00FF66)
  }

  // Draw Grid lines
  val gridSpacing = 28.dp.toPx()
  var gy = h * 0.55f
  while (gy < h) {
    drawLine(
      color = baseColor.copy(alpha = 0.25f),
      start = Offset(0f, gy),
      end = Offset(w, gy),
      strokeWidth = 1.dp.toPx()
    )
    gy += 14.dp.toPx()
  }

  // Draw cyber vehicle silhouette
  val cx = w / 2f
  val cy = h * 0.55f
  val carW = 80.dp.toPx()
  val carH = 34.dp.toPx()

  // Bloom aura behind car
  if (settings.neonBloom) {
    drawCircle(
      color = baseColor.copy(alpha = 0.35f * settings.bloomIntensity),
      radius = 50.dp.toPx(),
      center = Offset(cx, cy)
    )
  }

  // Car Body
  val carPath = Path().apply {
    moveTo(cx - carW / 2f, cy + carH / 2f)
    lineTo(cx - carW * 0.45f, cy)
    lineTo(cx - carW * 0.15f, cy - carH / 2f)
    lineTo(cx + carW * 0.25f, cy - carH / 2f)
    lineTo(cx + carW * 0.45f, cy)
    lineTo(cx + carW / 2f, cy + carH / 2f)
    close()
  }

  drawPath(
    carPath,
    brush = Brush.horizontalGradient(listOf(baseColor, XgtNeonMagenta))
  )

  // Particle sparks based on density
  val particleCount = (24 * settings.particleDensity).toInt()
  for (i in 0 until particleCount) {
    val px = (cx - carW * 0.6f) - ((i * 19 + (animPhase * 50).toInt()) % 90).toFloat()
    val py = (cy + carH * 0.3f) + (((i * 7) % 20) - 10).toFloat()
    drawCircle(
      color = if (i % 2 == 0) baseColor else XgtNeonMagenta,
      radius = 2.dp.toPx(),
      center = Offset(px, py)
    )
  }
}
