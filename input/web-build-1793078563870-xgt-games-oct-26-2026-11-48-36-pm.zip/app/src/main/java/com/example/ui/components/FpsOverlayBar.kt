package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.PerformanceMetrics
import com.example.ui.theme.XgtAmberBoost
import com.example.ui.theme.XgtMatrixGreen
import com.example.ui.theme.XgtNeonCyan
import com.example.ui.theme.XgtTextPrimary
import java.util.Locale

@Composable
fun FpsOverlayBar(
  metrics: PerformanceMetrics,
  isMemcActive: Boolean,
  onBoostClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  var isExpanded by remember { mutableStateOf(true) }

  Box(
    modifier = modifier
      .background(Color(0xE60A0E18), RoundedCornerShape(20.dp))
      .border(1.dp, XgtNeonCyan.copy(alpha = 0.4f), RoundedCornerShape(20.dp))
      .padding(horizontal = 10.dp, vertical = 6.dp)
      .clickable { isExpanded = !isExpanded }
      .testTag("fps_overlay_bar")
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.Center
    ) {
      Box(
        modifier = Modifier
          .size(8.dp)
          .background(XgtMatrixGreen, CircleShape)
      )
      Spacer(modifier = Modifier.width(6.dp))

      Text(
        text = String.format(Locale.US, "%.0f FPS", metrics.currentFps),
        color = XgtNeonCyan,
        fontSize = 13.sp,
        fontWeight = FontWeight.Black,
        fontFamily = FontFamily.Monospace
      )

      AnimatedVisibility(visible = isExpanded) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Spacer(modifier = Modifier.width(10.dp))

          Text(
            text = String.format(Locale.US, "%.1fms", metrics.frameTimeMs),
            color = XgtTextPrimary,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.SemiBold
          )

          Spacer(modifier = Modifier.width(8.dp))

          Box(
            modifier = Modifier
              .background(if (isMemcActive) Color(0x3300FF9D) else Color(0x3364748B), RoundedCornerShape(4.dp))
              .padding(horizontal = 4.dp, vertical = 2.dp)
          ) {
            Text(
              text = if (isMemcActive) "MEMC 2X" else "RAW",
              color = if (isMemcActive) XgtMatrixGreen else Color(0xFF94A3B8),
              fontSize = 9.sp,
              fontWeight = FontWeight.Bold
            )
          }

          Spacer(modifier = Modifier.width(8.dp))

          Box(
            modifier = Modifier
              .background(Color(0x33FF9E00), RoundedCornerShape(4.dp))
              .clickable { onBoostClick() }
              .padding(horizontal = 5.dp, vertical = 2.dp)
              .testTag("overlay_boost_btn")
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Default.Speed,
                contentDescription = "Turbo",
                tint = XgtAmberBoost,
                modifier = Modifier.size(10.dp)
              )
              Spacer(modifier = Modifier.width(2.dp))
              Text(
                text = "BOOST",
                color = XgtAmberBoost,
                fontSize = 9.sp,
                fontWeight = FontWeight.Black
              )
            }
          }
        }
      }
    }
  }
}
