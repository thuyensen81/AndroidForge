package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.PerformanceMetrics
import com.example.ui.theme.XgtAmberBoost
import com.example.ui.theme.XgtDarkSurface
import com.example.ui.theme.XgtMatrixGreen
import com.example.ui.theme.XgtNeonCyan
import com.example.ui.theme.XgtNeonMagenta
import com.example.ui.theme.XgtSurfaceHighlight
import com.example.ui.theme.XgtTextMuted
import com.example.ui.theme.XgtTextPrimary
import com.example.ui.theme.XgtTextSecondary
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun PerformanceGauge(
  metrics: PerformanceMetrics,
  modifier: Modifier = Modifier
) {
  val animatedFps by animateFloatAsState(
    targetValue = metrics.currentFps,
    animationSpec = tween(durationMillis = 200),
    label = "fps_gauge"
  )

  val maxDisplayFps = 144f
  val progress = (animatedFps / maxDisplayFps).coerceIn(0f, 1f)

  Box(
    modifier = modifier
      .fillMaxWidth()
      .background(XgtDarkSurface, RoundedCornerShape(20.dp))
      .border(1.dp, Brush.linearGradient(listOf(XgtNeonCyan.copy(alpha = 0.5f), XgtNeonMagenta.copy(alpha = 0.2f))), RoundedCornerShape(20.dp))
      .padding(16.dp)
      .testTag("performance_gauge_container"),
    contentAlignment = Alignment.Center
  ) {
    Column(
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      // Top status row
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(
            modifier = Modifier
              .size(8.dp)
              .background(if (metrics.isTurboActive) XgtMatrixGreen else XgtAmberBoost, RoundedCornerShape(4.dp))
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = if (metrics.isTurboActive) "TURBO GOVERNOR" else "STANDARD",
            color = if (metrics.isTurboActive) XgtMatrixGreen else XgtAmberBoost,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
          )
        }

        Box(
          modifier = Modifier
            .background(XgtSurfaceHighlight, RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
          Text(
            text = "TARGET: ${metrics.targetFps} Hz",
            color = XgtNeonCyan,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold
          )
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Speedometer Arc Canvas
      Box(
        modifier = Modifier.size(200.dp, 120.dp),
        contentAlignment = Alignment.Center
      ) {
        Canvas(modifier = Modifier.size(190.dp)) {
          val strokeWidth = 14.dp.toPx()
          val startAngle = 150f
          val sweepAngle = 240f

          // Background track
          drawArc(
            color = Color(0xFF1E2638),
            startAngle = startAngle,
            sweepAngle = sweepAngle,
            useCenter = false,
            style = Stroke(width = strokeWidth, cap = StrokeCap.Round),
            size = Size(size.width, size.height)
          )

          // Active glowing progress arc
          val activeSweep = sweepAngle * progress
          val gaugeBrush = Brush.sweepGradient(
            colors = listOf(XgtNeonCyan, XgtMatrixGreen, XgtNeonMagenta),
            center = Offset(size.width / 2f, size.height / 2f)
          )
          drawArc(
            brush = gaugeBrush,
            startAngle = startAngle,
            sweepAngle = activeSweep,
            useCenter = false,
            style = Stroke(width = strokeWidth, cap = StrokeCap.Round),
            size = Size(size.width, size.height)
          )

          // Ticks
          val tickCount = 13
          for (i in 0 until tickCount) {
            val angleDeg = startAngle + (sweepAngle / (tickCount - 1)) * i
            val rad = Math.toRadians(angleDeg.toDouble())
            val outerRadius = (size.width / 2f) - (strokeWidth / 2f) - 6.dp.toPx()
            val innerRadius = outerRadius - (if (i % 3 == 0) 8.dp.toPx() else 4.dp.toPx())
            val cx = size.width / 2f
            val cy = size.height / 2f
            val startX = cx + (innerRadius * cos(rad)).toFloat()
            val startY = cy + (innerRadius * sin(rad)).toFloat()
            val endX = cx + (outerRadius * cos(rad)).toFloat()
            val endY = cy + (outerRadius * sin(rad)).toFloat()

            drawLine(
              color = if (i.toFloat() / (tickCount - 1) <= progress) XgtNeonCyan else Color(0xFF2C3954),
              start = Offset(startX, startY),
              end = Offset(endX, endY),
              strokeWidth = if (i % 3 == 0) 2.5.dp.toPx() else 1.5.dp.toPx()
            )
          }
        }

        // Center Big FPS Counter readout
        Column(
          horizontalAlignment = Alignment.CenterHorizontally,
          modifier = Modifier.padding(top = 16.dp)
        ) {
          Text(
            text = String.format(Locale.US, "%.1f", animatedFps),
            color = XgtTextPrimary,
            fontSize = 38.sp,
            fontWeight = FontWeight.Black,
            fontFamily = FontFamily.Monospace,
            letterSpacing = (-1).sp
          )
          Text(
            text = "REAL-TIME FPS",
            color = XgtNeonCyan,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.5.sp
          )
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Telemetry row (Frame Time, Jitter, 1% Low, Temp)
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .background(Color(0xFF0C101A), RoundedCornerShape(12.dp))
          .padding(vertical = 10.dp, horizontal = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        TelemetryItem(
          label = "FRAME TIME",
          value = String.format(Locale.US, "%.1f ms", metrics.frameTimeMs),
          accentColor = XgtNeonCyan
        )
        TelemetryItem(
          label = "JITTER",
          value = String.format(Locale.US, "%.2f ms", metrics.jitterMs),
          accentColor = if (metrics.jitterMs < 1.0f) XgtMatrixGreen else XgtAmberBoost
        )
        TelemetryItem(
          label = "1% LOW",
          value = String.format(Locale.US, "%.0f fps", metrics.onePercentLowFps),
          accentColor = XgtNeonMagenta
        )
        TelemetryItem(
          label = "TEMP",
          value = String.format(Locale.US, "%.1f°C", metrics.batteryTempCelsius),
          accentColor = if (metrics.batteryTempCelsius < 40f) XgtTextPrimary else XgtAmberBoost
        )
      }
    }
  }
}

@Composable
private fun TelemetryItem(
  label: String,
  value: String,
  accentColor: Color
) {
  Column(horizontalAlignment = Alignment.CenterHorizontally) {
    Text(
      text = label,
      color = XgtTextMuted,
      fontSize = 9.sp,
      fontWeight = FontWeight.Bold,
      letterSpacing = 0.5.sp
    )
    Spacer(modifier = Modifier.height(2.dp))
    Text(
      text = value,
      color = accentColor,
      fontSize = 13.sp,
      fontWeight = FontWeight.ExtraBold,
      fontFamily = FontFamily.Monospace
    )
  }
}
