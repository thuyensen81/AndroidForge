package com.example.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.XgtAmberBoost
import com.example.ui.theme.XgtDarkSurface
import com.example.ui.theme.XgtMatrixGreen
import com.example.ui.theme.XgtNeonCyan
import com.example.ui.theme.XgtNeonMagenta
import com.example.ui.theme.XgtSurfaceHighlight
import com.example.ui.theme.XgtSurfaceVariant
import com.example.ui.theme.XgtTextMuted
import com.example.ui.theme.XgtTextPrimary
import com.example.ui.theme.XgtTextSecondary

@Composable
fun CyberSlider(
  label: String,
  valueText: String,
  value: Float,
  onValueChange: (Float) -> Unit,
  valueRange: ClosedFloatingPointRange<Float>,
  steps: Int = 0,
  accentColor: Color = XgtNeonCyan,
  modifier: Modifier = Modifier
) {
  Column(modifier = modifier.fillMaxWidth()) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = label,
        color = XgtTextPrimary,
        fontSize = 13.sp,
        fontWeight = FontWeight.SemiBold
      )
      Text(
        text = valueText,
        color = accentColor,
        fontSize = 13.sp,
        fontWeight = FontWeight.Bold,
        fontFamily = FontFamily.Monospace
      )
    }

    Slider(
      value = value,
      onValueChange = onValueChange,
      valueRange = valueRange,
      steps = steps,
      colors = SliderDefaults.colors(
        thumbColor = accentColor,
        activeTrackColor = accentColor,
        inactiveTrackColor = Color(0xFF1E283D)
      ),
      modifier = Modifier
        .fillMaxWidth()
        .testTag("slider_${label.lowercase().replace(" ", "_")}")
    )
  }
}

@Composable
fun CyberSwitchCard(
  title: String,
  subtitle: String,
  checked: Boolean,
  onCheckedChange: (Boolean) -> Unit,
  icon: ImageVector? = null,
  accentColor: Color = XgtNeonCyan,
  modifier: Modifier = Modifier
) {
  Box(
    modifier = modifier
      .fillMaxWidth()
      .background(XgtDarkSurface, RoundedCornerShape(14.dp))
      .border(
        width = 1.dp,
        color = if (checked) accentColor.copy(alpha = 0.4f) else Color(0xFF1D2638),
        shape = RoundedCornerShape(14.dp)
      )
      .clickable { onCheckedChange(!checked) }
      .padding(14.dp)
      .testTag("switch_card_${title.lowercase().replace(" ", "_")}")
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(
        modifier = Modifier.weight(1f),
        verticalAlignment = Alignment.CenterVertically
      ) {
        if (icon != null) {
          Box(
            modifier = Modifier
              .size(36.dp)
              .background(
                if (checked) accentColor.copy(alpha = 0.15f) else XgtSurfaceVariant,
                CircleShape
              ),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = icon,
              contentDescription = null,
              tint = if (checked) accentColor else XgtTextMuted,
              modifier = Modifier.size(20.dp)
            )
          }
          Spacer(modifier = Modifier.width(12.dp))
        }

        Column {
          Text(
            text = title,
            color = XgtTextPrimary,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold
          )
          Spacer(modifier = Modifier.height(2.dp))
          Text(
            text = subtitle,
            color = XgtTextSecondary,
            fontSize = 11.sp,
            lineHeight = 15.sp
          )
        }
      }

      Spacer(modifier = Modifier.width(8.dp))

      Switch(
        checked = checked,
        onCheckedChange = onCheckedChange,
        colors = SwitchDefaults.colors(
          checkedThumbColor = accentColor,
          checkedTrackColor = accentColor.copy(alpha = 0.3f),
          uncheckedThumbColor = Color(0xFF64748B),
          uncheckedTrackColor = Color(0xFF1E283D)
        )
      )
    }
  }
}

@Composable
fun TurboBoostButton(
  onClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  val infiniteTransition = rememberInfiniteTransition(label = "turbo_pulse")
  val pulseGlow by infiniteTransition.animateFloat(
    initialValue = 0.6f,
    targetValue = 1.0f,
    animationSpec = infiniteRepeatable(
      animation = tween(900),
      repeatMode = RepeatMode.Reverse
    ),
    label = "glow_alpha"
  )

  Box(
    modifier = modifier
      .fillMaxWidth()
      .height(56.dp)
      .shadow(12.dp, RoundedCornerShape(16.dp), spotColor = XgtNeonCyan)
      .background(
        Brush.horizontalGradient(
          listOf(XgtNeonCyan, Color(0xFF00B0FF), XgtNeonMagenta)
        ),
        RoundedCornerShape(16.dp)
      )
      .border(
        width = 1.5.dp,
        color = Color.White.copy(alpha = pulseGlow * 0.7f),
        shape = RoundedCornerShape(16.dp)
      )
      .clickable { onClick() }
      .testTag("turbo_boost_action_button"),
    contentAlignment = Alignment.Center
  ) {
    Row(
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.Center
    ) {
      Icon(
        imageVector = Icons.Default.Bolt,
        contentDescription = "Turbo Bolt",
        tint = Color(0xFF090C12),
        modifier = Modifier
          .size(24.dp)
          .scale(pulseGlow)
      )
      Spacer(modifier = Modifier.width(8.dp))
      Text(
        text = "⚡ ACTIVATE TURBO BOOST (0ms TOUCH)",
        color = Color(0xFF090C12),
        fontSize = 14.sp,
        fontWeight = FontWeight.Black,
        letterSpacing = 0.8.sp
      )
    }
  }
}
