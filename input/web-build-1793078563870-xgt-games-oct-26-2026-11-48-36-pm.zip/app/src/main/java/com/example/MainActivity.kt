package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.games.CyberRacerGame
import com.example.ui.games.QuantumStrikerGame
import com.example.ui.games.ReflexBladeGame
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.FrameInterpolationScreen
import com.example.ui.screens.GamesHubScreen
import com.example.ui.screens.GraphicsScreen
import com.example.ui.screens.TouchScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.XgtDarkSurface
import com.example.ui.theme.XgtMatrixGreen
import com.example.ui.theme.XgtNeonCyan
import com.example.ui.theme.XgtNeonMagenta
import com.example.ui.theme.XgtObsidian
import com.example.ui.theme.XgtSurfaceHighlight
import com.example.ui.theme.XgtTextMuted
import com.example.ui.theme.XgtTextPrimary
import com.example.viewmodel.XgtViewModel

class MainActivity : ComponentActivity() {

  private val viewModel: XgtViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    setContent {
      MyApplicationTheme {
        XgtApp(viewModel = viewModel)
      }
    }
  }
}

@Composable
fun XgtApp(viewModel: XgtViewModel) {
  val activeGame by viewModel.activeGame.collectAsState()
  val performanceMode by viewModel.performanceMode.collectAsState()
  val graphicSettings by viewModel.graphicSettings.collectAsState()
  val touchSettings by viewModel.touchSettings.collectAsState()
  val interpolationSettings by viewModel.interpolationSettings.collectAsState()
  val metrics by viewModel.metrics.collectAsState()
  val frameHistory by viewModel.frameHistory.collectAsState()
  val touchCalibration by viewModel.touchCalibration.collectAsState()
  val profiles by viewModel.persistedProfiles.collectAsState()
  val showFpsOverlay by viewModel.showFpsOverlay.collectAsState()
  val boostToastMessage by viewModel.boostToastMessage.collectAsState()
  val isBenchmarking by viewModel.isBenchmarking.collectAsState()
  val benchmarkResult by viewModel.benchmarkResult.collectAsState()

  var selectedTab by remember { mutableIntStateOf(0) }

  // If a game is actively running, render immersive game canvas
  if (activeGame != null) {
    when (activeGame) {
      "cyber_racer" -> {
        CyberRacerGame(
          graphicSettings = graphicSettings,
          touchSettings = touchSettings,
          interpolationSettings = interpolationSettings,
          metrics = metrics,
          onExit = { viewModel.exitGame() },
          onBoost = { viewModel.triggerTurboBoost() },
          onSaveScore = { score -> viewModel.saveGameScore("cyber_racer", score) }
        )
      }
      "quantum_striker" -> {
        QuantumStrikerGame(
          graphicSettings = graphicSettings,
          touchSettings = touchSettings,
          interpolationSettings = interpolationSettings,
          metrics = metrics,
          onExit = { viewModel.exitGame() },
          onBoost = { viewModel.triggerTurboBoost() },
          onSaveScore = { score -> viewModel.saveGameScore("quantum_striker", score) }
        )
      }
      "reflex_blade" -> {
        ReflexBladeGame(
          touchSettings = touchSettings,
          metrics = metrics,
          onExit = { viewModel.exitGame() },
          onBoost = { viewModel.triggerTurboBoost() },
          onSaveScore = { score -> viewModel.saveGameScore("reflex_blade", score) }
        )
      }
    }
    return
  }

  Scaffold(
    modifier = Modifier.fillMaxSize(),
    containerColor = XgtObsidian,
    bottomBar = {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .windowInsetsPadding(WindowInsets.navigationBars)
          .padding(horizontal = 12.dp, vertical = 8.dp)
      ) {
        NavigationBar(
          containerColor = Color(0xF2101522),
          modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .border(1.dp, Color(0xFF1E283D), RoundedCornerShape(20.dp))
            .testTag("main_navigation_bar"),
          tonalElevation = 8.dp
        ) {
          NavigationBarItem(
            selected = selectedTab == 0,
            onClick = { selectedTab = 0 },
            icon = { Icon(Icons.Default.Speed, contentDescription = "Turbo Dashboard") },
            label = { Text("Turbo", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
            colors = NavigationBarItemDefaults.colors(
              selectedIconColor = XgtNeonCyan,
              selectedTextColor = XgtNeonCyan,
              indicatorColor = XgtSurfaceHighlight,
              unselectedIconColor = XgtTextMuted,
              unselectedTextColor = XgtTextMuted
            ),
            modifier = Modifier.testTag("nav_tab_turbo")
          )

          NavigationBarItem(
            selected = selectedTab == 1,
            onClick = { selectedTab = 1 },
            icon = { Icon(Icons.Default.Tune, contentDescription = "Graphics") },
            label = { Text("Graphics", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
            colors = NavigationBarItemDefaults.colors(
              selectedIconColor = XgtNeonMagenta,
              selectedTextColor = XgtNeonMagenta,
              indicatorColor = XgtSurfaceHighlight,
              unselectedIconColor = XgtTextMuted,
              unselectedTextColor = XgtTextMuted
            ),
            modifier = Modifier.testTag("nav_tab_graphics")
          )

          NavigationBarItem(
            selected = selectedTab == 2,
            onClick = { selectedTab = 2 },
            icon = { Icon(Icons.Default.TouchApp, contentDescription = "Touch") },
            label = { Text("Touch", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
            colors = NavigationBarItemDefaults.colors(
              selectedIconColor = XgtMatrixGreen,
              selectedTextColor = XgtMatrixGreen,
              indicatorColor = XgtSurfaceHighlight,
              unselectedIconColor = XgtTextMuted,
              unselectedTextColor = XgtTextMuted
            ),
            modifier = Modifier.testTag("nav_tab_touch")
          )

          NavigationBarItem(
            selected = selectedTab == 3,
            onClick = { selectedTab = 3 },
            icon = { Icon(Icons.Default.Bolt, contentDescription = "MEMC Interpolation") },
            label = { Text("MEMC", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
            colors = NavigationBarItemDefaults.colors(
              selectedIconColor = XgtNeonCyan,
              selectedTextColor = XgtNeonCyan,
              indicatorColor = XgtSurfaceHighlight,
              unselectedIconColor = XgtTextMuted,
              unselectedTextColor = XgtTextMuted
            ),
            modifier = Modifier.testTag("nav_tab_memc")
          )

          NavigationBarItem(
            selected = selectedTab == 4,
            onClick = { selectedTab = 4 },
            icon = { Icon(Icons.Default.Gamepad, contentDescription = "Games Arcade") },
            label = { Text("Games", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
            colors = NavigationBarItemDefaults.colors(
              selectedIconColor = XgtNeonMagenta,
              selectedTextColor = XgtNeonMagenta,
              indicatorColor = XgtSurfaceHighlight,
              unselectedIconColor = XgtTextMuted,
              unselectedTextColor = XgtTextMuted
            ),
            modifier = Modifier.testTag("nav_tab_games")
          )
        }
      }
    }
  ) { innerPadding ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
    ) {
      when (selectedTab) {
        0 -> DashboardScreen(
          performanceMode = performanceMode,
          metrics = metrics,
          frameHistory = frameHistory,
          graphicSettings = graphicSettings,
          touchSettings = touchSettings,
          interpolationSettings = interpolationSettings,
          gameProfiles = profiles,
          showFpsOverlay = showFpsOverlay,
          boostToastMessage = boostToastMessage,
          onModeSelected = { viewModel.setPerformanceMode(it) },
          onBoostClick = { viewModel.triggerTurboBoost() },
          onToggleFpsOverlay = { viewModel.toggleFpsOverlay() },
          onLaunchGame = { viewModel.launchGame(it) },
          onNavigateTab = { selectedTab = it }
        )
        1 -> GraphicsScreen(
          settings = graphicSettings,
          onSettingsChanged = { viewModel.updateGraphics(it) }
        )
        2 -> TouchScreen(
          settings = touchSettings,
          calibrationState = touchCalibration,
          onSettingsChanged = { viewModel.updateTouch(it) },
          onTouchCalibration = { viewModel.registerTouchCalibration(it) },
          onResetCalibration = { viewModel.resetTouchCalibration() }
        )
        3 -> FrameInterpolationScreen(
          settings = interpolationSettings,
          metrics = metrics,
          isBenchmarking = isBenchmarking,
          benchmarkResult = benchmarkResult,
          onSettingsChanged = { viewModel.updateInterpolation(it) },
          onRunBenchmark = { viewModel.runBenchmark() }
        )
        4 -> GamesHubScreen(
          profiles = profiles,
          metrics = metrics,
          onLaunchGame = { viewModel.launchGame(it) },
          onApplyProfile = { viewModel.applyProfile(it) },
          onSaveNewProfile = { name, pkg, genre ->
            viewModel.saveCurrentSettingsAsProfile(name, pkg, genre)
          },
          onDeleteProfile = { viewModel.deleteProfile(it) }
        )
      }
    }
  }
}
