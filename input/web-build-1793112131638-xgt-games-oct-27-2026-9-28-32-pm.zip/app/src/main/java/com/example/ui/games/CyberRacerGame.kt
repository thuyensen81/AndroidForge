package com.example.ui.games

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.animation.bouncyClickable
import com.example.model.GraphicSettings
import com.example.model.InterpolationSettings
import com.example.model.PerformanceMetrics
import com.example.model.TouchSettings
import com.example.ui.components.FpsOverlayBar
import com.example.ui.theme.XgtAmberBoost
import com.example.ui.theme.XgtMatrixGreen
import com.example.ui.theme.XgtNeonCyan
import com.example.ui.theme.XgtNeonMagenta
import com.example.ui.theme.XgtTextMuted
import com.example.ui.theme.XgtTextPrimary
import java.util.Locale
import kotlin.math.abs
import kotlin.random.Random
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive

private data class TrafficCar(
  var x: Float, // -1.0f (left lane) to 1.0f (right lane)
  var z: Float, // 0.0f (close) to 1.0f (horizon)
  val color: Color,
  val speed: Float
)

private data class SpeedParticle(
  var x: Float,
  var y: Float,
  var speed: Float,
  var length: Float,
  val color: Color
)

@Composable
fun CyberRacerGame(
  graphicSettings: GraphicSettings,
  touchSettings: TouchSettings,
  interpolationSettings: InterpolationSettings,
  metrics: PerformanceMetrics,
  onExit: () -> Unit,
  onBoost: () -> Unit,
  onSaveScore: (Long) -> Unit
) {
  BackHandler { onExit() }

  var playerLaneX by remember { mutableFloatStateOf(0.0f) } // -0.8f to 0.8f
  var targetLaneX by remember { mutableFloatStateOf(0.0f) }
  var speedKmh by remember { mutableFloatStateOf(160.0f) }
  var nitroFuel by remember { mutableFloatStateOf(100.0f) }
  var isNitroActive by remember { mutableStateOf(false) }
  var score by remember { mutableLongStateOf(0L) }
  var distanceMeters by remember { mutableIntStateOf(0) }
  var isGameOver by remember { mutableStateOf(false) }

  val traffic = remember { mutableStateListOf<TrafficCar>() }
  val particles = remember { mutableStateListOf<SpeedParticle>() }

  // Game Loop
  LaunchedEffect(isGameOver) {
    if (isGameOver) return@LaunchedEffect

    // Seed traffic
    traffic.clear()
    traffic.add(TrafficCar(x = -0.5f, z = 0.8f, color = Color(0xFFFF3366), speed = 0.015f))
    traffic.add(TrafficCar(x = 0.4f, z = 0.95f, color = Color(0xFFFF9E00), speed = 0.012f))

    // Seed particles
    particles.clear()
    for (i in 0 until 35) {
      particles.add(
        SpeedParticle(
          x = Random.nextFloat(),
          y = Random.nextFloat(),
          speed = Random.nextFloat() * 0.04f + 0.02f,
          length = Random.nextFloat() * 40f + 20f,
          color = if (i % 2 == 0) XgtNeonCyan else XgtNeonMagenta
        )
      )
    }

    var roadPhase = 0f

    while (isActive && !isGameOver) {
      val dt = 1f / interpolationSettings.targetRefreshRate.toFloat()

      // Nitro & Speed
      if (isNitroActive && nitroFuel > 0) {
        speedKmh = (speedKmh + 220f * dt).coerceAtMost(380f)
        nitroFuel = (nitroFuel - 25f * dt).coerceAtLeast(0f)
        if (nitroFuel <= 0) isNitroActive = false
      } else {
        speedKmh = (speedKmh - 120f * dt).coerceAtLeast(160f)
        nitroFuel = (nitroFuel + 8f * dt).coerceAtMost(100f)
      }

      val speedFactor = speedKmh / 160f

      // Smooth Frame Interpolation on steering
      val lerpAlpha = if (interpolationSettings.memcEnabled) {
        interpolationSettings.smoothingMultiplier
      } else {
        0.35f
      }
      playerLaneX += (targetLaneX - playerLaneX) * lerpAlpha

      // Distance & score
      distanceMeters += (speedKmh * 0.28f * dt * 5).toInt()
      score += (speedFactor * 15).toLong()

      // Update traffic
      roadPhase += 0.05f * speedFactor
      val iter = traffic.listIterator()
      while (iter.hasNext()) {
        val car = iter.next()
        car.z -= 0.018f * speedFactor
        if (car.z <= 0.05f) {
          // Collision check
          if (abs(car.x - playerLaneX) < 0.32f) {
            isGameOver = true
            onSaveScore(score)
            break
          }
          // Reset to horizon
          car.z = 1.0f
          car.x = (Random.nextFloat() * 1.6f) - 0.8f
        }
      }

      // Add extra drone traffic
      if (traffic.size < 3 && Random.nextFloat() < 0.03f) {
        traffic.add(
          TrafficCar(
            x = (Random.nextFloat() * 1.6f) - 0.8f,
            z = 1.0f,
            color = if (Random.nextBoolean()) Color(0xFF9D4EDD) else Color(0xFFFF2A6D),
            speed = 0.012f
          )
        )
      }

      // Update speed particles
      particles.forEach { p ->
        p.y += p.speed * speedFactor
        if (p.y > 1.0f) {
          p.y = 0.0f
          p.x = Random.nextFloat()
        }
      }

      delay(12L) // high frequency loop
    }
  }

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF070A10))
  ) {
    // 3D Perspective Canvas
    Canvas(
      modifier = Modifier
        .fillMaxSize()
        .pointerInput(touchSettings) {
          detectDragGestures(
            onDrag = { change, dragAmount ->
              change.consume()
              // Apply touch sensitivity and low latency
              val deadzonePx = (touchSettings.deadzonePercent / 100f) * size.width
              var dx = dragAmount.x
              if (abs(dx) > deadzonePx) {
                dx = if (dx > 0) dx - deadzonePx else dx + deadzonePx
                val normalizedDelta = (dx / size.width) * touchSettings.touchSensitivity * 2.2f
                targetLaneX = (targetLaneX + normalizedDelta).coerceIn(-0.85f, 0.85f)
              }
            }
          )
        }
        .testTag("cyber_racer_canvas")
    ) {
      val w = size.width
      val h = size.height

      // Sky & City Horizon
      val horizonY = h * 0.42f
      drawRect(
        brush = Brush.verticalGradient(
          listOf(Color(0xFF04060A), Color(0xFF140D26), Color(0xFF281140)),
          startY = 0f,
          endY = horizonY
        ),
        size = Size(w, horizonY)
      )

      // Futuristic City Grid lines
      for (i in 0 until 12) {
        val cx = (w / 12f) * i
        val towerHeight = ((i * 37) % 90 + 40).dp.toPx()
        drawRect(
          color = Color(0xFF191F38),
          topLeft = Offset(cx + 4.dp.toPx(), horizonY - towerHeight),
          size = Size(w / 14f, towerHeight)
        )
        // Window dots
        drawCircle(
          color = if (i % 2 == 0) XgtNeonCyan.copy(alpha = 0.6f) else XgtNeonMagenta.copy(alpha = 0.5f),
          radius = 1.5.dp.toPx(),
          center = Offset(cx + 12.dp.toPx(), horizonY - towerHeight + 10.dp.toPx())
        )
      }

      // Neon Highway Surface
      val roadTopWidth = w * 0.18f
      val roadBottomWidth = w * 0.92f
      val roadPath = Path().apply {
        moveTo(w / 2f - roadTopWidth / 2f, horizonY)
        lineTo(w / 2f + roadTopWidth / 2f, horizonY)
        lineTo(w / 2f + roadBottomWidth / 2f, h)
        lineTo(w / 2f - roadBottomWidth / 2f, h)
        close()
      }

      drawPath(
        roadPath,
        brush = Brush.verticalGradient(
          listOf(Color(0xFF131728), Color(0xFF090D17)),
          startY = horizonY,
          endY = h
        )
      )

      // Road edge glowing neon rails
      drawLine(
        color = XgtNeonCyan,
        start = Offset(w / 2f - roadTopWidth / 2f, horizonY),
        end = Offset(w / 2f - roadBottomWidth / 2f, h),
        strokeWidth = 3.dp.toPx()
      )
      drawLine(
        color = XgtNeonMagenta,
        start = Offset(w / 2f + roadTopWidth / 2f, horizonY),
        end = Offset(w / 2f + roadBottomWidth / 2f, h),
        strokeWidth = 3.dp.toPx()
      )

      // Center Lane Dashes
      for (i in 1..8) {
        val t = (i / 8f)
        val cy = horizonY + (h - horizonY) * (t * t)
        val currentRoadW = roadTopWidth + (roadBottomWidth - roadTopWidth) * t
        val dashW = 4.dp.toPx() * t * 2f
        val dashH = 16.dp.toPx() * t * 2f

        drawRect(
          color = if (isNitroActive) XgtMatrixGreen else Color(0xFF00E5FF).copy(alpha = 0.8f),
          topLeft = Offset(w / 2f - dashW / 2f, cy),
          size = Size(dashW, dashH)
        )
      }

      // Draw Speed Particles (with motion blur if enabled)
      particles.forEach { p ->
        val px = p.x * w
        val py = p.y * h
        val len = if (graphicSettings.motionBlur) p.length * (speedKmh / 150f) else p.length * 0.5f
        drawLine(
          color = p.color.copy(alpha = 0.6f),
          start = Offset(px, py),
          end = Offset(px, py + len),
          strokeWidth = 1.5.dp.toPx()
        )
      }

      // Draw Traffic Cars
      traffic.forEach { car ->
        val t = 1.0f - car.z
        val cy = horizonY + (h - horizonY) * (t * t)
        val currentRoadW = roadTopWidth + (roadBottomWidth - roadTopWidth) * t
        val cx = (w / 2f) + (car.x * (currentRoadW / 2f))
        val carSize = (28.dp.toPx() * t).coerceAtLeast(10f)

        // Draw Drone Car Body
        drawRoundRect(
          color = car.color,
          topLeft = Offset(cx - carSize / 2f, cy - carSize * 0.8f),
          size = Size(carSize, carSize * 1.4f),
          cornerRadius = androidx.compose.ui.geometry.CornerRadius(4.dp.toPx(), 4.dp.toPx())
        )
        // Drone Red Tail Lights
        drawCircle(
          color = Color(0xFFFF2244),
          radius = 3.dp.toPx() * t,
          center = Offset(cx - carSize * 0.3f, cy + carSize * 0.5f)
        )
        drawCircle(
          color = Color(0xFFFF2244),
          radius = 3.dp.toPx() * t,
          center = Offset(cx + carSize * 0.3f, cy + carSize * 0.5f)
        )
      }

      // Draw Player Supercar (at bottom of screen)
      val playerY = h * 0.84f
      val currentBottomRoadW = roadBottomWidth * 0.88f
      val playerScreenX = (w / 2f) + (playerLaneX * (currentBottomRoadW / 2f))
      drawPlayerCar(
        playerScreenX,
        playerY,
        isNitro = isNitroActive,
        bloomEnabled = graphicSettings.neonBloom
      )
    }

    // Top Header & In-Game FPS HUD
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(top = 40.dp, start = 16.dp, end = 16.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        IconButton(
          onClick = onExit,
          modifier = Modifier
            .background(Color(0x80101522), CircleShape)
            .testTag("game_back_button")
        ) {
          Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Exit", tint = XgtTextPrimary)
        }

        FpsOverlayBar(
          metrics = metrics,
          isMemcActive = interpolationSettings.memcEnabled,
          onBoostClick = onBoost
        )
      }

      Spacer(modifier = Modifier.height(10.dp))

      // In-game score & speed dashboard
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .background(Color(0x990A0E18), RoundedCornerShape(12.dp))
          .padding(horizontal = 14.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text("SPEED", color = XgtTextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
          Text(
            text = String.format(Locale.US, "%.0f KM/H", speedKmh),
            color = if (isNitroActive) XgtMatrixGreen else XgtNeonCyan,
            fontSize = 18.sp,
            fontWeight = FontWeight.Black,
            fontFamily = FontFamily.Monospace
          )
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Text("SCORE", color = XgtTextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
          Text(
            text = String.format(Locale.US, "%,d", score),
            color = XgtTextPrimary,
            fontSize = 18.sp,
            fontWeight = FontWeight.Black,
            fontFamily = FontFamily.Monospace
          )
        }

        Column(horizontalAlignment = Alignment.End) {
          Text("NITRO FUEL", color = XgtTextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
          Box(
            modifier = Modifier
              .width(80.dp)
              .height(8.dp)
              .background(Color(0xFF202A3D), RoundedCornerShape(4.dp))
          ) {
            Box(
              modifier = Modifier
                .fillMaxWidth(nitroFuel / 100f)
                .height(8.dp)
                .background(
                  Brush.horizontalGradient(listOf(XgtNeonCyan, XgtNeonMagenta)),
                  RoundedCornerShape(4.dp)
                )
            )
          }
        }
      }
    }

    // Bottom Controls (Steering Pads & Nitro Boost Button)
    Row(
      modifier = Modifier
        .align(Alignment.BottomCenter)
        .fillMaxWidth()
        .padding(horizontal = 24.dp, vertical = 32.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      // Left/Right Tap Steering Pads for alternative touch mode
      Row {
        Box(
          modifier = Modifier
            .size(56.dp)
            .background(Color(0x801A2438), CircleShape)
            .border(1.dp, XgtNeonCyan.copy(alpha = 0.5f), CircleShape)
            .bouncyClickable {
              targetLaneX = (targetLaneX - 0.35f * touchSettings.touchSensitivity).coerceIn(-0.85f, 0.85f)
            }
            .testTag("steer_left_btn"),
          contentAlignment = Alignment.Center
        ) {
          Text("◄", color = XgtNeonCyan, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.width(16.dp))

        Box(
          modifier = Modifier
            .size(56.dp)
            .background(Color(0x801A2438), CircleShape)
            .border(1.dp, XgtNeonCyan.copy(alpha = 0.5f), CircleShape)
            .bouncyClickable {
              targetLaneX = (targetLaneX + 0.35f * touchSettings.touchSensitivity).coerceIn(-0.85f, 0.85f)
            }
            .testTag("steer_right_btn"),
          contentAlignment = Alignment.Center
        ) {
          Text("►", color = XgtNeonCyan, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
      }

      // NITRO TURBO BUTTON
      Box(
        modifier = Modifier
          .size(72.dp)
          .background(
            if (nitroFuel > 10) Brush.radialGradient(listOf(XgtNeonMagenta, Color(0xFF9D4EDD))) else Brush.radialGradient(listOf(Color(0xFF475569), Color(0xFF334155))),
            CircleShape
          )
          .border(2.dp, if (nitroFuel > 10) XgtNeonCyan else Color.Transparent, CircleShape)
          .bouncyClickable {
            if (nitroFuel > 10) {
              isNitroActive = !isNitroActive
            }
          }
          .testTag("nitro_boost_button"),
        contentAlignment = Alignment.Center
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Icon(
            imageVector = Icons.Default.Bolt,
            contentDescription = "Nitro",
            tint = Color.White,
            modifier = Modifier.size(28.dp)
          )
          Text(
            text = if (isNitroActive) "BOOST!" else "NITRO",
            color = Color.White,
            fontSize = 9.sp,
            fontWeight = FontWeight.Black
          )
        }
      }
    }

    // Game Over Dialog
    AnimatedVisibility(
      visible = isGameOver,
      modifier = Modifier.align(Alignment.Center)
    ) {
      Box(
        modifier = Modifier
          .padding(24.dp)
          .background(Color(0xF2090D14), RoundedCornerShape(20.dp))
          .border(1.5.dp, XgtNeonMagenta, RoundedCornerShape(20.dp))
          .padding(24.dp),
        contentAlignment = Alignment.Center
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Text(
            text = "SYSTEM OVERDRIVE CRASH",
            color = XgtNeonMagenta,
            fontSize = 18.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 1.sp
          )
          Spacer(modifier = Modifier.height(12.dp))
          Text(
            text = "FINAL SCORE: ${String.format(Locale.US, "%,d", score)}",
            color = XgtTextPrimary,
            fontSize = 22.sp,
            fontWeight = FontWeight.ExtraBold,
            fontFamily = FontFamily.Monospace
          )
          Text(
            text = "DISTANCE: ${distanceMeters}m",
            color = XgtNeonCyan,
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold
          )
          Spacer(modifier = Modifier.height(20.dp))
          Row {
            Button(
              onClick = {
                score = 0
                distanceMeters = 0
                targetLaneX = 0f
                playerLaneX = 0f
                isGameOver = false
              },
              colors = ButtonDefaults.buttonColors(containerColor = XgtNeonCyan),
              modifier = Modifier.testTag("restart_game_button")
            ) {
              Icon(Icons.Default.Refresh, contentDescription = null, tint = Color(0xFF090D14))
              Spacer(modifier = Modifier.width(6.dp))
              Text("RETRY", color = Color(0xFF090D14), fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.width(12.dp))

            Button(
              onClick = onExit,
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E283D))
            ) {
              Text("HUB", color = XgtTextPrimary, fontWeight = FontWeight.Bold)
            }
          }
        }
      }
    }
  }
}

private fun DrawScope.drawPlayerCar(
  cx: Float,
  cy: Float,
  isNitro: Boolean,
  bloomEnabled: Boolean
) {
  val carWidth = 64.dp.toPx()
  val carHeight = 90.dp.toPx()

  // Nitro exhaust flame
  if (isNitro) {
    val flamePath = Path().apply {
      moveTo(cx - carWidth * 0.25f, cy + carHeight * 0.45f)
      lineTo(cx - carWidth * 0.15f, cy + carHeight * 0.85f)
      lineTo(cx - carWidth * 0.05f, cy + carHeight * 0.45f)
      close()
    }
    drawPath(flamePath, color = Color(0xFF00E5FF))

    val flamePathRight = Path().apply {
      moveTo(cx + carWidth * 0.05f, cy + carHeight * 0.45f)
      lineTo(cx + carWidth * 0.15f, cy + carHeight * 0.85f)
      lineTo(cx + carWidth * 0.25f, cy + carHeight * 0.45f)
      close()
    }
    drawPath(flamePathRight, color = Color(0xFFFF2A6D))
  }

  // Aerodynamic Cyber Supercar Body
  val bodyPath = Path().apply {
    moveTo(cx, cy - carHeight * 0.5f) // Nose
    lineTo(cx + carWidth * 0.32f, cy - carHeight * 0.2f)
    lineTo(cx + carWidth * 0.48f, cy + carHeight * 0.35f) // Rear fender
    lineTo(cx + carWidth * 0.35f, cy + carHeight * 0.5f) // Rear bumper
    lineTo(cx - carWidth * 0.35f, cy + carHeight * 0.5f)
    lineTo(cx - carWidth * 0.48f, cy + carHeight * 0.35f)
    lineTo(cx - carWidth * 0.32f, cy - carHeight * 0.2f)
    close()
  }

  // Body gradient
  drawPath(
    bodyPath,
    brush = Brush.verticalGradient(
      listOf(Color(0xFF00E5FF), Color(0xFF0B2545), Color(0xFF071224)),
      startY = cy - carHeight * 0.5f,
      endY = cy + carHeight * 0.5f
    )
  )

  // Cockpit Glass
  drawRoundRect(
    color = Color(0xFF040810),
    topLeft = Offset(cx - carWidth * 0.22f, cy - carHeight * 0.15f),
    size = Size(carWidth * 0.44f, carHeight * 0.35f),
    cornerRadius = androidx.compose.ui.geometry.CornerRadius(6.dp.toPx(), 6.dp.toPx())
  )

  // Neon Body Accents
  drawLine(
    color = XgtNeonCyan,
    start = Offset(cx - carWidth * 0.3f, cy - carHeight * 0.1f),
    end = Offset(cx - carWidth * 0.42f, cy + carHeight * 0.3f),
    strokeWidth = 2.dp.toPx()
  )
  drawLine(
    color = XgtNeonCyan,
    start = Offset(cx + carWidth * 0.3f, cy - carHeight * 0.1f),
    end = Offset(cx + carWidth * 0.42f, cy + carHeight * 0.3f),
    strokeWidth = 2.dp.toPx()
  )

  // Rear Cyber Lights
  drawLine(
    color = Color(0xFFFF2A6D),
    start = Offset(cx - carWidth * 0.35f, cy + carHeight * 0.46f),
    end = Offset(cx + carWidth * 0.35f, cy + carHeight * 0.46f),
    strokeWidth = 3.dp.toPx()
  )
}
