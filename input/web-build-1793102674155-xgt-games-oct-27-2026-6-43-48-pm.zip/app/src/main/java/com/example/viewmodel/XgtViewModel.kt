package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.R
import com.example.ai.AiTuningRecommendation
import com.example.ai.AiUiState
import com.example.ai.XgtAiAdvisor
import com.example.data.local.GameProfileEntity
import com.example.data.local.XgtDatabase
import com.example.data.repository.GameProfileRepository
import com.example.engine.HapticFeedbackHelper
import com.example.engine.PerformanceGovernor
import com.example.engine.TouchCalibrationState
import com.example.engine.TouchPointInfo
import com.example.engine.TouchResponseManager
import com.example.model.BenchmarkResult
import com.example.model.GraphicSettings
import com.example.model.InterpolationSettings
import com.example.model.PerformanceMetrics
import com.example.model.PerformanceMode
import com.example.model.TouchSettings
import java.util.UUID
import java.util.concurrent.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class XgtViewModel(application: Application) : AndroidViewModel(application) {

  private val database = XgtDatabase.getInstance(application)
  val repository = GameProfileRepository(database.gameProfileDao())

  val hapticHelper = HapticFeedbackHelper(application.applicationContext)
  val governor = PerformanceGovernor(application.applicationContext)
  val touchManager = TouchResponseManager(hapticHelper)
  val aiAdvisor = XgtAiAdvisor()

  private val _performanceMode = MutableStateFlow(PerformanceMode.ESPORTS_EXTREME)
  val performanceMode: StateFlow<PerformanceMode> = _performanceMode.asStateFlow()

  private val _graphicSettings = MutableStateFlow(GraphicSettings())
  val graphicSettings: StateFlow<GraphicSettings> = _graphicSettings.asStateFlow()

  private val _touchSettings = MutableStateFlow(TouchSettings())
  val touchSettings: StateFlow<TouchSettings> = _touchSettings.asStateFlow()

  private val _interpolationSettings = MutableStateFlow(InterpolationSettings())
  val interpolationSettings: StateFlow<InterpolationSettings> = _interpolationSettings.asStateFlow()

  val metrics: StateFlow<PerformanceMetrics> = governor.metrics
  val frameHistory: StateFlow<List<Float>> = governor.recentFrameTimes

  private val _touchCalibration = MutableStateFlow(TouchCalibrationState())
  val touchCalibration: StateFlow<TouchCalibrationState> = _touchCalibration.asStateFlow()

  private val _boostToastMessage = MutableStateFlow<String?>(null)
  val boostToastMessage: StateFlow<String?> = _boostToastMessage.asStateFlow()

  private val _isBenchmarking = MutableStateFlow(false)
  val isBenchmarking: StateFlow<Boolean> = _isBenchmarking.asStateFlow()

  private val _benchmarkResult = MutableStateFlow<BenchmarkResult?>(null)
  val benchmarkResult: StateFlow<BenchmarkResult?> = _benchmarkResult.asStateFlow()

  private val _showFpsOverlay = MutableStateFlow(true)
  val showFpsOverlay: StateFlow<Boolean> = _showFpsOverlay.asStateFlow()

  private val _activeGame = MutableStateFlow<String?>(null)
  val activeGame: StateFlow<String?> = _activeGame.asStateFlow()

  // Gemini AI UI State
  private val _aiUiState = MutableStateFlow<AiUiState>(AiUiState.Idle)
  val aiUiState: StateFlow<AiUiState> = _aiUiState.asStateFlow()

  // Room Database Reactive Flow for Game Profiles
  val persistedProfiles: StateFlow<List<GameProfileEntity>> = repository.allProfiles
    .stateIn(
      scope = viewModelScope,
      started = SharingStarted.WhileSubscribed(5000),
      initialValue = emptyList()
    )

  init {
    viewModelScope.launch {
      while (isActive) {
        val mode = _performanceMode.value
        val interp = _interpolationSettings.value
        val inGame = _activeGame.value != null
        val load = if (inGame) 1.25f else 0.85f
        governor.updateFrame(mode, interp, load)
        delay(16L)
      }
    }
  }

  fun setPerformanceMode(mode: PerformanceMode) {
    _performanceMode.value = mode
    when (mode) {
      PerformanceMode.ECO -> {
        _interpolationSettings.value = _interpolationSettings.value.copy(
          targetRefreshRate = 60,
          memcEnabled = false,
          adaptiveFramePacing = true
        )
        _touchSettings.value = _touchSettings.value.copy(touchSamplingRateHz = 120)
        _graphicSettings.value = _graphicSettings.value.copy(
          resolutionScale = 0.75f,
          particleDensity = 0.5f,
          motionBlur = false
        )
      }
      PerformanceMode.BALANCED -> {
        _interpolationSettings.value = _interpolationSettings.value.copy(
          targetRefreshRate = 90,
          memcEnabled = true,
          smoothingMultiplier = 0.6f
        )
        _touchSettings.value = _touchSettings.value.copy(touchSamplingRateHz = 240)
        _graphicSettings.value = _graphicSettings.value.copy(
          resolutionScale = 1.0f,
          particleDensity = 1.0f,
          motionBlur = true
        )
      }
      PerformanceMode.ESPORTS_EXTREME -> {
        _interpolationSettings.value = _interpolationSettings.value.copy(
          targetRefreshRate = 120,
          memcEnabled = true,
          smoothingMultiplier = 0.85f,
          lowLatencyMode = true
        )
        _touchSettings.value = _touchSettings.value.copy(
          touchSamplingRateHz = 480,
          instantTouchDispatch = true
        )
        _graphicSettings.value = _graphicSettings.value.copy(
          resolutionScale = 1.25f,
          neonBloom = true,
          hdrContrast = true,
          particleDensity = 1.5f,
          motionBlur = true
        )
      }
      PerformanceMode.CUSTOM -> {}
    }
    hapticHelper.triggerTactile("Crisp Gaming", 0.6f)
  }

  fun updateGraphics(settings: GraphicSettings) {
    _graphicSettings.value = settings
    _performanceMode.value = PerformanceMode.CUSTOM
  }

  fun updateTouch(settings: TouchSettings) {
    _touchSettings.value = settings
    _performanceMode.value = PerformanceMode.CUSTOM
  }

  fun updateInterpolation(settings: InterpolationSettings) {
    _interpolationSettings.value = settings
    _performanceMode.value = PerformanceMode.CUSTOM
  }

  fun toggleFpsOverlay() {
    _showFpsOverlay.value = !_showFpsOverlay.value
    hapticHelper.triggerTactile("Subtle Click", 0.4f)
  }

  fun triggerTurboBoost() {
    val message = governor.boostTurbo()
    _boostToastMessage.value = message
    hapticHelper.triggerNitroBoost()
    viewModelScope.launch {
      delay(3500)
      if (_boostToastMessage.value == message) {
        _boostToastMessage.value = null
      }
    }
  }

  fun clearToast() {
    _boostToastMessage.value = null
  }

  fun registerTouchCalibration(points: List<TouchPointInfo>) {
    _touchCalibration.value = touchManager.onTouchInput(
      points = points,
      currentState = _touchCalibration.value,
      settings = _touchSettings.value
    )
  }

  fun resetTouchCalibration() {
    _touchCalibration.value = TouchCalibrationState()
    hapticHelper.triggerTactile("Crisp Gaming", 0.5f)
  }

  fun runBenchmark() {
    if (_isBenchmarking.value) return
    _isBenchmarking.value = true
    _benchmarkResult.value = null
    hapticHelper.triggerNitroBoost()

    viewModelScope.launch {
      delay(4000)
      val result = governor.computeBenchmark(_interpolationSettings.value.targetRefreshRate)
      _benchmarkResult.value = result
      _isBenchmarking.value = false
      hapticHelper.triggerTactile("Heavy Rumble", 1.0f)
    }
  }

  fun launchGame(gameId: String) {
    _activeGame.value = gameId
    governor.boostTurbo()
    hapticHelper.triggerNitroBoost()

    viewModelScope.launch {
      repository.getProfileById(gameId)?.let { profile ->
        applyProfile(profile, showToast = false)
      }
    }
  }

  fun exitGame() {
    _activeGame.value = null
    hapticHelper.triggerTactile("Subtle Click", 0.4f)
  }

  fun saveGameScore(gameId: String, newScore: Long) {
    viewModelScope.launch {
      val existing = repository.getProfileById(gameId)
      val bestScore = if (existing != null && existing.highScore > newScore) existing.highScore else newScore
      repository.updateScore(gameId, bestScore)
    }
  }

  fun applyProfile(profile: GameProfileEntity, showToast: Boolean = true) {
    _graphicSettings.value = profile.toGraphicSettings()
    _touchSettings.value = profile.toTouchSettings()
    _interpolationSettings.value = profile.toInterpolationSettings()
    _performanceMode.value = profile.toPerformanceMode()

    hapticHelper.triggerNitroBoost()
    if (showToast) {
      val msg = "Activated Profile: ${profile.gameTitle} (${profile.targetRefreshRate}Hz / ${profile.touchSamplingRateHz}Hz Touch)"
      _boostToastMessage.value = msg
      viewModelScope.launch {
        delay(3500)
        if (_boostToastMessage.value == msg) _boostToastMessage.value = null
      }
    }
  }

  fun saveCurrentSettingsAsProfile(
    gameTitle: String,
    packageName: String,
    genre: String
  ) {
    viewModelScope.launch {
      val id = packageName.ifBlank { "custom_" + UUID.randomUUID().toString().take(8) }
      val currentGraphics = _graphicSettings.value
      val currentTouch = _touchSettings.value
      val currentInterp = _interpolationSettings.value
      val currentMode = _performanceMode.value

      val newEntity = GameProfileEntity(
        id = id,
        gameTitle = gameTitle.ifBlank { "Custom Game" },
        packageName = packageName.ifBlank { "com.example.custom" },
        genre = genre.ifBlank { "Action / Esports" },
        isBuiltIn = false,
        bannerResId = null,
        performanceMode = currentMode.name,
        targetRefreshRate = currentInterp.targetRefreshRate,
        memcEnabled = currentInterp.memcEnabled,
        smoothingMultiplier = currentInterp.smoothingMultiplier,
        adaptiveFramePacing = currentInterp.adaptiveFramePacing,
        dynamicVsync = currentInterp.dynamicVsync,
        lowLatencyMode = currentInterp.lowLatencyMode,
        resolutionScale = currentGraphics.resolutionScale,
        neonBloom = currentGraphics.neonBloom,
        bloomIntensity = currentGraphics.bloomIntensity,
        hdrContrast = currentGraphics.hdrContrast,
        motionBlur = currentGraphics.motionBlur,
        motionBlurIntensity = currentGraphics.motionBlurIntensity,
        antiAliasing = currentGraphics.antiAliasing,
        particleDensity = currentGraphics.particleDensity,
        colorFilterMode = currentGraphics.colorFilter.name,
        touchSamplingRateHz = currentTouch.touchSamplingRateHz,
        touchSensitivity = currentTouch.touchSensitivity,
        deadzonePercent = currentTouch.deadzonePercent,
        instantTouchDispatch = currentTouch.instantTouchDispatch,
        edgeFilterEnabled = currentTouch.edgeFilterEnabled,
        hapticFeedbackMode = currentTouch.hapticFeedbackMode,
        hapticIntensity = currentTouch.hapticIntensity
      )

      repository.saveProfile(newEntity)
      hapticHelper.triggerTactile("Crisp Gaming", 0.9f)
      _boostToastMessage.value = "Saved profile for '${newEntity.gameTitle}' into Room database"
      delay(3000)
      _boostToastMessage.value = null
    }
  }

  fun deleteProfile(id: String) {
    viewModelScope.launch {
      repository.deleteProfileById(id)
      hapticHelper.triggerTactile("Subtle Click", 0.5f)
    }
  }

  fun updateGameProfile(updatedProfile: GameProfileEntity) {
    viewModelScope.launch {
      repository.saveProfile(updatedProfile)
      hapticHelper.triggerTactile("Crisp Gaming", 0.8f)
      val msg = "Đã cập nhật cấu hình cho '${updatedProfile.gameTitle}'"
      _boostToastMessage.value = msg
      delay(3000)
      if (_boostToastMessage.value == msg) _boostToastMessage.value = null
    }
  }

  // --- Gemini AI Optimizer Integration ---

  fun requestAiTuning(gameTitle: String, playStyle: String = "Esports Competitor") {
    viewModelScope.launch {
      _aiUiState.value = AiUiState.Loading
      hapticHelper.triggerTactile("Subtle Click", 0.5f)
      try {
        val current = metrics.value
        val deviceInfo = "Target Refresh: ${_interpolationSettings.value.targetRefreshRate}Hz, Current FPS: ${current.currentFps.toInt()}, RAM Used: ${current.ramUsedMb}MB, Temp: ${current.batteryTempCelsius}°C"
        val recommendation = aiAdvisor.generateGameTuning(gameTitle, deviceInfo, playStyle)
        _aiUiState.value = AiUiState.SuccessRecommendation(recommendation)
        hapticHelper.triggerNitroBoost()
      } catch (e: CancellationException) {
        throw e
      } catch (e: Exception) {
        _aiUiState.value = AiUiState.Error(e.localizedMessage ?: "Failed to generate AI recommendations.")
      }
    }
  }

  fun askAiTactician(query: String) {
    viewModelScope.launch {
      _aiUiState.value = AiUiState.Loading
      hapticHelper.triggerTactile("Subtle Click", 0.4f)
      try {
        aiAdvisor.streamEsportsAdvice(query).collect { text ->
          _aiUiState.value = AiUiState.StreamingAdvice(text)
        }
      } catch (e: CancellationException) {
        throw e
      } catch (e: Exception) {
        _aiUiState.value = AiUiState.Error(e.localizedMessage ?: "AI response failed.")
      }
    }
  }

  fun applyAiRecommendation(rec: AiTuningRecommendation) {
    viewModelScope.launch {
      _interpolationSettings.value = _interpolationSettings.value.copy(
        targetRefreshRate = rec.recommendedRefreshRate,
        memcEnabled = rec.recommendedMemc
      )
      _touchSettings.value = _touchSettings.value.copy(
        touchSamplingRateHz = rec.recommendedTouchPollingRate,
        touchSensitivity = rec.recommendedSensitivity,
        deadzonePercent = rec.recommendedDeadzone
      )
      _graphicSettings.value = _graphicSettings.value.copy(
        resolutionScale = rec.recommendedResolutionScale
      )
      _performanceMode.value = PerformanceMode.CUSTOM

      // Also persist to Room as a game profile!
      saveCurrentSettingsAsProfile(
        gameTitle = rec.gameTitle,
        packageName = "ai.optimized." + rec.gameTitle.lowercase().replace("[^a-z0-9]".toRegex(), ""),
        genre = "AI Neural Tuned"
      )

      hapticHelper.triggerNitroBoost()
      _boostToastMessage.value = "⚡ AI Neural Tuning Applied & Saved to Room!"
      delay(3000)
      _boostToastMessage.value = null
    }
  }

  fun resetAiState() {
    _aiUiState.value = AiUiState.Idle
  }
}
