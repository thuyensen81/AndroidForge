package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ai.AiTuningRecommendation
import com.example.ai.AiUiState
import com.example.ui.theme.XgtAmberBoost
import com.example.ui.theme.XgtDarkSurface
import com.example.ui.theme.XgtMatrixGreen
import com.example.ui.theme.XgtNeonCyan
import com.example.ui.theme.XgtSurfaceHighlight
import com.example.ui.theme.XgtTextMuted
import com.example.ui.theme.XgtTextPrimary
import com.example.ui.theme.XgtTextSecondary

@Composable
fun AiOptimizerScreen(
  uiState: AiUiState,
  onRequestAiTuning: (gameTitle: String, playStyle: String) -> Unit,
  onAskAiTactician: (query: String) -> Unit,
  onApplyRecommendation: (AiTuningRecommendation) -> Unit,
  onResetState: () -> Unit
) {
  var selectedTab by remember { mutableIntStateOf(0) }
  var gameInput by remember { mutableStateOf("Call of Duty: Warzone Mobile") }
  var selectedPlaystyle by remember { mutableStateOf("Esports Reflex & Ultra Touch") }
  var queryInput by remember { mutableStateOf("") }

  val popularGames = listOf(
    "Warzone Mobile",
    "Genshin Impact",
    "PUBG Mobile",
    "Apex Legends Mobile",
    "Neon Velocity (XGT)",
    "Asphalt Legends"
  )

  val playstyles = listOf(
    "Esports Reflex & Ultra Touch",
    "High-Fidelity Visuals (Bloom/HDR)",
    "Battery Endurance & Cool Thermals"
  )

  val quickPrompts = listOf(
    "Optimal touch sensitivity for snipers in FPS",
    "How to prevent thermal throttling during long gaming",
    "Best Gyroscope vs touch aiming settings",
    "How MEMC frame pacing eliminates micro-stutters"
  )

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp),
    contentPadding = PaddingValues(top = 16.dp, bottom = 96.dp)
  ) {
    // Header
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = XgtNeonCyan, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "GEMINI AI OPTIMIZER",
              color = XgtNeonCyan,
              fontSize = 18.sp,
              fontWeight = FontWeight.Black,
              letterSpacing = 1.sp
            )
          }
          Text(
            text = "Powered by Google Gemini 3.8 Flash & Firebase AI Logic",
            color = XgtTextSecondary,
            fontSize = 11.sp
          )
        }

        Box(
          modifier = Modifier
            .background(XgtSurfaceHighlight, RoundedCornerShape(10.dp))
            .border(1.dp, XgtNeonCyan.copy(alpha = 0.3f), RoundedCornerShape(10.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
          Text(
            text = "GEMINI 3.8 FLASH",
            color = XgtMatrixGreen,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
          )
        }
      }
    }

    // Tab Switcher
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        listOf("Neural Hardware Tuner", "AI Esports Coach").forEachIndexed { index, title ->
          val isSelected = selectedTab == index
          Box(
            modifier = Modifier
              .weight(1f)
              .background(
                if (isSelected) XgtSurfaceHighlight else XgtDarkSurface,
                RoundedCornerShape(10.dp)
              )
              .border(
                width = 1.dp,
                color = if (isSelected) XgtNeonCyan else Color(0xFF1E283D),
                shape = RoundedCornerShape(10.dp)
              )
              .clickable {
                selectedTab = index
                onResetState()
              }
              .padding(vertical = 10.dp),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = title,
              color = if (isSelected) XgtNeonCyan else XgtTextSecondary,
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold
            )
          }
        }
      }
    }

    // TAB 0: AI Hardware Tuner
    if (selectedTab == 0) {
      item {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .background(XgtDarkSurface, RoundedCornerShape(16.dp))
            .border(1.dp, Color(0xFF1E283D), RoundedCornerShape(16.dp))
            .padding(16.dp),
          verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
          Text(
            text = "GENERATE GAME-SPECIFIC TUNING",
            color = XgtTextPrimary,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold
          )

          OutlinedTextField(
            value = gameInput,
            onValueChange = { gameInput = it },
            label = { Text("Game Title") },
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = XgtNeonCyan,
              unfocusedBorderColor = Color(0xFF1E283D),
              focusedTextColor = XgtTextPrimary,
              unfocusedTextColor = XgtTextPrimary
            ),
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("ai_game_input")
          )

          // Quick Game Suggestions
          LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(popularGames) { game ->
              Box(
                modifier = Modifier
                  .background(Color(0xFF0C101A), RoundedCornerShape(8.dp))
                  .border(1.dp, Color(0xFF1C263B), RoundedCornerShape(8.dp))
                  .clickable { gameInput = game }
                  .padding(horizontal = 8.dp, vertical = 4.dp)
              ) {
                Text(text = game, color = XgtTextSecondary, fontSize = 10.sp)
              }
            }
          }

          Text(
            text = "TARGET PLAYSTYLE",
            color = XgtTextMuted,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold
          )

          // Playstyle chips
          Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            playstyles.forEach { style ->
              val isSelected = selectedPlaystyle == style
              Box(
                modifier = Modifier
                  .fillMaxWidth()
                  .background(
                    if (isSelected) XgtSurfaceHighlight else Color(0xFF0F1522),
                    RoundedCornerShape(8.dp)
                  )
                  .border(
                    width = 1.dp,
                    color = if (isSelected) XgtNeonCyan else Color(0xFF1E283D),
                    shape = RoundedCornerShape(8.dp)
                  )
                  .clickable { selectedPlaystyle = style }
                  .padding(10.dp)
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Box(
                    modifier = Modifier
                      .size(6.dp)
                      .background(if (isSelected) XgtNeonCyan else Color(0xFF475569), CircleShape)
                  )
                  Spacer(modifier = Modifier.width(8.dp))
                  Text(
                    text = style,
                    color = if (isSelected) XgtTextPrimary else XgtTextSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                  )
                }
              }
            }
          }

          // Trigger Button
          Button(
            onClick = { onRequestAiTuning(gameInput, selectedPlaystyle) },
            enabled = uiState !is AiUiState.Loading && gameInput.isNotBlank(),
            colors = ButtonDefaults.buttonColors(containerColor = XgtNeonCyan),
            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("trigger_ai_tuning_btn")
          ) {
            if (uiState is AiUiState.Loading) {
              CircularProgressIndicator(
                modifier = Modifier.size(18.dp),
                color = Color(0xFF090D14),
                strokeWidth = 2.dp
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text("ANALYZING HARDWARE WITH GEMINI...", color = Color(0xFF090D14), fontWeight = FontWeight.Bold, fontSize = 12.sp)
            } else {
              Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color(0xFF090D14), modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text("ANALYZE & OPTIMIZE WITH GEMINI", color = Color(0xFF090D14), fontWeight = FontWeight.Black, fontSize = 12.sp)
            }
          }
        }
      }

      // Display Structured Recommendation
      if (uiState is AiUiState.SuccessRecommendation) {
        val rec = uiState.recommendation
        item {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .background(XgtDarkSurface, RoundedCornerShape(16.dp))
              .border(1.5.dp, XgtMatrixGreen, RoundedCornerShape(16.dp))
              .padding(16.dp)
              .testTag("ai_recommendation_card")
          ) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Column {
                  Text("AI OPTIMIZED CONFIGURATION", color = XgtMatrixGreen, fontSize = 12.sp, fontWeight = FontWeight.Black)
                  Text(rec.gameTitle, color = XgtTextPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
                Box(
                  modifier = Modifier
                    .background(Color(0x3300FF9D), RoundedCornerShape(6.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                  Text("AI CERTIFIED", color = XgtMatrixGreen, fontSize = 10.sp, fontWeight = FontWeight.Black)
                }
              }

              // Parameter Badges Grid
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
              ) {
                AiBadge("Refresh", "${rec.recommendedRefreshRate}Hz", Modifier.weight(1f))
                AiBadge("Touch", "${rec.recommendedTouchPollingRate}Hz", Modifier.weight(1f))
                AiBadge("Sens", "${rec.recommendedSensitivity}x", Modifier.weight(1f))
                AiBadge("Scale", "${(rec.recommendedResolutionScale * 100).toInt()}%", Modifier.weight(1f))
              }

              // Reasoning
              Column(
                modifier = Modifier
                  .fillMaxWidth()
                  .background(Color(0xFF0A0E18), RoundedCornerShape(10.dp))
                  .padding(12.dp)
              ) {
                Text("AI TECHNICAL REASONING", color = XgtNeonCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                  text = rec.tuningReasoning,
                  color = XgtTextSecondary,
                  fontSize = 11.sp,
                  lineHeight = 16.sp
                )
              }

              // Pro Tips
              if (rec.proTips.isNotEmpty()) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                  Text("PRO ESPORTS TIPS", color = XgtAmberBoost, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                  rec.proTips.forEach { tip ->
                    Row {
                      Text("• ", color = XgtAmberBoost)
                      Text(tip, color = XgtTextPrimary, fontSize = 11.sp, lineHeight = 15.sp)
                    }
                  }
                }
              }

              // Apply & Save to Room Button
              Button(
                onClick = { onApplyRecommendation(rec) },
                colors = ButtonDefaults.buttonColors(containerColor = XgtMatrixGreen),
                modifier = Modifier.fillMaxWidth().height(48.dp).testTag("apply_ai_tuning_btn")
              ) {
                Icon(Icons.Default.Bolt, contentDescription = null, tint = Color(0xFF090D14))
                Spacer(modifier = Modifier.width(6.dp))
                Text("⚡ APPLY TO HARDWARE & SAVE TO ROOM", color = Color(0xFF090D14), fontWeight = FontWeight.Black, fontSize = 12.sp)
              }
            }
          }
        }
      }
    }

    // TAB 1: AI Esports Coach (Streaming Conversational)
    if (selectedTab == 1) {
      item {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .background(XgtDarkSurface, RoundedCornerShape(16.dp))
            .border(1.dp, Color(0xFF1E283D), RoundedCornerShape(16.dp))
            .padding(16.dp),
          verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          Text(
            text = "AI ESPORTS TACTICIAN",
            color = XgtTextPrimary,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold
          )

          // Quick Prompts
          Text(text = "QUICK TOPICS", color = XgtTextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
          LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(quickPrompts) { prompt ->
              Box(
                modifier = Modifier
                  .background(Color(0xFF0C101A), RoundedCornerShape(8.dp))
                  .border(1.dp, Color(0xFF1C263B), RoundedCornerShape(8.dp))
                  .clickable {
                    queryInput = prompt
                    onAskAiTactician(prompt)
                  }
                  .padding(horizontal = 10.dp, vertical = 6.dp)
              ) {
                Text(text = prompt, color = XgtTextSecondary, fontSize = 10.sp)
              }
            }
          }

          // Input Row
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
          ) {
            OutlinedTextField(
              value = queryInput,
              onValueChange = { queryInput = it },
              placeholder = { Text("Ask gaming mechanics, sensitivity, tips...") },
              colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = XgtNeonCyan,
                unfocusedBorderColor = Color(0xFF1E283D),
                focusedTextColor = XgtTextPrimary,
                unfocusedTextColor = XgtTextPrimary
              ),
              modifier = Modifier.weight(1f).testTag("ai_tactician_input")
            )

            Spacer(modifier = Modifier.width(8.dp))

            IconButton(
              onClick = {
                if (queryInput.isNotBlank()) {
                  onAskAiTactician(queryInput)
                }
              },
              modifier = Modifier
                .background(XgtNeonCyan, RoundedCornerShape(12.dp))
                .size(50.dp)
                .testTag("send_ai_query_btn")
            ) {
              Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = Color(0xFF090D14))
            }
          }
        }
      }

      // Streaming Advice Card
      if (uiState is AiUiState.StreamingAdvice) {
        item {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .background(XgtDarkSurface, RoundedCornerShape(16.dp))
              .border(1.dp, XgtNeonCyan.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
              .padding(16.dp)
              .testTag("ai_streaming_response_card")
          ) {
            Column {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Psychology, contentDescription = null, tint = XgtNeonCyan, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("TACTICAL ADVICE", color = XgtNeonCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
              }
              Spacer(modifier = Modifier.height(10.dp))
              Text(
                text = uiState.text,
                color = XgtTextPrimary,
                fontSize = 13.sp,
                lineHeight = 18.sp
              )
            }
          }
        }
      }
    }

    // Error State
    if (uiState is AiUiState.Error) {
      item {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .background(Color(0x33FF3366), RoundedCornerShape(12.dp))
            .border(1.dp, Color(0xFFFF3366), RoundedCornerShape(12.dp))
            .padding(14.dp)
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFFF3366))
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text("AI OPTIMIZER ERROR", color = Color(0xFFFF3366), fontSize = 12.sp, fontWeight = FontWeight.Bold)
              Spacer(modifier = Modifier.height(2.dp))
              Text(uiState.message, color = XgtTextPrimary, fontSize = 11.sp)
            }
          }
        }
      }
    }
  }
}

@Composable
private fun AiBadge(label: String, value: String, modifier: Modifier = Modifier) {
  Box(
    modifier = modifier
      .background(Color(0xFF0A0E18), RoundedCornerShape(8.dp))
      .border(1.dp, Color(0xFF1E283D), RoundedCornerShape(8.dp))
      .padding(vertical = 8.dp),
    contentAlignment = Alignment.Center
  ) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
      Text(label, color = XgtTextMuted, fontSize = 9.sp)
      Spacer(modifier = Modifier.height(2.dp))
      Text(value, color = XgtNeonCyan, fontSize = 12.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace)
    }
  }
}
