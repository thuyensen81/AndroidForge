package com.example.ai

import android.util.Log
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.generationConfig
import java.util.concurrent.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withTimeout
import org.json.JSONObject

private const val TAG = "XgtAiAdvisor"

class XgtAiAdvisor {

  // 1. Structured Output Schema for Hardware & Gaming Optimization
  private val tuningSchema by lazy {
    Schema.obj(
      properties = mapOf(
        "gameTitle" to Schema.string(description = "The target game title"),
        "recommendedRefreshRate" to Schema.integer(description = "Recommended display refresh rate in Hz: 60, 90, 120, or 144"),
        "recommendedTouchPollingRate" to Schema.integer(description = "Recommended touch polling rate in Hz: 120, 240, 360, or 480"),
        "recommendedSensitivity" to Schema.double(description = "Touch sensitivity multiplier between 0.5 and 3.0"),
        "recommendedDeadzone" to Schema.double(description = "Touch deadzone percentage between 0.0 and 15.0"),
        "recommendedResolutionScale" to Schema.double(description = "Graphics resolution scale: 0.75, 1.0, 1.25, or 1.5"),
        "recommendedMemc" to Schema.boolean(description = "Whether MEMC frame generation interpolation should be active"),
        "tuningReasoning" to Schema.string(description = "Detailed technical breakdown explaining why these parameters are optimal for the game engine and hardware"),
        "proTips" to Schema.array(
          items = Schema.string(),
          description = "2 to 3 competitive esports tips tailored for this specific game"
        )
      )
    )
  }

  // 2. Structured Model initialized lazily
  private val structuredModel by lazy {
    Firebase.ai.generativeModel(
      modelName = "gemini-3.8-flash",
      generationConfig = generationConfig {
        responseMimeType = "application/json"
        responseSchema = tuningSchema
      }
    )
  }

  // 3. Conversational / Streaming Model initialized lazily
  private val chatModel by lazy {
    Firebase.ai.generativeModel(
      modelName = "gemini-3.8-flash"
    )
  }

  /**
   * Generates tailored game optimization settings using Gemini 3.8 Flash structured JSON output.
   */
  suspend fun generateGameTuning(
    gameTitle: String,
    deviceInfo: String,
    playStyle: String = "Esports Competitor"
  ): AiTuningRecommendation {
    val prompt = """
      You are the XGT Neural Hardware Optimizer for mobile gaming.
      Provide the ultimate graphics, touch responsiveness, and frame interpolation configuration for:
      Game Title: $gameTitle
      Target Playstyle: $playStyle
      Hardware Profile: $deviceInfo
      
      Select the ideal refresh rate (60, 90, 120, 144), touch polling rate (120, 240, 360, 480),
      touch sensitivity multiplier (0.5 to 3.0), deadzone percent (0 to 15), resolution scale (0.75, 1.0, 1.25, 1.5),
      and MEMC interpolation recommendation with deep technical reasoning.
    """.trimIndent()

    try {
      val response = withTimeout(60_000L) {
        structuredModel.generateContent(prompt)
      }

      val jsonString = response.text ?: throw IllegalStateException("Model returned an empty response.")
      val json = JSONObject(jsonString)

      val title = json.optString("gameTitle", gameTitle)
      val refresh = json.optInt("recommendedRefreshRate", 120)
      val touchHz = json.optInt("recommendedTouchPollingRate", 360)
      val sens = json.optDouble("recommendedSensitivity", 1.5).toFloat()
      val deadzone = json.optDouble("recommendedDeadzone", 2.0).toFloat()
      val scale = json.optDouble("recommendedResolutionScale", 1.0).toFloat()
      val memc = json.optBoolean("recommendedMemc", true)
      val reasoning = json.optString("tuningReasoning", "Optimized by XGT Neural Engine for low latency.")

      val tipsArray = json.optJSONArray("proTips")
      val tips = mutableListOf<String>()
      if (tipsArray != null) {
        for (i in 0 until tipsArray.length()) {
          tips.add(tipsArray.getString(i))
        }
      } else {
        tips.add("Maintain steady grip and keep device thermals under 40°C.")
      }

      return AiTuningRecommendation(
        gameTitle = title,
        recommendedRefreshRate = refresh,
        recommendedTouchPollingRate = touchHz,
        recommendedSensitivity = sens,
        recommendedDeadzone = deadzone,
        recommendedResolutionScale = scale,
        recommendedMemc = memc,
        tuningReasoning = reasoning,
        proTips = tips
      )
    } catch (e: TimeoutCancellationException) {
      Log.e(TAG, "AI tuning generation timed out after 60s", e)
      throw Exception("AI tuning generation timed out. Please check your network and try again.")
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      Log.e(TAG, "Failed to generate AI game tuning", e)
      throw Exception(e.localizedMessage ?: "AI tuning failed.")
    }
  }

  /**
   * Streams tactical esports advice from Gemini 3.8 Flash.
   */
  fun streamEsportsAdvice(query: String): Flow<String> = flow {
    val prompt = """
      You are the XGT AI Esports Tactician & Mobile Gaming Coach.
      Provide concise, actionable tactical advice, sensitivity calibrations, or game mechanics for:
      $query
    """.trimIndent()

    val accumulated = StringBuilder()
    try {
      withTimeout(60_000L) {
        chatModel.generateContentStream(prompt).collect { chunk ->
          val text = chunk.text.orEmpty()
          accumulated.append(text)
          emit(accumulated.toString())
        }
      }
    } catch (e: TimeoutCancellationException) {
      Log.e(TAG, "Streaming advice timed out", e)
      throw Exception("Response streaming timed out.")
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      Log.e(TAG, "Streaming AI advice failed", e)
      throw Exception(e.localizedMessage ?: "AI advice request failed.")
    }
  }
}
