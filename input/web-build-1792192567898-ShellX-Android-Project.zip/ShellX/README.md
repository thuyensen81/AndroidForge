# ShellX — Glass System Toolkit

Android project targeting the user's realme RMX3834 / Android 15.

## Included
- Shell Terminal: commands are executed only via `Shizuku.newProcess`; there is no ordinary app-UID shell fallback.
- Shizuku status and permission request.
- Game Enhance Custom for Free Fire (`com.dts.freefireth`) and Free Fire MAX (`com.dts.freefiremax`).
- Adjustable mode and downscale, separate Apply and Reset actions, output/error/exit code display.
- Dark green glass-inspired UI.

## Build APK
1. Open this folder in Android Studio.
2. Allow Gradle to sync and download Android Gradle Plugin 8.7.3, Android SDK Platform 35, and `dev.rikka.shizuku:api:13.1.5`.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. The debug APK will be under `app/build/outputs/apk/debug/app-debug.apk`.

## Important
- This workspace had no Android SDK, Gradle installation, or network access at generation time, so an APK could not be compiled here. The source project is provided for build in Android Studio.
- Start Shizuku and grant ShellX permission before running commands. This app intentionally does not fall back to ordinary shell.
- `cmd game` support and mode/downscale semantics depend on the device firmware. Test with care; reset is per selected package.
- Arbitrary shell commands can change system state. Review commands before execution.
