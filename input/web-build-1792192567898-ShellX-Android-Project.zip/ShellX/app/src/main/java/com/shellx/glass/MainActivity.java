package com.shellx.glass;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    private static final int REQUEST_CODE = 701;
    private final int bg = Color.rgb(14, 20, 17);
    private final int card = Color.rgb(27, 37, 32);
    private final int card2 = Color.rgb(34, 46, 40);
    private final int green = Color.rgb(141, 232, 176);
    private final int white = Color.rgb(239, 246, 241);
    private final int muted = Color.rgb(166, 185, 174);
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());

    private LinearLayout root, content, shellPage, gamePage;
    private TextView statusText, outputText;
    private EditText commandInput, downscaleInput;
    private Spinner gameSpinner, modeSpinner;
    private String lastOutput = "Ready.";

    private final Shizuku.OnRequestPermissionResultListener permissionListener = (requestCode, grantResult) -> {
        if (requestCode == REQUEST_CODE) {
            refreshStatus();
            if (grantResult == PackageManager.PERMISSION_GRANTED) toastDialog("Shizuku permission granted. ShellX can now execute commands through Shizuku.");
            else toastDialog("Shizuku permission was not granted. Commands remain disabled.");
        }
    };
    private final Shizuku.OnBinderReceivedListener binderReceivedListener = this::refreshStatus;
    private final Shizuku.OnBinderDeadListener binderDeadListener = this::refreshStatus;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        Shizuku.addRequestPermissionResultListener(permissionListener);
        Shizuku.addBinderReceivedListener(binderReceivedListener);
        Shizuku.addBinderDeadListener(binderDeadListener);
        buildUi();
        refreshStatus();
    }

    @Override protected void onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permissionListener);
        Shizuku.removeBinderReceivedListener(binderReceivedListener);
        Shizuku.removeBinderDeadListener(binderDeadListener);
        executor.shutdownNow();
        super.onDestroy();
    }

    private void buildUi() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(18), dp(14), dp(18), dp(10)); root.setBackgroundColor(bg);
        setContentView(root);
        LinearLayout header = new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL); header.setOrientation(LinearLayout.HORIZONTAL);
        TextView brand = text("ShellX", 29, white, true); header.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
        TextView pill = text("GLASS TOOLKIT", 10, green, true); pill.setPadding(dp(11), dp(8), dp(11), dp(8)); pill.setBackground(round(card2, 18)); header.addView(pill);
        root.addView(header);
        TextView subtitle = text("Shizuku-only system terminal", 13, muted, false); subtitle.setPadding(0, dp(2), 0, dp(12)); root.addView(subtitle);

        LinearLayout statusCard = panel(); statusCard.setOrientation(LinearLayout.VERTICAL); statusCard.setPadding(dp(14), dp(12), dp(14), dp(12));
        statusText = text("Checking Shizuku…", 13, green, true); statusCard.addView(statusText);
        Button grant = button("Connect / grant Shizuku"); grant.setOnClickListener(v -> requestShizuku()); statusCard.addView(grant, matchWrap());
        root.addView(statusCard, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout tabs = new LinearLayout(this); tabs.setOrientation(LinearLayout.HORIZONTAL); tabs.setPadding(0, dp(12), 0, dp(10));
        Button shellTab = button("Shell Terminal"); Button gameTab = button("Game Enhance");
        tabs.addView(shellTab, new LinearLayout.LayoutParams(0, dp(44), 1)); LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(0, dp(44), 1); gp.leftMargin = dp(8); tabs.addView(gameTab, gp); root.addView(tabs);

        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); scroll.addView(content);
        shellPage = buildShellPage(); gamePage = buildGamePage();
        content.addView(shellPage); content.addView(gamePage); gamePage.setVisibility(View.GONE);
        shellTab.setOnClickListener(v -> showPage(true)); gameTab.setOnClickListener(v -> showPage(false));
        TextView footer = text("Commands run only through Shizuku. No ordinary-shell fallback.", 10, muted, false); footer.setGravity(Gravity.CENTER); footer.setPadding(0, dp(8), 0, 0); root.addView(footer);
    }

    private LinearLayout buildShellPage() {
        LinearLayout page = new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL);
        TextView title = text("Terminal", 21, white, true); title.setPadding(0, dp(6), 0, dp(8)); page.addView(title);
        TextView hint = text("Enter a command to execute it as the Shizuku shell user.", 12, muted, false); page.addView(hint);
        commandInput = new EditText(this); commandInput.setTextColor(white); commandInput.setHintTextColor(muted); commandInput.setHint("cmd game help"); commandInput.setTextSize(14); commandInput.setTypeface(Typeface.MONOSPACE); commandInput.setGravity(Gravity.TOP | Gravity.START); commandInput.setMinLines(2); commandInput.setPadding(dp(13), dp(12), dp(13), dp(12)); commandInput.setBackground(round(card2, 16)); LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1, -2); ip.topMargin = dp(12); page.addView(commandInput, ip);
        Button run = button("Run via Shizuku"); LinearLayout.LayoutParams rp = matchWrap(); rp.topMargin = dp(9); page.addView(run, rp); run.setOnClickListener(v -> runCommand(commandInput.getText().toString()));
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); Button copy = button("Copy output"); Button clear = button("Clear output"); row.addView(copy, new LinearLayout.LayoutParams(0, dp(42), 1)); LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, dp(42), 1); cp.leftMargin = dp(8); row.addView(clear, cp); LinearLayout.LayoutParams rowp = matchWrap(); rowp.topMargin = dp(8); page.addView(row, rowp);
        TextView outTitle = text("OUTPUT / STDERR", 11, green, true); outTitle.setPadding(0, dp(16), 0, dp(6)); page.addView(outTitle);
        outputText = text(lastOutput, 12, white, false); outputText.setTypeface(Typeface.MONOSPACE); outputText.setTextIsSelectable(true); outputText.setGravity(Gravity.TOP | Gravity.START); outputText.setPadding(dp(12), dp(12), dp(12), dp(12)); outputText.setMinHeight(dp(180)); outputText.setBackground(round(Color.rgb(8, 12, 10), 14)); page.addView(outputText, matchWrap());
        copy.setOnClickListener(v -> { android.content.ClipboardManager cm = (android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE); cm.setPrimaryClip(android.content.ClipData.newPlainText("ShellX output", outputText.getText())); toastDialog("Output copied."); });
        clear.setOnClickListener(v -> { outputText.setText(""); lastOutput = ""; });
        return page;
    }

    private LinearLayout buildGamePage() {
        LinearLayout page = new LinearLayout(this); page.setOrientation(LinearLayout.VERTICAL);
        TextView title = text("Game Enhance Custom", 21, white, true); title.setPadding(0, dp(6), 0, dp(4)); page.addView(title);
        TextView desc = text("Choose a game and customize the command. Firmware support may vary.", 12, muted, false); page.addView(desc);
        page.addView(label("GAME PACKAGE"));
        gameSpinner = new Spinner(this); gameSpinner.setAdapter(adapter(new String[]{"Free Fire · com.dts.freefireth", "Free Fire MAX · com.dts.freefiremax"})); gameSpinner.setPadding(dp(8), dp(3), dp(8), dp(3)); gameSpinner.setBackground(round(card2, 13)); page.addView(gameSpinner, matchHeight(dp(48)));
        page.addView(label("GAME MODE"));
        modeSpinner = new Spinner(this); modeSpinner.setAdapter(adapter(new String[]{"Mode 1", "Mode 2", "Mode 3", "Mode 4 · Custom"})); modeSpinner.setSelection(3); modeSpinner.setBackground(round(card2, 13)); page.addView(modeSpinner, matchHeight(dp(48)));
        page.addView(label("DOWNSCALE"));
        downscaleInput = new EditText(this); downscaleInput.setSingleLine(true); downscaleInput.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL); downscaleInput.setText("1.77"); downscaleInput.setTextColor(white); downscaleInput.setHintTextColor(muted); downscaleInput.setPadding(dp(13), dp(10), dp(13), dp(10)); downscaleInput.setBackground(round(card2, 13)); page.addView(downscaleInput, matchHeight(dp(48)));
        Button apply = button("Apply Enhance"); LinearLayout.LayoutParams ap = matchWrap(); ap.topMargin = dp(14); page.addView(apply, ap);
        Button reset = button("Reset game configuration"); LinearLayout.LayoutParams rst = matchWrap(); rst.topMargin = dp(8); page.addView(reset, rst);
        TextView note = text("Reset uses `cmd game reset <package>`. Apply runs both `cmd game set` and `cmd game mode` through Shizuku.", 11, muted, false); note.setPadding(0, dp(12), 0, dp(8)); page.addView(note);
        apply.setOnClickListener(v -> {
            String pkg = selectedPackage(); String mode = String.valueOf(modeSpinner.getSelectedItemPosition() + 1); String ds = downscaleInput.getText().toString().trim();
            if (!ds.matches("[0-9]+(\\.[0-9]+)?") || Double.parseDouble(ds) <= 0 || Double.parseDouble(ds) > 4) { toastDialog("Enter a valid downscale value greater than 0 and no more than 4."); return; }
            String command = "cmd game set --mode " + mode + " --downscale " + ds + " " + pkg + " && cmd game mode " + mode + " " + pkg;
            new AlertDialog.Builder(this).setTitle("Apply Game Enhance?").setMessage(command).setNegativeButton("Cancel", null).setPositiveButton("Run", (d, w) -> runCommand(command)).show();
        });
        reset.setOnClickListener(v -> { String pkg = selectedPackage(); String command = "cmd game reset " + pkg; new AlertDialog.Builder(this).setTitle("Reset game?").setMessage(command).setNegativeButton("Cancel", null).setPositiveButton("Reset", (d, w) -> runCommand(command)).show(); });
        return page;
    }

    private void showPage(boolean shell) { shellPage.setVisibility(shell ? View.VISIBLE : View.GONE); gamePage.setVisibility(shell ? View.GONE : View.VISIBLE); }
    private String selectedPackage() { return gameSpinner.getSelectedItemPosition() == 1 ? "com.dts.freefiremax" : "com.dts.freefireth"; }

    private void requestShizuku() {
        try {
            if (!Shizuku.pingBinder()) { toastDialog("Shizuku service is not running. Start Shizuku first, then return here."); refreshStatus(); return; }
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) { toastDialog("Shizuku permission is already granted."); refreshStatus(); }
            else Shizuku.requestPermission(REQUEST_CODE);
        } catch (Throwable e) { toastDialog("Shizuku unavailable: " + e.getMessage()); }
    }

    private boolean canExecute() {
        try { return Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED; }
        catch (Throwable e) { return false; }
    }

    private void runCommand(String command) {
        String cmd = command == null ? "" : command.trim();
        if (cmd.isEmpty()) { toastDialog("Enter a command first."); return; }
        if (!canExecute()) { toastDialog("Execution blocked: start Shizuku and grant ShellX permission first."); refreshStatus(); return; }
        outputText.setText("$ " + cmd + "\n\nRunning through Shizuku…");
        executor.execute(() -> {
            String result;
            try {
                Process p = Shizuku.newProcess(new String[]{"sh", "-c", cmd}, null, null);
                ByteArrayOutputStream stdout = new ByteArrayOutputStream(); ByteArrayOutputStream stderr = new ByteArrayOutputStream();
                Thread outThread = new Thread(() -> copy(p.getInputStream(), stdout));
                Thread errThread = new Thread(() -> copy(p.getErrorStream(), stderr)); outThread.start(); errThread.start();
                int code = p.waitFor(); outThread.join(3000); errThread.join(3000);
                String out = stdout.toString(StandardCharsets.UTF_8.name()).trim(); String err = stderr.toString(StandardCharsets.UTF_8.name()).trim();
                result = "$ " + cmd + "\n\n" + (out.isEmpty() ? "(no stdout)" : out) + (err.isEmpty() ? "" : "\n\nSTDERR:\n" + err) + "\n\nExit code: " + code;
            } catch (Throwable e) { result = "$ " + cmd + "\n\nExecution error: " + e.getClass().getSimpleName() + ": " + e.getMessage(); }
            final String finalResult = result;
            main.post(() -> { lastOutput = finalResult; outputText.setText(finalResult); refreshStatus(); });
        });
    }

    private void copy(InputStream in, ByteArrayOutputStream out) { try { byte[] b = new byte[4096]; int n; while ((n = in.read(b)) != -1) out.write(b, 0, n); } catch (Exception ignored) {} }

    private void refreshStatus() {
        if (statusText == null) return;
        boolean binder; boolean granted = false;
        try { binder = Shizuku.pingBinder(); if (binder) granted = Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED; }
        catch (Throwable e) { binder = false; }
        if (!binder) statusText.setText("● Shizuku service not connected");
        else if (!granted) statusText.setText("● Shizuku connected · permission needed");
        else statusText.setText("● Shizuku connected · permission granted");
    }

    private ArrayAdapter<String> adapter(String[] values) { ArrayAdapter<String> a = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, values) { @Override public android.view.View getView(int p, android.view.View cv, ViewGroup parent) { TextView t = (TextView)super.getView(p, cv, parent); t.setTextColor(white); t.setTextSize(13); t.setPadding(dp(10), dp(8), dp(10), dp(8)); return t; } @Override public android.view.View getDropDownView(int p, android.view.View cv, ViewGroup parent) { TextView t = (TextView)super.getDropDownView(p, cv, parent); t.setTextColor(white); t.setBackgroundColor(card); t.setPadding(dp(12), dp(12), dp(12), dp(12)); return t; } }; a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); return a; }
    private LinearLayout panel() { LinearLayout l = new LinearLayout(this); l.setBackground(round(card, 18)); return l; }
    private TextView label(String s) { TextView t = text(s, 11, green, true); t.setPadding(0, dp(14), 0, dp(7)); return t; }
    private TextView text(String s, int size, int color, boolean bold) { TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return t; }
    private Button button(String s) { Button b = new Button(this); b.setText(s); b.setTextAllCaps(false); b.setTextColor(white); b.setTextSize(13); b.setTypeface(Typeface.DEFAULT, Typeface.BOLD); b.setBackground(round(card2, 14)); b.setPadding(dp(10), dp(5), dp(10), dp(5)); return b; }
    private GradientDrawable round(int color, int radius) { GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); d.setStroke(dp(1), Color.rgb(52, 70, 60)); return d; }
    private LinearLayout.LayoutParams matchWrap() { return new LinearLayout.LayoutParams(-1, -2); }
    private LinearLayout.LayoutParams matchHeight(int h) { return new LinearLayout.LayoutParams(-1, h); }
    private int dp(int x) { return (int)(x * getResources().getDisplayMetrics().density + 0.5f); }
    private void toastDialog(String s) { if (isFinishing()) return; new AlertDialog.Builder(this).setMessage(s).setPositiveButton("OK", null).show(); }
}
