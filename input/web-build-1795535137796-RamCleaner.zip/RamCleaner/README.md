# RAM Cleaner (Android, Kotlin + Compose)

## Cách chạy
1. Mở Android Studio (Koala trở lên) -> File > Open -> chọn thư mục RamCleaner.
2. Chờ Gradle sync xong, bấm Run trên thiết bị thật hoặc máy ảo.

## Cách hoạt động
- Đọc RAM: ActivityManager.getMemoryInfo()
- Dọn RAM: ActivityManager.killBackgroundProcesses(pkg) cho mỗi app người dùng (quyền KILL_BACKGROUND_PROCESSES).
- Đo RAM trống trước/sau để hiển thị số MB giải phóng.

## Giới hạn
- Chỉ dừng được tiến trình nền/đã cache. Không thể dừng app đang chạy foreground hay app hệ thống.
- Android sẽ tự khởi động lại một số app nền, nên RAM trống có thể tăng lại nhanh.
