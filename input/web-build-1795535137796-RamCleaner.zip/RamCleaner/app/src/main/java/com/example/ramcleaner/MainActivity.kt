package com.example.ramcleaner

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { RamScreen() } }
    }
}

@Composable
fun RamScreen() {
    val context = LocalContext.current
    val cleaner = remember { RamCleaner(context) }
    val scope = rememberCoroutineScope()

    var ram by remember { mutableStateOf(cleaner.readRam()) }
    var cleaning by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<CleanResult?>(null) }

    // Tự cập nhật mỗi 2 giây
    LaunchedEffect(Unit) {
        while (true) {
            ram = cleaner.readRam()
            delay(2000)
        }
    }

    Surface(Modifier.fillMaxSize()) {
        Column(
            Modifier.fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("RAM Cleaner", fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(32.dp))

            Box(contentAlignment = Alignment.Center) {
                CircularProgressIndicator(
                    progress = { ram.usedPercent },
                    modifier = Modifier.size(200.dp),
                    strokeWidth = 14.dp
                )
                Text("${(ram.usedPercent * 100).toInt()}%", fontSize = 40.sp, fontWeight = FontWeight.Bold)
            }

            Spacer(Modifier.height(16.dp))
            Text("Đã dùng ${ram.usedBytes.toMb()} MB / ${ram.totalBytes.toMb()} MB")
            Text("Còn trống: ${ram.availBytes.toMb()} MB")

            Spacer(Modifier.height(32.dp))
            Button(
                onClick = {
                    scope.launch {
                        cleaning = true
                        result = cleaner.clean()
                        ram = cleaner.readRam()
                        cleaning = false
                    }
                },
                enabled = !cleaning,
                modifier = Modifier.fillMaxWidth().height(56.dp)
            ) {
                Text(if (cleaning) "Đang dọn..." else "Dọn RAM", fontSize = 18.sp)
            }

            result?.let {
                Spacer(Modifier.height(24.dp))
                Text("Đã yêu cầu dừng ${it.appsTargeted} ứng dụng nền")
                Text(
                    "Giải phóng: ${it.freedBytes.toMb()} MB",
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "Trước: ${it.before.availBytes.toMb()} MB → Sau: ${it.after.availBytes.toMb()} MB",
                    fontSize = 13.sp
                )
            }
        }
    }
}
