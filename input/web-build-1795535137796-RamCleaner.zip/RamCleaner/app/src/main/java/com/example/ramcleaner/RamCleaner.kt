package com.example.ramcleaner

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

data class RamInfo(val totalBytes: Long, val availBytes: Long) {
    val usedBytes get() = totalBytes - availBytes
    val usedPercent get() = if (totalBytes == 0L) 0f else usedBytes.toFloat() / totalBytes
}

data class CleanResult(val appsTargeted: Int, val freedBytes: Long, val before: RamInfo, val after: RamInfo)

class RamCleaner(private val context: Context) {

    private val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager

    fun readRam(): RamInfo {
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        return RamInfo(mi.totalMem, mi.availMem)
    }

    /** Lấy các app người dùng (có launcher, không phải app hệ thống, không phải chính app này). */
    private fun targetPackages(): List<String> {
        val pm = context.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(launcher, 0)
            .map { it.activityInfo.applicationInfo }
            .filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 }
            .map { it.packageName }
            .filter { it != context.packageName }
            .distinct()
    }

    suspend fun clean(): CleanResult = withContext(Dispatchers.Default) {
        val before = readRam()
        val packages = targetPackages()
        packages.forEach { pkg ->
            try { am.killBackgroundProcesses(pkg) } catch (_: SecurityException) { }
        }
        delay(1200) // chờ hệ thống thu hồi bộ nhớ
        val after = readRam()
        CleanResult(
            appsTargeted = packages.size,
            freedBytes = (after.availBytes - before.availBytes).coerceAtLeast(0),
            before = before,
            after = after
        )
    }
}

fun Long.toMb(): Long = this / (1024 * 1024)
