# Android WebView wrapper

This wrapper exposes only safe native APIs:
- `window.RamTurboNative.getDeviceInfo()` -> JSON with real manufacturer/model, Android version/API, total/available RAM, low-memory flag, battery percentage.
- `window.RamTurboNative.openSettings('app'|'battery'|'memory')` -> opens a system settings screen.

It deliberately does not expose arbitrary shell execution. Do not wire the UI's command buttons to pretend success. Real privileged actions require adding the official Shizuku API, checking permission state, and executing an allow-listed command with output/exit-code handling.

The WebView loads `app/src/main/assets/www/index.html`. Build the React app first (`npm install && npm run build`), then copy the contents of root `dist/` into `app/src/main/assets/www/`.

Open this `android/` folder in Android Studio and build a debug APK. No prebuilt APK is included.

## Shizuku integration (real status/permission request)

This source includes the Shizuku API dependency (`dev.rikka.shizuku:api:13.1.5`). The Android bridge checks whether the Shizuku app is installed, whether its Binder service is running, and whether RAM Turbo Pro has been granted permission. The UI requests permission through Shizuku's actual permission dialog; it no longer marks Shizuku connected just because a button was tapped.

Before testing, install and start the official Shizuku app using its Wireless debugging instructions, then open RAM Turbo Pro and request permission. A granted Shizuku permission does not itself implement any RAM/zRAM operation: each operation must still be explicitly implemented and verified. No `settings put global` or `settings put system` commands are included by this change.

The web assets must be built from the project root (`npm run build`) and copied from `dist/` into `android/app/src/main/assets/www/` before building the Android app. This environment did not complete dependency installation or compile/test an APK, so the source changes still need a Gradle build verification.
