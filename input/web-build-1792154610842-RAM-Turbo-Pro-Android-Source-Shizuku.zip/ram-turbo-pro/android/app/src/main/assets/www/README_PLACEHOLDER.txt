After running `npm run build` in the project root, copy the CONTENTS of `dist/` into this folder. The app loads www/index.html.
