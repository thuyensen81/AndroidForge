package vn.ramturbopro.app;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Debug;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import rikka.shizuku.Shizuku;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final int SHIZUKU_REQUEST_CODE = 7412;
    private WebView webView;
    private final Shizuku.OnRequestPermissionResultListener shizukuPermissionListener = (requestCode, grantResult) -> {
        if (requestCode == SHIZUKU_REQUEST_CODE && webView != null) {
            final boolean granted = grantResult == android.content.pm.PackageManager.PERMISSION_GRANTED;
            webView.post(() -> webView.evaluateJavascript("window.dispatchEvent(new CustomEvent('shizuku-permission-result',{detail:{granted:" + granted + "}}));", null));
        }
    };
    private final Shizuku.OnBinderReceivedListener shizukuBinderReceivedListener = () -> notifyShizukuStatus();
    private final Shizuku.OnBinderDeadListener shizukuBinderDeadListener = () -> notifyShizukuStatus();
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new NativeBridge(this), "RamTurboNative");
        setContentView(webView);
        try {
            Shizuku.addRequestPermissionResultListener(shizukuPermissionListener);
            Shizuku.addBinderReceivedListener(shizukuBinderReceivedListener);
            Shizuku.addBinderDeadListener(shizukuBinderDeadListener);
        } catch (Throwable ignored) { }
        webView.loadUrl("file:///android_asset/www/index.html");
    }
    @Override protected void onDestroy() {
        try {
            Shizuku.removeRequestPermissionResultListener(shizukuPermissionListener);
            Shizuku.removeBinderReceivedListener(shizukuBinderReceivedListener);
            Shizuku.removeBinderDeadListener(shizukuBinderDeadListener);
        } catch (Throwable ignored) { }
        super.onDestroy();
    }
    private void notifyShizukuStatus() {
        if (webView != null) webView.post(() -> webView.evaluateJavascript("window.dispatchEvent(new CustomEvent('shizuku-status-changed'));", null));
    }
    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    public static final class NativeBridge {
        private final Activity activity;
        NativeBridge(Activity activity) { this.activity = activity; }
        @JavascriptInterface public String getDeviceInfo() {
            try {
                ActivityManager am = (ActivityManager) activity.getSystemService(Context.ACTIVITY_SERVICE);
                ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
                am.getMemoryInfo(mi);
                long total = mi.totalMem / (1024L * 1024L);
                long avail = mi.availMem / (1024L * 1024L);
                Intent battery = activity.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
                Integer batteryPercent = null;
                if (battery != null) {
                    int level = battery.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                    int scale = battery.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
                    if (level >= 0 && scale > 0) batteryPercent = Math.round(level * 100f / scale);
                }
                JSONObject o = new JSONObject();
                o.put("manufacturer", Build.MANUFACTURER);
                o.put("model", Build.MODEL);
                o.put("androidVersion", Build.VERSION.RELEASE);
                o.put("apiLevel", Build.VERSION.SDK_INT);
                o.put("totalRamMb", total);
                o.put("availableRamMb", avail);
                o.put("lowMemory", mi.lowMemory);
                o.put("batteryPercent", batteryPercent == null ? JSONObject.NULL : batteryPercent);
                return o.toString();
            } catch (Exception e) { return "{}"; }
        }
        @JavascriptInterface public String getShizukuStatus() {
            try {
                boolean binder = Shizuku.pingBinder();
                boolean granted = binder && Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED;
                JSONObject o = new JSONObject();
                o.put("installed", isPackageInstalled(activity, "moe.shizuku.privileged.api"));
                o.put("binderAvailable", binder);
                o.put("permissionGranted", granted);
                return o.toString();
            } catch (Throwable e) {
                try {
                    JSONObject o = new JSONObject();
                    o.put("installed", isPackageInstalled(activity, "moe.shizuku.privileged.api"));
                    o.put("binderAvailable", false);
                    o.put("permissionGranted", false);
                    o.put("error", e.getClass().getSimpleName());
                    return o.toString();
                } catch (Exception ignored) { return "{}"; }
            }
        }
        @JavascriptInterface public String requestShizukuPermission() {
            try {
                if (!Shizuku.pingBinder()) return "binder_unavailable";
                if (Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED) return "granted";
                Shizuku.requestPermission(MainActivity.SHIZUKU_REQUEST_CODE);
                return "requested";
            } catch (Throwable e) { return "error"; }
        }
        @JavascriptInterface public String openShizukuApp() {
            try {
                Intent launch = activity.getPackageManager().getLaunchIntentForPackage("moe.shizuku.privileged.api");
                if (launch == null) return "not_installed";
                activity.startActivity(launch);
                return "ok";
            } catch (Exception e) { return "error"; }
        }
        private static boolean isPackageInstalled(Context context, String packageName) {
            try { context.getPackageManager().getPackageInfo(packageName, 0); return true; }
            catch (Exception e) { return false; }
        }
        @JavascriptInterface public String openSettings(String which) {
            try {
                Intent i;
                if ("battery".equals(which)) i = new Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS);
                else if ("memory".equals(which) && Build.VERSION.SDK_INT >= 29) i = new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS);
                else i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + activity.getPackageName()));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                activity.startActivity(i);
                return "ok";
            } catch (Exception e) { return "error"; }
        }
    }
}
