import { CheckCircle2, Code, X, Smartphone } from 'lucide-react';
import { PermissionState } from '../types';
import { soundFX } from '../utils/audio';
import { getShizukuStatus, requestNativeShizukuPermission, openNativeShizukuApp } from '../utils/androidBridge';
import { useEffect, useState } from 'react';

interface PermissionModalProps {
  isOpen: boolean;
  onClose: () => void;
  permission: PermissionState;
  onUpdatePermission: (newPerm: PermissionState) => void;
  onAddLog: (cmd: string, output: string, type: 'root' | 'adb') => void;
  language: 'vi' | 'en';
}

export function PermissionModal({
  isOpen,
  onClose,
  permission,
  onUpdatePermission,
  onAddLog,
  language,
}: PermissionModalProps) {
  const [shizukuMessage, setShizukuMessage] = useState('');
  const [nativeAvailable, setNativeAvailable] = useState(false);

  const refreshShizukuStatus = () => {
    const status = getShizukuStatus();
    setNativeAvailable(!!window.RamTurboNative);
    onUpdatePermission({
      mode: status.permissionGranted ? 'shizuku' : 'unauthorized',
      shizukuActive: status.permissionGranted,
      wirelessDebuggingEnabled: status.binderAvailable,
      selinuxEnforcing: true,
    });
    return status;
  };

  useEffect(() => {
    if (!isOpen) return;
    refreshShizukuStatus();
    const onPermissionResult = (event: Event) => {
      const detail = (event as CustomEvent<{ granted: boolean }>).detail;
      refreshShizukuStatus();
      if (detail?.granted) {
        setShizukuMessage(language === 'vi' ? 'Đã được Shizuku cấp quyền.' : 'Shizuku permission granted.');
        onAddLog('Shizuku permission check', 'Permission was granted by the Shizuku service.', 'adb');
      } else {
        setShizukuMessage(language === 'vi' ? 'Chưa được cấp quyền Shizuku.' : 'Shizuku permission was not granted.');
      }
    };
    const onStatusChanged = () => refreshShizukuStatus();
    window.addEventListener('shizuku-permission-result', onPermissionResult);
    window.addEventListener('shizuku-status-changed', onStatusChanged);
    return () => {
      window.removeEventListener('shizuku-permission-result', onPermissionResult);
      window.removeEventListener('shizuku-status-changed', onStatusChanged);
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const handleGrantShizuku = () => {
    soundFX.playTap();
    const status = refreshShizukuStatus();
    if (!nativeAvailable) {
      setShizukuMessage(language === 'vi' ? 'Bản xem trước web không thể kết nối Shizuku. Hãy dùng APK Android.' : 'Web preview cannot connect to Shizuku. Use the Android APK.');
      return;
    }
    if (!status.installed) {
      setShizukuMessage(language === 'vi' ? 'Chưa tìm thấy ứng dụng Shizuku trên máy.' : 'Shizuku app was not found on this device.');
      return;
    }
    const result = requestNativeShizukuPermission();
    if (result === 'granted') {
      refreshShizukuStatus();
      setShizukuMessage(language === 'vi' ? 'Shizuku đã cấp quyền cho ứng dụng.' : 'Shizuku permission is already granted.');
    } else if (result === 'requested') {
      setShizukuMessage(language === 'vi' ? 'Hãy xác nhận hộp thoại cấp quyền Shizuku.' : 'Confirm the Shizuku permission dialog.');
    } else if (result === 'binder_unavailable') {
      setShizukuMessage(language === 'vi' ? 'Dịch vụ Shizuku chưa chạy. Mở Shizuku và khởi động dịch vụ trước.' : 'Shizuku service is not running. Open Shizuku and start its service first.');
    } else {
      setShizukuMessage(language === 'vi' ? 'Không thể yêu cầu quyền Shizuku. Kiểm tra ứng dụng và dịch vụ Shizuku.' : 'Could not request Shizuku permission. Check the app and service.');
    }
  };

  const handleRevoke = () => {
    soundFX.playTap();
    // The app cannot revoke Shizuku's system-side permission itself.
    setShizukuMessage(language === 'vi' ? 'Muốn thu hồi quyền, hãy mở Shizuku và thu hồi quyền của RAM Turbo Pro tại đó.' : 'To revoke permission, open Shizuku and revoke RAM Turbo Pro there.');
    openNativeShizukuApp();
    refreshShizukuStatus();
  };


  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div className="w-full max-w-lg bg-slate-950 border border-cyan-500/30 rounded-3xl p-6 shadow-2xl relative overflow-hidden">
        {/* Close Button */}
        <button
          onClick={() => {
            soundFX.playTap();
            onClose();
          }}
          className="absolute top-4 right-4 p-2 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition"
        >
          <X size={18} />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 mb-4">
          <div className="p-3 rounded-2xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/30">
            <Code size={24} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base font-bold text-white">
                {language === 'vi' ? 'Cấp Quyền Dịch Vụ Shizuku' : 'Authorize Shizuku Service'}
              </h3>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 font-bold border border-cyan-500/30">
                ADB KHÔNG ROOT
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              {language === 'vi'
                ? 'Thực thi các lệnh dọn dẹp và tối ưu RAM qua giao thức Gỡ lỗi không dây Shizuku'
                : 'Elevated system RAM optimization commands via Shizuku Wireless Debugging'}
            </p>
          </div>
        </div>

        {/* Active Status Banner */}
        {permission.shizukuActive ? (
          <div className="space-y-4">
            <div className="p-4 rounded-2xl bg-emerald-950/40 border border-emerald-500/40 text-left space-y-3 text-xs">
              <div className="flex items-center justify-between pb-2 border-b border-emerald-500/20">
                <div className="flex items-center gap-2 text-emerald-400 font-bold">
                  <CheckCircle2 size={16} />
                  <span>{language === 'vi' ? 'Shizuku đã cấp quyền cho ứng dụng' : 'Shizuku permission granted'}</span>
                </div>
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-mono text-[10px] font-bold">
                  PERMISSION GRANTED
                </span>
              </div>

              <div className="space-y-1.5 font-mono text-[11px] text-slate-300">
                <div className="flex justify-between">
                  <span className="text-slate-400">Giao thức kết nối:</span>
                  <span className="text-cyan-400 font-bold">{language === 'vi' ? 'Binder Shizuku' : 'Shizuku Binder'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Phiên bản Server:</span>
                  <span className="text-white">{language === 'vi' ? 'Trạng thái thực tế' : 'Live status'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Đặc quyền cấp phát:</span>
                  <span className="text-emerald-400 font-bold">{language === 'vi' ? 'Quyền được cấp' : 'Permission granted'}</span>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-800 text-[11px] text-slate-400 leading-relaxed">
                {language === 'vi'
                  ? 'Đây chỉ xác nhận quyền Shizuku đã được cấp. Mỗi lệnh vẫn cần được triển khai và kiểm tra riêng; quyền này không tự động cho phép sửa zRAM hoặc đóng băng mọi ứng dụng.'
                  : 'This confirms Shizuku permission only. Each command still needs separate implementation and validation; this does not automatically allow zRAM changes or freezing every app.'}
              </div>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={handleRevoke}
                className="flex-1 py-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-rose-400 hover:text-rose-300 font-bold text-xs transition"
              >
                {language === 'vi' ? 'NGẮT KẾT NỐI SHIZUKU' : 'DISCONNECT SHIZUKU'}
              </button>

              <button
                onClick={() => {
                  soundFX.playTap();
                  onClose();
                }}
                className="flex-1 py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-teal-500 hover:from-cyan-400 hover:to-teal-400 text-slate-950 font-black text-xs tracking-wider uppercase shadow-lg shadow-cyan-500/20 active:scale-95 transition"
              >
                {language === 'vi' ? 'HOÀN TẤT' : 'DONE'}
              </button>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="p-3 rounded-xl bg-amber-950/30 border border-amber-500/30 text-xs text-amber-200">
              {shizukuMessage || (language === 'vi' ? 'Trạng thái sẽ được đọc trực tiếp từ dịch vụ Shizuku khi chạy trong APK Android.' : 'Status is read from the Shizuku service when running in the Android APK.')}
            </div>
            <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 text-left space-y-3.5 text-xs">
              <div className="flex items-center gap-2 text-cyan-400 font-bold">
                <Smartphone size={16} />
                <span>
                  {language === 'vi'
                    ? '3 Bước Kích Hoạt Shizuku (Không Cần Root Máy)'
                    : '3 Steps to Activate Shizuku (Rootless ADB)'}
                </span>
              </div>

              {/* Step 1 */}
              <div className="flex items-start gap-2.5 text-[11px] text-slate-300">
                <span className="w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-400 flex items-center justify-center font-mono font-bold shrink-0 mt-0.5">
                  1
                </span>
                <p className="leading-relaxed">
                  {language === 'vi'
                    ? 'Mở "Tùy chọn cho nhà phát triển" (Developer Options) trên điện thoại và bật "Gỡ lỗi không dây (Wireless Debugging)".'
                    : 'Open Developer Options on your phone and enable "Wireless Debugging".'}
                </p>
              </div>

              {/* Step 2 */}
              <div className="flex items-start gap-2.5 text-[11px] text-slate-300">
                <span className="w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-400 flex items-center justify-center font-mono font-bold shrink-0 mt-0.5">
                  2
                </span>
                <div className="flex-1 min-w-0">
                  <p className="leading-relaxed mb-2">
                    {language === 'vi'
                      ? 'Mở ứng dụng Shizuku, bật dịch vụ bằng Wireless debugging theo hướng dẫn trong chính Shizuku. Sau đó quay lại đây để kiểm tra kết nối.'
                      : 'Open Shizuku and start its service using Wireless debugging, following Shizuku’s own instructions. Return here to check the connection.'}
                  </p>
                  <button onClick={() => { soundFX.playTap(); const result = openNativeShizukuApp(); setShizukuMessage(result === 'ok' ? (language === 'vi' ? 'Đã mở Shizuku.' : 'Opened Shizuku.') : result === 'not_installed' ? (language === 'vi' ? 'Chưa cài Shizuku trên thiết bị.' : 'Shizuku is not installed.') : (language === 'vi' ? 'Hãy mở Shizuku thủ công trên điện thoại.' : 'Please open Shizuku manually.')); }} className="px-3 py-2 rounded-lg bg-slate-800 border border-slate-700 text-cyan-300 font-bold">
                    {language === 'vi' ? 'MỞ SHIZUKU' : 'OPEN SHIZUKU'}
                  </button>
                </div>
              </div>

              {/* Step 3 */}
              <div className="flex items-start gap-2.5 text-[11px] text-slate-300">
                <span className="w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-400 flex items-center justify-center font-mono font-bold shrink-0 mt-0.5">
                  3
                </span>
                <p className="leading-relaxed">
                  {language === 'vi'
                    ? 'Sau khi dịch vụ chạy, bấm nút bên dưới và xác nhận hộp thoại quyền thật của Shizuku.'
                    : 'Once the service is running, tap the button below and approve the real Shizuku permission dialog.'}
                </p>
              </div>
            </div>

            <button
              onClick={handleGrantShizuku}
              className="w-full py-3.5 rounded-xl bg-gradient-to-r from-cyan-500 via-teal-500 to-emerald-500 hover:from-cyan-400 hover:to-emerald-400 text-slate-950 font-black text-xs tracking-wider uppercase shadow-lg shadow-cyan-500/20 active:scale-95 transition flex items-center justify-center gap-2"
            >
              <Code size={16} />
              <span>
                {language === 'vi'
                  ? 'KIỂM TRA / XIN QUYỀN SHIZUKU'
                  : 'CHECK / REQUEST SHIZUKU PERMISSION'}
              </span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
