/** Native bridge exposed by the Android wrapper. Browser preview safely falls back. */
export type NativeDeviceInfo = {
  manufacturer: string; model: string; androidVersion: string; apiLevel: number;
  totalRamMb: number; availableRamMb: number; lowMemory: boolean; batteryPercent: number | null;
};

declare global {
  interface Window { RamTurboNative?: {
    getDeviceInfo(): string;
    openSettings(which: string): string;
    getShizukuStatus(): string;
    requestShizukuPermission(): string;
    openShizukuApp(): string;
  } }
}

export function getNativeDeviceInfo(): NativeDeviceInfo | null {
  try {
    const raw = window.RamTurboNative?.getDeviceInfo();
    if (!raw) return null;
    const value = JSON.parse(raw) as NativeDeviceInfo;
    if (!value || typeof value.totalRamMb !== 'number') return null;
    return value;
  } catch { return null; }
}

export function openAndroidSettings(which: 'app' | 'battery' | 'memory' = 'app'): boolean {
  try { return window.RamTurboNative?.openSettings(which) === 'ok'; }
  catch { return false; }
}


export type ShizukuStatus = { installed: boolean; binderAvailable: boolean; permissionGranted: boolean; error?: string };

export function getShizukuStatus(): ShizukuStatus {
  try {
    const raw = window.RamTurboNative?.getShizukuStatus();
    if (!raw) return { installed: false, binderAvailable: false, permissionGranted: false };
    return JSON.parse(raw) as ShizukuStatus;
  } catch { return { installed: false, binderAvailable: false, permissionGranted: false }; }
}

export function requestNativeShizukuPermission(): 'granted' | 'requested' | 'binder_unavailable' | 'error' | 'unsupported' {
  try {
    const result = window.RamTurboNative?.requestShizukuPermission();
    if (result === 'granted' || result === 'requested' || result === 'binder_unavailable' || result === 'error') return result;
    return 'unsupported';
  } catch { return 'error'; }
}

export function openNativeShizukuApp(): 'ok' | 'not_installed' | 'error' | 'unsupported' {
  try {
    const result = window.RamTurboNative?.openShizukuApp();
    if (result === 'ok' || result === 'not_installed' || result === 'error') return result;
    return 'unsupported';
  } catch { return 'error'; }
}
