# RAM Turbo Pro — Native Android starter

This project is a Kotlin + Jetpack Compose Android application. Its primary UI is native Compose; it does not use WebView or HTML as the app interface.

## Build
- Android Studio with JDK 17
- Android SDK platform 35
- Open this directory as a Gradle project, sync, then Build > Build APK(s).
- Expected APK: `app/build/outputs/apk/debug/app-debug.apk`

## Honest status
- Reads real total/available memory and device build properties using Android APIs.
- Other screens are native UI scaffolding and explicitly do not claim to change kernel/zRAM, kill processes, run benchmark tests, or apply game performance tweaks.
- Shizuku Binder integration is not implemented in this starter yet.
- Game Turbo is represented as native UI scaffolding, not a port of every behavior in the React component. The original React source is retained under `reference-source/` for future porting and comparison.
- No `settings put global` or `settings put system` commands are included.
