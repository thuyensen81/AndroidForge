package com.ramturbo.pro

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

private val Bg = Color(0xFF080D16)
private val Panel = Color(0xFF111A27)
private val Panel2 = Color(0xFF172334)
private val TextMain = Color(0xFFF2F6FC)
private val Muted = Color(0xFF8D9BB0)
private val Green = Color(0xFF34D399)
private val Cyan = Color(0xFF22D3EE)
private val Purple = Color(0xFFA78BFA)
private val Rose = Color(0xFFFB7185)
private val Amber = Color(0xFFFBBF24)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(8,13,22)
        window.navigationBarColor = android.graphics.Color.rgb(8,13,22)
        setContent { MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Panel, primary = Green, onBackground = TextMain, onSurface = TextMain)) { NativeApp(this) } }
    }
}

private data class Tab(val id: String, val label: String, val icon: ImageVector, val color: Color)

@Composable
private fun NativeApp(activity: ComponentActivity) {
    val tabs = listOf(
        Tab("overview", "Tổng Quan", Icons.Default.Bolt, Green),
        Tab("processes", "Tiến Trình", Icons.Default.Layers, Cyan),
        Tab("virtual", "RAM Ảo", Icons.Default.Memory, Purple),
        Tab("game", "Game Turbo", Icons.Default.LocalFireDepartment, Rose),
        Tab("benchmark", "Benchmark", Icons.Default.Speed, Amber),
        Tab("settings", "Cài Đặt", Icons.Default.Settings, Muted)
    )
    var selected by remember { mutableStateOf("overview") }
    var showDevices by remember { mutableStateOf(false) }
    var device by remember { mutableStateOf("Tự nhận diện thiết bị") }
    var gameEnabled by remember { mutableStateOf(false) }
    var autoBoost by remember { mutableStateOf(true) }
    var message by remember { mutableStateOf("Sẵn sàng") }
    val memory = remember { (activity.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager) }
    val memInfo = remember { ActivityManager.MemoryInfo() }
    memory.getMemoryInfo(memInfo)
    val totalGb = memInfo.totalMem / 1024.0 / 1024 / 1024
    val availGb = memInfo.availMem / 1024.0 / 1024 / 1024
    val usedGb = (totalGb - availGb).coerceAtLeast(0.0)
    val usedPct = if (totalGb > 0) (usedGb / totalGb * 100).toInt().coerceIn(0,100) else 0
    Scaffold(containerColor = Bg, bottomBar = {
        NavigationBar(containerColor = Color(0xF20B1220), tonalElevation = 0.dp) {
            tabs.forEach { tab -> NavigationBarItem(selected = selected == tab.id, onClick = { selected = tab.id }, icon = { Icon(tab.icon, null, tint = if (selected == tab.id) tab.color else Muted) }, label = { Text(tab.label, fontSize = 9.sp, maxLines = 1) }, colors = NavigationBarItemDefaults.colors(indicatorColor = tab.color.copy(alpha = .15f), selectedTextColor = TextMain, unselectedTextColor = Muted)) }
        }
    }) { padding ->
        Column(Modifier.fillMaxSize().background(Bg).padding(padding)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).background(Green.copy(alpha=.14f), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Default.Memory, null, tint = Green, modifier = Modifier.size(25.dp)) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) { Text("RAM TURBO PRO", fontSize = 17.sp, fontWeight = FontWeight.Black, color = TextMain, letterSpacing = 1.sp); Text("NATIVE ANDROID", fontSize = 10.sp, color = Green, letterSpacing = 2.sp) }
                IconButton(onClick = { selected = "settings" }) { Icon(Icons.Default.Settings, "Cài đặt", tint = Muted) }
            }
            when (selected) {
                "overview" -> LazyColumn(contentPadding = PaddingValues(horizontal=16.dp, vertical=8.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    item { CardPanel { Column(Modifier.fillMaxWidth().padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("BỘ NHỚ THIẾT BỊ", color=Muted, fontSize=11.sp, fontWeight=FontWeight.Bold); Text("RAM đang sử dụng", color=TextMain, fontSize=19.sp, fontWeight=FontWeight.Bold) }; Icon(Icons.Default.Memory, null, tint=Green, modifier=Modifier.size(30.dp)) }
                        Spacer(Modifier.height(16.dp)); Row(verticalAlignment=Alignment.Bottom) { Text(String.format(Locale.US,"%.1f",usedGb), fontSize=42.sp, fontWeight=FontWeight.Black, color=Green); Text(" / "+String.format(Locale.US,"%.1f GB",totalGb), color=Muted, modifier=Modifier.padding(bottom=7.dp)) }
                        LinearProgressIndicator(progress={usedPct/100f}, modifier=Modifier.fillMaxWidth().height(8.dp), color=Green, trackColor=Panel2)
                        Spacer(Modifier.height(10.dp)); Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) { Text("Đã dùng $usedPct%", color=Muted, fontSize=12.sp); Text(String.format(Locale.US,"Còn %.1f GB",availGb), color=Cyan, fontSize=12.sp) }
                    } } }
                    item { Row(horizontalArrangement=Arrangement.spacedBy(12.dp)) { StatCard("ANDROID", Build.VERSION.RELEASE, Icons.Default.Android, Green, Modifier.weight(1f)); StatCard("MODEL", Build.MODEL ?: "Không rõ", Icons.Default.PhoneAndroid, Cyan, Modifier.weight(1f)) } }
                    item { CardPanel { Column(Modifier.padding(16.dp)) { Text("Tăng tốc nhanh", fontSize=17.sp, fontWeight=FontWeight.Bold); Spacer(Modifier.height(6.dp)); Text("RAM Turbo Pro không tự ý đóng ứng dụng hay sửa thông số kernel.", color=Muted, fontSize=12.sp); Spacer(Modifier.height(14.dp)); Button(onClick={ message="Đã đọc số liệu RAM thực từ Android" }, modifier=Modifier.fillMaxWidth(), colors=ButtonDefaults.buttonColors(containerColor=Green, contentColor=Bg)) { Icon(Icons.Default.Bolt,null); Spacer(Modifier.width(8.dp)); Text("LÀM MỚI THÔNG TIN RAM", fontWeight=FontWeight.Bold) }; Text(message, color=Muted, fontSize=11.sp, modifier=Modifier.padding(top=8.dp)) } } }
                    item { CardPanel { Column(Modifier.padding(16.dp)) { Text("Thiết bị", fontSize=17.sp, fontWeight=FontWeight.Bold); Spacer(Modifier.height(10.dp)); Text(device, color=Cyan); Text("Nhận diện thực tế: ${Build.MANUFACTURER} ${Build.MODEL}", color=Muted, fontSize=12.sp); Text("Chọn hồ sơ mô phỏng", color=Muted, fontSize=12.sp, modifier=Modifier.clickable { showDevices=true }.padding(top=10.dp)); if(showDevices) { listOf("Tự nhận diện thiết bị","OnePlus 13","Samsung Galaxy S25 Ultra","vivo X200 Pro","iQOO 13","realme GT 7 Pro","Xiaomi 15 Ultra").forEach { item -> Text(item, color=TextMain, modifier=Modifier.fillMaxWidth().clickable { device=item; showDevices=false }.padding(vertical=8.dp)) } } } } }
                }
                "processes" -> SimplePage("Tiến Trình", "Danh sách tiến trình hệ thống bị giới hạn trên Android thường. Màn hình này chưa tuyên bố đã dọn hoặc kết thúc ứng dụng.", Icons.Default.Layers) { Button(onClick={ activity.startActivity(Intent(Settings.ACTION_APPLICATION_SETTINGS)) }, colors=ButtonDefaults.buttonColors(containerColor=Cyan, contentColor=Bg)) { Text("MỞ CÀI ĐẶT ỨNG DỤNG") } }
                "virtual" -> SimplePage("RAM Ảo", "Trạng thái zRAM/RAM ảo không thể tự ý thay đổi bằng ứng dụng thông thường. Không có thay đổi kernel nào được thực hiện ở bản này.", Icons.Default.Memory) { Text("Thiết bị: ${Build.MANUFACTURER} ${Build.MODEL}", color=Cyan) }
                "game" -> LazyColumn(contentPadding=PaddingValues(16.dp), verticalArrangement=Arrangement.spacedBy(14.dp)) {
                    item { CardPanel { Column(Modifier.padding(18.dp)) { Row(verticalAlignment=Alignment.CenterVertically) { Icon(Icons.Default.LocalFireDepartment, null, tint=Rose, modifier=Modifier.size(32.dp)); Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)) { Text("GAME TURBO", fontSize=20.sp, fontWeight=FontWeight.Black); Text("Trung tâm chơi game", color=Muted, fontSize=12.sp) }; Switch(checked=gameEnabled, onCheckedChange={ gameEnabled=it }) }; Spacer(Modifier.height(12.dp)); Text(if(gameEnabled) "Chế độ giao diện đang bật" else "Chế độ giao diện đang tắt", color=if(gameEnabled) Rose else Muted); Spacer(Modifier.height(8.dp)); Text("Lưu ý: nút này chỉ thay đổi trạng thái giao diện, chưa can thiệp hiệu năng trò chơi của hệ thống.", color=Muted, fontSize=12.sp) } } }
                    item { CardPanel { Column(Modifier.padding(16.dp)) { Text("Trò chơi", fontWeight=FontWeight.Bold, fontSize=17.sp); Spacer(Modifier.height(10.dp)); Text("Chưa quét danh sách ứng dụng trong bản native khởi đầu.", color=Muted); Button(onClick={ activity.startActivity(Intent(Settings.ACTION_APPLICATION_SETTINGS)) }, modifier=Modifier.padding(top=8.dp), colors=ButtonDefaults.buttonColors(containerColor=Rose, contentColor=Bg)) { Text("QUẢN LÝ ỨNG DỤNG") } } } }
                }
                "benchmark" -> SimplePage("Benchmark", "Chưa chạy bài kiểm tra hiệu năng thực. Không hiển thị điểm giả lập như kết quả đo thật.", Icons.Default.Speed) { Button(onClick={ message="Chưa tích hợp bộ đo benchmark" }, colors=ButtonDefaults.buttonColors(containerColor=Amber, contentColor=Bg)) { Text("KIỂM TRA TRẠNG THÁI") }; Text(message, color=Muted) }
                else -> LazyColumn(contentPadding=PaddingValues(16.dp), verticalArrangement=Arrangement.spacedBy(14.dp)) {
                    item { CardPanel { Column(Modifier.padding(16.dp)) { Text("Cài đặt", fontSize=22.sp, fontWeight=FontWeight.Bold); SettingRow("Tự tăng tốc", "Chỉ tùy chọn giao diện", autoBoost) { autoBoost=it }; HorizontalDivider(color=Panel2); Text("Ngôn ngữ", color=TextMain, modifier=Modifier.padding(top=12.dp)); Text("Tiếng Việt", color=Muted, fontSize=12.sp); HorizontalDivider(color=Panel2); Text("Shizuku", color=TextMain, modifier=Modifier.padding(top=12.dp)); Text("Chưa tích hợp Binder/ủy quyền trong bản native khởi đầu.", color=Muted, fontSize=12.sp); Button(onClick={ activity.startActivity(Intent("moe.shizuku.manager.MAIN_ACTIVITY")) }, modifier=Modifier.padding(top=8.dp), colors=ButtonDefaults.buttonColors(containerColor=Panel2)) { Text("MỞ SHIZUKU") }; Text("Không có lệnh settings put global/system trong dự án.", color=Green, fontSize=12.sp, modifier=Modifier.padding(top=12.dp)) } } }
                }
            }
        }
    }
}

@Composable private fun CardPanel(content: @Composable ColumnScope.() -> Unit) { Card(colors=CardDefaults.cardColors(containerColor=Panel), shape=RoundedCornerShape(22.dp), border=androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF243246)), content=content) }
@Composable private fun StatCard(title:String, value:String, icon:ImageVector, tint:Color, modifier:Modifier=Modifier) { CardPanel { Column(modifier.padding(14.dp)) { Icon(icon,null,tint=tint); Spacer(Modifier.height(8.dp)); Text(title,color=Muted,fontSize=10.sp,fontWeight=FontWeight.Bold); Text(value,color=TextMain,fontWeight=FontWeight.Bold,fontSize=15.sp,maxLines=2) } } }
@Composable private fun SimplePage(title:String, desc:String, icon:ImageVector, extra:@Composable ColumnScope.()->Unit) { Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement=Arrangement.spacedBy(14.dp)) { CardPanel { Column(Modifier.padding(18.dp)) { Icon(icon,null,tint=Green,modifier=Modifier.size(34.dp)); Spacer(Modifier.height(10.dp)); Text(title,fontSize=24.sp,fontWeight=FontWeight.Black); Spacer(Modifier.height(8.dp)); Text(desc,color=Muted,fontSize=14.sp); Spacer(Modifier.height(18.dp)); extra() } } } }
@Composable private fun SettingRow(title:String, subtitle:String, checked:Boolean, onChange:(Boolean)->Unit) { Row(Modifier.fillMaxWidth().padding(vertical=12.dp), verticalAlignment=Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(title,color=TextMain,fontWeight=FontWeight.SemiBold); Text(subtitle,color=Muted,fontSize=11.sp) }; Switch(checked=checked,onCheckedChange=onChange) } }
