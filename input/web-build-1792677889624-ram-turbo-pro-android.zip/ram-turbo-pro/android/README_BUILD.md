# Build APK (RAM Turbo Pro + Shizuku)

1. Build giao diện web (giữ nguyên UI):
   cd ram-turbo-pro && npm install && npm run build
2. Chép TOÀN BỘ nội dung thư mục dist/ vào android/app/src/main/assets/
   (phải có android/app/src/main/assets/index.html)
3. Mở thư mục android/ bằng Android Studio > Sync Gradle > Build > Build APK(s)
4. Trên điện thoại: cài app Shizuku, khởi động qua Wireless debugging,
   mở RAM Turbo Pro > "Cấp quyền Shizuku" > Cho phép.

Lưu ý: giữ nguyên các lệnh gốc. Lệnh ghi vào /proc, /sys cần root; ở chế độ ADB sẽ báo Permission denied.
cần root. Với Shizuku chế độ ADB (UID 2000) chúng sẽ báo Permission denied;
app hiển thị cảnh báo rõ ràng thay vì báo thành công giả.
