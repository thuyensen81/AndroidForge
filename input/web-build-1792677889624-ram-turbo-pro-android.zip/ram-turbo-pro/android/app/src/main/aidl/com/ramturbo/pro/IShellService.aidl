package com.ramturbo.pro;

interface IShellService {
    void destroy() = 16777114; // id do Shizuku quy định cho destroy
    // Trả về JSON: {"exitCode":0,"output":"...","timedOut":false}
    String exec(String command, int timeoutSec) = 1;
}
