package com.ramturbo.pro

import android.content.ComponentName
import android.content.Context
import android.content.IBinder
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONObject
import rikka.shizuku.Shizuku
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Cầu nối JS <-> Shizuku. Trong web: window.AndroidShizuku.xxx(...)
 * Kết quả bất đồng bộ trả về qua window.__onShellResult / window.__onShizukuState.
 */
class ShizukuBridge(private val context: Context, private val webView: WebView) {

    private val main = Handler(Looper.getMainLooper())
    private val pool = Executors.newSingleThreadExecutor()
    @Volatile private var shell: IShellService? = null
    private var bindLatch: CountDownLatch? = null

    private val permissionListener = Shizuku.OnRequestPermissionResultListener { _, _ -> pushState() }
    private val binderReceived = Shizuku.OnBinderReceivedListener { pushState() }
    private val binderDead = Shizuku.OnBinderDeadListener { shell = null; pushState() }

    private val userServiceArgs = Shizuku.UserServiceArgs(
        ComponentName(context.packageName, ShellService::class.java.name)
    ).daemon(false).processNameSuffix("shell").debuggable(BuildConfig.DEBUG).version(BuildConfig.VERSION_CODE)

    private val connection = object : android.content.ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            shell = IShellService.Stub.asInterface(binder)
            bindLatch?.countDown()
        }
        override fun onServiceDisconnected(name: ComponentName) { shell = null }
    }

    fun register() {
        Shizuku.addRequestPermissionResultListener(permissionListener)
        Shizuku.addBinderReceivedListenerSticky(binderReceived)
        Shizuku.addBinderDeadListener(binderDead)
    }

    fun unregister() {
        Shizuku.removeRequestPermissionResultListener(permissionListener)
        Shizuku.removeBinderReceivedListener(binderReceived)
        Shizuku.removeBinderDeadListener(binderDead)
        if (shell != null) runCatching { Shizuku.unbindUserService(userServiceArgs, connection, true) }
    }

    private fun installed(): Boolean = try {
        context.packageManager.getPackageInfo("moe.shizuku.privileged.api", 0); true
    } catch (e: PackageManager.NameNotFoundException) { false }

    private fun stateJson(): String {
        val o = JSONObject()
        val alive = Shizuku.pingBinder()
        o.put("installed", installed())
        o.put("running", alive)
        o.put("preV11", alive && Shizuku.isPreV11())
        var granted = false
        if (alive && !Shizuku.isPreV11()) {
            granted = Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        }
        o.put("granted", granted)
        o.put("denied", alive && !granted && !Shizuku.isPreV11() && Shizuku.shouldShowRequestPermissionRationale())
        o.put("uid", if (alive) Shizuku.getUid() else -1)       // 2000 = ADB, 0 = root
        o.put("version", if (alive) Shizuku.getVersion() else -1)
        return o.toString()
    }

    private fun js(code: String) = main.post { webView.evaluateJavascript(code, null) }

    private fun pushState() = js("window.__onShizukuState && window.__onShizukuState(${JSONObject.quote(stateJson())})")

    @JavascriptInterface fun getState(): String = stateJson()

    @JavascriptInterface fun requestPermission() {
        main.post {
            try {
                if (!Shizuku.pingBinder() || Shizuku.isPreV11()) { pushState(); return@post }
                if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) { pushState(); return@post }
                Shizuku.requestPermission(1001)
            } catch (_: Throwable) { pushState() }
        }
    }

    /** Mở app Shizuku để người dùng khởi động dịch vụ. */
    @JavascriptInterface fun openShizuku() {
        val i = context.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
        if (i != null) {
            i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(i)
        }
    }

    @JavascriptInterface fun exec(id: String, command: String, timeoutSec: Int) {
        pool.execute {
            val result = try {
                runCommand(command, timeoutSec.coerceIn(1, 120))
            } catch (t: Throwable) {
                JSONObject().put("exitCode", -2).put("output", "Lỗi: ${t.message}").put("timedOut", false).toString()
            }
            js("window.__onShellResult && window.__onShellResult(${JSONObject.quote(id)}, ${JSONObject.quote(result)})")
        }
    }

    private fun runCommand(command: String, timeoutSec: Int): String {
        if (!Shizuku.pingBinder())
            return err("Shizuku chưa chạy. Mở app Shizuku và khởi động (Wireless debugging).")
        if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED)
            return err("Chưa cấp quyền Shizuku cho RAM Turbo Pro.")
        val svc = ensureService() ?: return err("Không kết nối được dịch vụ Shizuku (timeout).")
        return svc.exec(command, timeoutSec)
    }

    private fun ensureService(): IShellService? {
        shell?.let { if (it.asBinder().pingBinder()) return it }
        val latch = CountDownLatch(1)
        bindLatch = latch
        main.post { Shizuku.bindUserService(userServiceArgs, connection) }
        latch.await(8, TimeUnit.SECONDS)
        return shell
    }

    private fun err(msg: String) =
        JSONObject().put("exitCode", -3).put("output", msg).put("timedOut", false).toString()
}
