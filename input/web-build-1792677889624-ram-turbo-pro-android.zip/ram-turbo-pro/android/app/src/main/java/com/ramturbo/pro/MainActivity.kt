package com.ramturbo.pro

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.webkit.WebViewAssetLoader

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var bridge: ShizukuBridge

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this).apply {
            setBackgroundColor(Color.parseColor("#020617"))
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true            // app lưu danh sách game vào localStorage
                allowFileAccess = false
                allowContentAccess = false
                mediaPlaybackRequiresUserGesture = false  // Web Audio SFX
                cacheMode = WebSettings.LOAD_NO_CACHE
            }
        }
        setContentView(webView)

        // Chỉ nạp file trong assets/ qua https ảo, không cho điều hướng ra ngoài
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
                request.url.host != WebViewAssetLoader.DEFAULT_DOMAIN
        }

        bridge = ShizukuBridge(this, webView)
        webView.addJavascriptInterface(bridge, "AndroidShizuku")
        bridge.register()

        webView.loadUrl("https://${WebViewAssetLoader.DEFAULT_DOMAIN}/assets/index.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) webView.goBack() else finish()
            }
        })
    }

    override fun onDestroy() {
        bridge.unregister()
        webView.destroy()
        super.onDestroy()
    }
}
