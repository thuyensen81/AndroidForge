package com.ramturbo.pro

import org.json.JSONObject
import java.util.concurrent.TimeUnit
import kotlin.system.exitProcess

/** Chạy trong tiến trình do Shizuku tạo (UID 2000 = shell ADB, hoặc 0 nếu Shizuku chạy root). */
class ShellService : IShellService.Stub() {

    override fun destroy() {
        exitProcess(0)
    }

    override fun exec(command: String, timeoutSec: Int): String {
        val json = JSONObject()
        try {
            val proc = ProcessBuilder("sh", "-c", command)
                .redirectErrorStream(true)
                .start()
            val out = StringBuilder()
            val reader = Thread {
                proc.inputStream.bufferedReader().use { r ->
                    val buf = CharArray(4096)
                    while (true) {
                        val n = r.read(buf)
                        if (n < 0) break
                        if (out.length < 64_000) out.append(buf, 0, n)
                    }
                }
            }
            reader.start()
            val finished = proc.waitFor(timeoutSec.toLong(), TimeUnit.SECONDS)
            if (!finished) proc.destroyForcibly()
            reader.join(1000)
            json.put("exitCode", if (finished) proc.exitValue() else -1)
            json.put("output", out.toString().trim())
            json.put("timedOut", !finished)
        } catch (t: Throwable) {
            json.put("exitCode", -2)
            json.put("output", "Lỗi thực thi: ${t.message}")
            json.put("timedOut", false)
        }
        return json.toString()
    }
}
