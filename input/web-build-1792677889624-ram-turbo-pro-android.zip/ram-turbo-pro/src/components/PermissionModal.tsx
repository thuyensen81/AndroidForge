import { useState } from 'react';
import { CheckCircle2, Code, Copy, Check, X, Smartphone, Wifi, Terminal } from 'lucide-react';
import { PermissionState } from '../types';
import { isNative, getShizukuState, openShizukuApp, requestShizukuPermission } from '../utils/nativeBridge';
import { soundFX } from '../utils/audio';

interface PermissionModalProps {
  isOpen: boolean;
  onClose: () => void;
  permission: PermissionState;
  onUpdatePermission: (newPerm: PermissionState) => void;
  onAddLog: (cmd: string, output: string, type: 'root' | 'adb') => void;
  language: 'vi' | 'en';
}

export function PermissionModal({
  isOpen,
  onClose,
  permission,
  onUpdatePermission,
  onAddLog,
  language,
}: PermissionModalProps) {
  const [copiedAdb, setCopiedAdb] = useState(false);

  if (!isOpen) return null;

  const handleGrantShizuku = () => {
    if (isNative()) {
      // Xin quyền thật; trạng thái sẽ tự cập nhật qua onShizukuState
      const st = getShizukuState();
      if (st && !st.running) openShizukuApp();
      else requestShizukuPermission();
      onClose();
      return;
    }
    soundFX.playBoostComplete();
    onUpdatePermission({
      mode: 'shizuku',
      shizukuActive: true,
      wirelessDebuggingEnabled: true,
      selinuxEnforcing: true,
    });
    onAddLog('shizuku_starter --version', 'Shizuku Server v13.5.4 (ADB mode: port 5555) connection established.\nPrivileged ADB Shell UID=2000 active.', 'adb');
    onClose();
  };

  const handleRevoke = () => {
    soundFX.playTap();
    onUpdatePermission({
      mode: 'unauthorized',
      shizukuActive: false,
      wirelessDebuggingEnabled: false,
      selinuxEnforcing: true,
    });
    onAddLog('shizuku_starter --stop', 'Shizuku connection terminated. Reverted to standard unprivileged mode.', 'adb');
  };

  const shizukuCmd = 'adb shell sh /sdcard/Android/data/moe.shizuku.privileged.api/start.sh';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div className="w-full max-w-lg bg-slate-950 border border-cyan-500/30 rounded-3xl p-6 shadow-2xl relative overflow-hidden">
        {/* Close Button */}
        <button
          onClick={() => {
            soundFX.playTap();
            onClose();
          }}
          className="absolute top-4 right-4 p-2 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition"
        >
          <X size={18} />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 mb-4">
          <div className="p-3 rounded-2xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/30">
            <Code size={24} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base font-bold text-white">
                {language === 'vi' ? 'Cấp Quyền Dịch Vụ Shizuku' : 'Authorize Shizuku Service'}
              </h3>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 font-bold border border-cyan-500/30">
                ADB KHÔNG ROOT
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              {language === 'vi'
                ? 'Thực thi các lệnh dọn dẹp và tối ưu RAM qua giao thức Gỡ lỗi không dây Shizuku'
                : 'Elevated system RAM optimization commands via Shizuku Wireless Debugging'}
            </p>
          </div>
        </div>

        {/* Active Status Banner */}
        {permission.shizukuActive ? (
          <div className="space-y-4">
            <div className="p-4 rounded-2xl bg-emerald-950/40 border border-emerald-500/40 text-left space-y-3 text-xs">
              <div className="flex items-center justify-between pb-2 border-b border-emerald-500/20">
                <div className="flex items-center gap-2 text-emerald-400 font-bold">
                  <CheckCircle2 size={16} />
                  <span>{language === 'vi' ? 'Dịch vụ Shizuku đang hoạt động' : 'Shizuku Service is Active'}</span>
                </div>
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-mono text-[10px] font-bold">
                  CONNECTED
                </span>
              </div>

              <div className="space-y-1.5 font-mono text-[11px] text-slate-300">
                <div className="flex justify-between">
                  <span className="text-slate-400">Giao thức kết nối:</span>
                  <span className="text-cyan-400 font-bold">Wireless Debugging (Port 5555)</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Phiên bản Server:</span>
                  <span className="text-white">Shizuku API v13.5.4</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Đặc quyền cấp phát:</span>
                  <span className="text-emerald-400 font-bold">shell (UID 2000)</span>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-800 text-[11px] text-slate-400 leading-relaxed">
                {language === 'vi'
                  ? 'Ứng dụng đã có đầy đủ quyền gọi lệnh dọn bộ nhớ Dalvik/ART, nén zRAM swap và đóng băng ứng dụng chạy ngầm an toàn.'
                  : 'App has full privileges to invoke Dalvik/ART memory trimming, zRAM compaction, and freeze rogue background apps.'}
              </div>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={handleRevoke}
                className="flex-1 py-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-rose-400 hover:text-rose-300 font-bold text-xs transition"
              >
                {language === 'vi' ? 'NGẮT KẾT NỐI SHIZUKU' : 'DISCONNECT SHIZUKU'}
              </button>

              <button
                onClick={() => {
                  soundFX.playTap();
                  onClose();
                }}
                className="flex-1 py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-teal-500 hover:from-cyan-400 hover:to-teal-400 text-slate-950 font-black text-xs tracking-wider uppercase shadow-lg shadow-cyan-500/20 active:scale-95 transition"
              >
                {language === 'vi' ? 'HOÀN TẤT' : 'DONE'}
              </button>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 text-left space-y-3.5 text-xs">
              <div className="flex items-center gap-2 text-cyan-400 font-bold">
                <Smartphone size={16} />
                <span>
                  {language === 'vi'
                    ? '3 Bước Kích Hoạt Shizuku (Không Cần Root Máy)'
                    : '3 Steps to Activate Shizuku (Rootless ADB)'}
                </span>
              </div>

              {/* Step 1 */}
              <div className="flex items-start gap-2.5 text-[11px] text-slate-300">
                <span className="w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-400 flex items-center justify-center font-mono font-bold shrink-0 mt-0.5">
                  1
                </span>
                <p className="leading-relaxed">
                  {language === 'vi'
                    ? 'Mở "Tùy chọn cho nhà phát triển" (Developer Options) trên điện thoại và bật "Gỡ lỗi không dây (Wireless Debugging)".'
                    : 'Open Developer Options on your phone and enable "Wireless Debugging".'}
                </p>
              </div>

              {/* Step 2 */}
              <div className="flex items-start gap-2.5 text-[11px] text-slate-300">
                <span className="w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-400 flex items-center justify-center font-mono font-bold shrink-0 mt-0.5">
                  2
                </span>
                <div className="flex-1 min-w-0">
                  <p className="leading-relaxed mb-2">
                    {language === 'vi'
                      ? 'Khởi động ứng dụng Shizuku trên máy, hoặc chạy lệnh ADB Shell này qua máy tính/Termux:'
                      : 'Launch Shizuku app, or execute this ADB shell command via PC/Termux:'}
                  </p>
                  <div className="p-2 rounded-xl bg-black border border-slate-800 font-mono text-[10px] text-cyan-300 flex items-center justify-between gap-2">
                    <span className="truncate select-all">{shizukuCmd}</span>
                    <button
                      onClick={() => {
                        soundFX.playTap();
                        navigator.clipboard.writeText(shizukuCmd);
                        setCopiedAdb(true);
                        setTimeout(() => setCopiedAdb(false), 2000);
                      }}
                      className="px-2 py-0.5 rounded bg-slate-800 text-[10px] text-cyan-400 hover:text-white flex items-center gap-1 shrink-0"
                    >
                      {copiedAdb ? <Check size={11} className="text-emerald-400" /> : <Copy size={11} />}
                      <span>{copiedAdb ? 'Copied' : 'Copy'}</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Step 3 */}
              <div className="flex items-start gap-2.5 text-[11px] text-slate-300">
                <span className="w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-400 flex items-center justify-center font-mono font-bold shrink-0 mt-0.5">
                  3
                </span>
                <p className="leading-relaxed">
                  {language === 'vi'
                    ? 'Bấm nút "KẾT NỐI VÀ CẤP QUYỀN SHIZUKU" bên dưới để hoàn tất cấp quyền.'
                    : 'Click "CONNECT & AUTHORIZE SHIZUKU" below to complete permission setup.'}
                </p>
              </div>
            </div>

            <button
              onClick={handleGrantShizuku}
              className="w-full py-3.5 rounded-xl bg-gradient-to-r from-cyan-500 via-teal-500 to-emerald-500 hover:from-cyan-400 hover:to-emerald-400 text-slate-950 font-black text-xs tracking-wider uppercase shadow-lg shadow-cyan-500/20 active:scale-95 transition flex items-center justify-center gap-2"
            >
              <Code size={16} />
              <span>
                {language === 'vi'
                  ? 'KẾT NỐI VÀ CẤP QUYỀN SHIZUKU'
                  : 'CONNECT & AUTHORIZE SHIZUKU'}
              </span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
