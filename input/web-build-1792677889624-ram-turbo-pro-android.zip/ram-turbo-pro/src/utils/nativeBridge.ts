// Cầu nối tới Android (Shizuku). Khi chạy trên trình duyệt (npm run dev) thì isNative() = false
// và app vẫn dùng dữ liệu mô phỏng như cũ.

export interface ShizukuState {
  installed: boolean;
  running: boolean;
  granted: boolean;
  denied: boolean;
  preV11: boolean;
  uid: number; // 2000 = ADB shell, 0 = root, -1 = chưa kết nối
  version: number;
}

export interface ShellResult {
  exitCode: number;
  output: string;
  timedOut: boolean;
}

interface AndroidShizukuApi {
  getState(): string;
  requestPermission(): void;
  openShizuku(): void;
  exec(id: string, command: string, timeoutSec: number): void;
}

declare global {
  interface Window {
    AndroidShizuku?: AndroidShizukuApi;
    __onShellResult?: (id: string, json: string) => void;
    __onShizukuState?: (json: string) => void;
  }
}

export const isNative = (): boolean =>
  typeof window !== 'undefined' && !!window.AndroidShizuku;

const pending = new Map<string, (r: ShellResult) => void>();
const stateListeners = new Set<(s: ShizukuState) => void>();

if (typeof window !== 'undefined') {
  window.__onShellResult = (id, json) => {
    const cb = pending.get(id);
    if (!cb) return;
    pending.delete(id);
    try {
      cb(JSON.parse(json) as ShellResult);
    } catch {
      cb({ exitCode: -2, output: 'Không đọc được kết quả từ Android', timedOut: false });
    }
  };
  window.__onShizukuState = (json) => {
    try {
      const s = JSON.parse(json) as ShizukuState;
      stateListeners.forEach((l) => l(s));
    } catch {
      /* bỏ qua */
    }
  };
}

export function getShizukuState(): ShizukuState | null {
  if (!isNative()) return null;
  try {
    return JSON.parse(window.AndroidShizuku!.getState()) as ShizukuState;
  } catch {
    return null;
  }
}

export function onShizukuState(cb: (s: ShizukuState) => void): () => void {
  stateListeners.add(cb);
  return () => stateListeners.delete(cb);
}

export function requestShizukuPermission(): void {
  window.AndroidShizuku?.requestPermission();
}

export function openShizukuApp(): void {
  window.AndroidShizuku?.openShizuku();
}

/** Chạy 1 lệnh shell qua Shizuku. Trả về null nếu không chạy trong app Android. */
export function runShell(command: string, timeoutSec = 30): Promise<ShellResult | null> {
  if (!isNative()) return Promise.resolve(null);
  return new Promise((resolve) => {
    const id = `${Date.now()}-${Math.random().toString(36).slice(2)}`;
    pending.set(id, resolve);
    window.AndroidShizuku!.exec(id, command, timeoutSec);
    setTimeout(() => {
      if (pending.delete(id)) {
        resolve({ exitCode: -1, output: 'Hết thời gian chờ phản hồi', timedOut: true });
      }
    }, (timeoutSec + 10) * 1000);
  });
}

/** Định dạng kết quả để hiện trong console, kèm giải thích khi thiếu quyền root. */
export function formatShellResult(r: ShellResult): string {
  const lines: string[] = [];
  if (r.output) lines.push(r.output);
  if (/permission denied|operation not permitted|read-only file system/i.test(r.output)) {
    lines.push('⚠ Lệnh này cần quyền root. Shizuku ở chế độ ADB (UID 2000) không ghi được vào /proc, /sys.');
  }
  lines.push(r.timedOut ? 'Quá thời gian chờ (timeout)' : `Exit code: ${r.exitCode}`);
  return lines.join('\n');
}
