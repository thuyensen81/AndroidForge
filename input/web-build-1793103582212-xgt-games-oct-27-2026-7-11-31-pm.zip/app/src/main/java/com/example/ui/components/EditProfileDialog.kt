package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.local.GameProfileEntity
import com.example.model.ColorFilterMode
import com.example.ui.animation.bouncyClickable
import com.example.ui.theme.XgtAmberBoost
import com.example.ui.theme.XgtDarkSurface
import com.example.ui.theme.XgtMatrixGreen
import com.example.ui.theme.XgtNeonCyan
import com.example.ui.theme.XgtNeonMagenta
import com.example.ui.theme.XgtSurfaceHighlight
import com.example.ui.theme.XgtTextMuted
import com.example.ui.theme.XgtTextPrimary
import com.example.ui.theme.XgtTextSecondary
import java.util.Locale

@Composable
fun EditProfileDialog(
  profile: GameProfileEntity,
  onDismiss: () -> Unit,
  onSave: (GameProfileEntity) -> Unit,
  onApplyAndSave: (GameProfileEntity) -> Unit
) {
  var gameTitle by remember { mutableStateOf(profile.gameTitle) }
  var genre by remember { mutableStateOf(profile.genre) }

  // Performance settings
  var targetRefreshRate by remember { mutableIntStateOf(profile.targetRefreshRate) }
  var memcEnabled by remember { mutableStateOf(profile.memcEnabled) }
  var smoothingMultiplier by remember { mutableFloatStateOf(profile.smoothingMultiplier) }
  var adaptiveFramePacing by remember { mutableStateOf(profile.adaptiveFramePacing) }
  var dynamicVsync by remember { mutableStateOf(profile.dynamicVsync) }

  // Graphics settings
  var resolutionScale by remember { mutableFloatStateOf(profile.resolutionScale) }
  var neonBloom by remember { mutableStateOf(profile.neonBloom) }
  var bloomIntensity by remember { mutableFloatStateOf(profile.bloomIntensity) }
  var hdrContrast by remember { mutableStateOf(profile.hdrContrast) }
  var motionBlur by remember { mutableStateOf(profile.motionBlur) }
  var motionBlurIntensity by remember { mutableFloatStateOf(profile.motionBlurIntensity) }
  var antiAliasing by remember { mutableStateOf(profile.antiAliasing) }
  var particleDensity by remember { mutableFloatStateOf(profile.particleDensity) }
  var colorFilterMode by remember { mutableStateOf(profile.colorFilterMode) }

  // Touch settings
  var touchSamplingRateHz by remember { mutableIntStateOf(profile.touchSamplingRateHz) }
  var touchSensitivity by remember { mutableFloatStateOf(profile.touchSensitivity) }
  var deadzonePercent by remember { mutableFloatStateOf(profile.deadzonePercent) }
  var instantTouchDispatch by remember { mutableStateOf(profile.instantTouchDispatch) }
  var edgeFilterEnabled by remember { mutableStateOf(profile.edgeFilterEnabled) }
  var hapticFeedbackMode by remember { mutableStateOf(profile.hapticFeedbackMode) }
  var hapticIntensity by remember { mutableFloatStateOf(profile.hapticIntensity) }

  var activeCategoryTab by remember { mutableIntStateOf(0) } // 0: Hiệu năng, 1: Đồ họa, 2: Cảm ứng

  val scrollState = rememberScrollState()

  fun buildUpdatedEntity(): GameProfileEntity {
    return profile.copy(
      gameTitle = gameTitle,
      genre = genre,
      targetRefreshRate = targetRefreshRate,
      memcEnabled = memcEnabled,
      smoothingMultiplier = smoothingMultiplier,
      adaptiveFramePacing = adaptiveFramePacing,
      dynamicVsync = dynamicVsync,
      resolutionScale = resolutionScale,
      neonBloom = neonBloom,
      bloomIntensity = bloomIntensity,
      hdrContrast = hdrContrast,
      motionBlur = motionBlur,
      motionBlurIntensity = motionBlurIntensity,
      antiAliasing = antiAliasing,
      particleDensity = particleDensity,
      colorFilterMode = colorFilterMode,
      touchSamplingRateHz = touchSamplingRateHz,
      touchSensitivity = touchSensitivity,
      deadzonePercent = deadzonePercent,
      instantTouchDispatch = instantTouchDispatch,
      edgeFilterEnabled = edgeFilterEnabled,
      hapticFeedbackMode = hapticFeedbackMode,
      hapticIntensity = hapticIntensity,
      lastUpdatedTimestamp = System.currentTimeMillis()
    )
  }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      modifier = Modifier
        .fillMaxWidth(0.95f)
        .fillMaxHeight(0.92f)
        .clip(RoundedCornerShape(26.dp))
        .border(
          width = 1.2.dp,
          brush = Brush.linearGradient(
            listOf(XgtNeonCyan.copy(alpha = 0.6f), Color(0x33FFFFFF), XgtNeonMagenta.copy(alpha = 0.5f))
          ),
          shape = RoundedCornerShape(26.dp)
        ),
      color = Color(0xFF0C101A)
    ) {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .padding(18.dp)
      ) {
        // Top Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text(
              text = "TÙY CHỈNH HỒ SƠ GAME",
              color = XgtNeonCyan,
              fontSize = 16.sp,
              fontWeight = FontWeight.Black,
              letterSpacing = 1.sp
            )
            Text(
              text = profile.packageName,
              color = XgtTextMuted,
              fontSize = 10.sp,
              fontFamily = FontFamily.Monospace
            )
          }

          IconButton(
            onClick = onDismiss,
            modifier = Modifier.size(32.dp).testTag("close_edit_dialog_btn")
          ) {
            Icon(Icons.Default.Close, contentDescription = "Close", tint = XgtTextSecondary)
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Title and Genre fields
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          OutlinedTextField(
            value = gameTitle,
            onValueChange = { gameTitle = it },
            label = { Text("Tên game", fontSize = 11.sp) },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = XgtNeonCyan,
              unfocusedBorderColor = Color(0xFF222E44),
              focusedTextColor = XgtTextPrimary,
              unfocusedTextColor = XgtTextPrimary
            ),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.weight(1.3f).testTag("edit_profile_name")
          )

          OutlinedTextField(
            value = genre,
            onValueChange = { genre = it },
            label = { Text("Thể loại", fontSize = 11.sp) },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
              focusedBorderColor = XgtNeonCyan,
              unfocusedBorderColor = Color(0xFF222E44),
              focusedTextColor = XgtTextPrimary,
              unfocusedTextColor = XgtTextPrimary
            ),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.weight(1f).testTag("edit_profile_genre")
          )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Category Tab Switcher
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          listOf(
            Triple(0, "Hiệu năng", Icons.Default.Speed),
            Triple(1, "Đồ họa", Icons.Default.Tune),
            Triple(2, "Cảm ứng", Icons.Default.TouchApp)
          ).forEach { (idx, title, icon) ->
            val isSelected = activeCategoryTab == idx
            val activeColor = when (idx) {
              0 -> XgtMatrixGreen
              1 -> XgtNeonCyan
              else -> XgtNeonMagenta
            }

            Box(
              modifier = Modifier
                .weight(1f)
                .background(
                  if (isSelected) activeColor.copy(alpha = 0.18f) else Color(0xFF131A2A),
                  RoundedCornerShape(12.dp)
                )
                .border(
                  width = if (isSelected) 1.2.dp else 1.dp,
                  color = if (isSelected) activeColor else Color(0xFF1E283D),
                  shape = RoundedCornerShape(12.dp)
                )
                .bouncyClickable { activeCategoryTab = idx }
                .padding(vertical = 10.dp),
              contentAlignment = Alignment.Center
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                  imageVector = icon,
                  contentDescription = null,
                  tint = if (isSelected) activeColor else XgtTextMuted,
                  modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = title,
                  color = if (isSelected) activeColor else XgtTextSecondary,
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold
                )
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Scrollable Config Parameters Form
        Column(
          modifier = Modifier
            .weight(1f)
            .verticalScroll(scrollState),
          verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
          when (activeCategoryTab) {
            0 -> {
              // --- HIỆU NĂNG & KHUNG HÌNH (PERFORMANCE) ---
              Column(
                modifier = Modifier
                  .fillMaxWidth()
                  .background(XgtDarkSurface, RoundedCornerShape(16.dp))
                  .border(1.dp, Color(0xFF1E283D), RoundedCornerShape(16.dp))
                  .padding(14.dp)
              ) {
                Text("TẦN SỐ QUÉT MỤC TIÊU (REFRESH RATE)", color = XgtTextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Black)
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                  listOf(60, 90, 120, 144).forEach { hz ->
                    val isSelected = targetRefreshRate == hz
                    Box(
                      modifier = Modifier
                        .weight(1f)
                        .background(
                          if (isSelected) XgtMatrixGreen.copy(alpha = 0.2f) else Color(0xFF0F1522),
                          RoundedCornerShape(10.dp)
                        )
                        .border(
                          1.dp,
                          if (isSelected) XgtMatrixGreen else Color(0xFF1E283D),
                          RoundedCornerShape(10.dp)
                        )
                        .bouncyClickable { targetRefreshRate = hz }
                        .padding(vertical = 8.dp),
                      contentAlignment = Alignment.Center
                    ) {
                      Text(
                        text = "${hz}Hz",
                        color = if (isSelected) XgtMatrixGreen else XgtTextSecondary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                      )
                    }
                  }
                }
              }

              CyberSlider(
                label = "Hệ số làm mượt chuyển động (MEMC LERP)",
                valueText = String.format(Locale.US, "%.2f", smoothingMultiplier),
                value = smoothingMultiplier,
                onValueChange = { smoothingMultiplier = it },
                valueRange = 0.2f..0.95f,
                accentColor = XgtMatrixGreen
              )

              CyberSwitchCard(
                title = "Nội suy khung hình MEMC 2X",
                subtitle = "Tăng gấp đôi số khung hình chuyển động bằng thuật toán AI",
                checked = memcEnabled,
                onCheckedChange = { memcEnabled = it },
                icon = Icons.Default.Bolt,
                accentColor = XgtMatrixGreen
              )

              CyberSwitchCard(
                title = "Điều phối khung hình thích ứng (Frame Pacing)",
                subtitle = "Triệt tiêu hiện tượng giật micro-stutter khi giao tranh",
                checked = adaptiveFramePacing,
                onCheckedChange = { adaptiveFramePacing = it },
                icon = Icons.Default.Speed,
                accentColor = XgtNeonCyan
              )

              CyberSwitchCard(
                title = "Dynamic VSync Không Độ Trễ",
                subtitle = "Chống xé hình mà không tăng input lag",
                checked = dynamicVsync,
                onCheckedChange = { dynamicVsync = it },
                icon = Icons.Default.Tune,
                accentColor = XgtAmberBoost
              )
            }

            1 -> {
              // --- ĐỒ HỌA & SHADERS (GRAPHICS) ---
              Column(
                modifier = Modifier
                  .fillMaxWidth()
                  .background(XgtDarkSurface, RoundedCornerShape(16.dp))
                  .border(1.dp, Color(0xFF1E283D), RoundedCornerShape(16.dp))
                  .padding(14.dp)
              ) {
                Text("ĐỘ PHÂN GIẢI HIỂN THỊ (RESOLUTION SCALE)", color = XgtTextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Black)
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                  listOf(0.75f to "720p", 1.0f to "1080p", 1.25f to "2K", 1.5f to "4K").forEach { (sc, label) ->
                    val isSelected = resolutionScale == sc
                    Box(
                      modifier = Modifier
                        .weight(1f)
                        .background(
                          if (isSelected) XgtNeonCyan.copy(alpha = 0.2f) else Color(0xFF0F1522),
                          RoundedCornerShape(10.dp)
                        )
                        .border(
                          1.dp,
                          if (isSelected) XgtNeonCyan else Color(0xFF1E283D),
                          RoundedCornerShape(10.dp)
                        )
                        .bouncyClickable { resolutionScale = sc }
                        .padding(vertical = 8.dp),
                      contentAlignment = Alignment.Center
                    ) {
                      Text(
                        text = label,
                        color = if (isSelected) XgtNeonCyan else XgtTextSecondary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                      )
                    }
                  }
                }
              }

              CyberSlider(
                label = "Cường độ phát sáng Neon Bloom",
                valueText = "${(bloomIntensity * 100).toInt()}%",
                value = bloomIntensity,
                onValueChange = { bloomIntensity = it },
                valueRange = 0.0f..1.0f,
                accentColor = XgtNeonCyan
              )

              CyberSlider(
                label = "Mật độ hiệu ứng hạt (Particle FX)",
                valueText = "${(particleDensity * 100).toInt()}%",
                value = particleDensity,
                onValueChange = { particleDensity = it },
                valueRange = 0.5f..2.0f,
                accentColor = XgtMatrixGreen
              )

              CyberSlider(
                label = "Độ mờ chuyển động (Motion Blur)",
                valueText = if (motionBlur) "${(motionBlurIntensity * 100).toInt()}%" else "Tắt",
                value = motionBlurIntensity,
                onValueChange = { motionBlurIntensity = it },
                valueRange = 0.0f..1.0f,
                accentColor = XgtNeonMagenta
              )

              CyberSwitchCard(
                title = "HDR Độ tương phản động",
                subtitle = "Tăng độ sâu chi tiết bóng tối và vùng sáng",
                checked = hdrContrast,
                onCheckedChange = { hdrContrast = it },
                accentColor = XgtAmberBoost
              )

              CyberSwitchCard(
                title = "Khử răng cưa FXAA",
                subtitle = "Làm mịn các cạnh viền polygon mà không hao pin",
                checked = antiAliasing,
                onCheckedChange = { antiAliasing = it },
                accentColor = XgtNeonCyan
              )
            }

            2 -> {
              // --- CẢM ỨNG & ĐỘ TRỄ (TOUCH & LATENCY) ---
              Column(
                modifier = Modifier
                  .fillMaxWidth()
                  .background(XgtDarkSurface, RoundedCornerShape(16.dp))
                  .border(1.dp, Color(0xFF1E283D), RoundedCornerShape(16.dp))
                  .padding(14.dp)
              ) {
                Text("TẦN SỐ LẤY MẪU CẢM ỨNG (TOUCH POLLING)", color = XgtTextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Black)
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                  listOf(120, 240, 360, 480).forEach { rate ->
                    val isSelected = touchSamplingRateHz == rate
                    Box(
                      modifier = Modifier
                        .weight(1f)
                        .background(
                          if (isSelected) XgtNeonMagenta.copy(alpha = 0.2f) else Color(0xFF0F1522),
                          RoundedCornerShape(10.dp)
                        )
                        .border(
                          1.dp,
                          if (isSelected) XgtNeonMagenta else Color(0xFF1E283D),
                          RoundedCornerShape(10.dp)
                        )
                        .bouncyClickable { touchSamplingRateHz = rate }
                        .padding(vertical = 8.dp),
                      contentAlignment = Alignment.Center
                    ) {
                      Text(
                        text = "${rate}Hz",
                        color = if (isSelected) XgtNeonMagenta else XgtTextSecondary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                      )
                    }
                  }
                }
              }

              CyberSlider(
                label = "Hệ số nhạy cảm ứng (Touch Sensitivity)",
                valueText = String.format(Locale.US, "%.1fx", touchSensitivity),
                value = touchSensitivity,
                onValueChange = { touchSensitivity = it },
                valueRange = 0.5f..3.0f,
                accentColor = XgtNeonCyan
              )

              CyberSlider(
                label = "Bộ lọc vùng chết (Deadzone Filter)",
                valueText = String.format(Locale.US, "%.1f%%", deadzonePercent),
                value = deadzonePercent,
                onValueChange = { deadzonePercent = it },
                valueRange = 0.0f..15.0f,
                accentColor = XgtAmberBoost
              )

              CyberSlider(
                label = "Cường độ rung xúc giác",
                valueText = "${(hapticIntensity * 100).toInt()}%",
                value = hapticIntensity,
                onValueChange = { hapticIntensity = it },
                valueRange = 0.1f..1.0f,
                accentColor = XgtNeonMagenta
              )

              CyberSwitchCard(
                title = "Điều phối cảm ứng tức thì (Instant Dispatch)",
                subtitle = "Bỏ qua hàng đợi hệ thống để đạt độ trễ cảm ứng 0ms",
                checked = instantTouchDispatch,
                onCheckedChange = { instantTouchDispatch = it },
                accentColor = XgtNeonCyan
              )

              CyberSwitchCard(
                title = "Chống chạm nhầm mép màn hình (Palm Rejection)",
                subtitle = "Loại bỏ thao tác chạm vô ý khi cầm nắm điện thoại",
                checked = edgeFilterEnabled,
                onCheckedChange = { edgeFilterEnabled = it },
                accentColor = XgtMatrixGreen
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Action Buttons Footer
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Button(
            onClick = onDismiss,
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1B2232)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.weight(1f).bouncyClickable { onDismiss() }
          ) {
            Text("ĐÓNG", color = XgtTextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
          }

          Button(
            onClick = {
              val updated = buildUpdatedEntity()
              onSave(updated)
            },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E283D)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.weight(1.3f).bouncyClickable { onSave(buildUpdatedEntity()) }.testTag("save_profile_changes_btn")
          ) {
            Text("LƯU CẤU HÌNH", color = XgtNeonCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
          }

          Button(
            onClick = {
              val updated = buildUpdatedEntity()
              onApplyAndSave(updated)
            },
            colors = ButtonDefaults.buttonColors(containerColor = XgtNeonCyan),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.weight(1.4f).bouncyClickable { onApplyAndSave(buildUpdatedEntity()) }.testTag("apply_and_save_profile_btn")
          ) {
            Text("ÁP DỤNG NGAY", color = Color(0xFF090D14), fontSize = 12.sp, fontWeight = FontWeight.Black)
          }
        }
      }
    }
  }
}
