package com.example.engine

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

class HapticFeedbackHelper(private val context: Context) {

  private val vibrator: Vibrator? = try {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
      val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
      vibratorManager?.defaultVibrator
    } else {
      @Suppress("DEPRECATION")
      context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }
  } catch (_: Exception) {
    null
  }

  fun triggerTactile(mode: String, intensity: Float = 0.8f) {
    if (vibrator == null || !vibrator.hasVibrator() || mode == "Off") return

    try {
      val scaledIntensity = (intensity.coerceIn(0.1f, 1.0f) * 255).toInt().coerceIn(1, 255)
      val durationMs: Long = when (mode) {
        "Subtle Click" -> 15L
        "Crisp Gaming" -> 30L
        "Heavy Rumble" -> 60L
        else -> 25L
      }

      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        val effect = VibrationEffect.createOneShot(durationMs, scaledIntensity)
        vibrator.vibrate(effect)
      } else {
        @Suppress("DEPRECATION")
        vibrator.vibrate(durationMs)
      }
    } catch (_: Exception) {
      // Graceful fallback
    }
  }

  fun triggerNitroBoost() {
    if (vibrator == null || !vibrator.hasVibrator()) return
    try {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        val timings = longArrayOf(0, 40, 20, 60, 20, 80)
        val amplitudes = intArrayOf(0, 150, 0, 200, 0, 255)
        val effect = VibrationEffect.createWaveform(timings, amplitudes, -1)
        vibrator.vibrate(effect)
      } else {
        @Suppress("DEPRECATION")
        vibrator.vibrate(120)
      }
    } catch (_: Exception) {
      // Fallback
    }
  }
}
