package com.example.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PanTool
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.TouchCalibrationState
import com.example.engine.TouchPointInfo
import com.example.model.TouchSettings
import com.example.ui.animation.bouncyClickable
import com.example.ui.components.CyberSlider
import com.example.ui.components.CyberSwitchCard
import com.example.ui.theme.XgtAmberBoost
import com.example.ui.theme.XgtDarkSurface
import com.example.ui.theme.XgtMatrixGreen
import com.example.ui.theme.XgtNeonCyan
import com.example.ui.theme.XgtNeonMagenta
import com.example.ui.theme.XgtSurfaceHighlight
import com.example.ui.theme.XgtTextMuted
import com.example.ui.theme.XgtTextPrimary
import com.example.ui.theme.XgtTextSecondary
import java.util.Locale

@Composable
fun TouchScreen(
  settings: TouchSettings,
  calibrationState: TouchCalibrationState,
  onSettingsChanged: (TouchSettings) -> Unit,
  onTouchCalibration: (List<TouchPointInfo>) -> Unit,
  onResetCalibration: () -> Unit
) {
  val samplingRates = listOf(120, 240, 360, 480)
  val hapticModes = listOf("Off", "Subtle Click", "Crisp Gaming", "Heavy Rumble")

  val infiniteTransition = rememberInfiniteTransition(label = "touch_wave")
  val waveRadius by infiniteTransition.animateFloat(
    initialValue = 15f,
    targetValue = 60f,
    animationSpec = infiniteRepeatable(
      animation = tween(1200, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Restart
    ),
    label = "wave_radius"
  )

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp),
    contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp)
  ) {
    item {
      Column {
        Text(
          text = "TOUCH & RESPONSIVENESS",
          color = XgtNeonCyan,
          fontSize = 18.sp,
          fontWeight = FontWeight.Black,
          letterSpacing = 1.sp
        )
        Text(
          text = "Tune input polling, deadzones, low-latency dispatch & haptics",
          color = XgtTextSecondary,
          fontSize = 11.sp
        )
      }
    }

    // Touch Sampling Rate Selector with spring animations
    item {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .background(XgtDarkSurface, RoundedCornerShape(20.dp))
          .border(
            width = 1.dp,
            brush = Brush.linearGradient(listOf(Color(0x22FFFFFF), Color(0xFF1E283D), XgtNeonCyan.copy(alpha = 0.2f))),
            shape = RoundedCornerShape(20.dp)
          )
          .padding(16.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text("POLLING RATE (HARDWARE)", color = XgtTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Black)
          val calculatedLatency = 1000f / settings.touchSamplingRateHz
          Text(
            text = String.format(Locale.US, "%.1f ms Delay", calculatedLatency),
            color = XgtMatrixGreen,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
          )
        }

        Spacer(modifier = Modifier.height(14.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          samplingRates.forEach { rate ->
            val isSelected = settings.touchSamplingRateHz == rate
            val scale by animateFloatAsState(
              targetValue = if (isSelected) 1.05f else 1.0f,
              animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
              label = "rate_scale"
            )

            Box(
              modifier = Modifier
                .weight(1f)
                .scale(scale)
                .background(
                  brush = Brush.verticalGradient(
                    listOf(
                      if (isSelected) XgtNeonCyan.copy(alpha = 0.18f) else Color(0xFF0F1522),
                      if (isSelected) XgtNeonCyan.copy(alpha = 0.05f) else Color(0xFF0B101A)
                    )
                  ),
                  shape = RoundedCornerShape(12.dp)
                )
                .border(
                  width = if (isSelected) 1.5.dp else 1.dp,
                  color = if (isSelected) XgtNeonCyan else Color(0xFF1E283D),
                  shape = RoundedCornerShape(12.dp)
                )
                .bouncyClickable { onSettingsChanged(settings.copy(touchSamplingRateHz = rate)) }
                .padding(vertical = 12.dp),
              contentAlignment = Alignment.Center
            ) {
              Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                  text = "${rate}Hz",
                  color = if (isSelected) XgtNeonCyan else XgtTextSecondary,
                  fontSize = 13.sp,
                  fontWeight = FontWeight.Black,
                  fontFamily = FontFamily.Monospace
                )
                Text(
                  text = if (rate >= 360) "Ultra" else "Standard",
                  color = if (isSelected) XgtMatrixGreen else XgtTextMuted,
                  fontSize = 9.sp,
                  fontWeight = FontWeight.Bold
                )
              }
            }
          }
        }
      }
    }

    // Interactive Touch Calibration Sandbox Pad with dynamic animated ripples
    item {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .background(XgtDarkSurface, RoundedCornerShape(20.dp))
          .border(
            width = 1.dp,
            brush = Brush.linearGradient(listOf(XgtNeonMagenta.copy(alpha = 0.5f), Color(0x22FFFFFF), XgtNeonCyan.copy(alpha = 0.3f))),
            shape = RoundedCornerShape(20.dp)
          )
          .padding(16.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text(
              text = "TOUCH SENSITIVITY CALIBRATION LAB",
              color = XgtNeonMagenta,
              fontSize = 12.sp,
              fontWeight = FontWeight.Black,
              letterSpacing = 0.8.sp
            )
            Text(
              text = "Touch, drag & test latency & tactile feedback",
              color = XgtTextMuted,
              fontSize = 10.sp
            )
          }

          Button(
            onClick = onResetCalibration,
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E283D)),
            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.testTag("reset_touch_lab_btn")
          ) {
            Icon(Icons.Default.Refresh, contentDescription = null, tint = XgtTextSecondary, modifier = Modifier.size(14.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Reset", color = XgtTextSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Interactive Canvas Pad with Ripples
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(170.dp)
            .background(Color(0xFF070B14), RoundedCornerShape(16.dp))
            .border(1.dp, Color(0xFF1C263B), RoundedCornerShape(16.dp))
            .clip(RoundedCornerShape(16.dp))
            .pointerInput(settings) {
              detectDragGestures(
                onDragStart = { offset ->
                  val pt = TouchPointInfo(id = 1, position = offset)
                  onTouchCalibration(listOf(pt))
                },
                onDrag = { change, _ ->
                  change.consume()
                  val pt = TouchPointInfo(id = 1, position = change.position)
                  onTouchCalibration(listOf(pt))
                }
              )
            }
            .testTag("touch_calibration_canvas_pad")
        ) {
          Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // Center Target Crosshair Grid
            drawLine(
              color = Color(0x2200E5FF),
              start = Offset(w / 2f, 0f),
              end = Offset(w / 2f, h),
              strokeWidth = 1.dp.toPx()
            )
            drawLine(
              color = Color(0x2200E5FF),
              start = Offset(0f, h / 2f),
              end = Offset(w, h / 2f),
              strokeWidth = 1.dp.toPx()
            )

            // Touch point ripple wave animation
            if (calibrationState.lastTouchPosition != Offset.Zero) {
              val pos = calibrationState.lastTouchPosition

              // Expanding shockwave ring
              drawCircle(
                color = XgtNeonCyan.copy(alpha = (1f - (waveRadius / 60f)).coerceIn(0f, 1f)),
                radius = waveRadius.dp.toPx(),
                center = pos,
                style = Stroke(width = 2.dp.toPx())
              )

              // Soft aura
              drawCircle(
                color = XgtNeonMagenta.copy(alpha = 0.35f),
                radius = 28.dp.toPx(),
                center = pos
              )
              // Core dot
              drawCircle(
                color = XgtNeonCyan,
                radius = 8.dp.toPx(),
                center = pos
              )
            }
          }

          // Live Touch Telemetry Overlay
          Row(
            modifier = Modifier
              .align(Alignment.BottomCenter)
              .fillMaxWidth()
              .background(Color(0xE6080C14))
              .padding(horizontal = 14.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(
              text = String.format(Locale.US, "LATENCY: %.1fms", calibrationState.simulatedLatencyMs),
              color = XgtMatrixGreen,
              fontSize = 11.sp,
              fontWeight = FontWeight.Black,
              fontFamily = FontFamily.Monospace
            )
            Text(
              text = String.format(Locale.US, "VELOCITY: %.1f px/ms", calibrationState.gestureVelocityPxPerMs),
              color = XgtNeonCyan,
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              fontFamily = FontFamily.Monospace
            )
            Text(
              text = "TOUCHES: ${calibrationState.touchesDetected}",
              color = XgtTextPrimary,
              fontSize = 11.sp,
              fontFamily = FontFamily.Monospace
            )
          }
        }
      }
    }

    // Touch Sensitivity & Deadzone Sliders
    item {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .background(XgtDarkSurface, RoundedCornerShape(20.dp))
          .border(1.dp, Color(0xFF1E283D), RoundedCornerShape(20.dp))
          .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
      ) {
        Text("SENSITIVITY & DEADZONE TUNING", color = XgtTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Black)

        CyberSlider(
          label = "Touch Sensitivity Multiplier",
          valueText = String.format(Locale.US, "%.1fx", settings.touchSensitivity),
          value = settings.touchSensitivity,
          onValueChange = { onSettingsChanged(settings.copy(touchSensitivity = it)) },
          valueRange = 0.5f..3.0f,
          accentColor = XgtNeonCyan
        )

        CyberSlider(
          label = "Deadzone Filter Radius",
          valueText = String.format(Locale.US, "%.1f%%", settings.deadzonePercent),
          value = settings.deadzonePercent,
          onValueChange = { onSettingsChanged(settings.copy(deadzonePercent = it)) },
          valueRange = 0.0f..15.0f,
          accentColor = XgtAmberBoost
        )

        CyberSlider(
          label = "Haptic Vibration Intensity",
          valueText = "${(settings.hapticIntensity * 100).toInt()}%",
          value = settings.hapticIntensity,
          onValueChange = { onSettingsChanged(settings.copy(hapticIntensity = it)) },
          valueRange = 0.1f..1.0f,
          accentColor = XgtNeonMagenta
        )
      }
    }

    // Haptic Feedback Mode Selection with spring scaling
    item {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .background(XgtDarkSurface, RoundedCornerShape(20.dp))
          .border(1.dp, Color(0xFF1E283D), RoundedCornerShape(20.dp))
          .padding(16.dp)
      ) {
        Text("TACTILE HAPTIC PROFILE", color = XgtTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Black)
        Spacer(modifier = Modifier.height(12.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          hapticModes.forEach { mode ->
            val isSelected = settings.hapticFeedbackMode == mode
            val scale by animateFloatAsState(
              targetValue = if (isSelected) 1.05f else 1.0f,
              animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
              label = "haptic_scale"
            )

            Box(
              modifier = Modifier
                .weight(1f)
                .scale(scale)
                .background(
                  brush = Brush.verticalGradient(
                    listOf(
                      if (isSelected) XgtMatrixGreen.copy(alpha = 0.2f) else Color(0xFF0F1522),
                      if (isSelected) XgtMatrixGreen.copy(alpha = 0.05f) else Color(0xFF0B101A)
                    )
                  ),
                  shape = RoundedCornerShape(12.dp)
                )
                .border(
                  width = if (isSelected) 1.5.dp else 1.dp,
                  color = if (isSelected) XgtMatrixGreen else Color(0xFF1E283D),
                  shape = RoundedCornerShape(12.dp)
                )
                .bouncyClickable { onSettingsChanged(settings.copy(hapticFeedbackMode = mode)) }
                .padding(vertical = 12.dp),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = mode,
                color = if (isSelected) XgtMatrixGreen else XgtTextSecondary,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1
              )
            }
          }
        }
      }
    }

    // Low-Latency Toggles
    item {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        CyberSwitchCard(
          title = "Instant Touch Dispatch",
          subtitle = "Bypasses input queuing to achieve zero-frame touch latency",
          checked = settings.instantTouchDispatch,
          onCheckedChange = { onSettingsChanged(settings.copy(instantTouchDispatch = it)) },
          icon = Icons.Default.Speed,
          accentColor = XgtNeonCyan
        )

        CyberSwitchCard(
          title = "Edge Palm Rejection",
          subtitle = "Filters out accidental corner touches during handheld gaming",
          checked = settings.edgeFilterEnabled,
          onCheckedChange = { onSettingsChanged(settings.copy(edgeFilterEnabled = it)) },
          icon = Icons.Default.PanTool,
          accentColor = XgtAmberBoost
        )
      }
    }
  }
}
