package com.example.ui.games

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.GraphicSettings
import com.example.model.InterpolationSettings
import com.example.model.PerformanceMetrics
import com.example.model.TouchSettings
import com.example.ui.components.FpsOverlayBar
import com.example.ui.theme.XgtAmberBoost
import com.example.ui.theme.XgtMatrixGreen
import com.example.ui.theme.XgtNeonCyan
import com.example.ui.theme.XgtNeonMagenta
import com.example.ui.theme.XgtTextMuted
import com.example.ui.theme.XgtTextPrimary
import java.util.Locale
import kotlin.math.hypot
import kotlin.random.Random
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive

private data class LaserBullet(
  var x: Float,
  var y: Float,
  val speedY: Float = -28f,
  val isSuper: Boolean = false
)

private data class AlienDrone(
  var x: Float,
  var y: Float,
  var hp: Int,
  val maxHp: Int,
  val radius: Float,
  val speedY: Float,
  val isBoss: Boolean = false
)

private data class ExplosionSpark(
  var x: Float,
  var y: Float,
  var vx: Float,
  var vy: Float,
  var life: Float, // 1.0 down to 0.0
  val color: Color
)

@Composable
fun QuantumStrikerGame(
  graphicSettings: GraphicSettings,
  touchSettings: TouchSettings,
  interpolationSettings: InterpolationSettings,
  metrics: PerformanceMetrics,
  onExit: () -> Unit,
  onBoost: () -> Unit,
  onSaveScore: (Long) -> Unit
) {
  BackHandler { onExit() }

  var playerX by remember { mutableFloatStateOf(0.5f) } // 0.0 to 1.0 normalized
  var playerY by remember { mutableFloatStateOf(0.85f) }
  var targetX by remember { mutableFloatStateOf(0.5f) }
  var targetY by remember { mutableFloatStateOf(0.85f) }

  var shieldHp by remember { mutableIntStateOf(100) }
  var score by remember { mutableLongStateOf(0L) }
  var isGameOver by remember { mutableStateOf(false) }

  val bullets = remember { mutableStateListOf<LaserBullet>() }
  val enemies = remember { mutableStateListOf<AlienDrone>() }
  val sparks = remember { mutableStateListOf<ExplosionSpark>() }

  // Game loop
  LaunchedEffect(isGameOver) {
    if (isGameOver) return@LaunchedEffect

    bullets.clear()
    enemies.clear()
    sparks.clear()

    var shootTimer = 0
    var spawnTimer = 0

    while (isActive && !isGameOver) {
      val lerpAlpha = if (interpolationSettings.memcEnabled) {
        interpolationSettings.smoothingMultiplier
      } else {
        0.4f
      }

      // Smooth Frame Interpolation for player position
      playerX += (targetX - playerX) * lerpAlpha
      playerY += (targetY - playerY) * lerpAlpha

      // Auto Rapid Fire
      shootTimer++
      if (shootTimer >= 8) { // Fire every ~100ms
        shootTimer = 0
        bullets.add(LaserBullet(x = playerX - 0.03f, y = playerY - 0.05f))
        bullets.add(LaserBullet(x = playerX + 0.03f, y = playerY - 0.05f))
      }

      // Spawn Enemies
      spawnTimer++
      if (spawnTimer >= 35) {
        spawnTimer = 0
        val isBoss = enemies.isEmpty() && score > 2000 && Random.nextFloat() < 0.25f
        enemies.add(
          AlienDrone(
            x = Random.nextFloat() * 0.8f + 0.1f,
            y = -0.05f,
            hp = if (isBoss) 30 else 3,
            maxHp = if (isBoss) 30 else 3,
            radius = if (isBoss) 42f else 18f,
            speedY = if (isBoss) 0.003f else 0.007f + Random.nextFloat() * 0.005f,
            isBoss = isBoss
          )
        )
      }

      // Update Bullets
      val bIter = bullets.listIterator()
      while (bIter.hasNext()) {
        val b = bIter.next()
        b.y -= 0.035f
        if (b.y < -0.1f) {
          bIter.remove()
        }
      }

      // Update Enemies & Bullet Collisions
      val eIter = enemies.listIterator()
      while (eIter.hasNext()) {
        val e = eIter.next()
        e.y += e.speedY

        // Check if hit player
        val distToPlayer = hypot((e.x - playerX) * 1000f, (e.y - playerY) * 1000f)
        if (distToPlayer < (e.radius + 24f)) {
          shieldHp = (shieldHp - 25).coerceAtLeast(0)
          createSparks(e.x, e.y, sparks, Color(0xFFFF2A6D))
          eIter.remove()
          if (shieldHp <= 0) {
            isGameOver = true
            onSaveScore(score)
            break
          }
          continue
        }

        // Check bullet collisions
        val bulletCheck = bullets.listIterator()
        while (bulletCheck.hasNext()) {
          val b = bulletCheck.next()
          val distToBullet = hypot((e.x - b.x) * 1000f, (e.y - b.y) * 1000f)
          if (distToBullet < e.radius + 12f) {
            bulletCheck.remove()
            e.hp--
            score += 15L
            if (e.hp <= 0) {
              createSparks(e.x, e.y, sparks, if (e.isBoss) XgtAmberBoost else XgtNeonCyan)
              score += if (e.isBoss) 800L else 120L
              eIter.remove()
              break
            }
          }
        }

        if (e.y > 1.1f) {
          eIter.remove()
        }
      }

      // Update Sparks
      val sIter = sparks.listIterator()
      while (sIter.hasNext()) {
        val s = sIter.next()
        s.x += s.vx
        s.y += s.vy
        s.life -= 0.04f
        if (s.life <= 0f) {
          sIter.remove()
        }
      }

      delay(14L)
    }
  }

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF06080F))
  ) {
    Canvas(
      modifier = Modifier
        .fillMaxSize()
        .pointerInput(touchSettings) {
          detectDragGestures(
            onDrag = { change, dragAmount ->
              change.consume()
              // Touch sensitivity mapping
              val deadzonePx = (touchSettings.deadzonePercent / 100f) * size.width
              var dx = dragAmount.x
              var dy = dragAmount.y

              if (kotlin.math.abs(dx) > deadzonePx) {
                dx = if (dx > 0) dx - deadzonePx else dx + deadzonePx
              }
              val sens = touchSettings.touchSensitivity * 1.5f
              targetX = (targetX + (dx / size.width) * sens).coerceIn(0.08f, 0.92f)
              targetY = (targetY + (dy / size.height) * sens).coerceIn(0.15f, 0.92f)
            }
          )
        }
        .testTag("space_striker_canvas")
    ) {
      val w = size.width
      val h = size.height

      // Space stars
      for (i in 0 until 40) {
        val sx = ((i * 137) % 1000) / 1000f * w
        val sy = ((i * 359) % 1000) / 1000f * h
        drawCircle(
          color = Color.White.copy(alpha = if (i % 3 == 0) 0.8f else 0.4f),
          radius = (if (i % 5 == 0) 2.dp else 1.dp).toPx(),
          center = Offset(sx, sy)
        )
      }

      // Bullets
      bullets.forEach { b ->
        val bx = b.x * w
        val by = b.y * h
        drawRoundRect(
          color = XgtNeonCyan,
          topLeft = Offset(bx - 2.5.dp.toPx(), by),
          size = Size(5.dp.toPx(), 18.dp.toPx()),
          cornerRadius = androidx.compose.ui.geometry.CornerRadius(2.dp.toPx(), 2.dp.toPx())
        )
      }

      // Enemies
      enemies.forEach { e ->
        val ex = e.x * w
        val ey = e.y * h
        val radiusPx = e.radius.dp.toPx()

        drawCircle(
          color = if (e.isBoss) Color(0xFFFF2A6D) else Color(0xFFFF9E00),
          radius = radiusPx,
          center = Offset(ex, ey)
        )
        drawCircle(
          color = Color(0xFF090D14),
          radius = radiusPx * 0.5f,
          center = Offset(ex, ey)
        )

        // HP bar above boss
        if (e.isBoss) {
          val barW = 60.dp.toPx()
          val barH = 5.dp.toPx()
          drawRect(
            color = Color(0xFF334155),
            topLeft = Offset(ex - barW / 2f, ey - radiusPx - 10.dp.toPx()),
            size = Size(barW, barH)
          )
          drawRect(
            color = XgtNeonMagenta,
            topLeft = Offset(ex - barW / 2f, ey - radiusPx - 10.dp.toPx()),
            size = Size(barW * (e.hp.toFloat() / e.maxHp), barH)
          )
        }
      }

      // Sparks
      sparks.forEach { s ->
        drawCircle(
          color = s.color.copy(alpha = s.life),
          radius = 3.dp.toPx() * s.life,
          center = Offset(s.x * w, s.y * h)
        )
      }

      // Player Ship
      val px = playerX * w
      val py = playerY * h
      drawStarship(px, py, shieldHp)
    }

    // Top Header & Overlay
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(top = 40.dp, start = 16.dp, end = 16.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        IconButton(
          onClick = onExit,
          modifier = Modifier.background(Color(0x80101522), CircleShape)
        ) {
          Icon(Icons.Default.ArrowBack, contentDescription = "Exit", tint = XgtTextPrimary)
        }

        FpsOverlayBar(
          metrics = metrics,
          isMemcActive = interpolationSettings.memcEnabled,
          onBoostClick = onBoost
        )
      }

      Spacer(modifier = Modifier.height(10.dp))

      // In-Game Status (Shield Bar + Score)
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .background(Color(0x990A0E18), RoundedCornerShape(12.dp))
          .padding(horizontal = 14.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text("SHIELD INTEGRITY", color = XgtTextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
          Spacer(modifier = Modifier.height(2.dp))
          Box(
            modifier = Modifier
              .width(110.dp)
              .height(8.dp)
              .background(Color(0xFF202A3D), RoundedCornerShape(4.dp))
          ) {
            Box(
              modifier = Modifier
                .fillMaxWidth(shieldHp / 100f)
                .height(8.dp)
                .background(
                  if (shieldHp > 35) XgtMatrixGreen else Color(0xFFFF3366),
                  RoundedCornerShape(4.dp)
                )
            )
          }
        }

        Column(horizontalAlignment = Alignment.End) {
          Text("SCORE", color = XgtTextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
          Text(
            text = String.format(Locale.US, "%,d", score),
            color = XgtTextPrimary,
            fontSize = 18.sp,
            fontWeight = FontWeight.Black,
            fontFamily = FontFamily.Monospace
          )
        }
      }
    }

    // Game Over Overlay
    AnimatedVisibility(
      visible = isGameOver,
      modifier = Modifier.align(Alignment.Center)
    ) {
      Box(
        modifier = Modifier
          .padding(24.dp)
          .background(Color(0xF2090D14), RoundedCornerShape(20.dp))
          .border(1.5.dp, XgtNeonMagenta, RoundedCornerShape(20.dp))
          .padding(24.dp),
        contentAlignment = Alignment.Center
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Text(
            text = "SHIELD COLLAPSED",
            color = Color(0xFFFF3366),
            fontSize = 18.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 1.sp
          )
          Spacer(modifier = Modifier.height(12.dp))
          Text(
            text = "FINAL SCORE: ${String.format(Locale.US, "%,d", score)}",
            color = XgtTextPrimary,
            fontSize = 22.sp,
            fontWeight = FontWeight.ExtraBold,
            fontFamily = FontFamily.Monospace
          )
          Spacer(modifier = Modifier.height(20.dp))
          Row {
            Button(
              onClick = {
                score = 0
                shieldHp = 100
                isGameOver = false
              },
              colors = ButtonDefaults.buttonColors(containerColor = XgtNeonCyan),
              modifier = Modifier.testTag("restart_space_btn")
            ) {
              Icon(Icons.Default.Refresh, contentDescription = null, tint = Color(0xFF090D14))
              Spacer(modifier = Modifier.width(6.dp))
              Text("REDEPLOY", color = Color(0xFF090D14), fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.width(12.dp))

            Button(
              onClick = onExit,
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E283D))
            ) {
              Text("HUB", color = XgtTextPrimary, fontWeight = FontWeight.Bold)
            }
          }
        }
      }
    }
  }
}

private fun createSparks(
  normX: Float,
  normY: Float,
  list: MutableList<ExplosionSpark>,
  color: Color
) {
  for (i in 0 until 18) {
    val angle = Random.nextFloat() * 6.28f
    val speed = Random.nextFloat() * 0.012f + 0.003f
    list.add(
      ExplosionSpark(
        x = normX,
        y = normY,
        vx = (kotlin.math.cos(angle) * speed),
        vy = (kotlin.math.sin(angle) * speed),
        life = 1.0f,
        color = color
      )
    )
  }
}

private fun DrawScope.drawStarship(px: Float, py: Float, shield: Int) {
  val shipSize = 36.dp.toPx()

  // Shield aura
  if (shield > 0) {
    drawCircle(
      color = Color(0x3300E5FF),
      radius = shipSize * 0.85f,
      center = Offset(px, py)
    )
  }

  // Delta Wing Starship Path
  val shipPath = Path().apply {
    moveTo(px, py - shipSize * 0.7f) // Nose
    lineTo(px + shipSize * 0.6f, py + shipSize * 0.5f) // Right wing
    lineTo(px, py + shipSize * 0.25f) // Thruster notch
    lineTo(px - shipSize * 0.6f, py + shipSize * 0.5f) // Left wing
    close()
  }

  drawPath(
    shipPath,
    brush = Brush.verticalGradient(
      listOf(XgtNeonCyan, Color(0xFF0D3B66), Color(0xFF06152B)),
      startY = py - shipSize * 0.7f,
      endY = py + shipSize * 0.5f
    )
  )

  // Cockpit
  drawCircle(
    color = XgtNeonCyan,
    radius = 4.dp.toPx(),
    center = Offset(px, py - shipSize * 0.15f)
  )

  // Plasma thruster flame
  drawCircle(
    color = XgtNeonMagenta,
    radius = 5.dp.toPx(),
    center = Offset(px, py + shipSize * 0.35f)
  )
}
