package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Modern Cyber Obsidian Deep Palette
val XgtObsidian = Color(0xFF06090F)
val XgtDarkSurface = Color(0xFF0D121D)
val XgtSurfaceVariant = Color(0xFF141B2A)
val XgtSurfaceHighlight = Color(0xFF1C263B)
val XgtGlassSurface = Color(0xCC0D1422)

// Iridescent Esports Accents & Neons
val XgtNeonCyan = Color(0xFF00F0FF)
val XgtNeonMagenta = Color(0xFFFF0055)
val XgtMatrixGreen = Color(0xFF00FFA3)
val XgtAmberBoost = Color(0xFFFFB800)
val XgtElectricPurple = Color(0xFF8A2BE2)
val XgtHyperBlue = Color(0xFF0077FE)

// Typography & Structural Tokens
val XgtTextPrimary = Color(0xFFF8FAFC)
val XgtTextSecondary = Color(0xFF94A3B8)
val XgtTextMuted = Color(0xFF64748B)
val XgtBorder = Color(0xFF222E44)
val XgtBorderGlow = Color(0x3300F0FF)
val XgtGlassHighlight = Color(0x22FFFFFF)
val XgtError = Color(0xFFFF2255)

// Translucent Glow Halos
val XgtCyanGlow = Color(0x3300F0FF)
val XgtMagentaGlow = Color(0x33FF0055)
val XgtGreenGlow = Color(0x3300FFA3)
val XgtAmberGlow = Color(0x33FFB800)
