package com.example.model

enum class PerformanceMode(val title: String, val subtitle: String, val targetFps: Int) {
  ECO("Eco Saver", "Battery optimization & stable thermals", 60),
  BALANCED("Balanced", "Smooth 90Hz adaptive fidelity", 90),
  ESPORTS_EXTREME("Esports Turbo", "Max 120Hz/144Hz zero-latency overclock", 120),
  CUSTOM("Custom Lab", "Manual override & parameter tuning", 120)
}

enum class ColorFilterMode(val label: String) {
  VIVID_NEON("Cyber Neon"),
  ESPORTS_CLARITY("Esports Sharp"),
  CINEMATIC_WARM("Cinematic Warm"),
  NIGHT_VISION("Night Matrix")
}

data class GraphicSettings(
  val resolutionScale: Float = 1.0f, // 0.75f, 1.0f, 1.25f, 1.5f
  val neonBloom: Boolean = true,
  val bloomIntensity: Float = 0.8f,
  val hdrContrast: Boolean = true,
  val motionBlur: Boolean = true,
  val motionBlurIntensity: Float = 0.5f,
  val antiAliasing: Boolean = true,
  val particleDensity: Float = 1.0f, // 0.5f to 2.0f
  val colorFilter: ColorFilterMode = ColorFilterMode.VIVID_NEON
)

data class TouchSettings(
  val touchSamplingRateHz: Int = 360, // 120, 240, 360, 480
  val touchSensitivity: Float = 1.5f, // 0.5f to 3.0f
  val deadzonePercent: Float = 2.0f, // 0% to 15%
  val instantTouchDispatch: Boolean = true,
  val edgeFilterEnabled: Boolean = true,
  val hapticFeedbackMode: String = "Crisp Gaming", // Off, Subtle, Crisp Gaming, Heavy Rumble
  val hapticIntensity: Float = 0.75f // 0.1f to 1.0f
)

data class InterpolationSettings(
  val memcEnabled: Boolean = true,
  val targetRefreshRate: Int = 120, // 60, 90, 120, 144
  val smoothingMultiplier: Float = 0.7f, // sub-frame lerp alpha
  val adaptiveFramePacing: Boolean = true,
  val dynamicVsync: Boolean = true,
  val lowLatencyMode: Boolean = true
)

data class PerformanceMetrics(
  val currentFps: Float = 120.0f,
  val targetFps: Int = 120,
  val frameTimeMs: Float = 8.3f,
  val jitterMs: Float = 0.4f,
  val onePercentLowFps: Float = 114.2f,
  val cpuUsagePercent: Int = 28,
  val ramUsedMb: Int = 1420,
  val ramTotalMb: Int = 4096,
  val batteryTempCelsius: Float = 36.2f,
  val pingLatencyMs: Int = 18,
  val interpolatedFramesCount: Long = 14250L,
  val isTurboActive: Boolean = true
)

data class GameProfile(
  val id: String,
  val title: String,
  val genre: String,
  val bannerDrawable: Int? = null,
  val targetFps: Int = 120,
  val performanceMode: PerformanceMode = PerformanceMode.ESPORTS_EXTREME,
  val touchSamplingRate: Int = 360,
  val highScore: Long = 0L,
  val playCount: Int = 0
)

data class BenchmarkResult(
  val timestamp: Long = System.currentTimeMillis(),
  val avgFps: Float = 118.6f,
  val maxFps: Float = 120.0f,
  val minFps: Float = 108.4f,
  val stabilityScore: Float = 98.7f, // % stability
  val totalFramesTested: Int = 1200,
  val maxTempCelsius: Float = 37.8f,
  val grade: String = "S+ ULTRA"
)
