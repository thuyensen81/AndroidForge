package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.GameProfileEntity
import com.example.model.PerformanceMetrics
import com.example.ui.animation.bouncyClickable
import com.example.ui.components.EditProfileDialog
import com.example.ui.theme.XgtDarkSurface
import com.example.ui.theme.XgtMatrixGreen
import com.example.ui.theme.XgtNeonCyan
import com.example.ui.theme.XgtNeonMagenta
import com.example.ui.theme.XgtSurfaceHighlight
import com.example.ui.theme.XgtSurfaceVariant
import com.example.ui.theme.XgtTextMuted
import com.example.ui.theme.XgtTextPrimary
import com.example.ui.theme.XgtTextSecondary

@Composable
fun GamesHubScreen(
  profiles: List<GameProfileEntity>,
  metrics: PerformanceMetrics,
  onLaunchGame: (String) -> Unit,
  onApplyProfile: (GameProfileEntity) -> Unit,
  onUpdateProfile: (GameProfileEntity) -> Unit = {},
  onSaveNewProfile: (String, String, String) -> Unit,
  onDeleteProfile: (String) -> Unit
) {
  var showAddDialog by remember { mutableStateOf(false) }
  var profileToEdit by remember { mutableStateOf<GameProfileEntity?>(null) }
  var filterTab by remember { mutableIntStateOf(0) } // 0: All, 1: Installed Titles, 2: Built-in Games

  val filteredProfiles = when (filterTab) {
    1 -> profiles.filter { !it.isBuiltIn }
    2 -> profiles.filter { it.isBuiltIn }
    else -> profiles
  }

  Box(modifier = Modifier.fillMaxSize()) {
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp),
      contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp)
    ) {
      // Header with Add Button
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text(
              text = "HỒ SƠ CẤU HÌNH TRÒ CHƠI",
              color = XgtNeonCyan,
              fontSize = 18.sp,
              fontWeight = FontWeight.Black,
              letterSpacing = 1.sp
            )
            Text(
              text = "Tùy chỉnh riêng tần số quét, MEMC, cảm ứng và đồ họa",
              color = XgtTextSecondary,
              fontSize = 11.sp
            )
          }

          Button(
            onClick = { showAddDialog = true },
            colors = ButtonDefaults.buttonColors(containerColor = XgtNeonCyan),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.testTag("save_current_profile_btn")
          ) {
            Icon(Icons.Default.Add, contentDescription = null, tint = Color(0xFF090D14), modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("LƯU CẤU HÌNH", color = Color(0xFF090D14), fontSize = 11.sp, fontWeight = FontWeight.Black)
          }
        }
      }

      // Filter Tabs with Spring Scaling
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          listOf("Tất cả (${profiles.size})", "Game đã cài đặt", "Game tích hợp").forEachIndexed { index, label ->
            val isSelected = filterTab == index
            val tabScale by animateFloatAsState(
              targetValue = if (isSelected) 1.04f else 1.0f,
              animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
              label = "tab_scale"
            )

            Box(
              modifier = Modifier
                .weight(1f)
                .scale(tabScale)
                .background(
                  brush = Brush.verticalGradient(
                    listOf(
                      if (isSelected) XgtNeonCyan.copy(alpha = 0.2f) else Color(0xFF101625),
                      if (isSelected) XgtNeonCyan.copy(alpha = 0.05f) else Color(0xFF0C101A)
                    )
                  ),
                  shape = RoundedCornerShape(12.dp)
                )
                .border(
                  width = if (isSelected) 1.5.dp else 1.dp,
                  color = if (isSelected) XgtNeonCyan else Color(0xFF1E283D),
                  shape = RoundedCornerShape(12.dp)
                )
                .bouncyClickable { filterTab = index }
                .padding(vertical = 10.dp),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = label,
                color = if (isSelected) XgtNeonCyan else XgtTextSecondary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
              )
            }
          }
        }
      }

      // Profiles List
      items(filteredProfiles, key = { it.id }) { profile ->
        GameProfileCard(
          profile = profile,
          onLaunch = { onLaunchGame(profile.id) },
          onApply = { onApplyProfile(profile) },
          onEdit = { profileToEdit = profile },
          onDelete = { onDeleteProfile(profile.id) }
        )
      }

      // Explanatory Card
      item {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .background(XgtDarkSurface, RoundedCornerShape(20.dp))
            .border(1.dp, Color(0xFF1E283D), RoundedCornerShape(20.dp))
            .padding(16.dp)
        ) {
          Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.Tune, contentDescription = null, tint = XgtMatrixGreen)
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "TÙY CHỈNH HỒ SƠ RIÊNG BIỆT CHO TỪNG GAME",
                color = XgtTextPrimary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Black
              )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
              text = "Bạn có thể nhấn 'TÙY CHỈNH' trên bất kỳ hồ sơ trò chơi nào để thay đổi tần số quét (60Hz–144Hz), thuật toán bù khung hình MEMC, độ nhạy cảm ứng 480Hz, tỷ lệ độ phân giải và cường độ rung theo đúng ý muốn. Tất cả được lưu trữ vĩnh viễn trong Room Database.",
              color = XgtTextSecondary,
              fontSize = 11.sp,
              lineHeight = 16.sp
            )
          }
        }
      }
    }

    // Modal Tùy chỉnh cấu hình chi tiết (Edit Profile Dialog)
    if (profileToEdit != null) {
      EditProfileDialog(
        profile = profileToEdit!!,
        onDismiss = { profileToEdit = null },
        onSave = { updated ->
          onUpdateProfile(updated)
          profileToEdit = null
        },
        onApplyAndSave = { updated ->
          onUpdateProfile(updated)
          onApplyProfile(updated)
          profileToEdit = null
        }
      )
    }

    // Modern Dialog for Saving Current Tuning as New Reusable Profile
    if (showAddDialog) {
      SaveProfileDialog(
        onDismiss = { showAddDialog = false },
        onConfirm = { name, pkg, genre ->
          onSaveNewProfile(name, pkg, genre)
          showAddDialog = false
        }
      )
    }
  }
}

@Composable
private fun GameProfileCard(
  profile: GameProfileEntity,
  onLaunch: () -> Unit,
  onApply: () -> Unit,
  onEdit: () -> Unit,
  onDelete: () -> Unit
) {
  Box(
    modifier = Modifier
      .fillMaxWidth()
      .shadow(12.dp, RoundedCornerShape(20.dp), spotColor = Color(0x3300F0FF))
      .background(
        brush = Brush.verticalGradient(listOf(Color(0xFF101726), Color(0xFF080C14))),
        shape = RoundedCornerShape(20.dp)
      )
      .border(
        width = 1.2.dp,
        brush = Brush.linearGradient(
          listOf(
            Color(0x3300F0FF),
            Color(0x22FFFFFF),
            Color(0x33FF0055)
          )
        ),
        shape = RoundedCornerShape(20.dp)
      )
      .clip(RoundedCornerShape(20.dp))
      .testTag("game_profile_card_${profile.id}")
  ) {
    Column {
      // Banner or Cyber Gradient Header
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(if (profile.bannerResId != null) 130.dp else 80.dp)
          .background(XgtSurfaceVariant)
      ) {
        if (profile.bannerResId != null) {
          Image(
            painter = painterResource(id = profile.bannerResId),
            contentDescription = profile.gameTitle,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
          )
        } else {
          Box(
            modifier = Modifier
              .fillMaxSize()
              .background(
                Brush.linearGradient(
                  listOf(Color(0xFF0F172A), Color(0xFF1E1B4B), Color(0xFF042F2E))
                )
              )
          ) {
            Row(
              modifier = Modifier
                .padding(14.dp)
                .align(Alignment.CenterStart),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(
                imageVector = Icons.Default.Gamepad,
                contentDescription = null,
                tint = XgtNeonCyan,
                modifier = Modifier.size(34.dp)
              )
              Spacer(modifier = Modifier.width(12.dp))
              Column {
                Text(
                  text = profile.gameTitle,
                  color = XgtTextPrimary,
                  fontSize = 16.sp,
                  fontWeight = FontWeight.Black
                )
                Text(
                  text = profile.packageName,
                  color = XgtTextMuted,
                  fontSize = 10.sp,
                  fontFamily = FontFamily.Monospace
                )
              }
            }
          }
        }

        // Top Badges
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp),
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Box(
            modifier = Modifier
              .background(Color(0xD90A0E18), RoundedCornerShape(8.dp))
              .border(1.dp, XgtNeonCyan.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
              .padding(horizontal = 8.dp, vertical = 3.dp)
          ) {
            Text(
              text = "${profile.touchSamplingRateHz}Hz TOUCH",
              color = XgtNeonCyan,
              fontSize = 9.sp,
              fontWeight = FontWeight.Black,
              fontFamily = FontFamily.Monospace
            )
          }

          Box(
            modifier = Modifier
              .background(Color(0xD90A0E18), RoundedCornerShape(8.dp))
              .border(1.dp, XgtMatrixGreen.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
              .padding(horizontal = 8.dp, vertical = 3.dp)
          ) {
            Text(
              text = "${profile.targetRefreshRate}Hz | MEMC",
              color = XgtMatrixGreen,
              fontSize = 9.sp,
              fontWeight = FontWeight.Black,
              fontFamily = FontFamily.Monospace
            )
          }
        }
      }

      // Profile Content
      Column(modifier = Modifier.padding(14.dp)) {
        if (profile.bannerResId != null) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Column {
              Text(
                text = profile.gameTitle,
                color = XgtTextPrimary,
                fontSize = 16.sp,
                fontWeight = FontWeight.Black
              )
              Text(
                text = profile.genre,
                color = XgtTextSecondary,
                fontSize = 11.sp
              )
            }
            Text(
              text = profile.packageName,
              color = XgtTextMuted,
              fontSize = 10.sp,
              fontFamily = FontFamily.Monospace
            )
          }
          Spacer(modifier = Modifier.height(10.dp))
        }

        // Detailed Settings Grid in Badge Chips
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          ConfigChip(
            label = "Độ phân giải",
            value = "${(profile.resolutionScale * 100).toInt()}%"
          )
          ConfigChip(
            label = "Độ nhạy",
            value = "${profile.touchSensitivity}x"
          )
          ConfigChip(
            label = "Deadzone",
            value = "${profile.deadzonePercent}%"
          )
          ConfigChip(
            label = "Rung",
            value = profile.hapticFeedbackMode.take(6)
          )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Action Buttons with Bouncy Click
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            // Apply Config Button (activates profile into governor)
            Button(
              onClick = onApply,
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1B2438)),
              contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier.bouncyClickable { onApply() }.testTag("apply_profile_${profile.id}")
            ) {
              Icon(Icons.Default.Tune, contentDescription = null, tint = XgtNeonCyan, modifier = Modifier.size(15.dp))
              Spacer(modifier = Modifier.width(5.dp))
              Text("ÁP DỤNG", color = XgtNeonCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            // Edit Profile Button (Opens customizer dialog)
            Button(
              onClick = onEdit,
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF221F38)),
              contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier.bouncyClickable { onEdit() }.testTag("edit_profile_${profile.id}")
            ) {
              Icon(Icons.Default.Edit, contentDescription = "Tùy chỉnh", tint = XgtNeonMagenta, modifier = Modifier.size(14.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("TÙY CHỈNH", color = XgtNeonMagenta, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
          }

          Row(verticalAlignment = Alignment.CenterVertically) {
            if (profile.isBuiltIn) {
              Button(
                onClick = onLaunch,
                colors = ButtonDefaults.buttonColors(containerColor = XgtNeonCyan),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.bouncyClickable { onLaunch() }.testTag("play_game_${profile.id}")
              ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color(0xFF090D14), modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("CHƠI", color = Color(0xFF090D14), fontSize = 11.sp, fontWeight = FontWeight.Black)
              }
            } else {
              IconButton(
                onClick = onDelete,
                modifier = Modifier.size(38.dp).testTag("delete_profile_${profile.id}")
              ) {
                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFF64748B), modifier = Modifier.size(20.dp))
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun ConfigChip(label: String, value: String) {
  Box(
    modifier = Modifier
      .background(Color(0xFF080C14), RoundedCornerShape(6.dp))
      .border(1.dp, Color(0xFF1E283D), RoundedCornerShape(6.dp))
      .padding(horizontal = 6.dp, vertical = 3.dp)
  ) {
    Row {
      Text(text = "$label: ", color = XgtTextMuted, fontSize = 9.sp)
      Text(text = value, color = XgtTextPrimary, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
    }
  }
}

@Composable
private fun SaveProfileDialog(
  onDismiss: () -> Unit,
  onConfirm: (name: String, pkg: String, genre: String) -> Unit
) {
  var gameName by remember { mutableStateOf("") }
  var packageName by remember { mutableStateOf("") }
  var genre by remember { mutableStateOf("Esports Action") }

  AlertDialog(
    onDismissRequest = onDismiss,
    shape = RoundedCornerShape(24.dp),
    containerColor = Color(0xFF0E1320),
    title = {
      Text(
        text = "LƯU HỒ SƠ GAME MỚI",
        color = XgtNeonCyan,
        fontSize = 16.sp,
        fontWeight = FontWeight.Black,
        letterSpacing = 1.sp
      )
    },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
          text = "Lưu các thông số đồ họa, cảm ứng 480Hz và điều phối khung hình MEMC hiện tại vào Room Database.",
          color = XgtTextSecondary,
          fontSize = 11.sp
        )

        OutlinedTextField(
          value = gameName,
          onValueChange = { gameName = it },
          label = { Text("Tên game (ví dụ: Apex Legends Mobile)") },
          shape = RoundedCornerShape(12.dp),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = XgtNeonCyan,
            unfocusedBorderColor = Color(0xFF1E283D),
            focusedTextColor = XgtTextPrimary,
            unfocusedTextColor = XgtTextPrimary
          ),
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("input_game_title")
        )

        OutlinedTextField(
          value = packageName,
          onValueChange = { packageName = it },
          label = { Text("Package Name (ví dụ: com.ea.apex)") },
          shape = RoundedCornerShape(12.dp),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = XgtNeonCyan,
            unfocusedBorderColor = Color(0xFF1E283D),
            focusedTextColor = XgtTextPrimary,
            unfocusedTextColor = XgtTextPrimary
          ),
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("input_package_name")
        )

        OutlinedTextField(
          value = genre,
          onValueChange = { genre = it },
          label = { Text("Thể loại (ví dụ: FPS / MOBA / Đua xe)") },
          shape = RoundedCornerShape(12.dp),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = XgtNeonCyan,
            unfocusedBorderColor = Color(0xFF1E283D),
            focusedTextColor = XgtTextPrimary,
            unfocusedTextColor = XgtTextPrimary
          ),
          singleLine = true,
          modifier = Modifier.fillMaxWidth().testTag("input_game_genre")
        )
      }
    },
    confirmButton = {
      Button(
        onClick = { onConfirm(gameName, packageName, genre) },
        enabled = gameName.isNotBlank(),
        colors = ButtonDefaults.buttonColors(containerColor = XgtNeonCyan),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.testTag("confirm_save_profile_btn")
      ) {
        Text("LƯU VÀO DATABASE", color = Color(0xFF090D14), fontWeight = FontWeight.Bold, fontSize = 12.sp)
      }
    },
    dismissButton = {
      Button(
        onClick = onDismiss,
        colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent)
      ) {
        Text("HỦY", color = XgtTextSecondary)
      }
    }
  )
}
