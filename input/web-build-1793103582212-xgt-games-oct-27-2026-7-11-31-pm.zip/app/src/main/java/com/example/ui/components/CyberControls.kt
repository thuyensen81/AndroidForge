package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.animation.bouncyClickable
import com.example.ui.theme.XgtAmberBoost
import com.example.ui.theme.XgtDarkSurface
import com.example.ui.theme.XgtElectricPurple
import com.example.ui.theme.XgtGlassHighlight
import com.example.ui.theme.XgtGlassSurface
import com.example.ui.theme.XgtHyperBlue
import com.example.ui.theme.XgtMatrixGreen
import com.example.ui.theme.XgtNeonCyan
import com.example.ui.theme.XgtNeonMagenta
import com.example.ui.theme.XgtSurfaceHighlight
import com.example.ui.theme.XgtSurfaceVariant
import com.example.ui.theme.XgtTextMuted
import com.example.ui.theme.XgtTextPrimary
import com.example.ui.theme.XgtTextSecondary

@Composable
fun CyberSlider(
  label: String,
  valueText: String,
  value: Float,
  onValueChange: (Float) -> Unit,
  valueRange: ClosedFloatingPointRange<Float>,
  steps: Int = 0,
  accentColor: Color = XgtNeonCyan,
  modifier: Modifier = Modifier
) {
  Column(
    modifier = modifier
      .fillMaxWidth()
      .background(XgtDarkSurface, RoundedCornerShape(16.dp))
      .border(
        width = 1.dp,
        brush = Brush.linearGradient(
          listOf(XgtGlassHighlight, Color(0xFF1E283D), accentColor.copy(alpha = 0.2f))
        ),
        shape = RoundedCornerShape(16.dp)
      )
      .padding(14.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = label,
        color = XgtTextPrimary,
        fontSize = 13.sp,
        fontWeight = FontWeight.Bold
      )

      Box(
        modifier = Modifier
          .background(accentColor.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
          .border(1.dp, accentColor.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
          .padding(horizontal = 8.dp, vertical = 3.dp)
      ) {
        Text(
          text = valueText,
          color = accentColor,
          fontSize = 12.sp,
          fontWeight = FontWeight.ExtraBold,
          fontFamily = FontFamily.Monospace
        )
      }
    }

    Spacer(modifier = Modifier.height(4.dp))

    Slider(
      value = value,
      onValueChange = onValueChange,
      valueRange = valueRange,
      steps = steps,
      colors = SliderDefaults.colors(
        thumbColor = accentColor,
        activeTrackColor = accentColor,
        inactiveTrackColor = Color(0xFF1B2335)
      ),
      modifier = Modifier
        .fillMaxWidth()
        .testTag("slider_${label.lowercase().replace(" ", "_")}")
    )
  }
}

@Composable
fun CyberSwitchCard(
  title: String,
  subtitle: String,
  checked: Boolean,
  onCheckedChange: (Boolean) -> Unit,
  icon: ImageVector? = null,
  accentColor: Color = XgtNeonCyan,
  modifier: Modifier = Modifier
) {
  Box(
    modifier = modifier
      .fillMaxWidth()
      .background(
        brush = Brush.verticalGradient(
          listOf(
            if (checked) accentColor.copy(alpha = 0.08f) else Color(0xFF0F1522),
            Color(0xFF0B0F19)
          )
        ),
        shape = RoundedCornerShape(16.dp)
      )
      .border(
        width = 1.dp,
        brush = if (checked) {
          Brush.linearGradient(
            listOf(accentColor.copy(alpha = 0.6f), Color(0x22FFFFFF), accentColor.copy(alpha = 0.2f))
          )
        } else {
          Brush.linearGradient(listOf(Color(0xFF1E283D), Color(0xFF151C2A)))
        },
        shape = RoundedCornerShape(16.dp)
      )
      .bouncyClickable { onCheckedChange(!checked) }
      .padding(14.dp)
      .testTag("switch_card_${title.lowercase().replace(" ", "_")}")
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(
        modifier = Modifier.weight(1f),
        verticalAlignment = Alignment.CenterVertically
      ) {
        if (icon != null) {
          Box(
            modifier = Modifier
              .size(40.dp)
              .background(
                if (checked) accentColor.copy(alpha = 0.18f) else Color(0xFF172030),
                CircleShape
              )
              .border(
                1.dp,
                if (checked) accentColor.copy(alpha = 0.5f) else Color(0xFF222E42),
                CircleShape
              ),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = icon,
              contentDescription = null,
              tint = if (checked) accentColor else XgtTextMuted,
              modifier = Modifier.size(20.dp)
            )
          }
          Spacer(modifier = Modifier.width(12.dp))
        }

        Column {
          Text(
            text = title,
            color = if (checked) XgtTextPrimary else Color(0xFFCBD5E1),
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold
          )
          Spacer(modifier = Modifier.height(2.dp))
          Text(
            text = subtitle,
            color = XgtTextSecondary,
            fontSize = 11.sp,
            lineHeight = 15.sp
          )
        }
      }

      Spacer(modifier = Modifier.width(8.dp))

      Switch(
        checked = checked,
        onCheckedChange = onCheckedChange,
        colors = SwitchDefaults.colors(
          checkedThumbColor = Color.White,
          checkedTrackColor = accentColor,
          uncheckedThumbColor = Color(0xFF64748B),
          uncheckedTrackColor = Color(0xFF1A2234)
        )
      )
    }
  }
}

/**
 * Modernized Reactor Turbo Boost button with glowing energy aura, rotating rings,
 * light sheen sweep, and tactile bouncy interaction.
 */
@Composable
fun TurboBoostButton(
  onClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  val infiniteTransition = rememberInfiniteTransition(label = "turbo_energy")

  val pulseScale by infiniteTransition.animateFloat(
    initialValue = 0.98f,
    targetValue = 1.02f,
    animationSpec = infiniteRepeatable(
      animation = tween(1200, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "pulse_scale"
  )

  val shimmerOffset by infiniteTransition.animateFloat(
    initialValue = -1f,
    targetValue = 2f,
    animationSpec = infiniteRepeatable(
      animation = tween(2400, easing = LinearEasing),
      repeatMode = RepeatMode.Restart
    ),
    label = "shimmer_offset"
  )

  Box(
    modifier = modifier
      .fillMaxWidth()
      .height(62.dp)
      .scale(pulseScale)
      .shadow(16.dp, RoundedCornerShape(18.dp), spotColor = XgtNeonCyan, ambientColor = XgtNeonMagenta)
      .background(
        brush = Brush.horizontalGradient(
          colors = listOf(
            XgtNeonCyan,
            XgtHyperBlue,
            XgtElectricPurple,
            XgtNeonMagenta
          )
        ),
        shape = RoundedCornerShape(18.dp)
      )
      .clip(RoundedCornerShape(18.dp))
      .bouncyClickable { onClick() }
      .testTag("turbo_boost_action_button")
  ) {
    // Dynamic light sheen sweep overlay
    Canvas(modifier = Modifier.fillMaxSize()) {
      val w = size.width
      val h = size.height
      val sweepX = w * shimmerOffset
      drawRect(
        brush = Brush.linearGradient(
          colors = listOf(
            Color.Transparent,
            Color.White.copy(alpha = 0.35f),
            Color.Transparent
          ),
          start = Offset(sweepX - 60f, 0f),
          end = Offset(sweepX + 60f, h)
        )
      )
    }

    // Button Content Row
    Row(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 16.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.Center
    ) {
      Box(
        modifier = Modifier
          .size(34.dp)
          .background(Color(0xFF06090F), CircleShape),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = Icons.Default.Bolt,
          contentDescription = "Turbo Bolt",
          tint = XgtNeonCyan,
          modifier = Modifier.size(20.dp)
        )
      }

      Spacer(modifier = Modifier.width(10.dp))

      Column(horizontalAlignment = Alignment.Start) {
        Text(
          text = "⚡ OVERCLOCK TURBO BOOST",
          color = Color(0xFF06090F),
          fontSize = 14.sp,
          fontWeight = FontWeight.Black,
          letterSpacing = 0.8.sp
        )
        Text(
          text = "PURGE RAM • ZERO INPUT LATENCY • 144Hz LOCK",
          color = Color(0xFF06090F).copy(alpha = 0.85f),
          fontSize = 9.sp,
          fontWeight = FontWeight.ExtraBold,
          letterSpacing = 0.5.sp
        )
      }
    }
  }
}
