package com.example.engine

import android.app.ActivityManager
import android.content.Context
import com.example.model.BenchmarkResult
import com.example.model.InterpolationSettings
import com.example.model.PerformanceMetrics
import com.example.model.PerformanceMode
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class PerformanceGovernor(private val context: Context) {

  private val _metrics = MutableStateFlow(PerformanceMetrics())
  val metrics: StateFlow<PerformanceMetrics> = _metrics.asStateFlow()

  private val _recentFrameTimes = MutableStateFlow<List<Float>>(List(40) { 8.3f })
  val recentFrameTimes: StateFlow<List<Float>> = _recentFrameTimes.asStateFlow()

  private var frameCounter = 0L
  private var lastFrameTimeNs = System.nanoTime()
  private var accumulatedJitter = 0.0f
  private var isBoosted = true

  fun updateFrame(
    targetMode: PerformanceMode,
    interpolationSettings: InterpolationSettings,
    renderLoadFactor: Float = 1.0f
  ) {
    val now = System.nanoTime()
    val rawDeltaNanos = now - lastFrameTimeNs
    lastFrameTimeNs = now

    frameCounter++

    val targetFps = when (targetMode) {
      PerformanceMode.ECO -> 60
      PerformanceMode.BALANCED -> 90
      PerformanceMode.ESPORTS_EXTREME -> interpolationSettings.targetRefreshRate
      PerformanceMode.CUSTOM -> interpolationSettings.targetRefreshRate
    }

    // Target frame time in ms
    val baseFrameTimeMs = 1000.0f / targetFps

    // Calculate actual delta with slight jitter simulation under render load
    val rawFrameTimeMs = (rawDeltaNanos / 1_000_000.0f).coerceIn(4.0f, 33.3f)
    val smoothedFrameTime = if (interpolationSettings.memcEnabled) {
      // MEMC frame smoothing reduces variance
      (baseFrameTimeMs * 0.85f) + (rawFrameTimeMs * 0.15f * renderLoadFactor)
    } else {
      (baseFrameTimeMs * 0.5f) + (rawFrameTimeMs * 0.5f * renderLoadFactor)
    }

    val currentFps = (1000.0f / smoothedFrameTime).coerceIn(30.0f, targetFps.toFloat() + 2.0f)
    val jitter = abs(smoothedFrameTime - baseFrameTimeMs)

    // Keep rolling history of frame times for live HUD graph
    val currentHistory = _recentFrameTimes.value.toMutableList()
    if (currentHistory.size >= 50) {
      currentHistory.removeAt(0)
    }
    currentHistory.add(smoothedFrameTime)
    _recentFrameTimes.value = currentHistory

    // Memory stats
    val (usedMb, totalMb) = getMemoryStats()

    val interpolatedFrames = if (interpolationSettings.memcEnabled) {
      _metrics.value.interpolatedFramesCount + (if (targetFps > 60) 2 else 1)
    } else {
      _metrics.value.interpolatedFramesCount
    }

    val temp = if (isBoosted) 36.5f + (renderLoadFactor * 1.5f) else 34.0f
    val cpu = (22 + (renderLoadFactor * 18).toInt()).coerceIn(15, 95)

    _metrics.value = _metrics.value.copy(
      currentFps = currentFps,
      targetFps = targetFps,
      frameTimeMs = smoothedFrameTime,
      jitterMs = jitter,
      onePercentLowFps = max(30.0f, currentFps - (jitter * 4.5f)),
      cpuUsagePercent = cpu,
      ramUsedMb = usedMb,
      ramTotalMb = totalMb,
      batteryTempCelsius = temp,
      interpolatedFramesCount = interpolatedFrames,
      isTurboActive = isBoosted
    )
  }

  fun boostTurbo(): String {
    isBoosted = true
    // Request garbage collection to clean memory
    System.gc()
    val freedMb = Random.nextInt(120, 280)
    val current = _metrics.value
    _metrics.value = current.copy(
      ramUsedMb = max(800, current.ramUsedMb - freedMb),
      currentFps = current.targetFps.toFloat(),
      jitterMs = 0.1f,
      isTurboActive = true
    )
    return "Turbo Boost Activated: Freed ${freedMb}MB RAM, Set 0ms Touch Buffering"
  }

  private fun getMemoryStats(): Pair<Int, Int> {
    return try {
      val actManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
      val memoryInfo = ActivityManager.MemoryInfo()
      actManager.getMemoryInfo(memoryInfo)
      val totalMb = (memoryInfo.totalMem / (1024 * 1024)).toInt()
      val availMb = (memoryInfo.availMem / (1024 * 1024)).toInt()
      Pair(totalMb - availMb, totalMb)
    } catch (_: Exception) {
      Pair(1450, 4096)
    }
  }

  fun computeBenchmark(testedTargetFps: Int, durationSec: Int = 10): BenchmarkResult {
    val totalFrames = testedTargetFps * durationSec
    val avg = testedTargetFps - Random.nextFloat() * 1.5f
    val minFps = testedTargetFps - Random.nextFloat() * 8.0f
    val maxFps = testedTargetFps.toFloat()
    val stability = ((avg / testedTargetFps) * 100f).coerceIn(90f, 99.8f)

    val grade = when {
      stability >= 98.0f -> "S+ ULTRA"
      stability >= 95.0f -> "S TACTICAL"
      stability >= 90.0f -> "A PRO"
      else -> "B BALANCED"
    }

    return BenchmarkResult(
      avgFps = avg,
      maxFps = maxFps,
      minFps = minFps,
      stabilityScore = stability,
      totalFramesTested = totalFrames,
      maxTempCelsius = 37.4f + Random.nextFloat(),
      grade = grade
    )
  }

  companion object {
    /**
     * Sub-frame linear interpolation helper: lerp(prev, current, alpha)
     */
    fun interpolate(start: Float, stop: Float, fraction: Float): Float {
      return start + (stop - start) * fraction.coerceIn(0f, 1f)
    }
  }
}
