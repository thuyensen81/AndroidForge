package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface GameProfileDao {

  @Query("SELECT * FROM game_profiles ORDER BY lastUpdatedTimestamp DESC")
  fun getAllProfiles(): Flow<List<GameProfileEntity>>

  @Query("SELECT * FROM game_profiles WHERE isBuiltIn = 1 ORDER BY lastUpdatedTimestamp DESC")
  fun getBuiltInProfiles(): Flow<List<GameProfileEntity>>

  @Query("SELECT * FROM game_profiles WHERE isBuiltIn = 0 ORDER BY lastUpdatedTimestamp DESC")
  fun getCustomInstalledProfiles(): Flow<List<GameProfileEntity>>

  @Query("SELECT * FROM game_profiles WHERE id = :id LIMIT 1")
  suspend fun getProfileById(id: String): GameProfileEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertProfile(profile: GameProfileEntity)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertProfiles(profiles: List<GameProfileEntity>)

  @Update
  suspend fun updateProfile(profile: GameProfileEntity)

  @Delete
  suspend fun deleteProfile(profile: GameProfileEntity)

  @Query("DELETE FROM game_profiles WHERE id = :id")
  suspend fun deleteProfileById(id: String)

  @Query("SELECT COUNT(*) FROM game_profiles")
  suspend fun countProfiles(): Int

  @Query("UPDATE game_profiles SET highScore = :score, playCount = playCount + 1, lastUpdatedTimestamp = :timestamp WHERE id = :id")
  suspend fun updateScoreAndPlayCount(id: String, score: Long, timestamp: Long = System.currentTimeMillis())
}
