package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.model.ColorFilterMode
import com.example.model.GraphicSettings
import com.example.model.InterpolationSettings
import com.example.model.PerformanceMode
import com.example.model.TouchSettings

@Entity(tableName = "game_profiles")
data class GameProfileEntity(
  @PrimaryKey
  val id: String, // unique id or package name e.g. "com.activision.codm" or "cyber_racer"
  val gameTitle: String,
  val packageName: String,
  val genre: String,
  val isBuiltIn: Boolean = false,
  val bannerResId: Int? = null,

  // Performance Governor Settings
  val performanceMode: String = "ESPORTS_EXTREME", // ECO, BALANCED, ESPORTS_EXTREME, CUSTOM
  val targetRefreshRate: Int = 120, // 60, 90, 120, 144
  val memcEnabled: Boolean = true,
  val smoothingMultiplier: Float = 0.85f,
  val adaptiveFramePacing: Boolean = true,
  val dynamicVsync: Boolean = true,
  val lowLatencyMode: Boolean = true,

  // Fine-Tuned Graphics Settings
  val resolutionScale: Float = 1.0f, // 0.75f, 1.0f, 1.25f, 1.5f
  val neonBloom: Boolean = true,
  val bloomIntensity: Float = 0.8f,
  val hdrContrast: Boolean = true,
  val motionBlur: Boolean = true,
  val motionBlurIntensity: Float = 0.5f,
  val antiAliasing: Boolean = true,
  val particleDensity: Float = 1.0f,
  val colorFilterMode: String = "VIVID_NEON",

  // Touch & Responsiveness Settings
  val touchSamplingRateHz: Int = 360, // 120, 240, 360, 480
  val touchSensitivity: Float = 1.5f,
  val deadzonePercent: Float = 2.0f,
  val instantTouchDispatch: Boolean = true,
  val edgeFilterEnabled: Boolean = true,
  val hapticFeedbackMode: String = "Crisp Gaming",
  val hapticIntensity: Float = 0.75f,

  // Metadata
  val highScore: Long = 0L,
  val playCount: Int = 0,
  val lastUpdatedTimestamp: Long = System.currentTimeMillis()
) {
  fun toGraphicSettings(): GraphicSettings {
    val filter = try {
      ColorFilterMode.valueOf(colorFilterMode)
    } catch (_: Exception) {
      ColorFilterMode.VIVID_NEON
    }
    return GraphicSettings(
      resolutionScale = resolutionScale,
      neonBloom = neonBloom,
      bloomIntensity = bloomIntensity,
      hdrContrast = hdrContrast,
      motionBlur = motionBlur,
      motionBlurIntensity = motionBlurIntensity,
      antiAliasing = antiAliasing,
      particleDensity = particleDensity,
      colorFilter = filter
    )
  }

  fun toTouchSettings(): TouchSettings {
    return TouchSettings(
      touchSamplingRateHz = touchSamplingRateHz,
      touchSensitivity = touchSensitivity,
      deadzonePercent = deadzonePercent,
      instantTouchDispatch = instantTouchDispatch,
      edgeFilterEnabled = edgeFilterEnabled,
      hapticFeedbackMode = hapticFeedbackMode,
      hapticIntensity = hapticIntensity
    )
  }

  fun toInterpolationSettings(): InterpolationSettings {
    return InterpolationSettings(
      memcEnabled = memcEnabled,
      targetRefreshRate = targetRefreshRate,
      smoothingMultiplier = smoothingMultiplier,
      adaptiveFramePacing = adaptiveFramePacing,
      dynamicVsync = dynamicVsync,
      lowLatencyMode = lowLatencyMode
    )
  }

  fun toPerformanceMode(): PerformanceMode {
    return try {
      PerformanceMode.valueOf(performanceMode)
    } catch (_: Exception) {
      PerformanceMode.ESPORTS_EXTREME
    }
  }
}
