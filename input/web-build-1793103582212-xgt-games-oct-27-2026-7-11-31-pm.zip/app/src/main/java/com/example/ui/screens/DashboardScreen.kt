package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.GameProfileEntity
import com.example.model.GraphicSettings
import com.example.model.InterpolationSettings
import com.example.model.PerformanceMetrics
import com.example.model.PerformanceMode
import com.example.model.TouchSettings
import com.example.ui.animation.bouncyClickable
import com.example.ui.components.CyberSwitchCard
import com.example.ui.components.FrameGraphView
import com.example.ui.components.PerformanceGauge
import com.example.ui.components.TurboBoostButton
import com.example.ui.theme.XgtAmberBoost
import com.example.ui.theme.XgtDarkSurface
import com.example.ui.theme.XgtElectricPurple
import com.example.ui.theme.XgtMatrixGreen
import com.example.ui.theme.XgtNeonCyan
import com.example.ui.theme.XgtNeonMagenta
import com.example.ui.theme.XgtSurfaceHighlight
import com.example.ui.theme.XgtSurfaceVariant
import com.example.ui.theme.XgtTextMuted
import com.example.ui.theme.XgtTextPrimary
import com.example.ui.theme.XgtTextSecondary
import java.util.Locale

@Composable
fun DashboardScreen(
  performanceMode: PerformanceMode,
  metrics: PerformanceMetrics,
  frameHistory: List<Float>,
  graphicSettings: GraphicSettings,
  touchSettings: TouchSettings,
  interpolationSettings: InterpolationSettings,
  gameProfiles: List<GameProfileEntity>,
  showFpsOverlay: Boolean,
  boostToastMessage: String?,
  onModeSelected: (PerformanceMode) -> Unit,
  onBoostClick: () -> Unit,
  onToggleFpsOverlay: () -> Unit,
  onLaunchGame: (String) -> Unit,
  onNavigateTab: (Int) -> Unit
) {
  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp),
    contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp)
  ) {
    // Top Brand & Header
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = "XGT",
              color = XgtNeonCyan,
              fontSize = 26.sp,
              fontWeight = FontWeight.Black,
              letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "GAMES",
              color = XgtTextPrimary,
              fontSize = 26.sp,
              fontWeight = FontWeight.Black,
              letterSpacing = 1.sp
            )
          }
          Text(
            text = "Extreme Game Turbo & Frame Smoothing Engine",
            color = XgtTextSecondary,
            fontSize = 11.sp
          )
        }

        Box(
          modifier = Modifier
            .background(
              brush = Brush.horizontalGradient(listOf(Color(0xFF131D30), Color(0xFF1C2840))),
              shape = RoundedCornerShape(20.dp)
            )
            .border(
              1.dp,
              Brush.linearGradient(listOf(XgtNeonCyan.copy(alpha = 0.5f), XgtElectricPurple.copy(alpha = 0.4f))),
              RoundedCornerShape(20.dp)
            )
            .padding(horizontal = 12.dp, vertical = 6.dp)
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(8.dp)
                .background(XgtMatrixGreen, CircleShape)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "144Hz READY",
              color = XgtNeonCyan,
              fontSize = 11.sp,
              fontWeight = FontWeight.Black,
              fontFamily = FontFamily.Monospace
            )
          }
        }
      }
    }

    // Animated Boost Notification Banner
    item {
      AnimatedVisibility(
        visible = boostToastMessage != null,
        enter = fadeIn() + expandVertically(),
        exit = fadeOut() + shrinkVertically()
      ) {
        if (boostToastMessage != null) {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .background(
                brush = Brush.horizontalGradient(listOf(Color(0x3300FFA3), Color(0x3300F0FF))),
                shape = RoundedCornerShape(16.dp)
              )
              .border(
                1.dp,
                Brush.linearGradient(listOf(XgtMatrixGreen, XgtNeonCyan)),
                RoundedCornerShape(16.dp)
              )
              .padding(14.dp)
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .size(32.dp)
                  .background(XgtMatrixGreen.copy(alpha = 0.2f), CircleShape),
                contentAlignment = Alignment.Center
              ) {
                Icon(Icons.Default.Bolt, contentDescription = null, tint = XgtMatrixGreen, modifier = Modifier.size(20.dp))
              }
              Spacer(modifier = Modifier.width(10.dp))
              Text(
                text = boostToastMessage,
                color = XgtTextPrimary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                lineHeight = 16.sp
              )
            }
          }
        }
      }
    }

    // Speedometer Performance Gauge
    item {
      PerformanceGauge(metrics = metrics)
    }

    // One-Tap Turbo Boost Button
    item {
      TurboBoostButton(onClick = onBoostClick)
    }

    // Performance Mode Selection with Spring Animations
    item {
      Column {
        Text(
          text = "PERFORMANCE GOVERNOR PROFILE",
          color = XgtTextPrimary,
          fontSize = 13.sp,
          fontWeight = FontWeight.Black,
          letterSpacing = 1.sp
        )
        Spacer(modifier = Modifier.height(10.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          PerformanceMode.values().forEach { mode ->
            val isSelected = performanceMode == mode
            val accent = when (mode) {
              PerformanceMode.ECO -> XgtAmberBoost
              PerformanceMode.BALANCED -> XgtNeonCyan
              PerformanceMode.ESPORTS_EXTREME -> XgtMatrixGreen
              PerformanceMode.CUSTOM -> XgtNeonMagenta
            }

            val scale by animateFloatAsState(
              targetValue = if (isSelected) 1.04f else 1.0f,
              animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
              label = "mode_scale"
            )

            Box(
              modifier = Modifier
                .weight(1f)
                .scale(scale)
                .background(
                  brush = Brush.verticalGradient(
                    listOf(
                      if (isSelected) accent.copy(alpha = 0.18f) else Color(0xFF101726),
                      if (isSelected) accent.copy(alpha = 0.05f) else Color(0xFF0C101A)
                    )
                  ),
                  shape = RoundedCornerShape(16.dp)
                )
                .border(
                  width = if (isSelected) 1.5.dp else 1.dp,
                  brush = if (isSelected) {
                    Brush.linearGradient(listOf(accent, Color.White.copy(alpha = 0.6f), accent))
                  } else {
                    Brush.linearGradient(listOf(Color(0xFF1E283D), Color(0xFF151C2A)))
                  },
                  shape = RoundedCornerShape(16.dp)
                )
                .bouncyClickable { onModeSelected(mode) }
                .padding(vertical = 12.dp, horizontal = 6.dp)
                .testTag("mode_${mode.name.lowercase()}"),
              contentAlignment = Alignment.Center
            ) {
              Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                  text = mode.title,
                  color = if (isSelected) accent else XgtTextSecondary,
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  maxLines = 1
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                  text = "${mode.targetFps} Hz",
                  color = if (isSelected) XgtTextPrimary else XgtTextMuted,
                  fontSize = 13.sp,
                  fontWeight = FontWeight.Black,
                  fontFamily = FontFamily.Monospace
                )
              }
            }
          }
        }
      }
    }

    // Frame Time Jitter Graph
    item {
      FrameGraphView(
        frameTimesMs = frameHistory,
        targetRefreshRate = metrics.targetFps
      )
    }

    // Playable Games Carousel with Parallax / Shimmer Cards
    item {
      Column {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "XGT ENHANCED GAMES",
            color = XgtTextPrimary,
            fontSize = 13.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 1.sp
          )
          Text(
            text = "120Hz & MEMC Ready",
            color = XgtNeonCyan,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold
          )
        }
        Spacer(modifier = Modifier.height(10.dp))

        LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
          items(gameProfiles) { profile ->
            GameCard(profile = profile, onLaunch = { onLaunchGame(profile.id) })
          }
        }
      }
    }

    // Quick Feature Toggles
    item {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
          text = "HIGH-FIDELITY HARDWARE TOGGLES",
          color = XgtTextPrimary,
          fontSize = 13.sp,
          fontWeight = FontWeight.Black,
          letterSpacing = 1.sp
        )

        CyberSwitchCard(
          title = "Floating FPS & Jitter HUD",
          subtitle = "In-game real-time diagnostics overlay with one-tap booster",
          checked = showFpsOverlay,
          onCheckedChange = { onToggleFpsOverlay() },
          icon = Icons.Default.Speed,
          accentColor = XgtNeonCyan
        )

        CyberSwitchCard(
          title = "MEMC Frame Interpolation (2X)",
          subtitle = "Sub-frame motion estimation, doubling refresh rate to silky 120Hz",
          checked = interpolationSettings.memcEnabled,
          onCheckedChange = { onNavigateTab(3) },
          icon = Icons.Default.Bolt,
          accentColor = XgtMatrixGreen
        )

        CyberSwitchCard(
          title = "480Hz Ultra-Touch Response",
          subtitle = "Zero-buffer touch dispatch with sub-millisecond input response",
          checked = touchSettings.touchSamplingRateHz == 480,
          onCheckedChange = { onNavigateTab(2) },
          icon = Icons.Default.TouchApp,
          accentColor = XgtNeonMagenta
        )
      }
    }
  }
}

@Composable
private fun GameCard(
  profile: GameProfileEntity,
  onLaunch: () -> Unit
) {
  Box(
    modifier = Modifier
      .width(260.dp)
      .shadow(12.dp, RoundedCornerShape(20.dp), spotColor = XgtNeonCyan.copy(alpha = 0.2f))
      .background(
        brush = Brush.verticalGradient(listOf(Color(0xFF111726), Color(0xFF090D15))),
        shape = RoundedCornerShape(20.dp)
      )
      .border(
        width = 1.2.dp,
        brush = Brush.linearGradient(
          listOf(
            XgtNeonCyan.copy(alpha = 0.5f),
            Color(0x22FFFFFF),
            XgtElectricPurple.copy(alpha = 0.4f)
          )
        ),
        shape = RoundedCornerShape(20.dp)
      )
      .clip(RoundedCornerShape(20.dp))
      .bouncyClickable { onLaunch() }
      .testTag("game_card_${profile.id}")
  ) {
    Column {
      // Banner
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(130.dp)
          .background(XgtSurfaceVariant)
      ) {
        if (profile.bannerResId != null) {
          Image(
            painter = painterResource(id = profile.bannerResId),
            contentDescription = profile.gameTitle,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
          )
        } else {
          Box(
            modifier = Modifier
              .fillMaxSize()
              .background(
                Brush.linearGradient(listOf(Color(0xFF160F30), Color(0xFF281140), Color(0xFF0F2027)))
              ),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.Gamepad,
              contentDescription = null,
              tint = XgtNeonCyan,
              modifier = Modifier.size(48.dp)
            )
          }
        }

        // FPS Badge over banner
        Box(
          modifier = Modifier
            .padding(10.dp)
            .background(Color(0xE60A0E18), RoundedCornerShape(8.dp))
            .border(1.dp, XgtNeonCyan.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)
            .align(Alignment.TopEnd)
        ) {
          Text(
            text = "${profile.targetRefreshRate} FPS TURBO",
            color = XgtNeonCyan,
            fontSize = 9.sp,
            fontWeight = FontWeight.Black,
            fontFamily = FontFamily.Monospace
          )
        }
      }

      // Details & Play Button
      Column(modifier = Modifier.padding(14.dp)) {
        Text(
          text = profile.gameTitle,
          color = XgtTextPrimary,
          fontSize = 15.sp,
          fontWeight = FontWeight.Bold
        )
        Text(
          text = profile.genre,
          color = XgtTextSecondary,
          fontSize = 11.sp
        )

        Spacer(modifier = Modifier.height(12.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text("BEST SCORE", color = XgtTextMuted, fontSize = 8.sp, fontWeight = FontWeight.Bold)
            Text(
              text = String.format(Locale.US, "%,d", profile.highScore),
              color = XgtMatrixGreen,
              fontSize = 13.sp,
              fontWeight = FontWeight.ExtraBold,
              fontFamily = FontFamily.Monospace
            )
          }

          Box(
            modifier = Modifier
              .background(
                Brush.horizontalGradient(listOf(XgtNeonCyan, Color(0xFF00B0FF))),
                RoundedCornerShape(10.dp)
              )
              .padding(horizontal = 14.dp, vertical = 7.dp)
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Default.PlayArrow,
                contentDescription = "Play",
                tint = Color(0xFF090C12),
                modifier = Modifier.size(15.dp)
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = "PLAY",
                color = Color(0xFF090C12),
                fontSize = 12.sp,
                fontWeight = FontWeight.Black
              )
            }
          }
        }
      }
    }
  }
}
