package com.example.ai

data class AiTuningRecommendation(
  val gameTitle: String,
  val recommendedRefreshRate: Int, // 60, 90, 120, 144
  val recommendedTouchPollingRate: Int, // 120, 240, 360, 480
  val recommendedSensitivity: Float, // 0.5f to 3.0f
  val recommendedDeadzone: Float, // 0% to 15%
  val recommendedResolutionScale: Float, // 0.75f, 1.0f, 1.25f, 1.5f
  val recommendedMemc: Boolean,
  val tuningReasoning: String,
  val proTips: List<String>
)

sealed interface AiUiState {
  data object Idle : AiUiState
  data object Loading : AiUiState
  data class SuccessRecommendation(val recommendation: AiTuningRecommendation) : AiUiState
  data class StreamingAdvice(val text: String) : AiUiState
  data class Error(val message: String) : AiUiState
}
