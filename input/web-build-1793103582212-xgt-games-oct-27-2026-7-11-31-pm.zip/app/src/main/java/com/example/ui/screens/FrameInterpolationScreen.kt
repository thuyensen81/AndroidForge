package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.DisplaySettings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.BenchmarkResult
import com.example.model.InterpolationSettings
import com.example.model.PerformanceMetrics
import com.example.ui.animation.bouncyClickable
import com.example.ui.components.CyberSlider
import com.example.ui.components.CyberSwitchCard
import com.example.ui.theme.XgtAmberBoost
import com.example.ui.theme.XgtDarkSurface
import com.example.ui.theme.XgtMatrixGreen
import com.example.ui.theme.XgtNeonCyan
import com.example.ui.theme.XgtNeonMagenta
import com.example.ui.theme.XgtSurfaceHighlight
import com.example.ui.theme.XgtTextMuted
import com.example.ui.theme.XgtTextPrimary
import com.example.ui.theme.XgtTextSecondary
import java.util.Locale
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive

@Composable
fun FrameInterpolationScreen(
  settings: InterpolationSettings,
  metrics: PerformanceMetrics,
  isBenchmarking: Boolean,
  benchmarkResult: BenchmarkResult?,
  onSettingsChanged: (InterpolationSettings) -> Unit,
  onRunBenchmark: () -> Unit
) {
  val refreshRates = listOf(60, 90, 120, 144)

  var rawBallX by remember { mutableFloatStateOf(0.1f) }
  var interpolatedBallX by remember { mutableFloatStateOf(0.1f) }
  var direction by remember { mutableFloatStateOf(1.0f) }

  // Visual comparison simulation loop
  LaunchedEffect(Unit) {
    var rawTick = 0
    while (isActive) {
      rawTick++
      if (rawTick >= 4) {
        rawTick = 0
        rawBallX += 0.08f * direction
        if (rawBallX > 0.9f) {
          rawBallX = 0.9f
          direction = -1.0f
        } else if (rawBallX < 0.1f) {
          rawBallX = 0.1f
          direction = 1.0f
        }
      }

      interpolatedBallX += (rawBallX - interpolatedBallX) * (if (settings.memcEnabled) settings.smoothingMultiplier else 0.25f)
      delay(16L)
    }
  }

  val infiniteTransition = rememberInfiniteTransition(label = "bench_glow")
  val benchPulse by infiniteTransition.animateFloat(
    initialValue = 0.96f,
    targetValue = 1.04f,
    animationSpec = infiniteRepeatable(
      animation = tween(800, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "bench_pulse"
  )

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .padding(horizontal = 16.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp),
    contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp)
  ) {
    item {
      Column {
        Text(
          text = "FRAME INTERPOLATION & MEMC",
          color = XgtNeonCyan,
          fontSize = 18.sp,
          fontWeight = FontWeight.Black,
          letterSpacing = 1.sp
        )
        Text(
          text = "Motion estimation & frame generation for silky 120Hz/144Hz fluidity",
          color = XgtTextSecondary,
          fontSize = 11.sp
        )
      }
    }

    // Live Motion Comparison Demo Canvas (Raw vs Interpolated)
    item {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .background(XgtDarkSurface, RoundedCornerShape(20.dp))
          .border(
            width = 1.dp,
            brush = Brush.linearGradient(listOf(XgtMatrixGreen.copy(alpha = 0.5f), Color(0x22FFFFFF), XgtNeonCyan.copy(alpha = 0.3f))),
            shape = RoundedCornerShape(20.dp)
          )
          .padding(16.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "LIVE MOTION COMPARISON DEMO",
            color = XgtMatrixGreen,
            fontSize = 12.sp,
            fontWeight = FontWeight.Black
          )
          Text(
            text = if (settings.memcEnabled) "MEMC 2X ACTIVE" else "MEMC OFF",
            color = if (settings.memcEnabled) XgtMatrixGreen else Color(0xFF64748B),
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
          )
        }

        Spacer(modifier = Modifier.height(12.dp))

        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(135.dp)
            .background(Color(0xFF070B14), RoundedCornerShape(14.dp))
            .border(1.dp, Color(0xFF1B2436), RoundedCornerShape(14.dp))
            .clip(RoundedCornerShape(14.dp))
            .testTag("memc_comparison_canvas_box")
        ) {
          Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height

            // Top lane: Raw Un-interpolated 30/60fps
            val topLaneY = h * 0.3f
            drawLine(
              color = Color(0x33FF9E00),
              start = Offset(0f, topLaneY),
              end = Offset(w, topLaneY),
              strokeWidth = 1.dp.toPx()
            )
            drawCircle(
              color = XgtAmberBoost,
              radius = 12.dp.toPx(),
              center = Offset(rawBallX * w, topLaneY)
            )

            // Bottom lane: MEMC 120Hz Interpolated smooth motion
            val bottomLaneY = h * 0.72f
            drawLine(
              color = Color(0x3300FF9D),
              start = Offset(0f, bottomLaneY),
              end = Offset(w, bottomLaneY),
              strokeWidth = 1.dp.toPx()
            )
            // Motion blur trail
            drawCircle(
              color = XgtNeonCyan.copy(alpha = 0.35f),
              radius = 14.dp.toPx(),
              center = Offset((interpolatedBallX - (0.015f * direction)) * w, bottomLaneY)
            )
            drawCircle(
              color = XgtMatrixGreen,
              radius = 12.dp.toPx(),
              center = Offset(interpolatedBallX * w, bottomLaneY)
            )
          }

          // Labels on canvas
          Text(
            text = "RAW 30/60 FPS (MICRO-STUTTERS)",
            color = XgtAmberBoost,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier
              .align(Alignment.TopStart)
              .padding(8.dp)
          )

          Text(
            text = "XGT MEMC 120/144 FPS (INTERPOLATED)",
            color = XgtMatrixGreen,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier
              .align(Alignment.BottomStart)
              .padding(8.dp)
          )
        }
      }
    }

    // Refresh Rate Switcher with Spring Scaling
    item {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .background(XgtDarkSurface, RoundedCornerShape(20.dp))
          .border(1.dp, Color(0xFF1E283D), RoundedCornerShape(20.dp))
          .padding(16.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text("DISPLAY REFRESH TARGET", color = XgtTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Black)
          Text(
            text = "${settings.targetRefreshRate} Hz",
            color = XgtNeonCyan,
            fontSize = 13.sp,
            fontWeight = FontWeight.Black,
            fontFamily = FontFamily.Monospace
          )
        }

        Spacer(modifier = Modifier.height(14.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          refreshRates.forEach { hz ->
            val isSelected = settings.targetRefreshRate == hz
            val hzScale by animateFloatAsState(
              targetValue = if (isSelected) 1.05f else 1.0f,
              animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
              label = "hz_scale"
            )

            Box(
              modifier = Modifier
                .weight(1f)
                .scale(hzScale)
                .background(
                  brush = Brush.verticalGradient(
                    listOf(
                      if (isSelected) XgtNeonCyan.copy(alpha = 0.2f) else Color(0xFF0F1522),
                      if (isSelected) XgtNeonCyan.copy(alpha = 0.05f) else Color(0xFF0B101A)
                    )
                  ),
                  shape = RoundedCornerShape(12.dp)
                )
                .border(
                  width = if (isSelected) 1.5.dp else 1.dp,
                  color = if (isSelected) XgtNeonCyan else Color(0xFF1E283D),
                  shape = RoundedCornerShape(12.dp)
                )
                .bouncyClickable { onSettingsChanged(settings.copy(targetRefreshRate = hz)) }
                .padding(vertical = 12.dp),
              contentAlignment = Alignment.Center
            ) {
              Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                  text = "${hz}Hz",
                  color = if (isSelected) XgtNeonCyan else XgtTextSecondary,
                  fontSize = 13.sp,
                  fontWeight = FontWeight.Black,
                  fontFamily = FontFamily.Monospace
                )
                Text(
                  text = String.format(Locale.US, "%.1fms", 1000f / hz),
                  color = if (isSelected) XgtMatrixGreen else XgtTextMuted,
                  fontSize = 9.sp,
                  fontWeight = FontWeight.Bold
                )
              }
            }
          }
        }
      }
    }

    // Frame Interpolation Multiplier Slider
    item {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .background(XgtDarkSurface, RoundedCornerShape(20.dp))
          .border(1.dp, Color(0xFF1E283D), RoundedCornerShape(20.dp))
          .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
      ) {
        Text("FRAME PACING & SMOOTHING MULTIPLIER", color = XgtTextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Black)

        CyberSlider(
          label = "Motion Estimation Smoothing",
          valueText = String.format(Locale.US, "%.2f LERP", settings.smoothingMultiplier),
          value = settings.smoothingMultiplier,
          onValueChange = { onSettingsChanged(settings.copy(smoothingMultiplier = it)) },
          valueRange = 0.2f..0.95f,
          accentColor = XgtMatrixGreen
        )
      }
    }

    // Toggles for MEMC, Pacing & VSync
    item {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        CyberSwitchCard(
          title = "MEMC Frame Generation",
          subtitle = "Interpolates intermediate frames to double perceived framerate",
          checked = settings.memcEnabled,
          onCheckedChange = { onSettingsChanged(settings.copy(memcEnabled = it)) },
          icon = Icons.Default.Bolt,
          accentColor = XgtMatrixGreen
        )

        CyberSwitchCard(
          title = "Adaptive Frame Pacing",
          subtitle = "Maintains consistent frame-time deltas to eliminate micro-jitter",
          checked = settings.adaptiveFramePacing,
          onCheckedChange = { onSettingsChanged(settings.copy(adaptiveFramePacing = it)) },
          icon = Icons.Default.Sync,
          accentColor = XgtNeonCyan
        )

        CyberSwitchCard(
          title = "Low-Latency Dynamic VSync",
          subtitle = "Synchronizes presentation with panel refresh with 0 display lag",
          checked = settings.dynamicVsync,
          onCheckedChange = { onSettingsChanged(settings.copy(dynamicVsync = it)) },
          icon = Icons.Default.DisplaySettings,
          accentColor = XgtNeonMagenta
        )
      }
    }

    // Hardware Stress Test Benchmark with Animated Reveal
    item {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .background(XgtDarkSurface, RoundedCornerShape(20.dp))
          .border(
            width = 1.dp,
            brush = Brush.linearGradient(listOf(XgtAmberBoost.copy(alpha = 0.5f), Color(0x22FFFFFF), XgtNeonCyan.copy(alpha = 0.3f))),
            shape = RoundedCornerShape(20.dp)
          )
          .padding(16.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column {
            Text(
              text = "GRAPHICS & FRAME STABILITY BENCHMARK",
              color = XgtAmberBoost,
              fontSize = 12.sp,
              fontWeight = FontWeight.Black,
              letterSpacing = 0.8.sp
            )
            Text(
              text = "Runs a high-load physics & rendering stress test",
              color = XgtTextMuted,
              fontSize = 10.sp
            )
          }

          Button(
            onClick = onRunBenchmark,
            enabled = !isBenchmarking,
            colors = ButtonDefaults.buttonColors(containerColor = XgtAmberBoost),
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 7.dp),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
              .scale(if (isBenchmarking) benchPulse else 1.0f)
              .testTag("run_benchmark_btn")
          ) {
            if (isBenchmarking) {
              CircularProgressIndicator(
                modifier = Modifier.size(16.dp),
                color = Color(0xFF090D14),
                strokeWidth = 2.dp
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text("TESTING...", color = Color(0xFF090D14), fontSize = 11.sp, fontWeight = FontWeight.Black)
            } else {
              Icon(Icons.Default.Speed, contentDescription = null, tint = Color(0xFF090D14), modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("BENCHMARK", color = Color(0xFF090D14), fontSize = 11.sp, fontWeight = FontWeight.Black)
            }
          }
        }

        // Animated Benchmark Results Card with Spring scaleIn
        AnimatedVisibility(
          visible = benchmarkResult != null,
          enter = fadeIn() + scaleIn(spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow))
        ) {
          if (benchmarkResult != null) {
            Column {
              Spacer(modifier = Modifier.height(14.dp))
              Box(
                modifier = Modifier
                  .fillMaxWidth()
                  .background(
                    brush = Brush.verticalGradient(listOf(Color(0xFF0F1726), Color(0xFF0A0F1A))),
                    shape = RoundedCornerShape(16.dp)
                  )
                  .border(1.2.dp, XgtMatrixGreen.copy(alpha = 0.6f), RoundedCornerShape(16.dp))
                  .padding(14.dp)
              ) {
                Column {
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Text("BENCHMARK SCORECARD", color = XgtTextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Box(
                      modifier = Modifier
                        .background(XgtMatrixGreen.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                        .border(1.dp, XgtMatrixGreen.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                      Text(
                        text = benchmarkResult.grade,
                        color = XgtMatrixGreen,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace
                      )
                    }
                  }

                  Spacer(modifier = Modifier.height(12.dp))

                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                  ) {
                    Column {
                      Text("AVERAGE FPS", color = XgtTextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                      Text(
                        text = String.format(Locale.US, "%.1f", benchmarkResult.avgFps),
                        color = XgtNeonCyan,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace
                      )
                    }
                    Column {
                      Text("MIN FPS (1% LOW)", color = XgtTextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                      Text(
                        text = String.format(Locale.US, "%.1f", benchmarkResult.minFps),
                        color = XgtNeonMagenta,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace
                      )
                    }
                    Column {
                      Text("STABILITY", color = XgtTextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                      Text(
                        text = String.format(Locale.US, "%.1f%%", benchmarkResult.stabilityScore),
                        color = XgtMatrixGreen,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace
                      )
                    }
                    Column {
                      Text("MAX TEMP", color = XgtTextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                      Text(
                        text = String.format(Locale.US, "%.1f°C", benchmarkResult.maxTempCelsius),
                        color = XgtTextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace
                      )
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
