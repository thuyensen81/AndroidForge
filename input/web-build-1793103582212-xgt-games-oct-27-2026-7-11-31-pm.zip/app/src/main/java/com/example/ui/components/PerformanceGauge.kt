package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.PerformanceMetrics
import com.example.ui.animation.bouncyClickable
import com.example.ui.theme.XgtAmberBoost
import com.example.ui.theme.XgtDarkSurface
import com.example.ui.theme.XgtElectricPurple
import com.example.ui.theme.XgtGlassHighlight
import com.example.ui.theme.XgtMatrixGreen
import com.example.ui.theme.XgtNeonCyan
import com.example.ui.theme.XgtNeonMagenta
import com.example.ui.theme.XgtSurfaceHighlight
import com.example.ui.theme.XgtTextMuted
import com.example.ui.theme.XgtTextPrimary
import com.example.ui.theme.XgtTextSecondary
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun PerformanceGauge(
  metrics: PerformanceMetrics,
  modifier: Modifier = Modifier
) {
  val animatedFps by animateFloatAsState(
    targetValue = metrics.currentFps,
    animationSpec = spring(dampingRatio = 0.7f, stiffness = 140f),
    label = "fps_gauge"
  )

  val infiniteTransition = rememberInfiniteTransition(label = "gauge_halo")
  val haloPulse by infiniteTransition.animateFloat(
    initialValue = 0.5f,
    targetValue = 0.9f,
    animationSpec = infiniteRepeatable(
      animation = tween(1400, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "halo_pulse"
  )

  val rotationAngle by infiniteTransition.animateFloat(
    initialValue = 0f,
    targetValue = 360f,
    animationSpec = infiniteRepeatable(
      animation = tween(10000, easing = LinearEasing),
      repeatMode = RepeatMode.Restart
    ),
    label = "rotation"
  )

  val maxDisplayFps = 144f
  val progress = (animatedFps / maxDisplayFps).coerceIn(0f, 1f)

  Box(
    modifier = modifier
      .fillMaxWidth()
      .background(
        brush = Brush.verticalGradient(
          colors = listOf(
            Color(0xFF0F1524),
            Color(0xFF090D15)
          )
        ),
        shape = RoundedCornerShape(24.dp)
      )
      .border(
        width = 1.2.dp,
        brush = Brush.sweepGradient(
          colors = listOf(
            XgtNeonCyan.copy(alpha = 0.7f),
            XgtElectricPurple.copy(alpha = 0.3f),
            XgtNeonMagenta.copy(alpha = 0.6f),
            XgtNeonCyan.copy(alpha = 0.7f)
          )
        ),
        shape = RoundedCornerShape(24.dp)
      )
      .padding(18.dp)
      .testTag("performance_gauge_container"),
    contentAlignment = Alignment.Center
  ) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
      // Top status row with glowing status chip
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier
            .background(Color(0xFF131A2A), RoundedCornerShape(20.dp))
            .border(1.dp, if (metrics.isTurboActive) XgtMatrixGreen.copy(alpha = 0.4f) else XgtAmberBoost.copy(alpha = 0.4f), RoundedCornerShape(20.dp))
            .padding(horizontal = 10.dp, vertical = 4.dp)
        ) {
          Box(
            modifier = Modifier
              .size(8.dp)
              .scale(haloPulse)
              .background(if (metrics.isTurboActive) XgtMatrixGreen else XgtAmberBoost, CircleShape)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = if (metrics.isTurboActive) "HARDWARE OVERCLOCK" else "STANDARD MODE",
            color = if (metrics.isTurboActive) XgtMatrixGreen else XgtAmberBoost,
            fontSize = 10.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 1.sp
          )
        }

        Box(
          modifier = Modifier
            .background(
              Brush.horizontalGradient(listOf(XgtNeonCyan.copy(alpha = 0.15f), XgtElectricPurple.copy(alpha = 0.15f))),
              RoundedCornerShape(8.dp)
            )
            .border(1.dp, XgtNeonCyan.copy(alpha = 0.35f), RoundedCornerShape(8.dp))
            .padding(horizontal = 10.dp, vertical = 4.dp)
        ) {
          Text(
            text = "TARGET: ${metrics.targetFps} Hz",
            color = XgtNeonCyan,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
          )
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Modern Cyber Arc Tachometer Gauge Canvas
      Box(
        modifier = Modifier.size(220.dp, 135.dp),
        contentAlignment = Alignment.Center
      ) {
        Canvas(modifier = Modifier.size(210.dp)) {
          val strokeWidth = 14.dp.toPx()
          val startAngle = 145f
          val sweepAngle = 250f

          // Outer Track Ring
          drawArc(
            color = Color(0xFF151D2D),
            startAngle = startAngle,
            sweepAngle = sweepAngle,
            useCenter = false,
            style = Stroke(width = strokeWidth, cap = StrokeCap.Round),
            size = Size(size.width, size.height)
          )

          // Glowing Active Arc
          val activeSweep = sweepAngle * progress
          val gaugeBrush = Brush.sweepGradient(
            colors = listOf(
              XgtNeonCyan,
              XgtElectricPurple,
              XgtNeonMagenta,
              XgtMatrixGreen
            ),
            center = Offset(size.width / 2f, size.height / 2f)
          )

          drawArc(
            brush = gaugeBrush,
            startAngle = startAngle,
            sweepAngle = activeSweep,
            useCenter = false,
            style = Stroke(width = strokeWidth, cap = StrokeCap.Round),
            size = Size(size.width, size.height)
          )

          // Subtle ticks
          val tickCount = 15
          for (i in 0 until tickCount) {
            val angleDeg = startAngle + (sweepAngle / (tickCount - 1)) * i
            val rad = Math.toRadians(angleDeg.toDouble())
            val outerRadius = (size.width / 2f) - (strokeWidth / 2f) - 6.dp.toPx()
            val innerRadius = outerRadius - (if (i % 2 == 0) 7.dp.toPx() else 4.dp.toPx())
            val cx = size.width / 2f
            val cy = size.height / 2f
            val startX = cx + (innerRadius * cos(rad)).toFloat()
            val startY = cy + (innerRadius * sin(rad)).toFloat()
            val endX = cx + (outerRadius * cos(rad)).toFloat()
            val endY = cy + (outerRadius * sin(rad)).toFloat()

            drawLine(
              color = if (i.toFloat() / (tickCount - 1) <= progress) XgtNeonCyan.copy(alpha = 0.9f) else Color(0xFF263348),
              start = Offset(startX, startY),
              end = Offset(endX, endY),
              strokeWidth = if (i % 2 == 0) 2.5.dp.toPx() else 1.2.dp.toPx()
            )
          }
        }

        // Center Digital Display
        Column(
          horizontalAlignment = Alignment.CenterHorizontally,
          modifier = Modifier.padding(top = 22.dp)
        ) {
          Text(
            text = String.format(Locale.US, "%.1f", animatedFps),
            color = XgtTextPrimary,
            fontSize = 42.sp,
            fontWeight = FontWeight.Black,
            fontFamily = FontFamily.Monospace,
            letterSpacing = (-1.5).sp
          )
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(6.dp)
                .background(XgtNeonCyan, CircleShape)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = "FPS REFRESH",
              color = XgtNeonCyan,
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              letterSpacing = 1.5.sp
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // Glassmorphic Telemetry Cards Row
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .background(Color(0xFF080C14), RoundedCornerShape(16.dp))
          .border(1.dp, Color(0xFF1A2336), RoundedCornerShape(16.dp))
          .padding(vertical = 12.dp, horizontal = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        TelemetryCard(
          label = "FRAME LATENCY",
          value = String.format(Locale.US, "%.1f ms", metrics.frameTimeMs),
          accentColor = XgtNeonCyan
        )
        TelemetryCard(
          label = "JITTER DELTA",
          value = String.format(Locale.US, "%.2f ms", metrics.jitterMs),
          accentColor = if (metrics.jitterMs < 1.0f) XgtMatrixGreen else XgtAmberBoost
        )
        TelemetryCard(
          label = "1% LOW FPS",
          value = String.format(Locale.US, "%.0f", metrics.onePercentLowFps),
          accentColor = XgtNeonMagenta
        )
        TelemetryCard(
          label = "CHIP TEMP",
          value = String.format(Locale.US, "%.1f°C", metrics.batteryTempCelsius),
          accentColor = if (metrics.batteryTempCelsius < 40f) Color(0xFFE2E8F0) else XgtAmberBoost
        )
      }
    }
  }
}

@Composable
private fun TelemetryCard(
  label: String,
  value: String,
  accentColor: Color
) {
  Column(horizontalAlignment = Alignment.CenterHorizontally) {
    Text(
      text = label,
      color = XgtTextMuted,
      fontSize = 9.sp,
      fontWeight = FontWeight.ExtraBold,
      letterSpacing = 0.5.sp
    )
    Spacer(modifier = Modifier.height(3.dp))
    Text(
      text = value,
      color = accentColor,
      fontSize = 13.sp,
      fontWeight = FontWeight.Black,
      fontFamily = FontFamily.Monospace
    )
  }
}
