package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.animation.bouncyClickable
import com.example.ui.games.CyberRacerGame
import com.example.ui.games.QuantumStrikerGame
import com.example.ui.games.ReflexBladeGame
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.FrameInterpolationScreen
import com.example.ui.screens.GamesHubScreen
import com.example.ui.screens.GraphicsScreen
import com.example.ui.screens.TouchScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.XgtMatrixGreen
import com.example.ui.theme.XgtNeonCyan
import com.example.ui.theme.XgtNeonMagenta
import com.example.ui.theme.XgtObsidian
import com.example.ui.theme.XgtTextMuted
import com.example.ui.theme.XgtTextPrimary
import com.example.viewmodel.XgtViewModel

class MainActivity : ComponentActivity() {

  private val viewModel: XgtViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    setContent {
      MyApplicationTheme {
        XgtApp(viewModel = viewModel)
      }
    }
  }
}

@Composable
fun XgtApp(viewModel: XgtViewModel) {
  val activeGame by viewModel.activeGame.collectAsState()
  val performanceMode by viewModel.performanceMode.collectAsState()
  val graphicSettings by viewModel.graphicSettings.collectAsState()
  val touchSettings by viewModel.touchSettings.collectAsState()
  val interpolationSettings by viewModel.interpolationSettings.collectAsState()
  val metrics by viewModel.metrics.collectAsState()
  val frameHistory by viewModel.frameHistory.collectAsState()
  val touchCalibration by viewModel.touchCalibration.collectAsState()
  val profiles by viewModel.persistedProfiles.collectAsState()
  val showFpsOverlay by viewModel.showFpsOverlay.collectAsState()
  val boostToastMessage by viewModel.boostToastMessage.collectAsState()
  val isBenchmarking by viewModel.isBenchmarking.collectAsState()
  val benchmarkResult by viewModel.benchmarkResult.collectAsState()

  var selectedTab by remember { mutableIntStateOf(0) }

  // If a game is actively running, render immersive game canvas
  if (activeGame != null) {
    when (activeGame) {
      "cyber_racer" -> {
        CyberRacerGame(
          graphicSettings = graphicSettings,
          touchSettings = touchSettings,
          interpolationSettings = interpolationSettings,
          metrics = metrics,
          onExit = { viewModel.exitGame() },
          onBoost = { viewModel.triggerTurboBoost() },
          onSaveScore = { score -> viewModel.saveGameScore("cyber_racer", score) }
        )
      }
      "quantum_striker" -> {
        QuantumStrikerGame(
          graphicSettings = graphicSettings,
          touchSettings = touchSettings,
          interpolationSettings = interpolationSettings,
          metrics = metrics,
          onExit = { viewModel.exitGame() },
          onBoost = { viewModel.triggerTurboBoost() },
          onSaveScore = { score -> viewModel.saveGameScore("quantum_striker", score) }
        )
      }
      "reflex_blade" -> {
        ReflexBladeGame(
          touchSettings = touchSettings,
          metrics = metrics,
          onExit = { viewModel.exitGame() },
          onBoost = { viewModel.triggerTurboBoost() },
          onSaveScore = { score -> viewModel.saveGameScore("reflex_blade", score) }
        )
      }
    }
    return
  }

  Scaffold(
    modifier = Modifier.fillMaxSize(),
    containerColor = XgtObsidian,
    bottomBar = {
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .windowInsetsPadding(WindowInsets.navigationBars)
          .padding(horizontal = 14.dp, vertical = 10.dp)
      ) {
        // Modern Floating Cyber Dock
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .height(68.dp)
            .shadow(24.dp, RoundedCornerShape(26.dp), spotColor = XgtNeonCyan.copy(alpha = 0.3f))
            .background(
              brush = Brush.verticalGradient(
                listOf(
                  Color(0xE6121929),
                  Color(0xF50A0E18)
                )
              ),
              shape = RoundedCornerShape(26.dp)
            )
            .border(
              width = 1.2.dp,
              brush = Brush.linearGradient(
                listOf(
                  Color(0x4000F0FF),
                  Color(0x1AFFFFFF),
                  Color(0x33FF0055)
                )
              ),
              shape = RoundedCornerShape(26.dp)
            )
            .padding(horizontal = 6.dp),
          horizontalArrangement = Arrangement.SpaceAround,
          verticalAlignment = Alignment.CenterVertically
        ) {
          CyberDockItem(
            label = "Turbo",
            icon = Icons.Default.Speed,
            selected = selectedTab == 0,
            activeColor = XgtNeonCyan,
            onClick = { selectedTab = 0 },
            testTag = "nav_tab_turbo"
          )

          CyberDockItem(
            label = "Graphics",
            icon = Icons.Default.Tune,
            selected = selectedTab == 1,
            activeColor = XgtNeonMagenta,
            onClick = { selectedTab = 1 },
            testTag = "nav_tab_graphics"
          )

          CyberDockItem(
            label = "Touch",
            icon = Icons.Default.TouchApp,
            selected = selectedTab == 2,
            activeColor = XgtMatrixGreen,
            onClick = { selectedTab = 2 },
            testTag = "nav_tab_touch"
          )

          CyberDockItem(
            label = "MEMC",
            icon = Icons.Default.Bolt,
            selected = selectedTab == 3,
            activeColor = XgtNeonCyan,
            onClick = { selectedTab = 3 },
            testTag = "nav_tab_memc"
          )

          CyberDockItem(
            label = "Arcade",
            icon = Icons.Default.Gamepad,
            selected = selectedTab == 4,
            activeColor = XgtNeonMagenta,
            onClick = { selectedTab = 4 },
            testTag = "nav_tab_games"
          )
        }
      }
    }
  ) { innerPadding ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
    ) {
      // Fluid Animated Content Transition between tabs
      AnimatedContent(
        targetState = selectedTab,
        transitionSpec = {
          if (targetState > initialState) {
            (slideInHorizontally(animationSpec = spring(stiffness = Spring.StiffnessMediumLow)) { width -> width / 4 } +
              fadeIn(animationSpec = tween(240))) togetherWith
              (slideOutHorizontally(animationSpec = spring(stiffness = Spring.StiffnessMediumLow)) { width -> -width / 4 } +
                fadeOut(animationSpec = tween(180)))
          } else {
            (slideInHorizontally(animationSpec = spring(stiffness = Spring.StiffnessMediumLow)) { width -> -width / 4 } +
              fadeIn(animationSpec = tween(240))) togetherWith
              (slideOutHorizontally(animationSpec = spring(stiffness = Spring.StiffnessMediumLow)) { width -> width / 4 } +
                fadeOut(animationSpec = tween(180)))
          }
        },
        label = "tab_animated_transition"
      ) { tabIndex ->
        when (tabIndex) {
          0 -> DashboardScreen(
            performanceMode = performanceMode,
            metrics = metrics,
            frameHistory = frameHistory,
            graphicSettings = graphicSettings,
            touchSettings = touchSettings,
            interpolationSettings = interpolationSettings,
            gameProfiles = profiles,
            showFpsOverlay = showFpsOverlay,
            boostToastMessage = boostToastMessage,
            onModeSelected = { viewModel.setPerformanceMode(it) },
            onBoostClick = { viewModel.triggerTurboBoost() },
            onToggleFpsOverlay = { viewModel.toggleFpsOverlay() },
            onLaunchGame = { viewModel.launchGame(it) },
            onNavigateTab = { selectedTab = it }
          )
          1 -> GraphicsScreen(
            settings = graphicSettings,
            onSettingsChanged = { viewModel.updateGraphics(it) }
          )
          2 -> TouchScreen(
            settings = touchSettings,
            calibrationState = touchCalibration,
            onSettingsChanged = { viewModel.updateTouch(it) },
            onTouchCalibration = { viewModel.registerTouchCalibration(it) },
            onResetCalibration = { viewModel.resetTouchCalibration() }
          )
          3 -> FrameInterpolationScreen(
            settings = interpolationSettings,
            metrics = metrics,
            isBenchmarking = isBenchmarking,
            benchmarkResult = benchmarkResult,
            onSettingsChanged = { viewModel.updateInterpolation(it) },
            onRunBenchmark = { viewModel.runBenchmark() }
          )
          4 -> GamesHubScreen(
            profiles = profiles,
            metrics = metrics,
            onLaunchGame = { viewModel.launchGame(it) },
            onApplyProfile = { viewModel.applyProfile(it) },
            onUpdateProfile = { viewModel.updateGameProfile(it) },
            onSaveNewProfile = { name, pkg, genre ->
              viewModel.saveCurrentSettingsAsProfile(name, pkg, genre)
            },
            onDeleteProfile = { viewModel.deleteProfile(it) }
          )
        }
      }
    }
  }
}

@Composable
private fun CyberDockItem(
  label: String,
  icon: ImageVector,
  selected: Boolean,
  activeColor: Color,
  onClick: () -> Unit,
  testTag: String
) {
  val iconScale by animateFloatAsState(
    targetValue = if (selected) 1.15f else 1.0f,
    animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
    label = "dock_scale"
  )

  Box(
    modifier = Modifier
      .clip(RoundedCornerShape(18.dp))
      .background(if (selected) activeColor.copy(alpha = 0.16f) else Color.Transparent)
      .border(
        width = 1.dp,
        color = if (selected) activeColor.copy(alpha = 0.4f) else Color.Transparent,
        shape = RoundedCornerShape(18.dp)
      )
      .bouncyClickable { onClick() }
      .padding(horizontal = 14.dp, vertical = 6.dp)
      .testTag(testTag),
    contentAlignment = Alignment.Center
  ) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
      Icon(
        imageVector = icon,
        contentDescription = label,
        tint = if (selected) activeColor else XgtTextMuted,
        modifier = Modifier
          .size(22.dp)
          .scale(iconScale)
      )
      Spacer(modifier = Modifier.height(2.dp))
      Text(
        text = label,
        color = if (selected) activeColor else XgtTextMuted,
        fontSize = 10.sp,
        fontWeight = if (selected) FontWeight.Black else FontWeight.Medium
      )
    }
  }
}
