package com.example.ui.games

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.PerformanceMetrics
import com.example.model.TouchSettings
import com.example.ui.components.FpsOverlayBar
import com.example.ui.theme.XgtMatrixGreen
import com.example.ui.theme.XgtNeonCyan
import com.example.ui.theme.XgtNeonMagenta
import com.example.ui.theme.XgtTextMuted
import com.example.ui.theme.XgtTextPrimary
import java.util.Locale
import kotlin.math.hypot
import kotlin.random.Random
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive

private data class ReflexTarget(
  val id: Int,
  val x: Float, // 0.1 to 0.9
  val y: Float, // 0.2 to 0.8
  var radius: Float = 0f,
  val maxRadius: Float = 55f,
  var isHit: Boolean = false,
  val spawnTimeMs: Long = System.currentTimeMillis()
)

@Composable
fun ReflexBladeGame(
  touchSettings: TouchSettings,
  metrics: PerformanceMetrics,
  onExit: () -> Unit,
  onBoost: () -> Unit,
  onSaveScore: (Long) -> Unit
) {
  BackHandler { onExit() }

  var score by remember { mutableLongStateOf(0L) }
  var streak by remember { mutableIntStateOf(0) }
  var bestMs by remember { mutableIntStateOf(999) }
  var lastReactionMs by remember { mutableIntStateOf(0) }
  var lives by remember { mutableIntStateOf(3) }
  var isGameOver by remember { mutableStateOf(false) }

  val targets = remember { mutableStateListOf<ReflexTarget>() }
  var targetCounter by remember { mutableIntStateOf(0) }

  LaunchedEffect(isGameOver) {
    if (isGameOver) return@LaunchedEffect

    targets.clear()

    while (isActive && !isGameOver) {
      // Spawn targets
      if (targets.size < 4 && Random.nextFloat() < 0.35f) {
        targetCounter++
        targets.add(
          ReflexTarget(
            id = targetCounter,
            x = Random.nextFloat() * 0.75f + 0.12f,
            y = Random.nextFloat() * 0.6f + 0.2f,
            radius = 10f,
            maxRadius = 50f + Random.nextFloat() * 15f
          )
        )
      }

      // Update existing targets
      val iter = targets.listIterator()
      while (iter.hasNext()) {
        val t = iter.next()
        t.radius += 1.2f
        if (t.radius >= t.maxRadius) {
          // Missed target!
          iter.remove()
          streak = 0
          lives--
          if (lives <= 0) {
            isGameOver = true
            onSaveScore(score)
            break
          }
        }
      }

      delay(16L)
    }
  }

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF070B14))
  ) {
    Canvas(
      modifier = Modifier
        .fillMaxSize()
        .pointerInput(touchSettings) {
          detectTapGestures { tapOffset ->
            val w = size.width
            val h = size.height

            // Check if any target was tapped
            val iter = targets.listIterator()
            var hit = false
            while (iter.hasNext()) {
              val t = iter.next()
              val tx = t.x * w
              val ty = t.y * h
              val dist = hypot(tapOffset.x - tx, tapOffset.y - ty)
              val hitRadiusPx = (t.maxRadius + 12f).dp.toPx()

              if (dist <= hitRadiusPx) {
                hit = true
                val reaction = (System.currentTimeMillis() - t.spawnTimeMs).toInt()
                lastReactionMs = reaction
                if (reaction < bestMs) bestMs = reaction

                streak++
                val accuracyBonus = ((1f - (t.radius / t.maxRadius)) * 300).toLong()
                score += 150L + accuracyBonus + (streak * 20L)
                iter.remove()
                break
              }
            }

            if (!hit) {
              streak = 0
            }
          }
        }
        .testTag("reflex_blade_canvas")
    ) {
      val w = size.width
      val h = size.height

      // Background Cyber Matrix Grid
      val gridSize = 40.dp.toPx()
      var x = 0f
      while (x <= w) {
        drawLine(
          color = Color(0x1500E5FF),
          start = Offset(x, 0f),
          end = Offset(x, h),
          strokeWidth = 1.dp.toPx()
        )
        x += gridSize
      }
      var y = 0f
      while (y <= h) {
        drawLine(
          color = Color(0x1500E5FF),
          start = Offset(0f, y),
          end = Offset(w, y),
          strokeWidth = 1.dp.toPx()
        )
        y += gridSize
      }

      // Draw Targets
      targets.forEach { t ->
        val tx = t.x * w
        val ty = t.y * h
        val currentRPx = t.radius.dp.toPx()
        val maxRPx = t.maxRadius.dp.toPx()

        // Outer shrinking boundary ring
        drawCircle(
          color = XgtNeonCyan.copy(alpha = 0.5f),
          radius = maxRPx,
          center = Offset(tx, ty),
          style = Stroke(width = 2.dp.toPx())
        )

        // Growing target core
        drawCircle(
          color = if (t.radius / t.maxRadius > 0.8f) Color(0xFFFF3366) else XgtNeonMagenta,
          radius = currentRPx,
          center = Offset(tx, ty)
        )

        // Center crosshair
        drawLine(
          color = Color.White,
          start = Offset(tx - 6.dp.toPx(), ty),
          end = Offset(tx + 6.dp.toPx(), ty),
          strokeWidth = 2.dp.toPx()
        )
        drawLine(
          color = Color.White,
          start = Offset(tx, ty - 6.dp.toPx()),
          end = Offset(tx, ty + 6.dp.toPx()),
          strokeWidth = 2.dp.toPx()
        )
      }
    }

    // Top Header & Overlay
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(top = 40.dp, start = 16.dp, end = 16.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        IconButton(
          onClick = onExit,
          modifier = Modifier.background(Color(0x80101522), CircleShape)
        ) {
          Icon(Icons.Default.ArrowBack, contentDescription = "Exit", tint = XgtTextPrimary)
        }

        FpsOverlayBar(
          metrics = metrics,
          isMemcActive = true,
          onBoostClick = onBoost
        )
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Reflex Telemetry readout
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .background(Color(0x990A0E18), RoundedCornerShape(12.dp))
          .padding(horizontal = 14.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text("REACTION TIME", color = XgtTextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
          Text(
            text = if (lastReactionMs > 0) "${lastReactionMs}ms" else "-- ms",
            color = if (lastReactionMs in 1..220) XgtMatrixGreen else XgtNeonCyan,
            fontSize = 18.sp,
            fontWeight = FontWeight.Black,
            fontFamily = FontFamily.Monospace
          )
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Text("SCORE", color = XgtTextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
          Text(
            text = String.format(Locale.US, "%,d", score),
            color = XgtTextPrimary,
            fontSize = 18.sp,
            fontWeight = FontWeight.Black,
            fontFamily = FontFamily.Monospace
          )
        }

        Column(horizontalAlignment = Alignment.End) {
          Text("LIVES", color = XgtTextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
          Row {
            for (i in 1..3) {
              Text(
                text = if (i <= lives) "♥ " else "♡ ",
                color = if (i <= lives) Color(0xFFFF2A6D) else XgtTextMuted,
                fontSize = 16.sp
              )
            }
          }
        }
      }
    }

    // Game Over Overlay
    AnimatedVisibility(
      visible = isGameOver,
      modifier = Modifier.align(Alignment.Center)
    ) {
      Box(
        modifier = Modifier
          .padding(24.dp)
          .background(Color(0xF2090D14), RoundedCornerShape(20.dp))
          .border(1.5.dp, XgtNeonMagenta, RoundedCornerShape(20.dp))
          .padding(24.dp),
        contentAlignment = Alignment.Center
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Text(
            text = "REFLEX SESSION COMPLETE",
            color = XgtNeonCyan,
            fontSize = 18.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 1.sp
          )
          Spacer(modifier = Modifier.height(12.dp))
          Text(
            text = "FINAL SCORE: ${String.format(Locale.US, "%,d", score)}",
            color = XgtTextPrimary,
            fontSize = 22.sp,
            fontWeight = FontWeight.ExtraBold,
            fontFamily = FontFamily.Monospace
          )
          if (bestMs < 999) {
            Text(
              text = "PEAK REACTION: ${bestMs}ms",
              color = XgtMatrixGreen,
              fontSize = 14.sp,
              fontWeight = FontWeight.Bold
            )
          }
          Spacer(modifier = Modifier.height(20.dp))
          Row {
            Button(
              onClick = {
                score = 0
                lives = 3
                streak = 0
                isGameOver = false
              },
              colors = ButtonDefaults.buttonColors(containerColor = XgtNeonCyan),
              modifier = Modifier.testTag("restart_reflex_btn")
            ) {
              Icon(Icons.Default.Refresh, contentDescription = null, tint = Color(0xFF090D14))
              Spacer(modifier = Modifier.width(6.dp))
              Text("RETRY", color = Color(0xFF090D14), fontWeight = FontWeight.Bold)
            }

            Spacer(modifier = Modifier.width(12.dp))

            Button(
              onClick = onExit,
              colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E283D))
            ) {
              Text("HUB", color = XgtTextPrimary, fontWeight = FontWeight.Bold)
            }
          }
        }
      }
    }
  }
}
