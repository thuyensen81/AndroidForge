package com.example.data.repository

import com.example.data.local.GameProfileDao
import com.example.data.local.GameProfileEntity
import kotlinx.coroutines.flow.Flow

class GameProfileRepository(private val dao: GameProfileDao) {

  val allProfiles: Flow<List<GameProfileEntity>> = dao.getAllProfiles()
  val builtInProfiles: Flow<List<GameProfileEntity>> = dao.getBuiltInProfiles()
  val customProfiles: Flow<List<GameProfileEntity>> = dao.getCustomInstalledProfiles()

  suspend fun getProfileById(id: String): GameProfileEntity? {
    return dao.getProfileById(id)
  }

  suspend fun saveProfile(profile: GameProfileEntity) {
    dao.insertProfile(profile)
  }

  suspend fun deleteProfileById(id: String) {
    dao.deleteProfileById(id)
  }

  suspend fun updateScore(id: String, score: Long) {
    dao.updateScoreAndPlayCount(id, score)
  }

  suspend fun countProfiles(): Int {
    return dao.countProfiles()
  }
}
