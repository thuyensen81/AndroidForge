package com.example.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val XgtDarkColorScheme = darkColorScheme(
  primary = XgtNeonCyan,
  onPrimary = XgtObsidian,
  primaryContainer = XgtSurfaceHighlight,
  onPrimaryContainer = XgtNeonCyan,
  secondary = XgtNeonMagenta,
  onSecondary = XgtObsidian,
  secondaryContainer = XgtSurfaceVariant,
  onSecondaryContainer = XgtNeonMagenta,
  tertiary = XgtMatrixGreen,
  onTertiary = XgtObsidian,
  background = XgtObsidian,
  onBackground = XgtTextPrimary,
  surface = XgtDarkSurface,
  onSurface = XgtTextPrimary,
  surfaceVariant = XgtSurfaceVariant,
  onSurfaceVariant = XgtTextSecondary,
  outline = XgtBorder,
  error = XgtError
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true, // Gaming app defaults to cyber dark theme
  dynamicColor: Boolean = false, // Keep consistent cyber branded look
  content: @Composable () -> Unit,
) {
  val colorScheme = XgtDarkColorScheme

  val view = LocalView.current
  if (!view.isInEditMode) {
    SideEffect {
      val window = (view.context as? Activity)?.window
      if (window != null) {
        window.statusBarColor = XgtObsidian.toArgb()
        window.navigationBarColor = XgtObsidian.toArgb()
        WindowCompat.getInsetsController(window, view).apply {
          isAppearanceLightStatusBars = false
          isAppearanceLightNavigationBars = false
        }
      }
    }
  }

  MaterialTheme(
    colorScheme = colorScheme,
    typography = Typography,
    content = content
  )
}
