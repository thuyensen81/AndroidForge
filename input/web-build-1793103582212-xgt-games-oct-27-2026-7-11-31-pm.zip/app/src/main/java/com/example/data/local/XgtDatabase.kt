package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.R
import java.util.concurrent.Executors

@Database(entities = [GameProfileEntity::class], version = 1, exportSchema = false)
abstract class XgtDatabase : RoomDatabase() {

  abstract fun gameProfileDao(): GameProfileDao

  companion object {
    @Volatile
    private var INSTANCE: XgtDatabase? = null

    fun getInstance(context: Context): XgtDatabase {
      return INSTANCE ?: synchronized(this) {
        val instance = Room.databaseBuilder(
          context.applicationContext,
          XgtDatabase::class.java,
          "xgt_games.db"
        )
          .addCallback(object : Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
              super.onCreate(db)
              Executors.newSingleThreadExecutor().execute {
                INSTANCE?.let { database ->
                  seedInitialProfiles(database.gameProfileDao())
                }
              }
            }
          })
          .fallbackToDestructiveMigration(false)
          .build()
        INSTANCE = instance
        instance
      }
    }

    private fun seedInitialProfiles(dao: GameProfileDao) {
      val initialProfiles = listOf(
        // Built-in Game Profiles
        GameProfileEntity(
          id = "cyber_racer",
          gameTitle = "Neon Velocity",
          packageName = "com.xgt.cyberracer",
          genre = "Cyber High-Speed Racer",
          isBuiltIn = true,
          bannerResId = R.drawable.xgt_neon_racer_1793031873995,
          performanceMode = "ESPORTS_EXTREME",
          targetRefreshRate = 120,
          memcEnabled = true,
          smoothingMultiplier = 0.85f,
          resolutionScale = 1.25f,
          neonBloom = true,
          motionBlur = true,
          motionBlurIntensity = 0.6f,
          touchSamplingRateHz = 480,
          touchSensitivity = 1.8f,
          deadzonePercent = 2.0f,
          hapticFeedbackMode = "Heavy Rumble",
          hapticIntensity = 0.8f,
          highScore = 84500L,
          playCount = 14
        ),
        GameProfileEntity(
          id = "quantum_striker",
          gameTitle = "Quantum Striker",
          packageName = "com.xgt.quantumstriker",
          genre = "Arcade Space Combat",
          isBuiltIn = true,
          bannerResId = R.drawable.xgt_space_striker_1793031873128,
          performanceMode = "ESPORTS_EXTREME",
          targetRefreshRate = 120,
          memcEnabled = true,
          smoothingMultiplier = 0.8f,
          resolutionScale = 1.0f,
          neonBloom = true,
          particleDensity = 1.5f,
          touchSamplingRateHz = 360,
          touchSensitivity = 1.5f,
          deadzonePercent = 1.5f,
          hapticFeedbackMode = "Crisp Gaming",
          hapticIntensity = 0.75f,
          highScore = 124000L,
          playCount = 9
        ),
        GameProfileEntity(
          id = "reflex_blade",
          gameTitle = "Reflex Matrix",
          packageName = "com.xgt.reflexblade",
          genre = "Sub-Millisecond Tap & Slice",
          isBuiltIn = true,
          bannerResId = null,
          performanceMode = "ESPORTS_EXTREME",
          targetRefreshRate = 144,
          memcEnabled = true,
          smoothingMultiplier = 0.95f,
          touchSamplingRateHz = 480,
          touchSensitivity = 2.0f,
          deadzonePercent = 0.0f,
          hapticFeedbackMode = "Crisp Gaming",
          highScore = 98200L,
          playCount = 6
        ),
        // Installed Popular Titles Pre-Configured Overclock Profiles
        GameProfileEntity(
          id = "com.activision.callofduty.shooter",
          gameTitle = "Call of Duty: Mobile",
          packageName = "com.activision.callofduty.shooter",
          genre = "Tactical FPS Esports",
          isBuiltIn = false,
          bannerResId = null,
          performanceMode = "ESPORTS_EXTREME",
          targetRefreshRate = 144,
          memcEnabled = true,
          smoothingMultiplier = 0.9f,
          adaptiveFramePacing = true,
          dynamicVsync = true,
          lowLatencyMode = true,
          resolutionScale = 1.0f,
          neonBloom = false,
          hdrContrast = true,
          antiAliasing = true,
          colorFilterMode = "ESPORTS_CLARITY",
          touchSamplingRateHz = 480,
          touchSensitivity = 2.2f,
          deadzonePercent = 1.0f,
          instantTouchDispatch = true,
          edgeFilterEnabled = true,
          hapticFeedbackMode = "Crisp Gaming",
          hapticIntensity = 0.85f,
          highScore = 0L,
          playCount = 0
        ),
        GameProfileEntity(
          id = "com.tencent.ig",
          gameTitle = "PUBG Mobile / BGMI",
          packageName = "com.tencent.ig",
          genre = "Competitive Battle Royale",
          isBuiltIn = false,
          bannerResId = null,
          performanceMode = "ESPORTS_EXTREME",
          targetRefreshRate = 120,
          memcEnabled = true,
          smoothingMultiplier = 0.85f,
          resolutionScale = 1.25f,
          hdrContrast = true,
          colorFilterMode = "ESPORTS_CLARITY",
          touchSamplingRateHz = 480,
          touchSensitivity = 2.0f,
          deadzonePercent = 1.0f,
          hapticFeedbackMode = "Crisp Gaming",
          highScore = 0L,
          playCount = 0
        ),
        GameProfileEntity(
          id = "com.miHoYo.GenshinImpact",
          gameTitle = "Genshin Impact",
          packageName = "com.miHoYo.GenshinImpact",
          genre = "Open World Action RPG",
          isBuiltIn = false,
          bannerResId = null,
          performanceMode = "BALANCED",
          targetRefreshRate = 90,
          memcEnabled = true,
          smoothingMultiplier = 0.75f,
          resolutionScale = 1.25f,
          neonBloom = true,
          bloomIntensity = 0.9f,
          hdrContrast = true,
          colorFilterMode = "CINEMATIC_WARM",
          particleDensity = 1.5f,
          touchSamplingRateHz = 240,
          touchSensitivity = 1.3f,
          deadzonePercent = 3.0f,
          hapticFeedbackMode = "Subtle Click",
          highScore = 0L,
          playCount = 0
        ),
        GameProfileEntity(
          id = "com.gameloft.android.ANMP.GloftA9HM",
          gameTitle = "Asphalt 9: Legends",
          packageName = "com.gameloft.android.ANMP.GloftA9HM",
          genre = "Arcade Hyper-Racer",
          isBuiltIn = false,
          bannerResId = null,
          performanceMode = "ESPORTS_EXTREME",
          targetRefreshRate = 120,
          memcEnabled = true,
          smoothingMultiplier = 0.85f,
          resolutionScale = 1.25f,
          neonBloom = true,
          motionBlur = true,
          motionBlurIntensity = 0.7f,
          colorFilterMode = "VIVID_NEON",
          touchSamplingRateHz = 360,
          touchSensitivity = 1.6f,
          hapticFeedbackMode = "Heavy Rumble",
          hapticIntensity = 0.9f,
          highScore = 0L,
          playCount = 0
        )
      )

      kotlinx.coroutines.runBlocking {
        dao.insertProfiles(initialProfiles)
      }
    }
  }
}
