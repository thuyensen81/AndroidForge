package com.example.engine

import androidx.compose.ui.geometry.Offset
import com.example.model.TouchSettings
import kotlin.math.hypot

data class TouchPointInfo(
  val id: Int,
  val position: Offset,
  val pressure: Float = 1.0f,
  val timestampNs: Long = System.nanoTime()
)

data class TouchCalibrationState(
  val lastTouchPosition: Offset = Offset.Zero,
  val simulatedLatencyMs: Float = 4.2f,
  val touchesDetected: Int = 0,
  val gestureVelocityPxPerMs: Float = 0.0f,
  val targetHitCount: Int = 0,
  val touchPoints: List<TouchPointInfo> = emptyList()
)

class TouchResponseManager(
  private val hapticHelper: HapticFeedbackHelper
) {

  fun applySensitivityAndDeadzone(
    rawDelta: Float,
    settings: TouchSettings,
    maxDimension: Float
  ): Float {
    val deadzonePx = (settings.deadzonePercent / 100f) * maxDimension
    if (kotlin.math.abs(rawDelta) < deadzonePx) {
      return 0.0f
    }
    val adjustedDelta = if (rawDelta > 0) rawDelta - deadzonePx else rawDelta + deadzonePx
    return adjustedDelta * settings.touchSensitivity
  }

  fun calculateLatencyMs(samplingRateHz: Int, instantDispatch: Boolean): Float {
    val baseHardwareLatency = 1000f / samplingRateHz
    val dispatchBuffer = if (instantDispatch) 0.5f else 2.5f
    return baseHardwareLatency + dispatchBuffer
  }

  fun onTouchInput(
    points: List<TouchPointInfo>,
    currentState: TouchCalibrationState,
    settings: TouchSettings
  ): TouchCalibrationState {
    val latency = calculateLatencyMs(settings.touchSamplingRateHz, settings.instantTouchDispatch)
    
    // Calculate gesture velocity
    var velocity = 0.0f
    if (points.isNotEmpty() && currentState.touchPoints.isNotEmpty()) {
      val p1 = currentState.touchPoints.first().position
      val p2 = points.first().position
      val dist = hypot(p2.x - p1.x, p2.y - p1.y)
      val timeDeltaMs = (points.first().timestampNs - currentState.touchPoints.first().timestampNs) / 1_000_000f
      if (timeDeltaMs > 0) {
        velocity = dist / timeDeltaMs
      }
    }

    if (points.isNotEmpty()) {
      hapticHelper.triggerTactile(settings.hapticFeedbackMode, settings.hapticIntensity)
    }

    return currentState.copy(
      lastTouchPosition = points.firstOrNull()?.position ?: currentState.lastTouchPosition,
      simulatedLatencyMs = latency,
      touchesDetected = currentState.touchesDetected + points.size,
      gestureVelocityPxPerMs = velocity,
      touchPoints = points
    )
  }
}
