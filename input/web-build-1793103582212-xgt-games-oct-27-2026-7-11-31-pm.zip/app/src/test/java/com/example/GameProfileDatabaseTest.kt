package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.GameProfileDao
import com.example.data.local.GameProfileEntity
import com.example.data.local.XgtDatabase
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class GameProfileDatabaseTest {

  private lateinit var db: XgtDatabase
  private lateinit var dao: GameProfileDao

  @Before
  fun createDb() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    db = Room.inMemoryDatabaseBuilder(context, XgtDatabase::class.java)
      .allowMainThreadQueries()
      .build()
    dao = db.gameProfileDao()
  }

  @After
  fun closeDb() {
    db.close()
  }

  @Test
  fun insertAndRetrieveGameProfile() = runBlocking {
    val profile = GameProfileEntity(
      id = "com.ea.apex",
      gameTitle = "Apex Legends Mobile",
      packageName = "com.ea.apex",
      genre = "Battle Royale",
      isBuiltIn = false,
      performanceMode = "ESPORTS_EXTREME",
      targetRefreshRate = 144,
      memcEnabled = true,
      resolutionScale = 1.25f,
      touchSamplingRateHz = 480,
      touchSensitivity = 2.4f,
      deadzonePercent = 1.5f,
      hapticFeedbackMode = "Crisp Gaming"
    )

    dao.insertProfile(profile)

    val retrieved = dao.getProfileById("com.ea.apex")
    assertNotNull(retrieved)
    assertEquals("Apex Legends Mobile", retrieved?.gameTitle)
    assertEquals(144, retrieved?.targetRefreshRate)
    assertEquals(480, retrieved?.touchSamplingRateHz)
    assertEquals(2.4f, retrieved?.touchSensitivity)

    // Flow query check
    val all = dao.getAllProfiles().first()
    assertEquals(1, all.size)
    assertEquals("com.ea.apex", all[0].id)
  }

  @Test
  fun updateScoreAndPlayCount() = runBlocking {
    val profile = GameProfileEntity(
      id = "test_game",
      gameTitle = "Test Game",
      packageName = "com.test",
      genre = "Shooter"
    )
    dao.insertProfile(profile)

    dao.updateScoreAndPlayCount("test_game", 50000L)

    val updated = dao.getProfileById("test_game")
    assertEquals(50000L, updated?.highScore)
    assertEquals(1, updated?.playCount)
  }

  @Test
  fun deleteProfileById() = runBlocking {
    val profile = GameProfileEntity(
      id = "temp_game",
      gameTitle = "Temporary Game",
      packageName = "com.temp",
      genre = "Racing"
    )
    dao.insertProfile(profile)
    assertNotNull(dao.getProfileById("temp_game"))

    dao.deleteProfileById("temp_game")
    assertNull(dao.getProfileById("temp_game"))
  }
}
