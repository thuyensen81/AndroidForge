RAM Turbo Pro — AndroidForge layout repair

Fix applied: Android Gradle root files (settings.gradle and build.gradle) are now at the project root, and the app module is at ./app, matching the directory where AndroidForge invokes Gradle.

Important: this fixes the exact Gradle-root error from the supplied logs; it does not certify a successful APK build. The React/Vite app still needs to be built (`npm install`, `npm run build`) and the generated `dist/` contents copied to `app/src/main/assets/www/` before the APK will show the real React UI in WebView. The current assets folder contains a placeholder until that step is done.

The original GameTurboTab.tsx is preserved byte-for-byte. No `settings put global` or `settings put system` commands were added.

Build requirements: Android SDK/Gradle environment and network access to resolve Gradle/Maven dependencies. Verify build logs after uploading.
