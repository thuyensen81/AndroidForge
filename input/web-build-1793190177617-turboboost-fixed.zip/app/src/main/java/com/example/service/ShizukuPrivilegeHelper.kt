package com.example.service

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.util.Log
import com.example.model.ExecutionMode
import com.example.model.PrivilegeStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.lang.reflect.Method

/**
 * Lớp tiện ích chuyên biệt quản lý và xác thực quyền Shizuku / Root
 * trước khi tiến hành các tác vụ dọn dẹp RAM, xóa cache và tối ưu hóa hệ thống.
 */
class ShizukuPrivilegeHelper(private val context: Context) {

    companion object {
        private const val TAG = "ShizukuPrivilegeHelper"
        const val SHIZUKU_PACKAGE = "moe.shizuku.privileged.api"
        const val SHIZUKU_REQUEST_CODE = 2001
        const val TRIM_CACHES_CMD = "pm trim-caches 1024G"

        @Volatile
        private var INSTANCE: ShizukuPrivilegeHelper? = null

        fun getInstance(context: Context): ShizukuPrivilegeHelper {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: ShizukuPrivilegeHelper(context.applicationContext).also { INSTANCE = it }
            }
        }
    }

    sealed class ShizukuState {
        object NotInstalled : ShizukuState()
        object ServiceStopped : ShizukuState()
        object PermissionRequired : ShizukuState()
        data class Ready(val version: Int) : ShizukuState()
    }

    sealed class RootState {
        object NotAvailable : RootState()
        object BinaryFound : RootState()
        object Granted : RootState()
    }

    sealed class PreExecutionCheck {
        data class Verified(
            val resolvedMode: ExecutionMode,
            val message: String
        ) : PreExecutionCheck()

        data class ActionRequired(
            val targetMode: ExecutionMode,
            val title: String,
            val reason: String,
            val canRequestDirectly: Boolean,
            val needsExternalSetup: Boolean
        ) : PreExecutionCheck()
    }

    private val _privilegeStatus = MutableStateFlow(PrivilegeStatus())
    val privilegeStatus: StateFlow<PrivilegeStatus> = _privilegeStatus.asStateFlow()

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        refreshStatus()
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        refreshStatus()
    }

    private val permissionResultListener = Shizuku.OnRequestPermissionResultListener { requestCode, _ ->
        if (requestCode == SHIZUKU_REQUEST_CODE) {
            refreshStatus()
        }
    }

    init {
        registerListeners()
        refreshStatus()
    }

    private fun registerListeners() {
        try {
            Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
            Shizuku.addBinderDeadListener(binderDeadListener)
            Shizuku.addRequestPermissionResultListener(permissionResultListener)
        } catch (e: Throwable) {
            Log.w(TAG, "Không thể đăng ký listener Shizuku: ${e.message}")
        }
    }

    fun unregisterListeners() {
        try {
            Shizuku.removeBinderReceivedListener(binderReceivedListener)
            Shizuku.removeBinderDeadListener(binderDeadListener)
            Shizuku.removeRequestPermissionResultListener(permissionResultListener)
        } catch (e: Throwable) {
            Log.w(TAG, "Không thể hủy đăng ký listener Shizuku: ${e.message}")
        }
    }

    /**
     * Kiểm tra trạng thái hiện tại của Shizuku
     */
    fun checkShizukuState(): ShizukuState {
        if (!isPackageInstalled(SHIZUKU_PACKAGE)) {
            return ShizukuState.NotInstalled
        }

        val isRunning = try {
            Shizuku.pingBinder()
        } catch (_: Throwable) {
            false
        }

        if (!isRunning) {
            return ShizukuState.ServiceStopped
        }

        val isGranted = try {
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (_: Throwable) {
            false
        }

        return if (isGranted) {
            val ver = try { Shizuku.getVersion() } catch (_: Throwable) { 13 }
            ShizukuState.Ready(ver)
        } else {
            ShizukuState.PermissionRequired
        }
    }

    /**
     * Kiểm tra trạng thái quyền Root
     */
    fun checkRootState(): RootState {
        val rootFound = checkRootBinary()
        if (!rootFound) return RootState.NotAvailable

        val isGranted = checkRootPermissionGranted()
        return if (isGranted) RootState.Granted else RootState.BinaryFound
    }

    /**
     * Cập nhật toàn bộ trạng thái quyền cho UI
     */
    fun refreshStatus(): PrivilegeStatus {
        val shizukuState = checkShizukuState()
        val rootState = checkRootState()

        val isInstalled = shizukuState !is ShizukuState.NotInstalled
        val isRunning = shizukuState is ShizukuState.PermissionRequired || shizukuState is ShizukuState.Ready
        val isShizukuGranted = shizukuState is ShizukuState.Ready
        val version = if (shizukuState is ShizukuState.Ready) shizukuState.version else 0

        val isRootAvailable = rootState !is RootState.NotAvailable
        val isRootGranted = rootState is RootState.Granted

        val newStatus = _privilegeStatus.value.copy(
            isShizukuInstalled = isInstalled,
            isShizukuRunning = isRunning,
            isShizukuPermissionGranted = isShizukuGranted,
            shizukuVersion = version,
            isRootAvailable = isRootAvailable,
            isRootGranted = isRootGranted
        )
        _privilegeStatus.value = newStatus
        return newStatus
    }

    /**
     * Đặt chế độ thực thi đang dùng (Auto / Shizuku / Root / Tiêu chuẩn)
     */
    fun setActiveMode(mode: ExecutionMode) {
        _privilegeStatus.value = _privilegeStatus.value.copy(activeMode = mode)
    }

    /**
     * Kiểm tra và xác minh quyền truy cập Shizuku/Root TRƯỚC KHI chạy tác vụ tối ưu hóa
     */
    fun verifyBeforeTask(preferredMode: ExecutionMode = ExecutionMode.AUTO): PreExecutionCheck {
        val status = refreshStatus()

        return when (preferredMode) {
            ExecutionMode.SHIZUKU -> {
                when {
                    status.isShizukuPermissionGranted -> {
                        PreExecutionCheck.Verified(ExecutionMode.SHIZUKU, "Quyền Shizuku đã sẵn sàng.")
                    }
                    status.isShizukuRunning -> {
                        PreExecutionCheck.ActionRequired(
                            targetMode = ExecutionMode.SHIZUKU,
                            title = "Cần cấp quyền Shizuku",
                            reason = "Dịch vụ Shizuku đang chạy nhưng ứng dụng chưa được cấp quyền truy cập.",
                            canRequestDirectly = true,
                            needsExternalSetup = false
                        )
                    }
                    status.isShizukuInstalled -> {
                        PreExecutionCheck.ActionRequired(
                            targetMode = ExecutionMode.SHIZUKU,
                            title = "Dịch vụ Shizuku chưa chạy",
                            reason = "Ứng dụng Shizuku đã được cài nhưng dịch vụ chưa được khởi động.",
                            canRequestDirectly = false,
                            needsExternalSetup = true
                        )
                    }
                    else -> {
                        PreExecutionCheck.ActionRequired(
                            targetMode = ExecutionMode.SHIZUKU,
                            title = "Chưa cài đặt Shizuku",
                            reason = "Thiết bị chưa cài đặt Shizuku. Bạn cần cài từ CH Play hoặc chuyển sang Root/Tiêu chuẩn.",
                            canRequestDirectly = false,
                            needsExternalSetup = true
                        )
                    }
                }
            }
            ExecutionMode.ROOT -> {
                when {
                    status.isRootGranted -> {
                        PreExecutionCheck.Verified(ExecutionMode.ROOT, "Quyền Root (su) đã sẵn sàng.")
                    }
                    status.isRootAvailable -> {
                        PreExecutionCheck.ActionRequired(
                            targetMode = ExecutionMode.ROOT,
                            title = "Yêu cầu quyền Superuser",
                            reason = "Đã phát hiện môi trường Root nhưng chưa được người dùng phê duyệt qua Magisk/KernelSU.",
                            canRequestDirectly = true,
                            needsExternalSetup = false
                        )
                    }
                    else -> {
                        PreExecutionCheck.ActionRequired(
                            targetMode = ExecutionMode.ROOT,
                            title = "Không tìm thấy Root",
                            reason = "Thiết bị này không có quyền Root hoặc chưa được bẻ khóa.",
                            canRequestDirectly = false,
                            needsExternalSetup = true
                        )
                    }
                }
            }
            ExecutionMode.AUTO -> {
                when {
                    status.isShizukuPermissionGranted -> {
                        PreExecutionCheck.Verified(ExecutionMode.SHIZUKU, "Tự động chọn Shizuku (Đã cấp quyền).")
                    }
                    status.isRootGranted -> {
                        PreExecutionCheck.Verified(ExecutionMode.ROOT, "Tự động chọn Root (su) (Đã cấp quyền).")
                    }
                    status.isShizukuRunning -> {
                        PreExecutionCheck.ActionRequired(
                            targetMode = ExecutionMode.SHIZUKU,
                            title = "Cần phê duyệt Shizuku",
                            reason = "Shizuku đang hoạt động, hãy nhấn để cấp quyền cho TurboBoost.",
                            canRequestDirectly = true,
                            needsExternalSetup = false
                        )
                    }
                    status.isRootAvailable -> {
                        PreExecutionCheck.ActionRequired(
                            targetMode = ExecutionMode.ROOT,
                            title = "Cần phê duyệt Root",
                            reason = "Đã tìm thấy nhị phân su, hãy nhấn để cấp quyền Root.",
                            canRequestDirectly = true,
                            needsExternalSetup = false
                        )
                    }
                    else -> {
                        // Vẫn cho phép chạy ở chế độ tiêu chuẩn kết hợp cảnh báo
                        PreExecutionCheck.Verified(
                            ExecutionMode.STANDARD,
                            "Chế độ tiêu chuẩn (Không có quyền Shizuku/Root. Lệnh pm trim-caches có thể bị giới hạn)."
                        )
                    }
                }
            }
            ExecutionMode.STANDARD -> {
                PreExecutionCheck.Verified(ExecutionMode.STANDARD, "Chạy ở chế độ tiêu chuẩn.")
            }
        }
    }

    /**
     * Yêu cầu cấp quyền Shizuku
     */
    fun requestShizukuPermission(): Boolean {
        return try {
            if (!Shizuku.pingBinder()) {
                false
            } else {
                Shizuku.requestPermission(SHIZUKU_REQUEST_CODE)
                true
            }
        } catch (e: Throwable) {
            Log.e(TAG, "Lỗi khi gọi Shizuku.requestPermission", e)
            false
        }
    }

    /**
     * Yêu cầu cấp quyền Root (su)
     */
    suspend fun requestRootPermission(): Boolean = withContext(Dispatchers.IO) {
        try {
            val process = Runtime.getRuntime().exec(arrayOf("su", "-c", "id"))
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val output = reader.readText()
            process.waitFor()
            val granted = output.contains("uid=0(root)") || process.exitValue() == 0
            refreshStatus()
            granted
        } catch (e: Exception) {
            Log.e(TAG, "Lỗi yêu cầu quyền Root", e)
            false
        }
    }

    /**
     * Mở ứng dụng Shizuku trên máy hoặc dẫn link CH Play
     */
    fun openShizukuApp() {
        try {
            val intent = context.packageManager.getLaunchIntentForPackage(SHIZUKU_PACKAGE)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
            } else {
                val marketIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$SHIZUKU_PACKAGE"))
                marketIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(marketIntent)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Không thể mở ứng dụng Shizuku", e)
        }
    }

    /**
     * Thực thi lệnh bảo mật với quyền xác thực
     */
    suspend fun executeCommand(
        command: String,
        targetMode: ExecutionMode? = null
    ): CommandResult = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        val currentStatus = refreshStatus()
        val mode = targetMode ?: currentStatus.activeMode

        val resolvedMode = when (mode) {
            ExecutionMode.AUTO -> {
                when {
                    currentStatus.isShizukuPermissionGranted -> ExecutionMode.SHIZUKU
                    currentStatus.isRootGranted -> ExecutionMode.ROOT
                    currentStatus.isRootAvailable -> ExecutionMode.ROOT
                    currentStatus.isShizukuRunning -> ExecutionMode.SHIZUKU
                    else -> ExecutionMode.STANDARD
                }
            }
            else -> mode
        }

        when (resolvedMode) {
            ExecutionMode.SHIZUKU -> executeViaShizuku(command, startTime)
            ExecutionMode.ROOT -> executeViaRoot(command, startTime)
            ExecutionMode.STANDARD, ExecutionMode.AUTO -> executeViaStandard(command, startTime)
        }
    }

    suspend fun runTrimCaches(mode: ExecutionMode? = null): CommandResult {
        return executeCommand(TRIM_CACHES_CMD, mode)
    }

    private fun executeViaShizuku(command: String, startTime: Long): CommandResult {
        if (!_privilegeStatus.value.isShizukuPermissionGranted) {
            return CommandResult(
                command = command,
                output = "LỖI: Ứng dụng chưa được cấp quyền Shizuku. Vui lòng cấp quyền trước khi thực thi.",
                isSuccess = false,
                exitCode = -1,
                executionMode = "Shizuku (Chưa cấp quyền)",
                durationMs = System.currentTimeMillis() - startTime
            )
        }

        return try {
            val args = command.split("\\s+".toRegex()).toTypedArray()
            val newProcessMethod: Method = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            newProcessMethod.isAccessible = true
            val process = newProcessMethod.invoke(null, args, null, null) as Process

            val outputBuilder = StringBuilder()
            val inputThread = Thread {
                try {
                    BufferedReader(InputStreamReader(process.inputStream)).use { reader ->
                        var line: String?
                        while (reader.readLine().also { line = it } != null) {
                            outputBuilder.append(line).append("\n")
                        }
                    }
                } catch (_: Exception) {}
            }

            val errorThread = Thread {
                try {
                    BufferedReader(InputStreamReader(process.errorStream)).use { reader ->
                        var line: String?
                        while (reader.readLine().also { line = it } != null) {
                            outputBuilder.append("[ERR] ").append(line).append("\n")
                        }
                    }
                } catch (_: Exception) {}
            }

            inputThread.start()
            errorThread.start()

            val exitCode = process.waitFor()
            inputThread.join(2000)
            errorThread.join(2000)

            val duration = System.currentTimeMillis() - startTime
            val output = outputBuilder.toString().trim()
            val formatted = if (output.isEmpty()) {
                "Lệnh đã thực thi thành công qua Shizuku (Exit Code: $exitCode). Đã yêu cầu hệ thống thu hồi bộ nhớ cache."
            } else {
                output
            }

            CommandResult(
                command = command,
                output = formatted,
                isSuccess = exitCode == 0,
                exitCode = exitCode,
                executionMode = "Shizuku",
                durationMs = duration
            )
        } catch (e: Throwable) {
            CommandResult(
                command = command,
                output = "Lỗi thực thi qua Shizuku: ${e.message ?: e.localizedMessage}",
                isSuccess = false,
                exitCode = -1,
                executionMode = "Shizuku",
                durationMs = System.currentTimeMillis() - startTime
            )
        }
    }

    private fun executeViaRoot(command: String, startTime: Long): CommandResult {
        return try {
            val process = ProcessBuilder("su", "-c", command)
                .redirectErrorStream(true)
                .start()

            val outputBuilder = StringBuilder()
            BufferedReader(InputStreamReader(process.inputStream)).use { reader ->
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    outputBuilder.append(line).append("\n")
                }
            }

            val exitCode = process.waitFor()
            val duration = System.currentTimeMillis() - startTime
            val output = outputBuilder.toString().trim()
            val formatted = if (output.isEmpty()) {
                "Lệnh root đã thực thi thành công (Exit Code: $exitCode)."
            } else {
                output
            }

            CommandResult(
                command = command,
                output = formatted,
                isSuccess = exitCode == 0,
                exitCode = exitCode,
                executionMode = "Root (su)",
                durationMs = duration
            )
        } catch (e: Exception) {
            CommandResult(
                command = command,
                output = "Lỗi thực thi qua Root (su): ${e.message ?: "Không thể khởi tạo tiến trình su"}",
                isSuccess = false,
                exitCode = -1,
                executionMode = "Root (su)",
                durationMs = System.currentTimeMillis() - startTime
            )
        }
    }

    private fun executeViaStandard(command: String, startTime: Long): CommandResult {
        return try {
            val process = Runtime.getRuntime().exec(command)
            val outputBuilder = StringBuilder()
            BufferedReader(InputStreamReader(process.inputStream)).use { reader ->
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    outputBuilder.append(line).append("\n")
                }
            }
            val exitCode = process.waitFor()
            val duration = System.currentTimeMillis() - startTime
            val raw = outputBuilder.toString().trim()

            CommandResult(
                command = command,
                output = if (raw.isEmpty()) "Thực thi hoàn tất (Exit: $exitCode)" else raw,
                isSuccess = exitCode == 0,
                exitCode = exitCode,
                executionMode = "Standard",
                durationMs = duration
            )
        } catch (e: Exception) {
            CommandResult(
                command = command,
                output = "Không thể chạy lệnh cấp cao ở chế độ thường. Vui lòng cấp quyền Shizuku hoặc Root.\nChi tiết: ${e.message}",
                isSuccess = false,
                exitCode = -1,
                executionMode = "Standard",
                durationMs = System.currentTimeMillis() - startTime
            )
        }
    }

    private fun checkRootBinary(): Boolean {
        val paths = arrayOf(
            "/system/bin/su",
            "/system/xbin/su",
            "/sbin/su",
            "/system/sd/xbin/su",
            "/system/bin/failsafe/su",
            "/data/local/xbin/su",
            "/data/local/bin/su",
            "/data/local/su"
        )
        for (path in paths) {
            if (File(path).exists()) return true
        }
        return try {
            val process = Runtime.getRuntime().exec(arrayOf("which", "su"))
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val line = reader.readLine()
            process.waitFor()
            !line.isNullOrEmpty()
        } catch (_: Exception) {
            false
        }
    }

    private fun checkRootPermissionGranted(): Boolean {
        return try {
            val process = Runtime.getRuntime().exec(arrayOf("su", "-c", "id"))
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val out = reader.readLine() ?: ""
            process.waitFor()
            out.contains("uid=0(root)")
        } catch (_: Exception) {
            false
        }
    }

    private fun isPackageInstalled(packageName: String): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.packageManager.getPackageInfo(packageName, PackageManager.PackageInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                context.packageManager.getPackageInfo(packageName, 0)
            }
            true
        } catch (_: PackageManager.NameNotFoundException) {
            false
        }
    }
}
