package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.PrivilegeStatus
import com.example.service.PrivilegeManager
import com.example.ui.TurboBoostViewModel
import com.example.ui.components.StatusBadge
import com.example.ui.theme.CardSurfaceDark
import com.example.ui.theme.CardSurfaceVariantDark
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.DangerCrimson
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.RootBrandColor
import com.example.ui.theme.ShizukuBrandColor
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark
import com.example.ui.theme.WarningAmber

@Composable
fun PrivilegeScreen(
    viewModel: TurboBoostViewModel,
    modifier: Modifier = Modifier
) {
    val privilegeStatus by viewModel.privilegeStatus.collectAsState()
    val scrollState = rememberScrollState()
    val clipboardManager = LocalClipboardManager.current
    var showCopyFeedback by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        // Title
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = null,
                    tint = CyanPrimary,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "TRUNG TÂM CẤP QUYỀN",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    color = TextPrimaryDark,
                    letterSpacing = 0.5.sp
                )
            }

            IconButton(
                onClick = { viewModel.refreshAll() },
                modifier = Modifier
                    .size(36.dp)
                    .testTag("refresh_privilege_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Kiểm tra lại quyền",
                    tint = CyanPrimary
                )
            }
        }

        Text(
            text = "Cấp quyền Shizuku hoặc Root để dọn dẹp pm trim-caches",
            fontSize = 12.sp,
            color = TextSecondaryDark
        )

        Spacer(modifier = Modifier.height(16.dp))

        // SHIZUKU CARD
        Card(
            colors = CardDefaults.cardColors(containerColor = CardSurfaceDark),
            shape = RoundedCornerShape(18.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(ShizukuBrandColor.copy(alpha = 0.2f))
                        ) {
                            Text(
                                text = "S",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Black,
                                color = ShizukuBrandColor
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Shizuku API",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimaryDark
                            )
                            Text(
                                text = if (privilegeStatus.isShizukuRunning) "Dịch vụ đang chạy (v${privilegeStatus.shizukuVersion})" else if (privilegeStatus.isShizukuInstalled) "Đã cài đặt, chưa khởi chạy" else "Chưa cài đặt Shizuku",
                                fontSize = 11.sp,
                                color = if (privilegeStatus.isShizukuRunning) NeonEmerald else TextSecondaryDark
                            )
                        }
                    }

                    StatusBadge(
                        isGranted = privilegeStatus.isShizukuPermissionGranted,
                        grantedText = "Đã cấp quyền",
                        deniedText = "Chưa cấp"
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "Shizuku cho phép ứng dụng thực thi lệnh cấp cao của hệ thống (như pm trim-caches) thông qua ADB mà KHÔNG cần Root máy.",
                    fontSize = 12.sp,
                    color = TextSecondaryDark,
                    lineHeight = 18.sp
                )

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            val requested = viewModel.requestShizukuPermission()
                            if (!requested) {
                                viewModel.openShizuku()
                            }
                        },
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (privilegeStatus.isShizukuPermissionGranted) CardSurfaceVariantDark else CyanPrimary
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("request_shizuku_button")
                    ) {
                        Text(
                            text = if (privilegeStatus.isShizukuPermissionGranted) "Đã cấp quyền ✓" else "Cấp quyền Shizuku",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (privilegeStatus.isShizukuPermissionGranted) NeonEmerald else Color(0xFF0A0E17)
                        )
                    }

                    OutlinedButton(
                        onClick = { viewModel.openShizuku() },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("open_shizuku_app_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.OpenInNew,
                            contentDescription = null,
                            tint = CyanPrimary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Mở Shizuku",
                            fontSize = 12.sp,
                            color = CyanPrimary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Fast ADB Command snippet
                Surface(
                    color = Color(0xFF070B12),
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Lệnh khởi động Shizuku qua ADB:",
                                fontSize = 10.sp,
                                color = TextSecondaryDark
                            )
                            Text(
                                text = "adb shell sh /sdcard/Android/data/moe.shizuku.privileged.api/start.sh",
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp,
                                color = CyanPrimary
                            )
                        }

                        IconButton(
                            onClick = {
                                clipboardManager.setText(AnnotatedString("adb shell sh /sdcard/Android/data/moe.shizuku.privileged.api/start.sh"))
                                showCopyFeedback = true
                            },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ContentCopy,
                                contentDescription = "Sao chép lệnh ADB",
                                tint = CyanPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // ROOT CARD
        Card(
            colors = CardDefaults.cardColors(containerColor = CardSurfaceDark),
            shape = RoundedCornerShape(18.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(RootBrandColor.copy(alpha = 0.2f))
                        ) {
                            Text(
                                text = "#",
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Black,
                                color = RootBrandColor
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Root Superuser (su)",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimaryDark
                            )
                            Text(
                                text = if (privilegeStatus.isRootGranted) "Đã cấp quyền Superuser (Root)" else if (privilegeStatus.isRootAvailable) "Đã phát hiện binary su" else "Thiết bị chưa root",
                                fontSize = 11.sp,
                                color = if (privilegeStatus.isRootGranted) NeonEmerald else TextSecondaryDark
                            )
                        }
                    }

                    StatusBadge(
                        isGranted = privilegeStatus.isRootGranted,
                        grantedText = "Đã cấp",
                        deniedText = "Chưa cấp"
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "Quyền Root cấp cao nhất cho phép dọn sạch toàn bộ cache hệ thống, xóa cache Linux PageCache và đóng các tiến trình ngầm cứng đầu.",
                    fontSize = 12.sp,
                    color = TextSecondaryDark,
                    lineHeight = 18.sp
                )

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = { viewModel.requestRootPermission() },
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (privilegeStatus.isRootGranted) CardSurfaceVariantDark else RootBrandColor
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("request_root_button")
                ) {
                    Text(
                        text = if (privilegeStatus.isRootGranted) "Quyền Root đã kích hoạt ✓" else "Yêu cầu quyền Root (su)",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (privilegeStatus.isRootGranted) NeonEmerald else Color.White
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // STEP-BY-STEP GUIDES
        Text(
            text = "HƯỚNG DẪN THIẾT LẬP CHI TIẾT",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = TextSecondaryDark,
            letterSpacing = 1.sp
        )

        Spacer(modifier = Modifier.height(8.dp))

        GuideAccordionItem(
            stepNumber = "1",
            title = "Khởi chạy Shizuku bằng 'Gỡ lỗi không dây' (Không cần PC)",
            content = "1. Mở Cài đặt điện thoại -> Giới thiệu điện thoại -> Nhấn 7 lần vào 'Số hiệu bản dựng' để bật Tùy chọn nhà phát triển.\n" +
                    "2. Vào Tùy chọn nhà phát triển -> Bật 'Gỡ lỗi qua Wi-Fi' (Wireless Debugging).\n" +
                    "3. Mở Shizuku -> Nhấn 'Ghép nối' (Pairing) -> Chọn 'Ghép nối bằng mã'.\n" +
                    "4. Nhập mã 6 chữ số vào thông báo của hệ thống để ghép nối.\n" +
                    "5. Quay lại Shizuku nhấn 'Khởi động' (Start).\n" +
                    "6. Mở lại TurboBoost và nhấn 'Cấp quyền Shizuku'."
        )

        Spacer(modifier = Modifier.height(8.dp))

        GuideAccordionItem(
            stepNumber = "2",
            title = "Khởi chạy Shizuku bằng Máy tính (ADB)",
            content = "1. Bật 'Gỡ lỗi USB' (USB Debugging) trên điện thoại.\n" +
                    "2. Kết nối cáp USB với máy tính và chấp thuận lời nhắc cấp quyền gỡ lỗi.\n" +
                    "3. Mở Terminal / Command Prompt trên máy tính và chạy:\n" +
                    "   adb shell sh /sdcard/Android/data/moe.shizuku.privileged.api/start.sh\n" +
                    "4. Shizuku trên điện thoại sẽ tự động kích hoạt."
        )

        Spacer(modifier = Modifier.height(8.dp))

        GuideAccordionItem(
            stepNumber = "3",
            title = "Sử dụng Root (Magisk / KernelSU / APatch)",
            content = "1. Nếu máy của bạn đã được Root (qua Magisk, KernelSU hoặc APatch).\n" +
                    "2. Chỉ cần nhấn nút 'Yêu cầu quyền Root (su)' ở trên.\n" +
                    "3. Một hộp thoại thông báo từ ứng dụng quản lý Root sẽ hiện lên -> Chọn 'Cho phép' (Grant).\n" +
                    "4. TurboBoost sẽ tự động nhận quyền vĩnh viễn."
        )

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun GuideAccordionItem(
    stepNumber: String,
    title: String,
    content: String,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }

    Surface(
        color = CardSurfaceDark,
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B)),
        modifier = modifier
            .fillMaxWidth()
            .clickable { expanded = !expanded }
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(CyanPrimary.copy(alpha = 0.2f))
                    ) {
                        Text(
                            text = stepNumber,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = CyanPrimary
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = title,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextPrimaryDark
                    )
                }

                Text(
                    text = if (expanded) "▲" else "▼",
                    color = TextSecondaryDark,
                    fontSize = 11.sp
                )
            }

            AnimatedVisibility(visible = expanded) {
                Column {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = content,
                        fontSize = 12.sp,
                        color = Color(0xFFCBD5E1),
                        lineHeight = 18.sp
                    )
                }
            }
        }
    }
}
