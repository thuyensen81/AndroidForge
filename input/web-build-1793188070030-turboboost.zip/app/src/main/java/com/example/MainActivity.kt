package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.TurboBoostViewModel
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.LogScreen
import com.example.ui.screens.PrivilegeScreen
import com.example.ui.screens.TrimCacheScreen
import com.example.ui.theme.CardSurfaceDark
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark
import com.example.ui.theme.TurboBoostTheme

enum class Screen(val title: String, val icon: ImageVector, val tag: String) {
    DASHBOARD("Tài nguyên", Icons.Default.Speed, "tab_dashboard"),
    TRIM_CACHE("Dọn Cache", Icons.Default.CleaningServices, "tab_trim_cache"),
    PRIVILEGES("Quyền", Icons.Default.Security, "tab_privileges"),
    LOGS("Nhật ký", Icons.Default.Terminal, "tab_logs")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TurboBoostTheme {
                MainApp()
            }
        }
    }
}

@Composable
fun MainApp(viewModel: TurboBoostViewModel = viewModel()) {
    var currentScreen by rememberSaveable { mutableStateOf(Screen.DASHBOARD) }

    // Support Back button navigation
    BackHandler(enabled = currentScreen != Screen.DASHBOARD) {
        currentScreen = Screen.DASHBOARD
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            NavigationBar(
                containerColor = CardSurfaceDark,
                contentColor = TextPrimaryDark,
                modifier = Modifier.testTag("main_bottom_nav")
            ) {
                Screen.values().forEach { screen ->
                    val isSelected = currentScreen == screen
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { currentScreen = screen },
                        icon = {
                            Icon(
                                imageVector = screen.icon,
                                contentDescription = screen.title
                            )
                        },
                        label = {
                            Text(
                                text = screen.title,
                                fontSize = 11.sp
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF0A0E17),
                            selectedTextColor = CyanPrimary,
                            indicatorColor = CyanPrimary,
                            unselectedIconColor = TextSecondaryDark,
                            unselectedTextColor = TextSecondaryDark
                        ),
                        modifier = Modifier.testTag(screen.tag)
                    )
                }
            }
        }
    ) { innerPadding ->
        Crossfade(
            targetState = currentScreen,
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            label = "screen_transition"
        ) { screen ->
            when (screen) {
                Screen.DASHBOARD -> DashboardScreen(
                    viewModel = viewModel,
                    onNavigateToTrim = { currentScreen = Screen.TRIM_CACHE },
                    onNavigateToPrivileges = { currentScreen = Screen.PRIVILEGES }
                )
                Screen.TRIM_CACHE -> TrimCacheScreen(
                    viewModel = viewModel,
                    onNavigateToPrivileges = { currentScreen = Screen.PRIVILEGES }
                )
                Screen.PRIVILEGES -> PrivilegeScreen(
                    viewModel = viewModel
                )
                Screen.LOGS -> LogScreen(
                    viewModel = viewModel
                )
            }
        }
    }
}
