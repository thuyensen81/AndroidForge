package com.example.model

enum class ExecutionMode(val displayName: String) {
    AUTO("Tự động (Ưu tiên Shizuku/Root)"),
    SHIZUKU("Shizuku"),
    ROOT("Root (su)"),
    STANDARD("Tiêu chuẩn (Không quyền)")
}

data class MemoryStats(
    val totalMb: Long = 0,
    val usedMb: Long = 0,
    val availableMb: Long = 0,
    val cachedMb: Long = 0,
    val usedPercent: Float = 0f
)

data class StorageStats(
    val totalBytes: Long = 0,
    val usedBytes: Long = 0,
    val freeBytes: Long = 0,
    val estimatedCacheBytes: Long = 0,
    val usedPercent: Float = 0f
) {
    val totalGbFormatted: String
        get() = String.format("%.1f GB", totalBytes / (1024.0 * 1024.0 * 1024.0))

    val usedGbFormatted: String
        get() = String.format("%.1f GB", usedBytes / (1024.0 * 1024.0 * 1024.0))

    val freeGbFormatted: String
        get() = String.format("%.1f GB", freeBytes / (1024.0 * 1024.0 * 1024.0))

    val estimatedCacheMbFormatted: String
        get() = String.format("%.1f MB", estimatedCacheBytes / (1024.0 * 1024.0))
}

data class CpuDeviceInfo(
    val socModel: String = "",
    val hardware: String = "",
    val manufacturer: String = "",
    val model: String = "",
    val androidVersion: String = "",
    val sdkInt: Int = 0,
    val cpuCores: Int = 0,
    val cpuArch: String = "",
    val batteryPercent: Int = 0,
    val batteryTempC: Float = 0f,
    val isCharging: Boolean = false,
    val uptimeFormatted: String = ""
)

data class PrivilegeStatus(
    val isShizukuInstalled: Boolean = false,
    val isShizukuRunning: Boolean = false,
    val isShizukuPermissionGranted: Boolean = false,
    val shizukuVersion: Int = 0,
    val isRootAvailable: Boolean = false,
    val isRootGranted: Boolean = false,
    val activeMode: ExecutionMode = ExecutionMode.AUTO
) {
    val hasPrivilege: Boolean
        get() = isShizukuPermissionGranted || isRootGranted

    val preferredPrivilegeName: String
        get() = when {
            isRootGranted -> "Root (su)"
            isShizukuPermissionGranted -> "Shizuku"
            isRootAvailable -> "Root (chưa cấp quyền)"
            isShizukuRunning -> "Shizuku (chưa cấp quyền)"
            else -> "Chưa cấp quyền"
        }
}

data class LogEntry(
    val id: String = java.util.UUID.randomUUID().toString(),
    val timestamp: Long = System.currentTimeMillis(),
    val title: String,
    val command: String,
    val output: String,
    val isSuccess: Boolean,
    val durationMs: Long
)

data class OptimizationResult(
    val freedRamMb: Long,
    val freedStorageBytes: Long,
    val command: String,
    val output: String,
    val isSuccess: Boolean,
    val privilegeUsed: String,
    val timestamp: Long = System.currentTimeMillis()
)
