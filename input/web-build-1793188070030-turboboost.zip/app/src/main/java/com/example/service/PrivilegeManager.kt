package com.example.service

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.util.Log
import com.example.model.ExecutionMode
import com.example.model.PrivilegeStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.lang.reflect.Method

data class CommandResult(
    val command: String,
    val output: String,
    val isSuccess: Boolean,
    val exitCode: Int,
    val executionMode: String,
    val durationMs: Long
)

class PrivilegeManager(private val context: Context) {

    companion object {
        private const val TAG = "PrivilegeManager"
        const val SHIZUKU_REQUEST_CODE = 1001
        const val SHIZUKU_PACKAGE = "moe.shizuku.privileged.api"
        const val TRIM_CACHES_CMD = "pm trim-caches 1024G"
    }

    private val _status = MutableStateFlow(PrivilegeStatus())
    val status: StateFlow<PrivilegeStatus> = _status.asStateFlow()

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        checkPrivileges()
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        checkPrivileges()
    }

    private val permissionResultListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == SHIZUKU_REQUEST_CODE) {
            checkPrivileges()
        }
    }

    init {
        try {
            Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
            Shizuku.addBinderDeadListener(binderDeadListener)
            Shizuku.addRequestPermissionResultListener(permissionResultListener)
        } catch (e: Throwable) {
            Log.w(TAG, "Failed to attach Shizuku listeners", e)
        }
        checkPrivileges()
    }

    fun cleanUp() {
        try {
            Shizuku.removeBinderReceivedListener(binderReceivedListener)
            Shizuku.removeBinderDeadListener(binderDeadListener)
            Shizuku.removeRequestPermissionResultListener(permissionResultListener)
        } catch (e: Throwable) {
            Log.w(TAG, "Error removing Shizuku listeners", e)
        }
    }

    fun checkPrivileges(): PrivilegeStatus {
        val isShizukuInstalled = isPackageInstalled(SHIZUKU_PACKAGE)
        var isShizukuRunning = false
        var isShizukuGranted = false
        var shizukuVersion = 0

        try {
            if (Shizuku.pingBinder()) {
                isShizukuRunning = true
                shizukuVersion = Shizuku.getVersion()
                isShizukuGranted = Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
            }
        } catch (e: Throwable) {
            Log.w(TAG, "Shizuku ping check error: ${e.message}")
        }

        val isRootAvailable = checkRootBinary()
        val isRootGranted = if (isRootAvailable) checkRootPermissionGranted() else false

        val newStatus = _status.value.copy(
            isShizukuInstalled = isShizukuInstalled,
            isShizukuRunning = isShizukuRunning,
            isShizukuPermissionGranted = isShizukuGranted,
            shizukuVersion = shizukuVersion,
            isRootAvailable = isRootAvailable,
            isRootGranted = isRootGranted
        )
        _status.value = newStatus
        return newStatus
    }

    fun requestShizukuPermission(): Boolean {
        return try {
            if (!Shizuku.pingBinder()) {
                false
            } else {
                Shizuku.requestPermission(SHIZUKU_REQUEST_CODE)
                true
            }
        } catch (e: Throwable) {
            Log.e(TAG, "Error requesting Shizuku permission", e)
            false
        }
    }

    suspend fun requestRootPermission(): Boolean = withContext(Dispatchers.IO) {
        try {
            val process = Runtime.getRuntime().exec(arrayOf("su", "-c", "id"))
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val output = reader.readText()
            process.waitFor()
            val granted = output.contains("uid=0(root)") || process.exitValue() == 0
            checkPrivileges()
            granted
        } catch (e: Exception) {
            Log.e(TAG, "Root permission request failed", e)
            false
        }
    }

    fun openShizukuApp() {
        try {
            val intent = context.packageManager.getLaunchIntentForPackage(SHIZUKU_PACKAGE)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
            } else {
                val marketIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$SHIZUKU_PACKAGE"))
                marketIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(marketIntent)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Cannot launch Shizuku", e)
        }
    }

    fun setExecutionMode(mode: ExecutionMode) {
        _status.value = _status.value.copy(activeMode = mode)
    }

    suspend fun executeCommand(command: String, requestedMode: ExecutionMode? = null): CommandResult = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        val currentStatus = checkPrivileges()
        val mode = requestedMode ?: currentStatus.activeMode

        // Resolve effective mode
        val effectiveMode = when (mode) {
            ExecutionMode.AUTO -> {
                when {
                    currentStatus.isShizukuPermissionGranted -> ExecutionMode.SHIZUKU
                    currentStatus.isRootGranted -> ExecutionMode.ROOT
                    currentStatus.isRootAvailable -> ExecutionMode.ROOT
                    currentStatus.isShizukuRunning -> ExecutionMode.SHIZUKU
                    else -> ExecutionMode.STANDARD
                }
            }
            else -> mode
        }

        when (effectiveMode) {
            ExecutionMode.SHIZUKU -> executeViaShizuku(command, startTime)
            ExecutionMode.ROOT -> executeViaRoot(command, startTime)
            ExecutionMode.STANDARD, ExecutionMode.AUTO -> executeViaStandard(command, startTime)
        }
    }

    suspend fun runTrimCaches(): CommandResult {
        return executeCommand(TRIM_CACHES_CMD)
    }

    private fun executeViaShizuku(command: String, startTime: Long): CommandResult {
        if (!_status.value.isShizukuPermissionGranted) {
            val duration = System.currentTimeMillis() - startTime
            return CommandResult(
                command = command,
                output = "LỖI: Chưa cấp quyền Shizuku cho ứng dụng. Vui lòng mở tab 'Quyền' và nhấn Cấp quyền Shizuku.",
                isSuccess = false,
                exitCode = -1,
                executionMode = "Shizuku (Chưa cấp quyền)",
                durationMs = duration
            )
        }

        return try {
            val args = command.split("\\s+".toRegex()).toTypedArray()
            
            // Call Shizuku.newProcess via reflection to avoid visibility/signature issues
            val newProcessMethod: Method = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            newProcessMethod.isAccessible = true
            val process = newProcessMethod.invoke(null, args, null, null) as Process

            val outputBuilder = StringBuilder()
            val inputThread = Thread {
                try {
                    BufferedReader(InputStreamReader(process.inputStream)).use { reader ->
                        var line: String?
                        while (reader.readLine().also { line = it } != null) {
                            outputBuilder.append(line).append("\n")
                        }
                    }
                } catch (_: Exception) {}
            }

            val errorThread = Thread {
                try {
                    BufferedReader(InputStreamReader(process.errorStream)).use { reader ->
                        var line: String?
                        while (reader.readLine().also { line = it } != null) {
                            outputBuilder.append("[ERR] ").append(line).append("\n")
                        }
                    }
                } catch (_: Exception) {}
            }

            inputThread.start()
            errorThread.start()

            val exitCode = process.waitFor()
            inputThread.join(2000)
            errorThread.join(2000)

            val duration = System.currentTimeMillis() - startTime
            val output = outputBuilder.toString().trim()
            val formattedOutput = if (output.isEmpty()) {
                "Lệnh đã thực thi thành công qua Shizuku (Exit Code: $exitCode). Đã yêu cầu hệ thống thu hồi toàn bộ cache."
            } else {
                output
            }

            CommandResult(
                command = command,
                output = formattedOutput,
                isSuccess = exitCode == 0,
                exitCode = exitCode,
                executionMode = "Shizuku",
                durationMs = duration
            )
        } catch (e: Throwable) {
            val duration = System.currentTimeMillis() - startTime
            CommandResult(
                command = command,
                output = "Lỗi thực thi qua Shizuku: ${e.message ?: e.localizedMessage}",
                isSuccess = false,
                exitCode = -1,
                executionMode = "Shizuku",
                durationMs = duration
            )
        }
    }

    private fun executeViaRoot(command: String, startTime: Long): CommandResult {
        return try {
            val process = ProcessBuilder("su", "-c", command)
                .redirectErrorStream(true)
                .start()

            val outputBuilder = StringBuilder()
            BufferedReader(InputStreamReader(process.inputStream)).use { reader ->
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    outputBuilder.append(line).append("\n")
                }
            }

            val exitCode = process.waitFor()
            val duration = System.currentTimeMillis() - startTime
            val output = outputBuilder.toString().trim()
            val formattedOutput = if (output.isEmpty()) {
                "Lệnh root đã thực thi thành công (Exit Code: $exitCode)."
            } else {
                output
            }

            CommandResult(
                command = command,
                output = formattedOutput,
                isSuccess = exitCode == 0,
                exitCode = exitCode,
                executionMode = "Root (su)",
                durationMs = duration
            )
        } catch (e: Exception) {
            val duration = System.currentTimeMillis() - startTime
            CommandResult(
                command = command,
                output = "Lỗi thực thi qua Root (su): ${e.message ?: "Không thể khởi chạy tiến trình su"}",
                isSuccess = false,
                exitCode = -1,
                executionMode = "Root (su)",
                durationMs = duration
            )
        }
    }

    private fun executeViaStandard(command: String, startTime: Long): CommandResult {
        return try {
            val process = Runtime.getRuntime().exec(command)
            val outputBuilder = StringBuilder()
            BufferedReader(InputStreamReader(process.inputStream)).use { reader ->
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    outputBuilder.append(line).append("\n")
                }
            }
            BufferedReader(InputStreamReader(process.errorStream)).use { reader ->
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    outputBuilder.append("[ERR] ").append(line).append("\n")
                }
            }

            val exitCode = process.waitFor()
            val duration = System.currentTimeMillis() - startTime
            val rawOutput = outputBuilder.toString().trim()

            CommandResult(
                command = command,
                output = if (rawOutput.isEmpty()) "Thực thi hoàn tất (Exit: $exitCode)" else rawOutput,
                isSuccess = exitCode == 0,
                exitCode = exitCode,
                executionMode = "Standard (Non-privileged)",
                durationMs = duration
            )
        } catch (e: Exception) {
            val duration = System.currentTimeMillis() - startTime
            CommandResult(
                command = command,
                output = "Không thể chạy lệnh cấp cao ở chế độ thường. Hãy cấp quyền Shizuku hoặc Root để chạy lệnh này!\nChi tiết: ${e.message}",
                isSuccess = false,
                exitCode = -1,
                executionMode = "Standard",
                durationMs = duration
            )
        }
    }

    private fun checkRootBinary(): Boolean {
        val paths = arrayOf(
            "/system/bin/su",
            "/system/xbin/su",
            "/sbin/su",
            "/system/sd/xbin/su",
            "/system/bin/failsafe/su",
            "/data/local/xbin/su",
            "/data/local/bin/su",
            "/data/local/su"
        )
        for (path in paths) {
            if (File(path).exists()) return true
        }
        return try {
            val process = Runtime.getRuntime().exec(arrayOf("which", "su"))
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val line = reader.readLine()
            process.waitFor()
            !line.isNullOrEmpty()
        } catch (_: Exception) {
            false
        }
    }

    private fun checkRootPermissionGranted(): Boolean {
        return try {
            val process = Runtime.getRuntime().exec(arrayOf("su", "-c", "id"))
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val out = reader.readLine() ?: ""
            process.waitFor()
            out.contains("uid=0(root)")
        } catch (_: Exception) {
            false
        }
    }

    private fun isPackageInstalled(packageName: String): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.packageManager.getPackageInfo(packageName, PackageManager.PackageInfoFlags.of(0))
            } else {
                @Suppress("DEPRECATION")
                context.packageManager.getPackageInfo(packageName, 0)
            }
            true
        } catch (_: PackageManager.NameNotFoundException) {
            false
        }
    }
}
