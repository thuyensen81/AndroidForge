package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CardSurfaceDark
import com.example.ui.theme.CardSurfaceVariantDark
import com.example.ui.theme.CyanPrimary
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun CircularOptimizationVisualizer(
    progress: Float,
    currentStep: String,
    isRunning: Boolean,
    modifier: Modifier = Modifier,
    size: Dp = 230.dp,
    freedRamMb: Long? = null,
    freedStorageBytes: Long? = null
) {
    val animatedProgress by animateFloatAsState(
        targetValue = progress.coerceIn(0f, 1f),
        animationSpec = tween(durationMillis = 400, easing = FastOutSlowInEasing),
        label = "opt_progress_anim"
    )

    // Infinite transitions for radar rotation, breathing aura, and orbiting particles
    val infiniteTransition = rememberInfiniteTransition(label = "visualizer_infinite")

    val radarRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "radar_rotation"
    )

    val counterRotation by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(3400, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "counter_rotation"
    )

    val auraPulse by infiniteTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "aura_pulse"
    )

    val isCompleted = !isRunning && progress >= 0.99f

    Column(
        modifier = modifier
            .fillMaxWidth()
            .testTag("circular_optimization_visualizer"),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.size(size)
        ) {
            Canvas(modifier = Modifier.size(size)) {
                val centerOffset = center
                val diameter = size.toPx() - 32.dp.toPx()
                val radius = diameter / 2f

                // 1. Pulsing Outer Energy Glow
                if (isRunning) {
                    val auraRadius = radius * auraPulse
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                CyanPrimary.copy(alpha = 0.25f),
                                ElectricViolet.copy(alpha = 0.08f),
                                Color.Transparent
                            ),
                            center = centerOffset,
                            radius = auraRadius + 24.dp.toPx()
                        ),
                        radius = auraRadius + 16.dp.toPx()
                    )
                }

                // 2. Track Ring Background
                drawCircle(
                    color = Color(0xFF131D31),
                    radius = radius,
                    style = Stroke(width = 10.dp.toPx())
                )

                // 3. Counter-Rotating Segmented Tech Arcs (Radar Scanner)
                if (isRunning) {
                    // Outer decorative dashed arc
                    drawArc(
                        brush = Brush.sweepGradient(
                            listOf(ElectricViolet.copy(alpha = 0.1f), ElectricViolet, Color.Transparent)
                        ),
                        startAngle = counterRotation,
                        sweepAngle = 120f,
                        useCenter = false,
                        style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round),
                        topLeft = Offset(centerOffset.x - radius - 8.dp.toPx(), centerOffset.y - radius - 8.dp.toPx()),
                        size = Size((radius + 8.dp.toPx()) * 2, (radius + 8.dp.toPx()) * 2)
                    )

                    // Inner scanning arc
                    drawArc(
                        brush = Brush.sweepGradient(
                            listOf(CyanPrimary.copy(alpha = 0.1f), CyanPrimary, Color.Transparent)
                        ),
                        startAngle = radarRotation,
                        sweepAngle = 90f,
                        useCenter = false,
                        style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round),
                        topLeft = Offset(centerOffset.x - radius + 8.dp.toPx(), centerOffset.y - radius + 8.dp.toPx()),
                        size = Size((radius - 8.dp.toPx()) * 2, (radius - 8.dp.toPx()) * 2)
                    )
                }

                // 4. Main Progress Arc with Gradient
                val sweepAngle = animatedProgress * 360f
                if (sweepAngle > 0f) {
                    val progressBrush = if (isCompleted) {
                        Brush.sweepGradient(
                            listOf(NeonEmerald, CyanPrimary, NeonEmerald)
                        )
                    } else {
                        Brush.sweepGradient(
                            listOf(CyanPrimary, ElectricViolet, CyanPrimary)
                        )
                    }

                    drawArc(
                        brush = progressBrush,
                        startAngle = -90f,
                        sweepAngle = sweepAngle,
                        useCenter = false,
                        style = Stroke(width = 12.dp.toPx(), cap = StrokeCap.Round)
                    )

                    // 5. Orbiting Glowing Particle at Head of Progress
                    val angleRad = Math.toRadians((sweepAngle - 90.0))
                    val particleX = centerOffset.x + (radius * cos(angleRad)).toFloat()
                    val particleY = centerOffset.y + (radius * sin(angleRad)).toFloat()

                    drawCircle(
                        color = Color.White,
                        radius = 6.dp.toPx(),
                        center = Offset(particleX, particleY)
                    )
                    drawCircle(
                        color = if (isCompleted) NeonEmerald else CyanPrimary,
                        radius = 11.dp.toPx(),
                        center = Offset(particleX, particleY),
                        alpha = 0.5f
                    )
                }
            }

            // Center Content
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                if (isCompleted) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(52.dp)
                            .clip(CircleShape)
                            .background(NeonEmerald.copy(alpha = 0.2f))
                            .border(2.dp, NeonEmerald, CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "Hoàn tất",
                            tint = NeonEmerald,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "100%",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Black,
                        color = NeonEmerald
                    )
                    Text(
                        text = "ĐÃ TỐI ƯU HÓA",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        color = TextPrimaryDark
                    )
                } else if (isRunning) {
                    // Current step icon
                    val icon = when {
                        currentStep.contains("pm trim-caches") -> Icons.Default.CleaningServices
                        currentStep.contains("ngầm") -> Icons.Default.Memory
                        else -> Icons.Default.RocketLaunch
                    }

                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = CyanPrimary,
                        modifier = Modifier.size(36.dp)
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "${(animatedProgress * 100).toInt()}%",
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Black,
                        color = TextPrimaryDark
                    )

                    Text(
                        text = "ĐANG XỬ LÝ",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.5.sp,
                        color = CyanPrimary
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.RocketLaunch,
                        contentDescription = null,
                        tint = CyanPrimary,
                        modifier = Modifier.size(38.dp)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "SẴN SÀNG",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 1.sp,
                        color = TextPrimaryDark
                    )
                    Text(
                        text = "Nhấn để bắt đầu",
                        fontSize = 11.sp,
                        color = TextSecondaryDark
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Step Label & Linear Bar
        AnimatedVisibility(visible = isRunning || isCompleted) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp)
            ) {
                Surface(
                    color = CardSurfaceVariantDark,
                    shape = RoundedCornerShape(20.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF263554))
                ) {
                    Text(
                        text = currentStep.ifEmpty { "Đang tối ưu hóa hệ thống..." },
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = if (isCompleted) NeonEmerald else CyanPrimary,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                    )
                }

                if (isRunning) {
                    Spacer(modifier = Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = { animatedProgress },
                        color = CyanPrimary,
                        trackColor = Color(0xFF1E293B),
                        strokeCap = StrokeCap.Round,
                        modifier = Modifier
                            .fillMaxWidth(0.7f)
                            .height(4.dp)
                            .clip(RoundedCornerShape(2.dp))
                    )
                }
            }
        }

        // Summary Badges if completed
        if (isCompleted && (freedRamMb != null || freedStorageBytes != null)) {
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                freedRamMb?.let { ram ->
                    Surface(
                        color = NeonEmerald.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, NeonEmerald.copy(alpha = 0.4f))
                    ) {
                        Text(
                            text = "+$ram MB RAM",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = NeonEmerald,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }

                freedStorageBytes?.let { storage ->
                    val storageMb = (storage / (1024.0 * 1024.0)).toInt()
                    Surface(
                        color = CyanPrimary.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, CyanPrimary.copy(alpha = 0.4f))
                    ) {
                        Text(
                            text = "+$storageMb MB Cache",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = CyanPrimary,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }
    }
}
