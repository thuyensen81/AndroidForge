package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CyanPrimary = Color(0xFF00E5FF)
val CyanPrimaryVariant = Color(0xFF00B0FF)
val ElectricViolet = Color(0xFF7C4DFF)
val NeonEmerald = Color(0xFF00E676)
val WarningAmber = Color(0xFFFFAB00)
val DangerCrimson = Color(0xFFFF5252)

val DeepDarkBackground = Color(0xFF0A0E17)
val CardSurfaceDark = Color(0xFF131B2E)
val CardSurfaceVariantDark = Color(0xFF1A243D)
val BorderDark = Color(0xFF263554)

val TextPrimaryDark = Color(0xFFF8FAFC)
val TextSecondaryDark = Color(0xFF94A3B8)
val TextTertiaryDark = Color(0xFF64748B)

val GaugeTrackDark = Color(0xFF1E293B)
val ShizukuBrandColor = Color(0xFF388E3C)
val RootBrandColor = Color(0xFFE53935)
