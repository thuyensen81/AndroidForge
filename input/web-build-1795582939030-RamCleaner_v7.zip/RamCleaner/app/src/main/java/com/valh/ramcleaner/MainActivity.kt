package com.valh.ramcleaner

import android.content.Context
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.keyframes
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.roundToLong

// ───────────── Bảng màu Cyberpunk (tối / sáng) ─────────────

data class Pal(
    val dark: Boolean,
    val bg: Color, val panel: Color, val panel2: Color, val line: Color,
    val text: Color, val muted: Color, val hi: Color,
    val accent: Color, val onAccent: Color,
    val c1: Color, val c2: Color, val c3: Color, val c4: Color, val c5: Color
)

// Tối: nền đen, vàng chói + cyan + đỏ neon
private val DarkPal = Pal(
    dark = true,
    bg = Color(0xFF07070C), panel = Color(0xFF111118), panel2 = Color(0xFF0A0A10), line = Color(0xFF5C5708),
    text = Color(0xFFEDEDED), muted = Color(0xFF8E8E9C), hi = Color(0xFFFCEE0A),
    accent = Color(0xFFFCEE0A), onAccent = Color(0xFF0A0A0A),
    c1 = Color(0xFF00F0FF), c2 = Color(0xFFFF003C), c3 = Color(0xFFB026FF), c4 = Color(0xFFFF8A00), c5 = Color(0xFF00FF9C)
)

// Sáng: nền vàng Cyberpunk, viền và chữ đen
private val LightPal = Pal(
    dark = false,
    bg = Color(0xFFFCEE0A), panel = Color(0xFFFFF566), panel2 = Color(0xFFF1DF00), line = Color(0xFF0A0A0A),
    text = Color(0xFF0A0A0A), muted = Color(0xFF4D4800), hi = Color(0xFF0A0A0A),
    accent = Color(0xFF0A0A0A), onAccent = Color(0xFFFCEE0A),
    c1 = Color(0xFF006C78), c2 = Color(0xFFC8002E), c3 = Color(0xFF5B0AA5), c4 = Color(0xFF9A4A00), c5 = Color(0xFF0A6B3A)
)

private val LocalPal = compositionLocalOf { DarkPal }

/** Hình chữ nhật vát góc (trên-phải và dưới-trái) đặc trưng của HUD Cyberpunk. */
private class CutShape(private val cutDp: Float) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val c = cutDp * density.density
        val path = Path().apply {
            moveTo(0f, 0f)
            lineTo(size.width - c, 0f)
            lineTo(size.width, c)
            lineTo(size.width, size.height)
            lineTo(c, size.height)
            lineTo(0f, size.height - c)
            close()
        }
        return Outline.Generic(path)
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { App() } }
    }
}

// ───────────── Hiệu ứng dùng chung ─────────────

@Composable
private fun anim(c: Color): Color = animateColorAsState(c, tween(500), label = "pal").value

/** Chuyển bảng màu sáng/tối mượt: mọi màu được nội suy trong 0,5 giây. */
@Composable
private fun animatedPal(t: Pal): Pal = Pal(
    t.dark, anim(t.bg), anim(t.panel), anim(t.panel2), anim(t.line), anim(t.text), anim(t.muted),
    anim(t.hi), anim(t.accent), anim(t.onAccent), anim(t.c1), anim(t.c2), anim(t.c3), anim(t.c4), anim(t.c5)
)

/** Nhấn xuống thì nút co lại rồi bật về bằng lò xo. */
@Composable
private fun Modifier.pressScale(onClick: () -> Unit, enabled: Boolean = true): Modifier {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(
        if (pressed) 0.93f else 1f, spring(dampingRatio = 0.45f, stiffness = 500f), label = "press"
    )
    return this
        .graphicsLayer { scaleX = scale; scaleY = scale }
        .clickable(interactionSource = src, indication = null, enabled = enabled, onClick = onClick)
}

/** Hiện dần và trượt lên, mỗi phần tử trễ hơn phần trước một chút. */
@Composable
private fun Modifier.enter(index: Int): Modifier {
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay(index * 100L)
        a.animateTo(1f, tween(650, easing = FastOutSlowInEasing))
    }
    return this.graphicsLayer { alpha = a.value; translationY = (1f - a.value) * 70f }
}

/** Scanline tĩnh kèm một vệt sáng quét từ trên xuống (chỉ ở chế độ tối). */
@Composable
private fun Modifier.scanlines(on: Boolean): Modifier {
    if (!on) return this
    val inf = rememberInfiniteTransition(label = "scan")
    val beam by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(7000, easing = LinearEasing)), label = "beam")
    return this.drawBehind {
        val step = 6.dp.toPx()
        var y = 0f
        while (y < size.height) {
            drawLine(Color(0x0DFFFFFF), Offset(0f, y), Offset(size.width, y), 1f)
            y += step
        }
        val by = beam * size.height
        drawRect(
            Brush.verticalGradient(
                listOf(Color.Transparent, Color(0x1AFCEE0A), Color.Transparent),
                startY = by - 160f, endY = by + 160f
            ),
            topLeft = Offset(0f, by - 160f), size = Size(size.width, 320f)
        )
    }
}

@Composable
private fun PulseDot(color: Color) {
    val inf = rememberInfiniteTransition(label = "dot")
    val a by inf.animateFloat(0.35f, 1f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "dotA")
    Box(Modifier.size(10.dp).graphicsLayer { alpha = a }.background(color))
}

@Composable
private fun UsageBar(frac: Float, color: Color) {
    val p = LocalPal.current
    val f by animateFloatAsState(frac.coerceIn(0f, 1f), tween(900, easing = FastOutSlowInEasing), label = "bar")
    Box(Modifier.fillMaxWidth().height(8.dp).background(p.line.copy(alpha = 0.3f))) {
        Box(Modifier.fillMaxWidth(f).fillMaxHeight().background(color))
    }
}

// ───────────── Thành phần dùng chung ─────────────

@Composable
private fun T(
    text: String, color: Color = LocalPal.current.text, size: Int = 14,
    weight: FontWeight = FontWeight.Normal, modifier: Modifier = Modifier,
    align: TextAlign? = null, spacing: Int = 0
) = Text(
    text, color = color, fontSize = size.sp, fontWeight = weight, modifier = modifier,
    fontFamily = FontFamily.Monospace, textAlign = align, letterSpacing = spacing.sp
)

@Composable
private fun Panel(title: String? = null, index: Int = 0, content: @Composable ColumnScope.() -> Unit) {
    val p = LocalPal.current
    val shape = CutShape(16f)
    Column(
        Modifier.enter(index).fillMaxWidth().clip(shape).background(p.panel)
            .border(2.dp, p.line, shape).padding(18.dp)
    ) {
        if (title != null) {
            T("// $title", p.hi, 12, FontWeight.Bold, spacing = 2)
            Spacer(Modifier.height(12.dp))
        }
        content()
    }
}

@Composable
private fun Chip(text: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val p = LocalPal.current
    val shape = CutShape(8f)
    val bg by animateColorAsState(if (selected) p.accent else p.accent.copy(alpha = 0f), tween(300), label = "chipBg")
    val br by animateColorAsState(if (selected) p.accent else p.line, tween(300), label = "chipBr")
    val fg by animateColorAsState(if (selected) p.onAccent else p.muted, tween(300), label = "chipFg")
    Box(
        modifier.pressScale(onClick).clip(shape).background(bg).border(1.5.dp, br, shape)
            .padding(horizontal = 14.dp, vertical = 10.dp)
    ) { T(text, fg, 13, FontWeight.Bold, spacing = 1) }
}

@Composable
private fun Tag(text: String, color: Color) {
    val shape = CutShape(6f)
    Box(
        Modifier.clip(shape).border(1.dp, color, shape).padding(horizontal = 8.dp, vertical = 4.dp)
    ) { T(text, color, 11, FontWeight.Bold, spacing = 1) }
}

@Composable
private fun NeonButton(text: String, busy: Boolean, onClick: () -> Unit) {
    val p = LocalPal.current
    val shape = CutShape(18f)
    val inf = rememberInfiniteTransition(label = "btn")
    val shimmer by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(2200, easing = LinearEasing)), label = "shimmer")
    val dots by inf.animateFloat(0f, 3.99f, infiniteRepeatable(tween(1200, easing = LinearEasing)), label = "dots")
    val bg by animateColorAsState(if (busy) p.muted else p.accent, tween(300), label = "btnBg")
    val n = dots.toInt()
    Box(
        Modifier.fillMaxWidth().height(58.dp).pressScale(onClick, enabled = !busy).clip(shape).background(bg)
            .drawWithContent {
                drawContent()
                val x = shimmer * (size.width + 400f) - 200f
                drawRect(
                    Brush.horizontalGradient(
                        listOf(Color.Transparent, Color.White.copy(alpha = if (busy) 0.5f else 0.28f), Color.Transparent),
                        startX = x - 120f, endX = x + 120f
                    )
                )
            },
        contentAlignment = Alignment.Center
    ) {
        T(if (busy) text + ".".repeat(n) + " ".repeat(3 - n) else text, p.onAccent, 16, FontWeight.Bold, spacing = 2)
    }
}

// ───────────── Khung ứng dụng ─────────────

@Composable
private fun App() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("ramc", Context.MODE_PRIVATE) }
    var dark by remember { mutableStateOf(prefs.getBoolean("dark", true)) }
    val pal = animatedPal(if (dark) DarkPal else LightPal)
    val cleaner = remember { RamCleaner(context) }
    var tab by remember { mutableIntStateOf(0) }

    LaunchedEffect(dark) {
        val act = context as? ComponentActivity ?: return@LaunchedEffect
        val t = android.graphics.Color.TRANSPARENT
        val style = if (dark) SystemBarStyle.dark(t) else SystemBarStyle.light(t, t)
        act.enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
    }

    CompositionLocalProvider(LocalPal provides pal) {
        Column(Modifier.fillMaxSize().background(pal.bg).scanlines(dark).systemBarsPadding()) {
            Header(dark) {
                dark = !dark
                prefs.edit().putBoolean("dark", dark).apply()
            }
            AnimatedContent(
                targetState = tab,
                modifier = Modifier.weight(1f),
                transitionSpec = {
                    val dir = if (targetState > initialState) 1 else -1
                    (slideInHorizontally(tween(450, easing = FastOutSlowInEasing)) { w -> w * dir / 3 } +
                        fadeIn(tween(450))) togetherWith
                        (slideOutHorizontally(tween(350, easing = FastOutSlowInEasing)) { w -> -w * dir / 3 } +
                            fadeOut(tween(250)))
                },
                label = "tabs"
            ) { t ->
                if (t == 0) OverviewScreen(cleaner) else ProcessScreen()
            }
            BottomBar(tab) { tab = it }
        }
    }
}

@Composable
private fun ThemeToggle(dark: Boolean, onToggle: () -> Unit) {
    val p = LocalPal.current
    val rot by animateFloatAsState(if (dark) 0f else 180f, tween(600, easing = FastOutSlowInEasing), label = "rot")
    val shape = CutShape(8f)
    Row(
        Modifier.pressScale(onToggle).clip(shape).border(1.5.dp, p.line, shape)
            .padding(horizontal = 12.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        T("◐", p.hi, 18, FontWeight.Bold, Modifier.graphicsLayer { rotationZ = rot })
        Spacer(Modifier.width(8.dp))
        AnimatedContent(
            targetState = dark,
            transitionSpec = { fadeIn(tween(300)) togetherWith fadeOut(tween(200)) },
            label = "mode"
        ) { d -> T(if (d) "TỐI" else "SÁNG", p.text, 13, FontWeight.Bold, spacing = 1) }
    }
}

@Composable
private fun Header(dark: Boolean, onToggle: () -> Unit) {
    val p = LocalPal.current
    val inf = rememberInfiniteTransition(label = "glitch")
    val g by inf.animateFloat(
        initialValue = 0f, targetValue = 0f,
        animationSpec = infiniteRepeatable(
            keyframes<Float> {
                durationMillis = 3800
                0f at 0
                0f at 3300
                1f at 3360
                -1f at 3440
                0.6f at 3520
                0f at 3600
            }
        ),
        label = "g"
    )
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.weight(1f)) {
                if (dark) {
                    T("RAMC", p.c2, 36, FontWeight.Bold,
                        Modifier.graphicsLayer { translationX = -2.dp.toPx() - g * 6.dp.toPx() }, spacing = 3)
                    T("RAMC", p.c1, 36, FontWeight.Bold,
                        Modifier.graphicsLayer { translationX = 2.dp.toPx() + g * 6.dp.toPx() }, spacing = 3)
                } else {
                    T("RAMC", p.c2, 36, FontWeight.Bold,
                        Modifier.graphicsLayer { translationX = 2.dp.toPx() + g * 4.dp.toPx(); translationY = 2.dp.toPx() },
                        spacing = 3)
                }
                T("RAMC", p.hi, 36, FontWeight.Bold, spacing = 3)
            }
            ThemeToggle(dark, onToggle)
        }
        Spacer(Modifier.height(4.dp))
        T("// RAM CLEANER · ${Build.MODEL.uppercase()}", p.muted, 11, spacing = 1)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Tag("ANDROID ${Build.VERSION.RELEASE} · API ${Build.VERSION.SDK_INT}", p.c1)
            Tag("V7", p.c2)
        }
    }
}

// ───────────── Thanh điều hướng hình viên thuốc ─────────────

/** Biểu tượng viên thuốc: nửa trái đặc, nửa phải viền, nghiêng 45 độ. */
@Composable
private fun PillIcon(color: Color) {
    Canvas(Modifier.size(26.dp)) {
        val w = size.width
        val ch = w * 0.46f
        val top = (w - ch) / 2f
        val r = CornerRadius(ch / 2f, ch / 2f)
        rotate(-45f) {
            val left = Path().apply {
                addRoundRect(RoundRect(0f, top, w / 2f, top + ch, r, CornerRadius.Zero, CornerRadius.Zero, r))
            }
            drawPath(left, color)
            drawRoundRect(color, topLeft = Offset(0f, top), size = Size(w, ch), cornerRadius = r, style = Stroke(3f))
            drawLine(color, Offset(w / 2f, top), Offset(w / 2f, top + ch), 3f)
        }
    }
}

@Composable
private fun TabItem(label: String, on: Boolean, pill: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val p = LocalPal.current
    val fg by animateColorAsState(if (on) p.onAccent else p.muted, tween(300), label = "tabFg")
    val scale by animateFloatAsState(
        if (on) 1.1f else 1f, spring(dampingRatio = 0.5f, stiffness = 400f), label = "tabScale"
    )
    Row(
        modifier.fillMaxHeight().clickable(
            interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick
        ),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Box(Modifier.graphicsLayer { scaleX = scale; scaleY = scale }) {
            if (pill) PillIcon(fg) else T("ϟ", fg, 22, FontWeight.Bold)
        }
        Spacer(Modifier.width(8.dp))
        T(label, fg, 12, FontWeight.Bold, spacing = 1)
    }
}

@Composable
private fun BottomBar(selected: Int, onSelect: (Int) -> Unit) {
    val p = LocalPal.current
    val pillShape = RoundedCornerShape(50)
    val frac by animateFloatAsState(
        selected.toFloat(), spring(dampingRatio = 0.65f, stiffness = 320f), label = "tabFrac"
    )
    val inf = rememberInfiniteTransition(label = "bar-inf")
    val glow by inf.animateFloat(
        0.1f, 0.45f, infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "barGlow"
    )
    Box(Modifier.enter(3).fillMaxWidth().padding(horizontal = 28.dp, vertical = 12.dp)) {
        Box(
            Modifier.fillMaxWidth().height(62.dp)
                .drawBehind {
                    drawRoundRect(
                        p.hi.copy(alpha = glow), cornerRadius = CornerRadius(size.height / 2f), style = Stroke(10f)
                    )
                }
                .clip(pillShape).background(p.panel).border(2.dp, p.line, pillShape)
        ) {
            BoxWithConstraints(Modifier.fillMaxSize().padding(5.dp)) {
                val half = maxWidth / 2
                Box(
                    Modifier.offset(x = half * frac).width(half).fillMaxHeight()
                        .clip(pillShape).background(p.accent)
                )
                Row(Modifier.fillMaxSize()) {
                    TabItem("TỔNG QUAN", selected == 0, false, Modifier.weight(1f)) { onSelect(0) }
                    TabItem("TIẾN TRÌNH", selected == 1, true, Modifier.weight(1f)) { onSelect(1) }
                }
            }
        }
    }
}

// ───────────── Tab Tổng quan ─────────────

@Composable
private fun OverviewScreen(cleaner: RamCleaner) {
    val p = LocalPal.current
    val scope = rememberCoroutineScope()
    var ram by remember { mutableStateOf(cleaner.readRam()) }
    var bd by remember { mutableStateOf(cleaner.readBreakdown()) }
    var cleaning by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<CleanResult?>(null) }
    val pageSize = remember { cleaner.pageSizeBytes() }

    LaunchedEffect(Unit) {
        while (true) {
            ram = cleaner.readRam(); bd = cleaner.readBreakdown(); delay(2000)
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Panel("TRẠNG THÁI RAM", 0) {
            Gauge(ram)
            Spacer(Modifier.height(12.dp))
            T("PAGE SIZE: $pageSize BYTES", p.muted, 11, modifier = Modifier.fillMaxWidth(),
                align = TextAlign.Center, spacing = 1)
            Spacer(Modifier.height(16.dp))
            NeonButton(if (cleaning) "ĐANG DỌN" else "ϟ  TĂNG TỐC RAM NGAY", cleaning) {
                scope.launch {
                    cleaning = true
                    result = cleaner.clean()
                    ram = cleaner.readRam()
                    cleaning = false
                }
            }
            AnimatedVisibility(
                visible = result != null,
                enter = fadeIn(tween(400)) + expandVertically(tween(400))
            ) {
                val r = result
                if (r != null) {
                    var tgt by remember { mutableIntStateOf(0) }
                    LaunchedEffect(r) { tgt = r.freedBytes.toMb().toInt() }
                    val shown by animateIntAsState(tgt, tween(900, easing = FastOutSlowInEasing), label = "freed")
                    Column {
                        Spacer(Modifier.height(14.dp))
                        T("ĐÃ DỪNG ${r.appsTargeted} ỨNG DỤNG NỀN\nGIẢI PHÓNG $shown MB",
                            p.c5, 13, FontWeight.Bold, Modifier.fillMaxWidth(), TextAlign.Center)
                    }
                }
            }
        }

        Panel("PHÂN BỔ BỘ NHỚ", 1) {
            T("${ram.usedBytes.toMb()} / ${ram.totalBytes.toMb()} MB", p.muted, 12)
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth().height(14.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                Seg(bd.appsMb, p.c1); Seg(bd.cachedMb, p.c4); Seg(bd.kernelMb, p.c3); Seg(bd.freeMb, p.c5)
            }
            Spacer(Modifier.height(16.dp))
            Row {
                Legend("ỨNG DỤNG", bd.appsMb, p.c1, Modifier.weight(1f))
                Legend("ĐỆM", bd.cachedMb, p.c4, Modifier.weight(1f))
            }
            Spacer(Modifier.height(10.dp))
            Row {
                Legend("KERNEL", bd.kernelMb, p.c3, Modifier.weight(1f))
                Legend("TRỐNG", bd.freeMb, p.c5, Modifier.weight(1f))
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun RowScope.Seg(value: Long, color: Color) {
    val w by animateFloatAsState(
        maxOf(value, 1L).toFloat(), tween(900, easing = FastOutSlowInEasing), label = "seg"
    )
    Box(Modifier.weight(w).fillMaxHeight().background(color))
}

@Composable
private fun Legend(name: String, mb: Long, color: Color, modifier: Modifier) {
    val p = LocalPal.current
    val shown by animateIntAsState(mb.toInt(), tween(900, easing = FastOutSlowInEasing), label = "legend")
    Column(modifier) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(10.dp).background(color))
            Spacer(Modifier.width(8.dp))
            T(name, p.muted, 11, spacing = 1)
        }
        T("$shown MB", color, 15, FontWeight.Bold, Modifier.padding(start = 18.dp))
    }
}

@Composable
private fun Gauge(ram: RamInfo) {
    val p = LocalPal.current
    var target by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(ram.usedPercent) { target = ram.usedPercent }
    val prog by animateFloatAsState(target, tween(1200, easing = FastOutSlowInEasing), label = "gauge")
    val pct by animateIntAsState((target * 100).toInt(), tween(1200, easing = FastOutSlowInEasing), label = "pct")
    val ring by animateColorAsState(
        when {
            target < 0.6f -> p.c1
            target < 0.8f -> p.hi
            else -> p.c2
        },
        tween(600), label = "ring"
    )
    val inf = rememberInfiniteTransition(label = "gauge-inf")
    val glow by inf.animateFloat(
        0.12f, 0.42f, infiniteRepeatable(tween(1500, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "glow"
    )
    val spin by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(30000, easing = LinearEasing)), label = "spin")

    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        Box(Modifier.size(250.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                rotate(spin) {
                    drawCircle(
                        p.line.copy(alpha = 0.6f), radius = size.minDimension / 2f - 3f,
                        style = Stroke(2f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 16f)))
                    )
                }
            }
            Canvas(Modifier.fillMaxSize().padding(16.dp)) {
                val w = 24f
                drawArc(p.line.copy(alpha = 0.35f), 135f, 270f, false, style = Stroke(w))
                drawArc(ring.copy(alpha = glow), 135f, 270f * prog, false, style = Stroke(w + 14f))
                drawArc(ring, 135f, 270f * prog, false, style = Stroke(w))
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Row(verticalAlignment = Alignment.Bottom) {
                    T("$pct", p.text, 56, FontWeight.Bold)
                    T("%", p.c2, 22, FontWeight.Bold, Modifier.padding(bottom = 10.dp))
                }
                val gb = 1024.0 * 1024 * 1024
                T("%.1f / %.1f GB".format(ram.usedBytes / gb, ram.totalBytes / gb), p.c1, 14, FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                T("TRỐNG %.1f GB".format(ram.availBytes / gb), p.hi, 13)
            }
        }
    }
}

// ───────────── Tab Tiến trình (pm trim-caches) ─────────────

private fun gbText(bytes: Long) = "%.1f GB".format(bytes / 1024.0 / 1024 / 1024)

private fun unitBytes(unit: String): Double = if (unit == "GB") 1024.0 * 1024 * 1024 else 1024.0 * 1024

private fun fmtAmount(v: Double, unit: String): String = when {
    unit == "MB" -> v.roundToLong().toString()
    v % 1.0 == 0.0 -> v.toLong().toString()
    else -> "%.1f".format(Locale.US, v)
}

@Composable
private fun ProcessScreen() {
    val p = LocalPal.current
    val scope = rememberCoroutineScope()
    var unit by remember { mutableStateOf("GB") }
    var text by remember { mutableStateOf("5") }
    var all by remember { mutableStateOf(false) }
    var running by remember { mutableStateOf(false) }
    var granted by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var free by remember { mutableLongStateOf(Storage.freeBytes()) }
    var report by remember { mutableStateOf<String?>(null) }
    var reportOk by remember { mutableStateOf(true) }
    val total = remember { Storage.totalBytes() }

    LaunchedEffect(Unit) {
        while (true) {
            running = ShizukuHelper.isRunning()
            granted = running && ShizukuHelper.hasPermission()
            if (!busy) free = Storage.freeBytes()
            delay(1000)
        }
    }

    val ub = unitBytes(unit)
    val maxUnits = total / ub
    val amount = (text.replace(',', '.').toDoubleOrNull() ?: 0.0).coerceIn(0.0, maxUnits)
    val amountBytes = (amount * ub).toLong()
    val mb = 1024L * 1024
    val desiredFreeMb = if (all) total / mb else (free + amountBytes) / mb
    val command = "pm trim-caches ${desiredFreeMb}M"

    fun switchUnit(new: String) {
        if (new == unit) return
        val bytes = amount * ub
        unit = new
        text = fmtAmount(bytes / unitBytes(new), new)
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Panel("DỌN BỘ NHỚ ĐỆM", 0) {
            Row(verticalAlignment = Alignment.Top) {
                val iconShape = CutShape(8f)
                Box(
                    Modifier.size(52.dp).clip(iconShape).background(p.panel2).border(1.5.dp, p.c4, iconShape),
                    contentAlignment = Alignment.Center
                ) { T("▤", p.c4, 26) }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    T("DỌN CACHE ỨNG DỤNG", p.text, 15, FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                    T("Xóa cache của app hệ thống và bên thứ ba để lấy lại dung lượng lưu trữ.", p.muted, 12)
                }
            }
            Spacer(Modifier.height(14.dp))
            val (label, color) = when {
                !running -> "SHIZUKU CHƯA CHẠY" to p.c2
                !granted -> "CHƯA CẤP QUYỀN SHIZUKU" to p.c4
                else -> "SHIZUKU SẴN SÀNG" to p.c5
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                PulseDot(color)
                Spacer(Modifier.width(8.dp))
                T(label, color, 12, FontWeight.Bold, spacing = 1)
            }
        }

        Panel("SỐ LƯỢNG CẦN DỌN", 1) {
            Row {
                T("BỘ NHỚ ĐÃ DÙNG", p.muted, 12, modifier = Modifier.weight(1f))
                T("${gbText(total - free)} / ${gbText(total)}", p.c1, 12, FontWeight.Bold)
            }
            Spacer(Modifier.height(8.dp))
            UsageBar(if (total > 0) (total - free).toFloat() / total else 0f, p.c4)
            Spacer(Modifier.height(16.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                val boxShape = CutShape(10f)
                val borderColor by animateColorAsState(if (all) p.line else p.hi, tween(300), label = "inBr")
                Box(
                    Modifier.weight(1f).clip(boxShape).background(p.panel2)
                        .border(1.5.dp, borderColor, boxShape)
                        .padding(horizontal = 14.dp, vertical = 12.dp)
                ) {
                    BasicTextField(
                        value = if (all) "TẤT CẢ" else text,
                        onValueChange = { v ->
                            if (v.length <= 9 && v.all { it.isDigit() || it == '.' || it == ',' }) {
                                val n = v.replace(',', '.').toDoubleOrNull()
                                text = if (n != null && n > maxUnits) fmtAmount(maxUnits, unit) else v
                            }
                        },
                        enabled = !all,
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        textStyle = TextStyle(
                            color = if (all) p.muted else p.hi, fontSize = 22.sp,
                            fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace
                        ),
                        cursorBrush = SolidColor(p.hi),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                Spacer(Modifier.width(10.dp))
                Chip("GB", unit == "GB", { switchUnit("GB") })
                Spacer(Modifier.width(6.dp))
                Chip("MB", unit == "MB", { switchUnit("MB") })
            }

            Spacer(Modifier.height(8.dp))
            Slider(
                value = amount.toFloat().coerceIn(0f, maxUnits.toFloat()),
                onValueChange = { text = fmtAmount(it.toDouble(), unit) },
                valueRange = 0f..maxUnits.toFloat(),
                enabled = !all,
                colors = SliderDefaults.colors(
                    thumbColor = p.accent, activeTrackColor = p.accent,
                    inactiveTrackColor = p.line.copy(alpha = 0.35f),
                    disabledThumbColor = p.muted, disabledActiveTrackColor = p.muted.copy(alpha = 0.5f),
                    disabledInactiveTrackColor = p.line.copy(alpha = 0.25f)
                )
            )
            Row {
                T("0", p.muted, 11, modifier = Modifier.weight(1f))
                T("${fmtAmount(maxUnits, unit)} $unit", p.muted, 11)
            }

            Spacer(Modifier.height(12.dp))
            Chip("DỌN TẤT CẢ CACHE", all, { all = !all })

            Spacer(Modifier.height(16.dp))
            val cmdShape = CutShape(8f)
            Box(
                Modifier.fillMaxWidth().clip(cmdShape).background(p.panel2)
                    .border(1.dp, p.line, cmdShape).padding(12.dp)
            ) {
                AnimatedContent(
                    targetState = command,
                    transitionSpec = { fadeIn(tween(200)) togetherWith fadeOut(tween(120)) },
                    label = "cmd"
                ) { c -> T("$ $c", p.c1, 13, FontWeight.Bold) }
            }

            Spacer(Modifier.height(16.dp))
            NeonButton(
                when {
                    busy -> "ĐANG DỌN"
                    running && !granted -> "CẤP QUYỀN SHIZUKU"
                    else -> "DỌN BỘ NHỚ ĐỆM"
                },
                busy
            ) {
                when {
                    !all && amountBytes <= 0L -> {
                        reportOk = false
                        report = "Nhập số lượng lớn hơn 0 hoặc bật Dọn tất cả cache."
                    }
                    !running -> {
                        reportOk = false
                        report = "Shizuku chưa chạy. Mở ứng dụng Shizuku và khởi động dịch vụ (gỡ lỗi không dây hoặc root), rồi quay lại đây."
                    }
                    !granted -> ShizukuHelper.requestPermission()
                    else -> scope.launch {
                        busy = true
                        val before = Storage.freeBytes()
                        val (code, out) = ShizukuHelper.exec(command)
                        delay(500)
                        val after = Storage.freeBytes()
                        free = after
                        reportOk = code == 0
                        report = if (code == 0)
                            "GIẢI PHÓNG ${gbText((after - before).coerceAtLeast(0))}\nTRỐNG: ${gbText(before)} → ${gbText(after)}"
                        else "LỖI ($code): $out"
                        busy = false
                    }
                }
            }
            AnimatedVisibility(
                visible = report != null,
                enter = fadeIn(tween(350)) + expandVertically(tween(350))
            ) {
                Column {
                    Spacer(Modifier.height(14.dp))
                    T(report ?: "", if (reportOk) p.c5 else p.c2, 13, FontWeight.Bold,
                        Modifier.fillMaxWidth(), TextAlign.Center)
                }
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}
